#include "wren_memory.h"
#include "wren_catalog.h"
#include "wren_ai.h"
#include "wren_shipping.h"
#include "wren_security.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <unistd.h>

#define THREADS 4
#define PRODUCTS_PER_THREAD 10
#define AI_REQUESTS_PER_THREAD 5

MemoryPool pool;
ProductCatalog catalog;
AIRequestQueue aiq;

/* --------------------
 * Memory Thread
 * -------------------- */
void* memory_task(void* arg) {
    for (int i = 0; i < 50; i++) {
        void* blk = wren_pool_alloc(&pool, 64);
        if (blk) {
            usleep(500);
            wren_pool_free(&pool, blk);
        }
    }
    return NULL;
}

/* --------------------
 * Catalog Thread
 * -------------------- */
void* catalog_task(void* arg) {
    int tid = *(int*)arg;
    for (int i = 0; i < PRODUCTS_PER_THREAD; i++) {
        char name[64];
        snprintf(name, sizeof(name), "Shoe-%d-%d", tid, i);
        Naira price = { .kobo = 1000 + i };
        add_product(&catalog, tid * 100 + i, name, price, "sneaker");

        ProductNode* node = wren_catalog_find(&catalog, tid * 100 + i);
        assert(node != NULL);
    }
    return NULL;
}

/* --------------------
 * AI Thread
 * -------------------- */
void* ai_task(void* arg) {
    int tid = *(int*)arg;
    for (int i = 0; i < AI_REQUESTS_PER_THREAD; i++) {
        char prompt[128];
        snprintf(prompt, sizeof(prompt), "Design shoe %d-%d", tid, i);
        int id = enqueue_ai_request(&aiq, prompt, "casual", "blue");
        assert(id > 0);
        AIRequest* req = dequeue_ai_request(&aiq);
        assert(req != NULL);
    }
    return NULL;
}

/* --------------------
 * Shipping + Security Test
 * -------------------- */
void compound_shipping_security_test(void) {
    NigerianAddress addr = {
        .house_number = "12B",
        .street = "Victoria Island Rd",
        .area = "Victoria Island",
        .landmark = "Opposite Eko Hotel",
        .city = "Lagos",
        .state = "Lagos State",
        .postal_code = "101001"
    };

    ShippingInfo* shipping = wren_shipping_create(SHIPPING_EXPRESS, &addr);
    assert(shipping != NULL);
    wren_shipping_print(shipping);

    TransactionHeader trans = {
        .method = PAYMENT_CARD,
        .amount = { .kobo = 250000 }, // 2500 naira
        .timestamp = time(NULL)
    };
    strncpy(trans.transaction_id, shipping->tracking_id, sizeof(trans.transaction_id) - 1);

    wren_sign_transaction(&trans, "supersecretkey");
    assert(wren_verify_transaction_signature(&trans, "supersecretkey"));

    wren_shipping_free(shipping);
}

/* --------------------
 * Main Compound Test
 * -------------------- */
int main(void) {
    printf("=== WREN Compound Test ===\n");

    /* Memory Pool */
    wren_pool_init(&pool);

    /* Catalog */
    wren_catalog_init(&catalog);

    /* AI Queue */
    wren_ai_queue_init(&aiq, THREADS);

    /* Launch Threads */
    pthread_t mem_threads[THREADS];
    pthread_t cat_threads[THREADS];
    pthread_t ai_threads[THREADS];
    int tids[THREADS];
    for (int i = 0; i < THREADS; i++) {
        tids[i] = i;
        pthread_create(&mem_threads[i], NULL, memory_task, NULL);
        pthread_create(&cat_threads[i], NULL, catalog_task, &tids[i]);
        pthread_create(&ai_threads[i], NULL, ai_task, &tids[i]);
    }

    for (int i = 0; i < THREADS; i++) {
        pthread_join(mem_threads[i], NULL);
        pthread_join(cat_threads[i], NULL);
        pthread_join(ai_threads[i], NULL);
    }

    /* Shipping + Security Test */
    compound_shipping_security_test();

    /* Cleanup */
    wren_ai_queue_shutdown(&aiq);

    printf("=== Compound test passed ===\n");
    return 0;
}
