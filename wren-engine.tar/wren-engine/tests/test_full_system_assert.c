#include "wren_memory.h"
#include "wren_catalog.h"
#include "wren_shipping.h"
#include "wren_ai.h"
#include "wren_localization.h"

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#include <time.h>
#include <stdarg.h>

#define NUM_THREADS 16
#define NUM_ITERATIONS 50

typedef struct {
    int thread_id;
    MemoryPool* pool;
    ProductCatalog* catalog;
    AIRequestQueue* ai_queue;
    NigerianAddress addr;
} ThreadArg;

/* =========================
 * Thread-safe logging
 * ========================= */
pthread_mutex_t log_lock = PTHREAD_MUTEX_INITIALIZER;

static void log_debug_fmt(int thread_id, const char* fmt, ...) {
    pthread_mutex_lock(&log_lock);
    printf("[Thread %02d] ", thread_id);
    va_list args;
    va_start(args, fmt);
    vprintf(fmt, args);
    va_end(args);
    printf("\n");
    pthread_mutex_unlock(&log_lock);
}

/* Random sleep to simulate workload */
static void random_sleep() {
    usleep(1000 + (rand() % 5000)); // 1ms to 5ms
}

/* =========================
 * Stress thread routine with assertions
 * ========================= */
void* stress_thread(void* arg) {
    ThreadArg* t = (ThreadArg*)arg;

    for (int i = 0; i < NUM_ITERATIONS; ++i) {
        int op = rand() % 5;

        switch (op) {
            case 0: { // Memory pool alloc/free
                void* block = wren_pool_alloc(t->pool, 64);
                if (!block) {
                    log_debug_fmt(t->thread_id, "Memory pool exhausted!");
                    assert(block != NULL); // FAIL if pool exhausted
                }
                random_sleep();
                wren_pool_free(t->pool, block);
                break;
            }
            case 1: { // Add product
                char name[64];
                snprintf(name, sizeof(name), "Product-%d-%d", t->thread_id, rand() % 1000);
                int product_id = rand() % 10000;
                add_product(t->catalog, product_id, name, (Naira){.kobo = rand() % 10000}, "sneaker");
                log_debug_fmt(t->thread_id, "Added product id=%d name=%s", product_id, name);
                assert(t->catalog->count > 0); // FAIL if catalog not updated
                random_sleep();
                break;
            }
            case 2: { // Find product
                int product_id = rand() % 10000;
                ProductNode* p = wren_catalog_find(t->catalog, product_id);
                if (p) {
                    assert(p->id == product_id); // sanity check
                    log_debug_fmt(t->thread_id, "Found product id=%d", product_id);
                }
                random_sleep();
                break;
            }
            case 3: { // Shipping creation
                ShippingInfo* ship = wren_shipping_create(SHIPPING_EXPRESS, &t->addr);
                assert(ship != NULL); // FAIL immediately if shipping creation failed
                log_debug_fmt(t->thread_id, "Shipping created tracking_id=%s", ship->tracking_id);
                random_sleep();
                wren_shipping_free(ship);
                break;
            }
            case 4: { // AI request enqueue
                int req_id = enqueue_ai_request(t->ai_queue, "Stress image", "formal", "blue");
                assert(req_id >= 0); // FAIL immediately if enqueue failed
                log_debug_fmt(t->thread_id, "AI request enqueued id=%d", req_id);
                random_sleep();
                break;
            }
        }
    }
    return NULL;
}

/* =========================
 * Main stress test
 * ========================= */
int main(void) {
    printf("=== WREN Full-System Concurrency Validator ===\n");

    srand((unsigned int)time(NULL));

    MemoryPool pool;
    wren_pool_init(&pool);

    ProductCatalog catalog;
    wren_catalog_init(&catalog);

    AIRequestQueue ai_queue;
    wren_ai_queue_init(&ai_queue, NUM_THREADS);

    NigerianAddress addr = {
        .house_number = "12B",
        .street = "Victoria Island Rd",
        .area = "Victoria Island",
        .landmark = "Opposite Eko Hotel",
        .city = "Lagos",
        .state = "Lagos State",
        .postal_code = "101001"
    };

    pthread_t threads[NUM_THREADS];
    ThreadArg args[NUM_THREADS];

    for (int i = 0; i < NUM_THREADS; ++i) {
        args[i].thread_id = i + 1;
        args[i].pool = &pool;
        args[i].catalog = &catalog;
        args[i].ai_queue = &ai_queue;
        args[i].addr = addr;

        int rc = pthread_create(&threads[i], NULL, stress_thread, &args[i]);
        assert(rc == 0); // FAIL if thread creation fails
    }

    for (int i = 0; i < NUM_THREADS; ++i) {
        pthread_join(threads[i], NULL);
    }

    printf("\n=== Summary ===\n");
    printf("Memory allocations: %zu, frees: %zu\n", pool.allocations, pool.frees);
    printf("Catalog count: %d\n", catalog.count);
    printf("AI queue current requests: %d\n", ai_queue.current_requests);

    wren_ai_queue_shutdown(&ai_queue);

    

    printf("=== All assertions passed. System is concurrency-safe ===\n");
    return 0;
}
