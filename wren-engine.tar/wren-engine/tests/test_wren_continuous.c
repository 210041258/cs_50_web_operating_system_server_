#include "wren_memory.h"
#include "wren_catalog.h"
#include "wren_shipping.h"
#include "wren_ai.h"
#include "wren_localization.h"
#include "wren_security.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <time.h>
#include <stdint.h>
#include <stdarg.h>
#include <unistd.h>

#define NUM_THREADS 16
#define LOOP_DURATION_SEC 30  // Run stress for 30 seconds per test

typedef struct {
    int thread_id;
    MemoryPool* pool;
    ProductCatalog* catalog;
    AIRequestQueue* ai_queue;
    NigerianAddress addr;
} ThreadArg;

/* =========================
 * Thread-safe logging with timestamps
 * ========================= */
pthread_mutex_t log_lock = PTHREAD_MUTEX_INITIALIZER;
static void log_debug(int thread_id, const char* fmt, ...) {
    pthread_mutex_lock(&log_lock);
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    printf("[%ld.%03ld][Thread %02d] ", ts.tv_sec, ts.tv_nsec/1000000, thread_id);
    va_list args;
    va_start(args, fmt);
    vprintf(fmt, args);
    va_end(args);
    printf("\n");
    pthread_mutex_unlock(&log_lock);
}

/* =========================
 * Random micro-sleep
 * ========================= */
static void random_sleep() {
    usleep(500 + (rand() % 5000)); // 0.5ms–5ms
}

/* =========================
 * Continuous Stress Thread
 * ========================= */
void* stress_thread(void* arg) {
    ThreadArg* t = (ThreadArg*)arg;
    time_t start = time(NULL);

    while (time(NULL) - start < LOOP_DURATION_SEC) {
        int op = rand() % 6;

        switch (op) {
            case 0: { // Memory pool alloc/free
                void* block = wren_pool_alloc(t->pool, 64);
                if (block) wren_pool_free(t->pool, block);
                break;
            }
            case 1: { // Catalog add
                char name[64];
                snprintf(name, sizeof(name), "Prod-%d-%d", t->thread_id, rand() % 10000);
                int pid = rand() % 100000;
                add_product(t->catalog, pid, name, (Naira){.kobo=rand()%10000}, "sneaker");
                break;
            }
            case 2: { // Catalog find/remove
                int pid = rand() % 100000;
                ProductNode* p = wren_catalog_find(t->catalog, pid);
                if (p && (rand() % 10 == 0)) wren_catalog_remove(t->catalog, pid);
                break;
            }
            case 3: { // Shipping creation
                ShippingInfo* s = wren_shipping_create(SHIPPING_EXPRESS, &t->addr);
                if (s) wren_shipping_free(s);
                break;
            }
            case 4: { // AI enqueue/dequeue
                int req_id = enqueue_ai_request(t->ai_queue, "Continuous image", "casual", "red");
                AIRequest* r = dequeue_ai_request(t->ai_queue);
                if (r) {
                    free(r->generated_image);
                    free(r);
                }
                break;
            }
            case 5: { // Transaction HMAC
                TransactionHeader trans;
                memset(&trans, 0, sizeof(trans));
                snprintf(trans.transaction_id, sizeof(trans.transaction_id), "TX-%d-%d", t->thread_id, rand()%100000);
                trans.amount.kobo = rand() % 50000 + 100;
                const char* key = "supersecret";
                unsigned char hmac[32];
                wren_sign_transaction(&trans, key, hmac, sizeof(hmac));
                assert(wren_verify_transaction_signature(&trans, key, hmac, sizeof(hmac)));
                break;
            }
        }
        random_sleep();
    }
    log_debug(t->thread_id, "Thread finished stress cycle.");
    return NULL;
}

/* =========================
 * Main Continuous Test
 * ========================= */
int main(void) {
    printf("=== WREN Engine Continuous Stress Test ===\n");
    srand((unsigned int)time(NULL));

    /* Initialize modules */
    MemoryPool pool;
    wren_pool_init(&pool);

    ProductCatalog catalog;
    wren_catalog_init(&catalog);

    AIRequestQueue ai_queue;
    wren_ai_queue_init(&ai_queue, NUM_THREADS);

    NigerianAddress addr = {
        .house_number = "12B",
        .street = "Victoria Island Rd",
        .area = "Victoria Island",
        .landmark = "Opposite Eko Hotel",
        .city = "Lagos",
        .state = "Lagos State",
        .postal_code = "101001"
    };

    /* Launch threads */
    pthread_t threads[NUM_THREADS];
    ThreadArg args[NUM_THREADS];

    for (int i = 0; i < NUM_THREADS; ++i) {
        args[i].thread_id = i + 1;
        args[i].pool = &pool;
        args[i].catalog = &catalog;
        args[i].ai_queue = &ai_queue;
        args[i].addr = addr;
        int rc = pthread_create(&threads[i], NULL, stress_thread, &args[i]);
        assert(rc == 0);
    }

    for (int i = 0; i < NUM_THREADS; ++i) {
        pthread_join(threads[i], NULL);
    }

    /* Summary */
    printf("\n=== Continuous Test Summary ===\n");
    printf("Memory allocations: %zu, frees: %zu\n", pool.allocations, pool.frees);
    printf("Catalog count: %d\n", catalog.count);
    printf("AI queue current requests: %d\n", ai_queue.current_requests);

    wren_ai_queue_shutdown(&ai_queue);

    printf("=== Continuous Stress Test Completed ===\n");
    return 0;
}
