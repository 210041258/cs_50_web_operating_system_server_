#include "wren_shipping.h"
#include "wren_localization.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <time.h>

#define NUM_THREADS 10

typedef struct {
    int thread_id;
    NigerianAddress addr;
} ThreadArg;

void* create_shipping_thread(void* arg) {
    ThreadArg* t = (ThreadArg*)arg;

    ShippingInfo* info = wren_shipping_create(SHIPPING_EXPRESS, &t->addr);
    assert(info != NULL);

    printf("[Thread %d] Created shipping: %s, Cost: %llu kobo\n",
           t->thread_id, info->tracking_id, info->shipping_cost.kobo);

    /* Simulate actual delivery assignment */
    info->actual_delivery = time(NULL);
    printf("[Thread %d] Actual delivery: %s", t->thread_id, ctime(&info->actual_delivery));

    wren_shipping_free(info);
    return NULL;
}

int main(void) {
    printf("=== WREN Concurrent Delivery Test ===\n");

    /* Base address for all threads */
    NigerianAddress base_addr = {
        .house_number = "12B",
        .street = "Victoria Island Rd",
        .area = "Victoria Island",
        .landmark = "Opposite Eko Hotel",
        .city = "Lagos",
        .state = "Lagos State",
        .postal_code = "101001"
    };

    pthread_t threads[NUM_THREADS];
    ThreadArg args[NUM_THREADS];

    for (int i = 0; i < NUM_THREADS; ++i) {
        args[i].thread_id = i + 1;
        args[i].addr = base_addr;

        if (pthread_create(&threads[i], NULL, create_shipping_thread, &args[i]) != 0) {
            perror("Failed to create thread");
            exit(EXIT_FAILURE);
        }
    }

    for (int i = 0; i < NUM_THREADS; ++i) {
        pthread_join(threads[i], NULL);
    }

    printf("=== Concurrent Delivery Test Passed ===\n");
    return 0;
}
