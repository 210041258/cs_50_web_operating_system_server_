#include "wren_memory.h"
#include "wren_catalog.h"
#include "wren_shipping.h"
#include "wren_ai.h"
#include "wren_localization.h"
#include "wren_security.h"
#include "wren_system.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <time.h>
#include <stdint.h>
#include <stdarg.h>
#include <unistd.h>

#define NUM_THREADS 16
#define LOOP_DURATION_SEC 30       // Test duration
#define METRICS_INTERVAL_MS 500    // Interval for logging metrics
#define NUM_PRODUCTS 50
#define NUM_AI_REQUESTS 20
#define NUM_SHIPMENTS 10

/* =========================
 * Thread-safe logging
 * ========================= */
pthread_mutex_t log_lock = PTHREAD_MUTEX_INITIALIZER;

static void log_debug(int thread_id, const char* fmt, ...) {
    pthread_mutex_lock(&log_lock);
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    printf("[%ld.%03ld][Thread %02d] ", ts.tv_sec, ts.tv_nsec/1000000, thread_id);
    va_list args;
    va_start(args, fmt);
    vprintf(fmt, args);
    va_end(args);
    printf("\n");
    pthread_mutex_unlock(&log_lock);
}

/* =========================
 * Thread pool for testing
 * ========================= */
typedef struct {
    pthread_t threads[NUM_THREADS];
    int num_threads;
    int active_threads;
    pthread_mutex_t lock;
} ThreadPool;

/* =========================
 * Thread arguments
 * ========================= */
typedef struct {
    int thread_id;
    MemoryPool* pool;
    ProductCatalog* catalog;
    AIRequestQueue* ai_queue;
    NigerianAddress addr;
    int shipping_count;
} ThreadArg;

typedef struct {
    MemoryPool* pool;
    ProductCatalog* catalog;
    AIRequestQueue* ai_queue;
    ThreadArg* threads;
    int num_threads;
    const char* csv_file;
    int stop;
} MetricsArg;

/* =========================
 * Global resources for thread pool test
 * ========================= */
static ThreadPool g_thread_pool;
static ShippingInfo* g_shipments[NUM_SHIPMENTS];

/* =========================
 * Random micro-sleep
 * ========================= */
static void random_sleep() {
    usleep(500 + (rand() % 5000));
}

/* =========================
 * Continuous stress thread
 * ========================= */
void* stress_thread(void* arg) {
    ThreadArg* t = (ThreadArg*)arg;
    time_t start = time(NULL);

    while (time(NULL) - start < LOOP_DURATION_SEC) {
        int op = rand() % 6;

        switch (op) {
            case 0: { // Memory pool alloc/free
                void* block = wren_pool_alloc(t->pool, 64);
                if (block) wren_pool_free(t->pool, block);
                break;
            }
            case 1: { // Catalog add
                char name[64];
                snprintf(name, sizeof(name), "Prod-%d-%d", t->thread_id, rand() % 10000);
                int pid = rand() % 100000;
                add_product(t->catalog, pid, name, (Naira){.kobo=rand()%10000}, "sneaker");
                break;
            }
            case 2: { // Catalog find/remove
                int pid = rand() % 100000;
                ProductNode* p = wren_catalog_find(t->catalog, pid);
                if (p && (rand() % 10 == 0)) wren_catalog_remove(t->catalog, pid);
                break;
            }
            case 3: { // Shipping creation
                ShippingInfo* s = wren_shipping_create(SHIPPING_EXPRESS, &t->addr);
                if (s) {
                    t->shipping_count++;
                    wren_shipping_free(s);
                }
                break;
            }
            case 4: { // AI enqueue/dequeue
                int req_id = enqueue_ai_request(t->ai_queue, "Continuous image", "casual", "red");
                AIRequest* r = dequeue_ai_request(t->ai_queue);
                if (r) {
                    free(r->generated_image);
                    free(r);
                }
                break;
            }
            case 5: { // Transaction HMAC
                TransactionHeader trans;
                memset(&trans, 0, sizeof(trans));
                snprintf(trans.transaction_id, sizeof(trans.transaction_id), "TX-%d-%d", t->thread_id, rand()%100000);
                trans.amount.kobo = rand() % 50000 + 100;
                const char* key = "supersecret";
                unsigned char hmac[32];
                wren_sign_transaction(&trans, key, hmac, sizeof(hmac));
                assert(wren_verify_transaction_signature(&trans, key, hmac, sizeof(hmac)));
                break;
            }
        }
        random_sleep();
    }

    log_debug(t->thread_id, "Thread finished stress cycle.");
    return NULL;
}

/* =========================
 * Thread pool task
 * ========================= */
void* thread_task(void* arg) {
    int id = *(int*)arg;
    pthread_mutex_lock(&g_thread_pool.lock);
    g_thread_pool.active_threads++;
    pthread_mutex_unlock(&g_thread_pool.lock);

    // Simulate memory alloc
    void* mem = wren_pool_alloc(&g_thread_pool.pool, 64);
    if (mem) {
        memset(mem, id, 64);
        usleep(1000);
        wren_pool_free(&g_thread_pool.pool, mem);
    }

    // Simulate AI request
    char prompt[128];
    snprintf(prompt, sizeof(prompt), "AI Test Prompt %d", id);
    enqueue_ai_request(&g_thread_pool.ai_queue, prompt, "casual", "blue");

    pthread_mutex_lock(&g_thread_pool.lock);
    g_thread_pool.active_threads--;
    pthread_mutex_unlock(&g_thread_pool.lock);
    return NULL;
}

/* =========================
 * Metrics logger for continuous test
 * ========================= */
void* metrics_logger(void* arg) {
    MetricsArg* m = (MetricsArg*)arg;
    FILE* f = fopen(m->csv_file, "w");
    if (!f) {
        perror("fopen metrics CSV");
        return NULL;
    }

    // Write CSV header
    fprintf(f, "timestamp,allocations,frees,catalog_count,ai_queue,shipping_count\n");
    fflush(f);

    while (!m->stop) {
        time_t now = time(NULL);
        size_t total_alloc = m->pool->allocations;
        size_t total_free = m->pool->frees;
        int catalog_count = m->catalog->count;
        int ai_req = m->ai_queue->current_requests;
        int shipping_total = 0;
        for (int i = 0; i < m->num_threads; ++i) {
            shipping_total += m->threads[i].shipping_count;
        }

        fprintf(f, "%ld,%zu,%zu,%d,%d,%d\n",
                now, total_alloc, total_free, catalog_count, ai_req, shipping_total);
        fflush(f);

        usleep(METRICS_INTERVAL_MS * 1000);
    }

    fclose(f);
    return NULL;
}

/* =========================
 * Metrics logger for thread pool test
 * ========================= */
void log_threadpool_metrics(FILE* f, MemoryPool* pool, ProductCatalog* catalog, 
                           AIRequestQueue* ai_queue, ThreadPool* thread_pool) {
    // Memory metrics
    size_t current_usage = pool->current_usage;
    size_t peak_usage = pool->peak_usage;

    // Catalog metrics
    int catalog_count = catalog->count;

    // AI queue metrics
    int ai_queue_size = 0;
    double total_latency = 0;
    int processed = 0;
    AIRequest* r = ai_queue->head;
    while (r) {
        ai_queue_size++;
        if (r->dequeue_time.tv_sec != 0) {
            double latency = (r->dequeue_time.tv_sec - r->enqueue_time.tv_sec) * 1000.0 +
                             (r->dequeue_time.tv_nsec - r->enqueue_time.tv_nsec) / 1e6;
            total_latency += latency;
            processed++;
        }
        r = r->next;
    }
    double avg_latency = processed ? total_latency / processed : 0.0;

    // Shipping metrics
    int shipments = 0;
    for (int i = 0; i < NUM_SHIPMENTS; i++)
        if (g_shipments[i]) shipments++;

    // Thread pool metrics
    int active, idle;
    pthread_mutex_lock(&thread_pool->lock);
    active = thread_pool->active_threads;
    idle = thread_pool->num_threads - active;
    pthread_mutex_unlock(&thread_pool->lock);

    // Timestamp
    time_t t = time(NULL);

    fprintf(f, "%ld,%zu,%zu,%d,%d,%.2f,%d,%d,%d\n",
            t, current_usage, peak_usage, catalog_count,
            ai_queue_size, avg_latency, shipments, active, idle);
    fflush(f);
}

/* =========================
 * Continuous Stress Test
 * ========================= */
void run_continuous_stress_test(void) {
    printf("=== WREN Engine Continuous Metrics Stress Test ===\n");
    srand((unsigned int)time(NULL));

    MemoryPool pool;
    wren_pool_init(&pool);

    ProductCatalog catalog;
    wren_catalog_init(&catalog);

    AIRequestQueue ai_queue;
    wren_ai_queue_init(&ai_queue, NUM_THREADS);

    NigerianAddress addr = {
        .house_number = "12B",
        .street = "Victoria Island Rd",
        .area = "Victoria Island",
        .landmark = "Opposite Eko Hotel",
        .city = "Lagos",
        .state = "Lagos State",
        .postal_code = "101001"
    };

    /* Launch stress threads */
    pthread_t threads[NUM_THREADS];
    ThreadArg args[NUM_THREADS];
    for (int i = 0; i < NUM_THREADS; ++i) {
        args[i].thread_id = i + 1;
        args[i].pool = &pool;
        args[i].catalog = &catalog;
        args[i].ai_queue = &ai_queue;
        args[i].addr = addr;
        args[i].shipping_count = 0;
        int rc = pthread_create(&threads[i], NULL, stress_thread, &args[i]);
        assert(rc == 0);
    }

    /* Launch metrics logger thread */
    pthread_t metrics_thread;
    MetricsArg m_arg = {
        .pool = &pool,
        .catalog = &catalog,
        .ai_queue = &ai_queue,
        .threads = args,
        .num_threads = NUM_THREADS,
        .csv_file = "wren_metrics_continuous.csv",
        .stop = 0
    };
    int rc = pthread_create(&metrics_thread, NULL, metrics_logger, &m_arg);
    assert(rc == 0);

    /* Wait for stress threads */
    for (int i = 0; i < NUM_THREADS; ++i) {
        pthread_join(threads[i], NULL);
    }

    /* Stop metrics logger */
    m_arg.stop = 1;
    pthread_join(metrics_thread, NULL);

    /* Summary */
    printf("\n=== Continuous Test Summary ===\n");
    printf("Memory allocations: %zu, frees: %zu\n", pool.allocations, pool.frees);
    printf("Catalog count: %d\n", catalog.count);
    printf("AI queue current requests: %d\n", ai_queue.current_requests);

    wren_ai_queue_shutdown(&ai_queue);
    printf("Metrics CSV saved to: wren_metrics_continuous.csv\n");
    printf("=== Continuous Test Completed ===\n");
}

/* =========================
 * Thread Pool Test
 * ========================= */
void run_threadpool_test(void) {
    printf("\n=== WREN Engine Thread Pool Test ===\n");
    
    // Initialize thread pool structure
    pthread_mutex_init(&g_thread_pool.lock, NULL);
    g_thread_pool.num_threads = NUM_THREADS;
    g_thread_pool.active_threads = 0;
    
    // Initialize resources
    wren_system_init();
    wren_pool_init(&g_thread_pool.pool);
    wren_catalog_init(&g_thread_pool.catalog);
    wren_ai_queue_init(&g_thread_pool.ai_queue, 5);

    FILE* log_file = fopen("wren_metrics_threadpool.csv", "w");
    fprintf(log_file, "timestamp,current_usage,peak_usage,catalog_count,ai_queue,avg_ai_latency_ms,shipments,active_threads,idle_threads\n");

    // Populate catalog
    for (int i = 0; i < NUM_PRODUCTS; i++) {
        char name[64];
        snprintf(name, sizeof(name), "Product %d", i);
        add_product(&g_thread_pool.catalog, i, name, (Naira){10000 + i * 100}, "sneaker");
    }

    // Create shipping entries
    for (int i = 0; i < NUM_SHIPMENTS; i++) {
        NigerianAddress addr = {"12", "Main St", "Ikeja", "", "Lagos", "Lagos State", "100001"};
        g_shipments[i] = wren_shipping_create(SHIPPING_STANDARD, &addr);
    }

    // Log initial metrics
    log_threadpool_metrics(log_file, &g_thread_pool.pool, &g_thread_pool.catalog, 
                          &g_thread_pool.ai_queue, &g_thread_pool);

    // Start worker threads
    int thread_ids[NUM_THREADS];
    for (int i = 0; i < NUM_THREADS; i++) {
        thread_ids[i] = i;
        pthread_create(&g_thread_pool.threads[i], NULL, thread_task, &thread_ids[i]);
    }

    // Wait for threads
    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(g_thread_pool.threads[i], NULL);
    }

    // Log final metrics
    log_threadpool_metrics(log_file, &g_thread_pool.pool, &g_thread_pool.catalog, 
                          &g_thread_pool.ai_queue, &g_thread_pool);

    // Cleanup
    for (int i = 0; i < NUM_SHIPMENTS; i++) {
        if (g_shipments[i]) free(g_shipments[i]);
    }
    wren_ai_queue_shutdown(&g_thread_pool.ai_queue);
    wren_system_shutdown();
    fclose(log_file);

    printf("\n=== Thread Pool Test Summary ===\n");
    printf("Test complete. Metrics written to wren_metrics_threadpool.csv\n");
    printf("Active threads at end: %d\n", g_thread_pool.active_threads);
    printf("=== Thread Pool Test Completed ===\n");
}

/* =========================
 * Main function
 * ========================= */
int main(void) {
    printf("=== WREN Engine Combined Test Suite ===\n\n");
    
    // Run continuous stress test
    run_continuous_stress_test();
    
    printf("\n" "----------------------------------------" "\n\n");
    
    // Run thread pool test
    run_threadpool_test();
    
    printf("\n=== All Tests Completed Successfully ===\n");
    return 0;
}