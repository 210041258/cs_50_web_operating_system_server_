#include "wren_shipping.h"
#include "wren_localization.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

int main(void) {
    printf("=== WREN Delivery Test ===\n");

    /* Setup addresses */
    NigerianAddress addr = {
        .house_number = "12B",
        .street = "Victoria Island Rd",
        .area = "Victoria Island",
        .landmark = "Opposite Eko Hotel",
        .city = "Lagos",
        .state = "Lagos State",
        .postal_code = "101001"
    };

    

    /* Test Standard Shipping */
    ShippingInfo* standard = wren_shipping_create(SHIPPING_STANDARD, &addr);
    assert(standard != NULL);
    printf("Standard Shipping Estimated Delivery: %s", ctime(&standard->estimated_delivery));
    assert(standard->shipping_cost.kobo == 0);
    assert(standard->method == SHIPPING_STANDARD);
    wren_shipping_free(standard);

    /* Test Express Shipping */
    ShippingInfo* express = wren_shipping_create(SHIPPING_EXPRESS, &addr);
    assert(express != NULL);
    printf("Express Shipping Estimated Delivery: %s", ctime(&express->estimated_delivery));
    assert(express->shipping_cost.kobo > 0);
    assert(express->method == SHIPPING_EXPRESS);

    /* Simulate Actual Delivery */
    express->actual_delivery = time(NULL);
    printf("Express Shipping Actual Delivery: %s", ctime(&express->actual_delivery));

    /* Test invalid address */
    NigerianAddress invalid = {0};
    ShippingInfo* fail = wren_shipping_create(SHIPPING_STANDARD, &invalid);
    assert(fail == NULL);



    wren_shipping_free(express);

    printf("=== Delivery Test Passed ===\n");
    return 0;
}
