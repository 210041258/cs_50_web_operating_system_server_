#include "wren_memory.h"
#include "wren_catalog.h"
#include "wren_shipping.h"
#include "wren_ai.h"
#include "wren_localization.h"

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <time.h>

#define NUM_THREADS 8
#define NUM_PRODUCTS 20

/* Thread argument */
typedef struct {
    int thread_id;
    MemoryPool* pool;
    ProductCatalog* catalog;
    AIRequestQueue* ai_queue;
    NigerianAddress addr;
} ThreadArg;

/* ========================
 * Thread routine
 * ======================== */
void* thread_routine(void* arg) {
    ThreadArg* t = (ThreadArg*)arg;

    /* --- Memory pool allocation --- */
    void* block = wren_pool_alloc(t->pool, 64);
    assert(block != NULL);

    /* --- Add product to catalog --- */
    char name[64];
    snprintf(name, sizeof(name), "Product-%d-%d", t->thread_id, rand() % 100);
    int product_id = rand() % 1000;
    add_product(t->catalog, product_id, name, (Naira){.kobo = (rand() % 10000)}, "sneaker");

    /* --- Find product in catalog --- */
    ProductNode* p = wren_catalog_find(t->catalog, product_id);
    assert(p != NULL);

    /* --- Create shipping --- */
    ShippingInfo* ship = wren_shipping_create(SHIPPING_EXPRESS, &t->addr);
    assert(ship != NULL);

    /* --- Enqueue AI request --- */
    int req_id = enqueue_ai_request(t->ai_queue, "Generate image", "casual", "red");
    assert(req_id >= 0);

    /* --- Cleanup --- */
    wren_pool_free(t->pool, block);
    wren_shipping_free(ship);

    return NULL;
}

/* ========================
 * Main test
 * ======================== */
int main(void) {
    printf("=== Full-System Concurrency Test ===\n");

    /* --- Initialize systems --- */
    MemoryPool pool;
    wren_pool_init(&pool);

    ProductCatalog catalog;
    wren_catalog_init(&catalog);

    AIRequestQueue ai_queue;
    wren_ai_queue_init(&ai_queue, NUM_THREADS);

    NigerianAddress addr = {
        .house_number = "12B",
        .street = "Victoria Island Rd",
        .area = "Victoria Island",
        .landmark = "Opposite Eko Hotel",
        .city = "Lagos",
        .state = "Lagos State",
        .postal_code = "101001"
    };

    /* --- Launch threads --- */
    pthread_t threads[NUM_THREADS];
    ThreadArg args[NUM_THREADS];

    for (int i = 0; i < NUM_THREADS; ++i) {
        args[i].thread_id = i + 1;
        args[i].pool = &pool;
        args[i].catalog = &catalog;
        args[i].ai_queue = &ai_queue;
        args[i].addr = addr;

        if (pthread_create(&threads[i], NULL, thread_routine, &args[i]) != 0) {
            perror("Failed to create thread");
            exit(EXIT_FAILURE);
        }
    }

    /* --- Wait for threads --- */
    for (int i = 0; i < NUM_THREADS; ++i) {
        pthread_join(threads[i], NULL);
    }

    printf("Memory allocations: %zu, frees: %zu\n", pool.allocations, pool.frees);
    printf("Catalog count: %d\n", catalog.count);
    printf("AI queue requests: %d\n", ai_queue.current_requests);

    /* --- Shutdown AI queue --- */
    wren_ai_queue_shutdown(&ai_queue);

    printf("=== Full-System Concurrency Test Passed ===\n");
    return 0;
}
