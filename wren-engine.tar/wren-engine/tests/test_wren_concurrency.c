#include "wren_memory.h"
#include "wren_catalog.h"
#include "wren_ai.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <unistd.h>

#define THREADS 8
#define ALLOCS_PER_THREAD 100

/* =========================
 * Memory Pool Thread Test
 * ========================= */
MemoryPool pool;

void* mem_thread(void* arg) {
    for (int i = 0; i < ALLOCS_PER_THREAD; i++) {
        void* blk = wren_pool_alloc(&pool, 64);
        if (!blk) {
            fprintf(stderr, "Memory allocation failed\n");
            continue;
        }
        usleep(1000); // simulate work
        wren_pool_free(&pool, blk);
    }

    return NULL;
}

/* =========================
 * Catalog Thread Test
 * ========================= */
ProductCatalog catalog;

void* catalog_thread(void* arg) {

    int tid = *(int*)arg;
    for (int i = 0; i < 50; i++) {
        Naira price = { .kobo = 1000 + i };
        add_product(&catalog, tid * 100 + i, "Shoe", price, "sneaker");
        ProductNode* node = wren_catalog_find(&catalog, tid * 100 + i);
        assert(node != NULL);
        if (i % 5 == 0) {
            wren_catalog_remove(&catalog, tid * 100 + i);
        }
    }
    return NULL;
}

/* =========================
 * AI Queue Thread Test
 * ========================= */
AIRequestQueue aiq;

void* ai_thread(void* arg) {
    int tid = *(int*)arg;
    for (int i = 0; i < 50; i++) {
        char prompt[64];
        snprintf(prompt, sizeof(prompt), "Design shoe %d-%d", tid, i);
        int id = enqueue_ai_request(&aiq, prompt, "casual", "red");
        assert(id > 0);
        AIRequest* req = dequeue_ai_request(&aiq);
        assert(req != NULL);
    }
    return NULL;
}

/* =========================
 * Main
 * ========================= */
int main(void) {
    printf("=== WREN Concurrency Tests ===\n");

    /* Memory Pool */
    wren_pool_init(&pool);

    pthread_t mem_threads[THREADS];
    for (int i = 0; i < THREADS; i++) {
        pthread_create(&mem_threads[i], NULL, mem_thread, NULL);
    }
    for (int i = 0; i < THREADS; i++) pthread_join(mem_threads[i], NULL);
    printf("Memory pool thread-safe test passed.\n");

    /* Catalog */
    wren_catalog_init(&catalog);
    int tids[THREADS];
    pthread_t cat_threads[THREADS];
    for (int i = 0; i < THREADS; i++) {
        tids[i] = i;
        pthread_create(&cat_threads[i], NULL, catalog_thread, &tids[i]);
    }
    for (int i = 0; i < THREADS; i++) pthread_join(cat_threads[i], NULL);
    printf("Catalog thread-safe add/find/remove test passed.\n");

    /* AI Queue */
    wren_ai_queue_init(&aiq, THREADS);

    pthread_t ai_threads[THREADS];
    for (int i = 0; i < THREADS; i++) {
        tids[i] = i;
        pthread_create(&ai_threads[i], NULL, ai_thread, &tids[i]);
    }
    for (int i = 0; i < THREADS; i++) pthread_join(ai_threads[i], NULL);

    wren_ai_queue_shutdown(&aiq);
    printf("AI queue concurrent enqueue/dequeue test passed.\n");

    printf("=== All concurrency tests passed ===\n");
    return 0;
}
