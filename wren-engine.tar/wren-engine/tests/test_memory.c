#include "wren_memory.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

int main() {
    MemoryPool pool;
    wren_pool_init(&pool);

    // Test 1: Initial state
    assert(pool.allocations == 0);
    assert(pool.frees == 0);
    assert(pool.free_top == WREN_POOL_BLOCK_COUNT - 1);
    printf("Pool initialized correctly.\n");

    // Test 2: Allocate a block
    void* block = wren_pool_alloc(&pool, 64);
    assert(block != NULL);
    assert(pool.allocations == 1);
    printf("Allocation successful.\n");

    // Test 3: Allocate maximum block size
    void* block2 = wren_pool_alloc(&pool, WREN_POOL_BLOCK_SIZE);
    assert(block2 != NULL);
    assert(pool.allocations == 2);
    printf("Max size allocation successful.\n");

    // Test 4: Free a block
    wren_pool_free(&pool, block);
    assert(pool.frees == 1);
    printf("Free successful.\n");

    // Test 5: Exhaust the pool
    for (int i = 0; i < WREN_POOL_BLOCK_COUNT - 2; i++) {
        void* b = wren_pool_alloc(&pool, 32);
        assert(b != NULL);
    }
    // Next allocation should fail
    void* fail = wren_pool_alloc(&pool, 32);
    assert(fail == NULL);
    printf("Pool exhaustion test passed.\n");

    // Test 6: Free everything
    for (int i = 0; i < WREN_POOL_BLOCK_COUNT - 1; i++) {
        wren_pool_free(&pool, pool.blocks[i]);
    }
    printf("All blocks freed.\n");
    
    assert(pool.frees == WREN_POOL_BLOCK_COUNT - 1);

    printf("=== All memory pool tests passed ===\n");
    return 0;
}

