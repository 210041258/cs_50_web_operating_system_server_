#include "wren_common.h"
#include "wren_memory.h"
#include "wren_catalog.h"
#include "wren_cache.h"
#include "wren_shipping.h"
#include "wren_ai.h"
#include "wren_system.h"
#include "wren_localization.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdbool.h>

/* =========================
 *  Helper for NigerianAddress
 * ========================= */
static NigerianAddress test_address(void) {
    NigerianAddress addr;
    strcpy(addr.house_number, "12B");
    strcpy(addr.street, "Awolowo Rd");
    strcpy(addr.area, "Ikoyi");
    strcpy(addr.landmark, "Near Shoprite");
    strcpy(addr.city, "Lagos");
    strcpy(addr.state, "Lagos State");
    strcpy(addr.postal_code, "100001");
    return addr;
}

/* =========================
 *  Main Test
 * ========================= */
int main(void) {
    printf("=== WREN Engine Full Test Suite ===\n");

    /* ---------------------------
     * System init / shutdown
     * --------------------------- */
    wren_system_init();
    wren_log_event("System init test", 0);

    /* ---------------------------
     * Memory pool tests
     * --------------------------- */
    MemoryPool pool;
    wren_pool_init(&pool);
    assert(pool.allocations == 0);
    void* blk = wren_pool_alloc(&pool, 64);
    assert(blk != NULL);
    wren_pool_free(&pool, blk);
    assert(pool.frees == 1);
    printf("Memory pool test passed.\n");

    /* ---------------------------
     * Catalog tests
     * --------------------------- */
    ProductCatalog catalog;
    wren_catalog_init(&catalog);
    Naira price = { .kobo = 10000 };
    add_product(&catalog, 1, "Sandal", price, "sandal");
    ProductNode* node = wren_catalog_find(&catalog, 1);
    assert(node != NULL && strcmp(node->name, "Sandal") == 0);
    assert(wren_catalog_remove(&catalog, 1) == true);
    printf("Catalog test passed.\n");

    /* ---------------------------
     * Cache tests
     * --------------------------- */
    LRUCache cache;
    wren_cache_init(&cache, 5);
    int val = 123;
    wren_cache_put(&cache, 1, &val);
    int* ret = (int*)wren_cache_get(&cache, 1);
    assert(ret != NULL && *ret == 123);
    printf("Cache test passed.\n");

    /* ---------------------------
     * Shipping tests
     * --------------------------- */
    NigerianAddress addr = test_address();
    ShippingInfo* ship = wren_shipping_create(SHIPPING_STANDARD, &addr);
    assert(ship != NULL);
    wren_shipping_print(ship);
    wren_shipping_free(ship);
    printf("Shipping test passed.\n");

    /* ---------------------------
     * AI queue tests
     * --------------------------- */
    AIRequestQueue aiq;
    wren_ai_queue_init(&aiq, 2);

    int req_id = enqueue_ai_request(&aiq, "Design shoe", "casual", "red");
    assert(req_id > 0);

    AIRequest* req = dequeue_ai_request(&aiq);
    assert(req != NULL && strcmp(req->prompt, "Design shoe") == 0);

    wren_ai_queue_shutdown(&aiq);
    printf("AI queue test passed.\n");

    /* ---------------------------
     * System shutdown
     * --------------------------- */
    wren_system_shutdown();

    
    printf("=== All WREN Engine tests passed ===\n");
    return 0;
}
