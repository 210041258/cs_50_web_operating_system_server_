#include "wren_catalog.h"
#include "wren_common.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

int main() {
    ProductCatalog catalog;
    wren_catalog_init(&catalog);

    // Test 1: Catalog initialized
    assert(catalog.count == 0);
    printf("Catalog initialized correctly.\n");

    // Test 2: Add products
    Naira price1 = { .kobo = 10000 }; // 100 naira
    Naira price2 = { .kobo = 5000 };  // 50 naira
    add_product(&catalog, 1, "Sandal", price1, "sandal");
    add_product(&catalog, 2, "Loafer", price2, "loafer");

    assert(catalog.count == 2);
    printf("Products added successfully.\n");

    // Test 3: Find product
    ProductNode* p = wren_catalog_find(&catalog, 1);
    assert(p != NULL && strcmp(p->name, "Sandal") == 0);
    printf("Product find test passed.\n");

    // Test 4: Remove product
    bool removed = wren_catalog_remove(&catalog, 2);
    assert(removed == true);
    assert(catalog.count == 1);
    printf("Product removal test passed.\n");

    // Test 5: Sort catalog by price
    Naira price3 = { .kobo = 20000 }; // 200 naira
    add_product(&catalog, 3, "Sneaker", price3, "sneaker");
    wren_catalog_sort_by_price(&catalog, true);

    ProductNode* first = catalog.head;
    assert(first->price.kobo == 10000); // Sandal
    printf("Catalog sort ascending test passed.\n");

    wren_catalog_sort_by_price(&catalog, false);
    first = catalog.head;
    assert(first->price.kobo == 20000); // Sneaker
    printf("Catalog sort descending test passed.\n");
    printf("=== All catalog tests passed ===\n");
    return 0;
}
