#!/usr/bin/env python3
"""
WREN Engine Metrics Visualization
Simple script to graph CSV metrics from stress tests
"""

import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.dates import DateFormatter
import numpy as np
from datetime import datetime
import argparse
import os

def plot_continuous_metrics(csv_file="wren_metrics_continuous.csv"):
    """
    Plot metrics from the continuous stress test
    """
    try:
        df = pd.read_csv(csv_file)
        print(f"Loaded {len(df)} records from {csv_file}")
        
        # Create figure with subplots
        fig, axes = plt.subplots(3, 2, figsize=(15, 10))
        fig.suptitle('WREN Engine Continuous Stress Test Metrics', fontsize=16, fontweight='bold')
        
        # Convert timestamp to datetime
        df['datetime'] = pd.to_datetime(df['timestamp'], unit='s')
        
        # Plot 1: Memory Usage Pattern
        ax = axes[0, 0]
        ax.plot(df['datetime'], df['allocations'], 'b-', label='Allocations', linewidth=2)
        ax.plot(df['datetime'], df['frees'], 'r-', label='Frees', linewidth=2)
        ax.set_title('Memory Operations Over Time')
        ax.set_xlabel('Time')
        ax.set_ylabel('Count')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        # Plot 2: Catalog Size
        ax = axes[0, 1]
        ax.plot(df['datetime'], df['catalog_count'], 'g-', linewidth=2)
        ax.fill_between(df['datetime'], df['catalog_count'], alpha=0.3, color='green')
        ax.set_title('Product Catalog Size')
        ax.set_xlabel('Time')
        ax.set_ylabel('Products')
        ax.grid(True, alpha=0.3)
        
        # Plot 3: AI Queue Length
        ax = axes[1, 0]
        ax.plot(df['datetime'], df['ai_queue'], 'm-', linewidth=2)
        ax.set_title('AI Request Queue Length')
        ax.set_xlabel('Time')
        ax.set_ylabel('Pending Requests')
        ax.grid(True, alpha=0.3)
        
        # Plot 4: Shipping Throughput
        ax = axes[1, 1]
        shipping_rate = df['shipping_count'].diff().fillna(0)
        ax.bar(df['datetime'], shipping_rate, width=0.001, alpha=0.7, color='orange')
        ax.set_title('Shipping Operations Rate')
        ax.set_xlabel('Time')
        ax.set_ylabel('Operations/sec')
        ax.grid(True, alpha=0.3)
        
        # Plot 5: Memory Balance
        ax = axes[2, 0]
        memory_balance = df['allocations'] - df['frees']
        ax.plot(df['datetime'], memory_balance, 'c-', linewidth=2)
        ax.axhline(y=0, color='r', linestyle='--', alpha=0.5)
        ax.set_title('Memory Balance (Allocations - Frees)')
        ax.set_xlabel('Time')
        ax.set_ylabel('Balance')
        ax.grid(True, alpha=0.3)
        
        # Plot 6: Combined Operations Heatmap (simplified)
        ax = axes[2, 1]
        operations = pd.DataFrame({
            'Memory': (df['allocations'] + df['frees']) / 2,
            'Catalog': df['catalog_count'],
            'AI': df['ai_queue'] * 10,
            'Shipping': df['shipping_count'].diff().abs().fillna(0) * 50
        })
        im = ax.imshow(operations.T, aspect='auto', cmap='YlOrRd')
        ax.set_title('Operation Intensity Heatmap')
        ax.set_yticks(range(4))
        ax.set_yticklabels(['Memory', 'Catalog', 'AI', 'Shipping'])
        plt.colorbar(im, ax=ax, label='Relative Intensity')
        
        plt.tight_layout()
        plt.savefig('continuous_metrics.png', dpi=150, bbox_inches='tight')
        print("Saved plot to continuous_metrics.png")
        plt.show()
        
        # Print statistics
        print("\n" + "="*60)
        print("CONTINUOUS TEST STATISTICS")
        print("="*60)
        print(f"Test Duration: {len(df)} samples ({len(df)*0.5:.1f} seconds)")
        print(f"Total Memory Allocations: {df['allocations'].max():,}")
        print(f"Total Memory Frees: {df['frees'].max():,}")
        print(f"Peak Catalog Size: {df['catalog_count'].max()}")
        print(f"Peak AI Queue: {df['ai_queue'].max()}")
        print(f"Total Shipping Operations: {df['shipping_count'].max():,}")
        
    except FileNotFoundError:
        print(f"Error: {csv_file} not found. Run the C test first.")
    except Exception as e:
        print(f"Error plotting continuous metrics: {e}")

def plot_threadpool_metrics(csv_file="wren_metrics_threadpool.csv"):
    """
    Plot metrics from the thread pool test
    """
    try:
        df = pd.read_csv(csv_file)
        print(f"Loaded {len(df)} records from {csv_file}")
        
        # Create figure with subplots
        fig, axes = plt.subplots(2, 3, figsize=(15, 8))
        fig.suptitle('WREN Engine Thread Pool Test Metrics', fontsize=16, fontweight='bold')
        
        # Convert timestamp to datetime
        df['datetime'] = pd.to_datetime(df['timestamp'], unit='s')
        
        # Plot 1: Memory Usage
        ax = axes[0, 0]
        ax.plot(df['datetime'], df['current_usage'], 'b-', label='Current', linewidth=2)
        ax.plot(df['datetime'], df['peak_usage'], 'r--', label='Peak', linewidth=2)
        ax.set_title('Memory Usage (bytes)')
        ax.set_xlabel('Time')
        ax.set_ylabel('Bytes')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        # Plot 2: AI Queue Performance
        ax = axes[0, 1]
        if 'avg_ai_latency_ms' in df.columns:
            ax.plot(df['datetime'], df['avg_ai_latency_ms'], 'm-', linewidth=2)
            ax.set_title('AI Request Latency')
            ax.set_xlabel('Time')
            ax.set_ylabel('Latency (ms)')
            ax.grid(True, alpha=0.3)
        else:
            ax.text(0.5, 0.5, 'No AI latency data', ha='center', va='center')
            ax.set_title('AI Latency')
        
        # Plot 3: Thread Pool Activity
        ax = axes[0, 2]
        if 'active_threads' in df.columns and 'idle_threads' in df.columns:
            width = 0.35
            x = np.arange(len(df))
            ax.bar(x - width/2, df['active_threads'], width, label='Active', color='green', alpha=0.7)
            ax.bar(x + width/2, df['idle_threads'], width, label='Idle', color='gray', alpha=0.7)
            ax.set_title('Thread Pool Status')
            ax.set_xlabel('Sample')
            ax.set_ylabel('Threads')
            ax.legend()
            ax.grid(True, alpha=0.3)
        else:
            ax.text(0.5, 0.5, 'No thread pool data', ha='center', va='center')
            ax.set_title('Thread Activity')
        
        # Plot 4: Catalog Size
        ax = axes[1, 0]
        ax.bar(df['datetime'], df['catalog_count'], width=0.001, color='teal', alpha=0.7)
        ax.set_title('Product Catalog Size')
        ax.set_xlabel('Time')
        ax.set_ylabel('Products')
        ax.grid(True, alpha=0.3)
        
        # Plot 5: AI Queue Length
        ax = axes[1, 1]
        ax.plot(df['datetime'], df['ai_queue'], 'orange', linewidth=2, marker='o', markersize=4)
        ax.set_title('AI Queue Length')
        ax.set_xlabel('Time')
        ax.set_ylabel('Requests')
        ax.grid(True, alpha=0.3)
        
        # Plot 6: Shipping Operations
        ax = axes[1, 2]
        ax.bar(df['datetime'], df['shipments'], width=0.001, color='purple', alpha=0.7)
        ax.set_title('Shipping Operations')
        ax.set_xlabel('Time')
        ax.set_ylabel('Shipments')
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig('threadpool_metrics.png', dpi=150, bbox_inches='tight')
        print("Saved plot to threadpool_metrics.png")
        plt.show()
        
        # Print statistics
        print("\n" + "="*60)
        print("THREAD POOL TEST STATISTICS")
        print("="*60)
        if len(df) > 0:
            print(f"Peak Memory Usage: {df['peak_usage'].max():,} bytes")
            print(f"Final Catalog Size: {df['catalog_count'].iloc[-1]}")
            print(f"Final AI Queue: {df['ai_queue'].iloc[-1]}")
            print(f"Total Shipments: {df['shipments'].iloc[-1]}")
            if 'active_threads' in df.columns:
                print(f"Max Active Threads: {df['active_threads'].max()}")
            if 'avg_ai_latency_ms' in df.columns:
                print(f"Max AI Latency: {df['avg_ai_latency_ms'].max():.2f} ms")
        
    except FileNotFoundError:
        print(f"Error: {csv_file} not found. Run the C test first.")
    except Exception as e:
        print(f"Error plotting thread pool metrics: {e}")

def plot_comparative_metrics(continuous_csv="wren_metrics_continuous.csv", 
                            threadpool_csv="wren_metrics_threadpool.csv"):
    """
    Compare metrics between the two test types
    """
    try:
        # Try to load both files
        df_cont = pd.read_csv(continuous_csv)
        df_thread = pd.read_csv(threadpool_csv)
        
        # Normalize timestamps for comparison
        df_cont['time_norm'] = np.linspace(0, 1, len(df_cont))
        if len(df_thread) > 1:
            df_thread['time_norm'] = np.linspace(0, 1, len(df_thread))
        else:
            df_thread['time_norm'] = [0.5]
        
        fig, axes = plt.subplots(1, 2, figsize=(12, 5))
        fig.suptitle('WREN Engine Test Comparison', fontsize=14, fontweight='bold')
        
        # Plot 1: Resource Usage Comparison
        ax = axes[0]
        # Calculate normalized metrics for comparison
        cont_norm = df_cont['catalog_count'].max()
        thread_norm = df_thread['catalog_count'].max() if 'catalog_count' in df_thread.columns else 1
        
        categories = ['Memory Ops', 'Catalog Size', 'AI Queue']
        cont_values = [
            (df_cont['allocations'].mean() + df_cont['frees'].mean()) / 1000,
            df_cont['catalog_count'].mean(),
            df_cont['ai_queue'].mean()
        ]
        
        thread_values = [
            df_thread['current_usage'].mean() / 1000 if 'current_usage' in df_thread.columns else 0,
            df_thread['catalog_count'].mean() if 'catalog_count' in df_thread.columns else 0,
            df_thread['ai_queue'].mean() if 'ai_queue' in df_thread.columns else 0
        ]
        
        x = np.arange(len(categories))
        width = 0.35
        
        ax.bar(x - width/2, cont_values, width, label='Continuous Test', color='skyblue', alpha=0.8)
        ax.bar(x + width/2, thread_values, width, label='Thread Pool Test', color='lightcoral', alpha=0.8)
        
        ax.set_xlabel('Metric Category')
        ax.set_ylabel('Average Value')
        ax.set_title('Average Resource Usage Comparison')
        ax.set_xticks(x)
        ax.set_xticklabels(categories, rotation=45)
        ax.legend()
        ax.grid(True, alpha=0.3, axis='y')
        
        # Plot 2: Test Characteristics
        ax = axes[1]
        characteristics = {
            'Test Type': ['Continuous', 'Thread Pool'],
            'Duration': [len(df_cont)*0.5, 'N/A'],
            'Threads': [16, df_thread['active_threads'].max() if 'active_threads' in df_thread.columns else 4],
            'Peak Memory': [f"{df_cont['allocations'].max():,}", f"{df_thread['peak_usage'].max():,}" if 'peak_usage' in df_thread.columns else 'N/A'],
            'Operations/sec': [df_cont['shipping_count'].diff().mean()*2, 'N/A']
        }
        
        # Create a simple table
        table_data = []
        for i in range(2):
            table_data.append([
                characteristics['Test Type'][i],
                characteristics['Duration'][i],
                characteristics['Threads'][i],
                characteristics['Peak Memory'][i],
                characteristics['Operations/sec'][i]
            ])
        
        table = ax.table(cellText=table_data,
                        colLabels=['Test', 'Duration(s)', 'Threads', 'Peak Mem', 'Ops/s'],
                        cellLoc='center',
                        loc='center')
        table.auto_set_font_size(False)
        table.set_fontsize(10)
        table.scale(1, 2)
        
        ax.set_title('Test Configuration Comparison')
        ax.axis('off')
        
        plt.tight_layout()
        plt.savefig('test_comparison.png', dpi=150, bbox_inches='tight')
        print("Saved comparison plot to test_comparison.png")
        plt.show()
        
    except Exception as e:
        print(f"Error in comparative plot: {e}")

def main():
    parser = argparse.ArgumentParser(description='Visualize WREN Engine test metrics')
    parser.add_argument('--continuous', action='store_true', help='Plot continuous test metrics')
    parser.add_argument('--threadpool', action='store_true', help='Plot thread pool test metrics')
    parser.add_argument('--compare', action='store_true', help='Compare both tests')
    parser.add_argument('--all', action='store_true', help='Generate all plots')
    parser.add_argument('--csv-continuous', default='wren_metrics_continuous.csv', 
                       help='Continuous test CSV file')
    parser.add_argument('--csv-threadpool', default='wren_metrics_threadpool.csv', 
                       help='Thread pool test CSV file')
    
    args = parser.parse_args()
    
    if not any([args.continuous, args.threadpool, args.compare, args.all]):
        parser.print_help()
        return
    
    print("WREN Engine Metrics Visualizer")
    print("=" * 50)
    
    if args.all or args.continuous:
        print("\nPlotting Continuous Test Metrics...")
        plot_continuous_metrics(args.csv_continuous)
    
    if args.all or args.threadpool:
        print("\nPlotting Thread Pool Test Metrics...")
        plot_threadpool_metrics(args.csv_threadpool)
    
    if args.all or args.compare:
        print("\nGenerating Comparative Analysis...")
        plot_comparative_metrics(args.csv_continuous, args.csv_threadpool)
    
    print("\n" + "="*50)
    print("Visualization complete!")
    print("Check for generated PNG files:")
    print("  - continuous_metrics.png")
    print("  - threadpool_metrics.png")
    print("  - test_comparison.png")

if __name__ == "__main__":
    main()