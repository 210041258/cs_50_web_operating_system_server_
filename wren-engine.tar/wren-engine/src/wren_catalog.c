#include "wren_catalog.h"
#include "wren_debug.h"
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

/* =========================
 * Initialize Catalog
 * ========================= */
void wren_catalog_init(ProductCatalog* catalog) {
    if (!catalog) {
        WREN_FATAL("Catalog pointer is NULL");
        return;
    }

    catalog->head = NULL;
    catalog->tail = NULL;
    catalog->count = 0;

#if WREN_CATALOG_THREAD_SAFE
    pthread_mutex_init(&catalog->_lock, NULL);
#endif

    WREN_DEBUG("Product catalog initialized");
}

/* =========================
 * Add Product
 * ========================= */
ProductNode* wren_catalog_add(ProductCatalog* catalog,
                              int id,
                              const char* name,
                              Naira price,
                              const char* category,
                              int stock_count) {
    if (!catalog || !name || !category) return NULL;

    ProductNode* node = (ProductNode*)malloc(sizeof(ProductNode));
    if (!node) {
        WREN_FATAL("Failed to allocate memory for ProductNode");
        return NULL;
    }

    node->id = id;
    strncpy(node->name, name, sizeof(node->name)-1);
    node->name[sizeof(node->name)-1] = '\0';
    strncpy(node->category, category, sizeof(node->category)-1);
    node->category[sizeof(node->category)-1] = '\0';
    node->price = price;
    node->discount_price.kobo = 0; // default no discount
    node->stock_count = stock_count;
    node->next = NULL;

#if WREN_CATALOG_THREAD_SAFE
    pthread_mutex_lock(&catalog->_lock);
#endif

    if (!catalog->head) {
        catalog->head = catalog->tail = node;
    } else {
        catalog->tail->next = node;
        catalog->tail = node;
    }
    catalog->count++;

#if WREN_CATALOG_THREAD_SAFE
    pthread_mutex_unlock(&catalog->_lock);
#endif

    WREN_DEBUG("Added product id=%d name=%s", id, name);
    return node;
}

/* =========================
 * Find Product by ID
 * ========================= */
ProductNode* wren_catalog_find(ProductCatalog* catalog, int id) {
    if (!catalog) return NULL;

#if WREN_CATALOG_THREAD_SAFE
    pthread_mutex_lock(&catalog->_lock);
#endif

    ProductNode* node = catalog->head;
    while (node) {
        if (node->id == id) {
#if WREN_CATALOG_THREAD_SAFE
            pthread_mutex_unlock(&catalog->_lock);
#endif
            WREN_DEBUG("Found product id=%d name=%s", id, node->name);
            return node;
        }
        node = node->next;
    }

#if WREN_CATALOG_THREAD_SAFE
    pthread_mutex_unlock(&catalog->_lock);
#endif

    WREN_DEBUG("Product id=%d not found", id);
    return NULL;
}

/* =========================
 * Remove Product by ID
 * ========================= */
bool wren_catalog_remove(ProductCatalog* catalog, int id) {
    if (!catalog) return false;

#if WREN_CATALOG_THREAD_SAFE
    pthread_mutex_lock(&catalog->_lock);
#endif

    ProductNode* prev = NULL;
    ProductNode* node = catalog->head;
    while (node) {
        if (node->id == id) {
            if (prev) prev->next = node->next;
            else catalog->head = node->next;

            if (catalog->tail == node) catalog->tail = prev;

            free(node);
            catalog->count--;

#if WREN_CATALOG_THREAD_SAFE
            pthread_mutex_unlock(&catalog->_lock);
#endif

            WREN_DEBUG("Removed product id=%d", id);
            return true;
        }
        prev = node;
        node = node->next;
    }

#if WREN_CATALOG_THREAD_SAFE
    pthread_mutex_unlock(&catalog->_lock);
#endif

    WREN_DEBUG("Cannot remove, product id=%d not found", id);
    return false;
}

/* =========================
 * Apply Flash Sale (discount %)
 * ========================= */
void wren_catalog_apply_flash_sale(ProductCatalog* catalog, float discount_percent) {
    if (!catalog || discount_percent <= 0.0f || discount_percent >= 100.0f) return;

#if WREN_CATALOG_THREAD_SAFE
    pthread_mutex_lock(&catalog->_lock);
#endif

    ProductNode* node = catalog->head;
    while (node) {
        node->discount_price.kobo = node->price.kobo * (100.0f - discount_percent) / 100.0f;
        node = node->next;
    }

#if WREN_CATALOG_THREAD_SAFE
    pthread_mutex_unlock(&catalog->_lock);
#endif

    WREN_DEBUG("Applied flash sale discount=%.2f%%", discount_percent);
}

/* =========================
 * Sort Catalog by Price (ascending/descending)
 * ========================= */
static int compare_price_asc(const void* a, const void* b) {
    ProductNode* pa = *(ProductNode**)a;
    ProductNode* pb = *(ProductNode**)b;
    return (pa->price.kobo > pb->price.kobo) - (pa->price.kobo < pb->price.kobo);
}

static int compare_price_desc(const void* a, const void* b) {
    ProductNode* pa = *(ProductNode**)a;
    ProductNode* pb = *(ProductNode**)b;
    return (pa->price.kobo < pb->price.kobo) - (pa->price.kobo > pb->price.kobo);
}

void wren_catalog_sort_by_price(ProductCatalog* catalog, bool ascending) {
    if (!catalog || catalog->count == 0) return;

#if WREN_CATALOG_THREAD_SAFE
    pthread_mutex_lock(&catalog->_lock);
#endif

    ProductNode** array = (ProductNode**)malloc(catalog->count * sizeof(ProductNode*));
    if (!array) {
        WREN_FATAL("Failed to allocate array for sorting");
#if WREN_CATALOG_THREAD_SAFE
        pthread_mutex_unlock(&catalog->_lock);
#endif
        return;
    }

    ProductNode* node = catalog->head;
    for (int i = 0; node && i < catalog->count; i++) {
        array[i] = node;
        node = node->next;
    }

    qsort(array, catalog->count, sizeof(ProductNode*),
          ascending ? compare_price_asc : compare_price_desc);

    // Rebuild linked list
    catalog->head = array[0];
    node = catalog->head;
    for (int i = 1; i < catalog->count; i++) {
        node->next = array[i];
        node = node->next;
    }
    catalog->tail = node;
    catalog->tail->next = NULL;

    free(array);

#if WREN_CATALOG_THREAD_SAFE
    pthread_mutex_unlock(&catalog->_lock);
#endif

    WREN_DEBUG("Catalog sorted by price (%s)", ascending ? "asc" : "desc");
}

/* =========================
 * Shutdown Catalog
 * ========================= */

void wren_catalog_shutdown(ProductCatalog* catalog) {
    if (!catalog) return;

#if WREN_CATALOG_THREAD_SAFE
    pthread_mutex_lock(&catalog->_lock);

    pthread_mutex_destroy(&catalog->_lock);

#endif

    ProductNode* node = catalog->head;
    while (node) {
        ProductNode* next = node->next;
        free(node);
        node = next;
    }

    catalog->head = NULL;
    catalog->tail = NULL;
    catalog->count = 0;

    WREN_DEBUG("Product catalog shutdown completed");
}

/* =========================
 * Validate Nigerian Phone Number
 * =========================
 * Basic checks: length 11, all digits
 */     

#include <ctype.h>
#include <stdio.h>

bool wren_validate_nigerian_phone(const char* phone) {
    if (!phone) {
        WREN_DEBUG("Phone validation failed: NULL input");
        return false;
    }

    size_t len = strlen(phone);
    if (len != 11) {
        WREN_DEBUG("Phone validation failed: invalid length %zu", len);
        return false;
    }

    if (phone[0] != '0') {
        WREN_DEBUG("Phone validation failed: must start with 0");
        return false;
    }

    for (size_t i = 1; i < len; i++) {
        if (!isdigit((unsigned char)phone[i])) {
            WREN_DEBUG("Phone validation failed: non-digit character found");
            return false;
        }
    }

    WREN_DEBUG("Phone validation passed for %s", phone);
    return true;
}
bool wren_validate_nigerian_address(const char* address) {

    if (!address) {
        WREN_DEBUG("Address validation failed: NULL input");
        return false;
    }

    size_t len = strlen(address);
    if (len == 0 || len > 100) {
        WREN_DEBUG("Address validation failed: invalid length %zu", len);
        return false;
    }

    WREN_DEBUG("Address validation passed for %s", address);
    return true;
}

#include <ctype.h>
#include <string.h>
#include <stdio.h>

bool wren_validate_nigerian_postal_code(const char* postal_code) {
    if (!postal_code) {
        WREN_DEBUG("Postal code validation failed: NULL input");
        return false;
    }

    size_t len = strlen(postal_code);
    if (len != 6) {
        WREN_DEBUG("Postal code validation failed: invalid length %zu", len);
        return false;
    }

    for (size_t i = 0; i < len; i++) {
        if (!isdigit((unsigned char)postal_code[i])) {
            WREN_DEBUG("Postal code validation failed: non-digit character found");
            return false;
        }
    }

    WREN_DEBUG("Postal code validation passed for %s", postal_code);
    return true;
}
/* =========================
    * Validate Nigerian Address     
    * =========================
    * Basic checks: non-empty, reasonable length
    */

typedef struct {
    char house_number[20];
    char street[50];
    char city[50];
    char area[50];
    char state[50];
    char landmark[50];
    char postal_code[10];
} NigerianAddress;

bool wren_validate_phone(const char* phone) {
    if (!phone) {
        WREN_DEBUG("Phone validation failed: NULL input");
        return false;
    }

    size_t len = strlen(phone);
    if (len != 11) {
        WREN_DEBUG("Phone validation failed: invalid length %zu", len);
        return false;
    }

    const char* ptr = phone;
    while (*ptr) {
        if (!isdigit((unsigned char)*ptr)) {
            WREN_DEBUG("Phone validation failed: non-digit character found");
            return false;
        }
        ptr++;
    }

    WREN_DEBUG("Phone validation passed for %s", phone);
    return true;
}

/* =========================
 * Validate Nigerian Phone Number
 * =========================
 * Basic checks: length 11, all digits
 */
bool wren_validate_nigerian_phone_number(const char* phone) {
    if (!phone) {
        WREN_DEBUG("Phone validation failed: NULL input");
        return false;
    }   
    size_t len = strlen(phone);
    if (len != 11) {
        WREN_DEBUG("Phone validation failed: invalid length %zu", len);
        return false;
    }
    for (size_t i = 0; i < len; i++) {
        if (!isdigit((unsigned char)phone[i])) {
            WREN_DEBUG("Phone validation failed: non-digit character found");
            return false;
        }
    }
    WREN_DEBUG("Phone validation passed for %s", phone);
    return true;
}





