#include "wren_localization.h"
#include "wren_debug.h"
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

/* =========================
 * Validate Nigerian phone number
 * =========================
 * Accepts:
 * - Local format: 08012345678
 * - International format: +2348012345678
 * - No spaces, no dashes
 */
bool wren_validate_phone(const char* phone) {
    if (!phone) {
        WREN_DEBUG("Phone validation failed: NULL input");
        return false;
    }

    size_t len = strlen(phone);
    if (len < 11 || len > 14) {
        WREN_DEBUG("Phone validation failed: invalid length %zu", len);
        return false;
    }

    const char* ptr = phone;
    if (phone[0] == '+') {
        // Must be +234XXXXXXXXXX
        if (len != 13) {
            WREN_DEBUG("Phone validation failed: invalid international length");
            return false;
        }
        if (strncmp(phone + 1, "234", 3) != 0) {
            WREN_DEBUG("Phone validation failed: country code not 234");
            return false;
        }
        ptr += 4; // skip +234
    } else {
        // Must start with 0
        if (phone[0] != '0') {
            WREN_DEBUG("Phone validation failed: local phone must start with 0");
            return false;
        }
        ptr++; // skip leading 0
    }

    // Check remaining characters are digits
    while (*ptr) {
        if (!isdigit((unsigned char)*ptr)) {
            WREN_DEBUG("Phone validation failed: non-digit character found");
            return false;
        }
        ptr++;
    }

    WREN_DEBUG("Phone validation passed for %s", phone);
    return true;
}

/* =========================
 * Validate Nigerian Address
 * =========================
 * Basic checks: required fields non-empty, postal code <= 10
 */
bool wren_validate_address(const NigerianAddress* addr) {
    if (!addr) {
        WREN_DEBUG("Address validation failed: NULL input");
        return false;
    }

    if (strlen(addr->house_number) == 0 ||
        strlen(addr->street) == 0 ||
        strlen(addr->area) == 0 ||
        strlen(addr->city) == 0 ||
        strlen(addr->state) == 0) {
        WREN_DEBUG("Address validation failed: missing required field");
        return false;
    }

    if (strlen(addr->postal_code) > 10) {
        WREN_DEBUG("Address validation failed: postal code too long");
        return false;
    }

    WREN_DEBUG("Address validation passed for %s, %s", addr->street, addr->city);
    return true;
}

/* =========================
 * Format Nigerian Address
 * =========================
 * Output: "house_number, street, area, landmark, city, state, postal_code"
 */
void wren_format_address(const NigerianAddress* addr, char* buffer, size_t buf_size) {
    if (!addr || !buffer || buf_size == 0) return;

    snprintf(buffer, buf_size, "%s, %s, %s, %s, %s, %s, %s",
             addr->house_number,
             addr->street,
             addr->area,
             addr->landmark,
             addr->city,
             addr->state,
             addr->postal_code);

    WREN_DEBUG("Formatted address: %s", buffer);
}
