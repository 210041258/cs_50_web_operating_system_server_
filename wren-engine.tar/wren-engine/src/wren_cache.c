#include "wren_cache.h"
#include "wren_debug.h"
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

/* =========================
 * Initialize LRU Cache
 * ========================= */
void wren_cache_init(LRUCache* cache, int capacity) {
    if (!cache || capacity <= 0) {
        WREN_FATAL("Invalid cache initialization");
        return;
    }

    cache->head = NULL;
    cache->tail = NULL;
    cache->size = 0;
    cache->capacity = capacity;

#if WREN_CACHE_THREAD_SAFE
    pthread_mutex_init(&cache->_lock, NULL);
#endif

    WREN_DEBUG("LRU cache initialized with capacity=%d", capacity);
}

/* =========================
 * Move a node to head (most recently used)
 * ========================= */
static void move_to_head(LRUCache* cache, CacheNode* node) {
    if (cache->head == node) return; // Already head

    // Detach node
    if (node->prev) node->prev->next = node->next;
    if (node->next) node->next->prev = node->prev;

    if (cache->tail == node) cache->tail = node->prev;

    // Insert at head
    node->next = cache->head;
    node->prev = NULL;
    if (cache->head) cache->head->prev = node;
    cache->head = node;

    if (!cache->tail) cache->tail = node;
}

/* =========================
 * Get data from cache by product_id
 * ========================= */
void* wren_cache_get(LRUCache* cache, int product_id) {
    if (!cache) return NULL;

#if WREN_CACHE_THREAD_SAFE
    pthread_mutex_lock(&cache->_lock);
#endif

    CacheNode* node = cache->head;
    while (node) {
        if (node->product_id == product_id) {
            node->last_access = time(NULL);
            move_to_head(cache, node);
#if WREN_CACHE_THREAD_SAFE
            pthread_mutex_unlock(&cache->_lock);
#endif
            WREN_DEBUG("Cache hit for product_id=%d", product_id);
            return node->data;
        }
        node = node->next;
    }

#if WREN_CACHE_THREAD_SAFE
    pthread_mutex_unlock(&cache->_lock);
#endif

    WREN_DEBUG("Cache miss for product_id=%d", product_id);
    return NULL;
}

/* =========================
 * Put data into cache
 * ========================= */
void wren_cache_put(LRUCache* cache, int product_id, void* data) {
    if (!cache || !data) return;

#if WREN_CACHE_THREAD_SAFE
    pthread_mutex_lock(&cache->_lock);
#endif

    // Check if node already exists
    CacheNode* node = cache->head;
    while (node) {
        if (node->product_id == product_id) {
            node->data = data;
            node->last_access = time(NULL);
            move_to_head(cache, node);
#if WREN_CACHE_THREAD_SAFE
            pthread_mutex_unlock(&cache->_lock);
#endif
            WREN_DEBUG("Updated cache node for product_id=%d", product_id);
            return;
        }
        node = node->next;
    }

    // Create new node
    node = (CacheNode*)malloc(sizeof(CacheNode));
    if (!node) {
#if WREN_CACHE_THREAD_SAFE
        pthread_mutex_unlock(&cache->_lock);
#endif
        WREN_FATAL("Failed to allocate memory for cache node");
        return;
    }
    node->product_id = product_id;
    node->data = data;
    node->last_access = time(NULL);
    node->prev = NULL;
    node->next = cache->head;

    if (cache->head) cache->head->prev = node;
    cache->head = node;

    if (!cache->tail) cache->tail = node;

    cache->size++;

    // Evict least recently used if over capacity
    if (cache->size > cache->capacity) {
        CacheNode* evict = cache->tail;
        if (evict->prev) evict->prev->next = NULL;
        cache->tail = evict->prev;
        WREN_DEBUG("Evicting cache node product_id=%d", evict->product_id);
        free(evict);
        cache->size--;
    }

#if WREN_CACHE_THREAD_SAFE
    pthread_mutex_unlock(&cache->_lock);
#endif

    WREN_DEBUG("Inserted cache node product_id=%d, size=%d", product_id, cache->size);
}
