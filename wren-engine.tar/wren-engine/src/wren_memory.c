#include "wren_memory.h"
#include "wren_debug.h"
#include <string.h>
#include <pthread.h>

/* =========================
 * Internal lock handling
 * ========================= */
#if WREN_POOL_THREAD_SAFE
static pthread_mutex_t* pool_lock(MemoryPool* pool) {
    return (pthread_mutex_t*)&pool->_lock;
}
#endif

/* =========================
 * Initialize Memory Pool
 * ========================= */
WrenStatus wren_pool_init(MemoryPool* pool) {
    if (!pool) {
        WREN_DEBUG("Pool pointer is NULL");
        return WREN_ERR_INVALID_ARG;
    }

    memset(pool->blocks, 0, sizeof(pool->blocks));
    pool->free_top = WREN_POOL_BLOCK_COUNT - 1;
    pool->allocations = 0;
    pool->frees = 0;

    for (int i = 0; i < WREN_POOL_BLOCK_COUNT; i++) {
        pool->free_indices[i] = i;
    }

#if WREN_POOL_THREAD_SAFE
    pthread_mutex_t* lock = pool_lock(pool);
    if (pthread_mutex_init(lock, NULL) != 0) {
        WREN_FATAL("Failed to initialize pool mutex");
        return WREN_ERR_INTERNAL;
    }
#endif

    WREN_DEBUG("Memory pool initialized with %d blocks of %d bytes", 
                WREN_POOL_BLOCK_COUNT, WREN_POOL_BLOCK_SIZE);
    return WREN_OK;
}

/* =========================
 * Allocate a block from the pool
 * ========================= */
void* wren_pool_alloc(MemoryPool* pool, size_t size) {
    if (!pool || size == 0 || size > WREN_POOL_BLOCK_SIZE) {
        WREN_DEBUG("Invalid allocation request: size=%zu", size);
        return NULL;
    }

#if WREN_POOL_THREAD_SAFE
    pthread_mutex_lock(pool_lock(pool));
#endif

    if (pool->free_top < 0) {
#if WREN_POOL_THREAD_SAFE
        pthread_mutex_unlock(pool_lock(pool));
#endif
        WREN_DEBUG("Memory pool exhausted");
        return NULL;
    }

    int index = pool->free_indices[pool->free_top--];
    pool->allocations++;

#if WREN_POOL_THREAD_SAFE
    pthread_mutex_unlock(pool_lock(pool));
#endif

    WREN_DEBUG("Allocated block %d, used=%zu, free=%zu", 
               index, pool->allocations, pool->free_top + 1);
    return (void*)pool->blocks[index];
}

/* =========================
 * Free a block back to the pool
 * ========================= */
void wren_pool_free(MemoryPool* pool, void* ptr) {
    if (!pool || !ptr) {
        WREN_DEBUG("Invalid free request");
        return;
    }

    uintptr_t offset = (uint8_t*)ptr - (uint8_t*)pool->blocks;
    if (offset >= sizeof(pool->blocks)) {
        WREN_FATAL("Attempted to free pointer outside pool");
        return;
    }

    int index = offset / WREN_POOL_BLOCK_SIZE;

#if WREN_POOL_THREAD_SAFE
    pthread_mutex_lock(pool_lock(pool));
#endif

    pool->free_indices[++pool->free_top] = index;
    pool->frees++;

#if WREN_POOL_THREAD_SAFE
    pthread_mutex_unlock(pool_lock(pool));
#endif

    WREN_DEBUG("Freed block %d, used=%zu, free=%zu", 
               index, pool->allocations - pool->frees, pool->free_top + 1);
}
