#include "wren_system.h"
#include "wren_debug.h"
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

/* =========================
 * Global system state
 * ========================= */
static bool g_wren_initialized = false;
static pthread_mutex_t g_system_lock = PTHREAD_MUTEX_INITIALIZER;

/* =========================
 * Initialize WREN system
 * ========================= */
void wren_system_init(void) {
    pthread_mutex_lock(&g_system_lock);

    if (g_wren_initialized) {
        WREN_WARN("WREN system already initialized");
        pthread_mutex_unlock(&g_system_lock);
        return;
    }

    /* TODO: Initialize subsystems here
       - Memory pools
       - AI request queue
       - Product catalog
       - Logging
    */
    WREN_DEBUG("Initializing WREN system...");

    g_wren_initialized = true;

    WREN_DEBUG("WREN system initialized successfully");
    pthread_mutex_unlock(&g_system_lock);
}

/* =========================
 * Shutdown WREN system
 * ========================= */
void wren_system_shutdown(void) {
    pthread_mutex_lock(&g_system_lock);

    if (!g_wren_initialized) {
        WREN_WARN("WREN system not initialized or already shutdown");
        pthread_mutex_unlock(&g_system_lock);
        return;
    }

    /* TODO: Cleanup subsystems here
       - Free memory pools
       - Stop AI workers
       - Save product catalog
       - Close logs
    */
    WREN_DEBUG("Shutting down WREN system...");

    g_wren_initialized = false;

    WREN_DEBUG("WREN system shutdown complete");
    pthread_mutex_unlock(&g_system_lock);
}

/* =========================
 * Log an event (thread-safe)
 * severity: 0=info, 1=warning, 2=error
 * ========================= */
void wren_log_event(const char* event, int severity) {
    if (!event) return;

    pthread_mutex_lock(&g_system_lock);

    const char* prefix;
    switch (severity) {
        case 0: prefix = "[INFO] "; break;
        case 1: prefix = "[WARN] "; break;
        case 2: prefix = "[ERROR] "; break;
        default: prefix = "[LOG] "; break;
    }

    /* Timestamp */
    time_t now = time(NULL);
    char buf[64];
    strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", localtime(&now));

    fprintf(stdout, "%s %s%s\n", buf, prefix, event);
    fflush(stdout);

    pthread_mutex_unlock(&g_system_lock);
}


/* =========================
 * Check if WREN system is initialized
 * ========================= */

bool wren_is_initialized(void) {
    pthread_mutex_lock(&g_system_lock);
    bool initialized = g_wren_initialized;

    pthread_mutex_unlock(&g_system_lock);
    return initialized;
}


/* =========================
 * Get current system time in milliseconds
 * ========================= */

uint64_t wren_get_time_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    return (uint64_t)(ts.tv_sec) * 1000 + (ts.tv_nsec / 1000000);
}   

/* =========================
 * Sleep for specified milliseconds
 * ========================= */

void wren_sleep_ms(uint32_t milliseconds) {
    struct timespec req, rem;
    req.tv_sec = milliseconds / 1000;
    req.tv_nsec = (milliseconds % 1000) * 1000000;
    nanosleep(&req, &rem);

}

/* =========================
 * Get system memory usage (dummy implementation)
 * ========================= */

size_t wren_get_memory_usage(void) {

    return 0;
}

/* =========================
 * Allocate memory (thread-safe)
 * ========================= */     

void* wren_system_malloc(size_t size) {
    pthread_mutex_lock(&g_system_lock);
    void* ptr = malloc(size);
    pthread_mutex_unlock(&g_system_lock);
    return ptr;
}

/* =========================
 * Free memory (thread-safe)
 * ========================= */

void wren_system_free(void* ptr) {
    pthread_mutex_lock(&g_system_lock);
    free(ptr);
    pthread_mutex_unlock(&g_system_lock);

}

/* =========================
 * Reallocate memory (thread-safe)
 * ========================= */

void* wren_system_realloc(void* ptr, size_t size) {
    pthread_mutex_lock(&g_system_lock);
    void* new_ptr = realloc(ptr, size);
    pthread_mutex_unlock(&g_system_lock);
    return new_ptr;

}


/* =========================
 * End of wren_system.c
 * ========================= */
    



