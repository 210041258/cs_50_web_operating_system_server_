#include "wren_security.h"
#include "wren_debug.h"
#include "wren_localization.h"

#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <stdint.h>
#include <stdio.h>

#ifndef WREN_USE_OPENSSL
#define WREN_USE_OPENSSL 0
#endif

#if WREN_USE_OPENSSL
#include <openssl/sha.h>
#include <openssl/hmac.h>
#include <openssl/rand.h>
#endif

/* --------------------------
 * Internal AES/HMAC key
 * -------------------------- */
static unsigned char s_hmac_key[32]; // 256-bit key for HMAC
static int s_hmac_key_initialized = 0;

/* --------------------------
 * Helpers
 * -------------------------- */
static void to_hex(const unsigned char* src, size_t len, char* dest, size_t dest_len) {
    static const char hex[] = "0123456789abcdef";
    if (!src || !dest || dest_len < (len * 2 + 1)) return;
    for (size_t i = 0; i < len; ++i) {
        dest[i*2]     = hex[(src[i] >> 4) & 0xF];
        dest[i*2 + 1] = hex[src[i] & 0xF];
    }
    dest[len*2] = '\0';
}

/* --------------------------
 * Security init
 * -------------------------- */
WrenStatus wren_security_init(void) {
#if WREN_USE_OPENSSL
    if (!s_hmac_key_initialized) {
        if (RAND_bytes(s_hmac_key, sizeof(s_hmac_key)) != 1) {
            WREN_DEBUG("OpenSSL RAND_bytes failed");
            return WREN_ERR_INTERNAL;
        }
        s_hmac_key_initialized = 1;
        WREN_DEBUG("HMAC key initialized (OpenSSL)");
    }
#else
    /* fallback: deterministic PRNG key (not secure) */
    srand((unsigned int)time(NULL));
    for (size_t i = 0; i < sizeof(s_hmac_key); i++) {
        s_hmac_key[i] = (unsigned char)(rand() & 0xFF);
    }
    s_hmac_key_initialized = 1;
    WREN_DEBUG("HMAC key initialized (fallback, NOT secure)");
#endif
    return WREN_OK;
}

/* --------------------------
 * Sign transaction
 * -------------------------- */
WrenStatus wren_sign_transaction(TransactionHeader* trans) {
    if (!trans || !s_hmac_key_initialized) return WREN_ERR_INVALID_ARG;

    unsigned char digest[32];

#if WREN_USE_OPENSSL
    /* HMAC-SHA256 using OpenSSL */
    HMAC(EVP_sha256(), s_hmac_key, sizeof(s_hmac_key),
         (unsigned char*)trans, sizeof(TransactionHeader) - sizeof(trans->iv), digest, NULL);
#else
    /* fallback: simple deterministic hash (NOT secure) */
    for (int i = 0; i < 32; i++) digest[i] = 0;
    const unsigned char* p = (unsigned char*)trans;
    for (size_t i = 0; i < sizeof(TransactionHeader) - sizeof(trans->iv); i++) {
        digest[i % 32] ^= p[i] ^ s_hmac_key[i % sizeof(s_hmac_key)];
    }
#endif

    /* store result in iv (reuse 16 bytes) */
    memcpy(trans->iv, digest, sizeof(trans->iv));
    WREN_DEBUG("Transaction %s signed with HMAC", trans->transaction_id);
    return WREN_OK;
}

/* --------------------------
 * Verify transaction signature
 * -------------------------- */
bool wren_verify_transaction_signature(const TransactionHeader* trans) {
    if (!trans || !s_hmac_key_initialized) return false;

    unsigned char expected_iv[16];
#if WREN_USE_OPENSSL
    unsigned char digest[32];
    HMAC(EVP_sha256(), s_hmac_key, sizeof(s_hmac_key),
         (unsigned char*)trans, sizeof(TransactionHeader) - sizeof(trans->iv), digest, NULL);
    memcpy(expected_iv, digest, sizeof(expected_iv));
#else
    unsigned char digest[32];
    for (int i = 0; i < 32; i++) digest[i] = 0;
    const unsigned char* p = (unsigned char*)trans;
    for (size_t i = 0; i < sizeof(TransactionHeader) - sizeof(trans->iv); i++) {
        digest[i % 32] ^= p[i] ^ s_hmac_key[i % sizeof(s_hmac_key)];
    }
    memcpy(expected_iv, digest, sizeof(expected_iv));
#endif

    if (memcmp(trans->iv, expected_iv, sizeof(trans->iv)) == 0) {
        WREN_DEBUG("Transaction %s HMAC verification PASSED", trans->transaction_id);
        return true;
    } else {
        WREN_DEBUG("Transaction %s HMAC verification FAILED", trans->transaction_id);
        return false;
    }
}


/* --------------------------
 * Shutdown security
 * -------------------------- */

void wren_security_shutdown(void) {
    memset(s_hmac_key, 0, sizeof(s_hmac_key));
    s_hmac_key_initialized = 0;
    WREN_DEBUG("WREN security shutdown completed");
}

/* =========================
 * Validate Nigerian Phone Number
 * =========================
 * Format: +234XXXXXXXXXX or 0XXXXXXXXXX
 */

bool wren_validate_phone_number(const char* phone) {
    if (!phone) {
        WREN_DEBUG("Phone validation failed: NULL input");
        return false;
    }

    size_t len = strlen(phone);
    if (len < 11 || len > 14) {
        WREN_DEBUG("Phone validation failed: invalid length %zu", len);
        return false;
    }

    const char* ptr = phone;
    if (phone[0] == '+') {
        if (strncmp(phone, "+234", 4) != 0) {
            WREN_DEBUG("Phone validation failed: invalid country code");
            return false;
        }
        ptr += 4;
    } else if (phone[0] == '0') {
        ptr += 1;
    } else {
        WREN_DEBUG("Phone validation failed: invalid prefix");
        return false;
    }

    while (*ptr) {
        if (!isdigit((unsigned char)*ptr)) {
            WREN_DEBUG("Phone validation failed: non-digit character found");
            return false;
        }
        ptr++;
    }

    WREN_DEBUG("Phone validation passed for %s", phone);
    return true;
}

/* =========================
 * Validate Nigerian Address
 * =========================
 * Basic checks: required fields non-empty, postal code <= 10
 */

bool wren_validate_address(const NigerianAddress* addr) {
    if (!addr) {
        WREN_DEBUG("Address validation failed: NULL input");
        return false;
    }

    if (strlen(addr->house_number) == 0 ||
        strlen(addr->street) == 0 ||
        strlen(addr->city) == 0 ||
        strlen(addr->state) == 0) {
        WREN_DEBUG("Address validation failed: required fields missing");
        return false;
    }

    if (strlen(addr->postal_code) > 10) {
        WREN_DEBUG("Address validation failed: postal code too long");
        return false;
    }

    WREN_DEBUG("Address validation passed for %s, %s", addr->street, addr->city);
    return true;
}






