#include "wren_ai.h"
#include "wren_debug.h"
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>  // For sleep()

/* ------------------------
 * Initialize AI request queue
 * ------------------------ */
void wren_ai_queue_init(AIRequestQueue* queue, int max_concurrent) {
    if (!queue || max_concurrent <= 0) return;

    queue->head = NULL;
    queue->tail = NULL;
    queue->max_concurrent = max_concurrent;
    queue->current_requests = 0;
    queue->active = true;

    pthread_mutex_init(&queue->lock, NULL);
    pthread_cond_init(&queue->cond, NULL);

    WREN_DEBUG("AI queue initialized (max_concurrent=%d)", max_concurrent);
}

/* ------------------------
 * Shutdown AI queue
 * ------------------------ */
void wren_ai_queue_shutdown(AIRequestQueue* queue) {
    if (!queue) return;

    pthread_mutex_lock(&queue->lock);
    queue->active = false;
    pthread_cond_broadcast(&queue->cond);
    pthread_mutex_unlock(&queue->lock);

    // Free remaining requests
    AIRequest* req = queue->head;
    while (req) {
        AIRequest* tmp = req;
        req = req->next;
        if (tmp->generated_image) free(tmp->generated_image);
        free(tmp);
    }

    queue->head = queue->tail = NULL;
    WREN_DEBUG("AI queue shutdown");
}

/* ------------------------
 * Enqueue a new AI request
 * ------------------------ */
int wren_ai_queue_enqueue(AIRequestQueue* queue,
                          const char* prompt,
                          const char* style,
                          const char* colors,
                          int target_audience) {
    if (!queue || !prompt) return -1;

    AIRequest* req = (AIRequest*)malloc(sizeof(AIRequest));
    if (!req) return -1;

    memset(req, 0, sizeof(AIRequest));
    strncpy(req->prompt, prompt, sizeof(req->prompt)-1);
    if (style) strncpy(req->style, style, sizeof(req->style)-1);
    if (colors) strncpy(req->color_scheme, colors, sizeof(req->color_scheme)-1);
    req->target_audience = target_audience;
    req->next = NULL;

    pthread_mutex_lock(&queue->lock);

    // Assign request ID sequentially
    static int s_request_counter = 1;
    req->request_id = s_request_counter++;

    if (!queue->head) {
        queue->head = queue->tail = req;
    } else {
        queue->tail->next = req;
        queue->tail = req;
    }

    pthread_cond_signal(&queue->cond);
    pthread_mutex_unlock(&queue->lock);

    WREN_DEBUG("Enqueued AI request id=%d prompt=%s", req->request_id, req->prompt);
    return req->request_id;
}

/* ------------------------
 * Dequeue next AI request (blocking)
 * ------------------------ */
AIRequest* wren_ai_queue_dequeue(AIRequestQueue* queue) {
    if (!queue) return NULL;

    pthread_mutex_lock(&queue->lock);
    while (queue->active && !queue->head) {
        pthread_cond_wait(&queue->cond, &queue->lock);
    }

    if (!queue->active) {
        pthread_mutex_unlock(&queue->lock);
        return NULL;
    }

    AIRequest* req = queue->head;
    if (req) {
        queue->head = req->next;
        if (!queue->head) queue->tail = NULL;
        req->next = NULL;
        WREN_DEBUG("Dequeued AI request id=%d", req->request_id);
    }

    pthread_mutex_unlock(&queue->lock);
    return req;
}

/* ------------------------
 * AI Processing Thread Stub
 * ------------------------ */
void* wren_ai_processing_thread(void* arg) {
    AIRequestQueue* queue = (AIRequestQueue*)arg;
    if (!queue) return NULL;

    while (queue->active) {
        AIRequest* req = wren_ai_queue_dequeue(queue);
        if (!req) continue;

        // Simulate AI image generation (replace with real AI call)
        WREN_DEBUG("Processing AI request id=%d prompt=%s", req->request_id, req->prompt);
        sleep(1);  // simulate processing delay

        req->generated_image_size = 1024; // fake size
        req->generated_image = (unsigned char*)malloc(req->generated_image_size);
        if (req->generated_image) memset(req->generated_image, 0xAB, req->generated_image_size);

        WREN_DEBUG("Completed AI request id=%d (image_size=%zu)", req->request_id, req->generated_image_size);

        // Here you could enqueue to a completed queue or callback
    }
    return NULL;
}

/* ------------------------
 * Start AI processing threads
 * ------------------------ */

void wren_ai_start_processing(AIRequestQueue* queue, int thread_count) {
    if (!queue || thread_count <= 0) return;

    for (int i = 0; i < thread_count; i++) {
        pthread_t thread;
        pthread_create(&thread, NULL, wren_ai_processing_thread, (void*)queue);
        pthread_detach(thread);  // Detach thread to run independently
    }

    WREN_DEBUG("Started %d AI processing threads", thread_count);
}

            
    /   * ------------------------
 * End of wren_ai.c
 * ------------------------ * / 


    