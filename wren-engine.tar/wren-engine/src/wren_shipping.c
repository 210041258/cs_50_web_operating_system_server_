#include "wren_shipping.h"
#include "wren_debug.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>

/* =========================
 * Generate a simple tracking ID
 * Format: SHIP-<timestamp>-<rand>
 * ========================= */
static void generate_tracking_id(char* buffer, size_t size) {
    if (!buffer || size == 0) return;
    srand((unsigned int)time(NULL));
    snprintf(buffer, size, "SHIP-%ld-%03d", time(NULL), rand() % 1000);
}

/* =========================
 * Calculate shipping cost
 * =========================
 * Example:
 * - Standard: free for all
 * - Express: 1000 kobo per km (simplified)
 */
static Naira calculate_shipping_cost(ShippingMethod method, const NigerianAddress* dest) {
    Naira cost = {0};

    if (!dest) return cost;

    switch (method) {
        case SHIPPING_STANDARD:
            cost.kobo = 0; // free
            break;
        case SHIPPING_EXPRESS:
            cost.kobo = 50000; // 500 naira flat rate (example)
            break;
        default:
            cost.kobo = 0;
            break;
    }

    WREN_DEBUG("Calculated shipping cost %llu kobo for method %d", cost.kobo, method);
    return cost;
}

/* =========================
 * Create Shipping Info
 * ========================= */
ShippingInfo* wren_shipping_create(ShippingMethod method, const NigerianAddress* dest) {
    if (!dest) {
        WREN_FATAL("Cannot create shipping info: destination is NULL");
        return NULL;
    }

    if (!wren_validate_address(dest)) {
        WREN_FATAL("Cannot create shipping info: invalid address");
        return NULL;
    }

    ShippingInfo* info = (ShippingInfo*)malloc(sizeof(ShippingInfo));
    if (!info) {
        WREN_FATAL("Failed to allocate memory for ShippingInfo");
        return NULL;
    }

    memset(info, 0, sizeof(ShippingInfo));
    info->method = method;
    info->destination = *dest;
    info->shipping_cost = calculate_shipping_cost(method, dest);

    generate_tracking_id(info->tracking_id, sizeof(info->tracking_id));

    time_t now = time(NULL);
    if (method == SHIPPING_STANDARD) {
        info->estimated_delivery = now + 3 * 24 * 3600; // 3 days
    } else {
        info->estimated_delivery = now + 1 * 24 * 3600; // 1 day
    }
    info->actual_delivery = 0; // Not delivered yet

    strncpy(info->carrier, "Local", sizeof(info->carrier) - 1);

    WREN_DEBUG("Created shipping info tracking_id=%s", info->tracking_id);
    return info;
}
void wren_shipping_free(ShippingInfo* info) {
    if (info) {
        WREN_DEBUG("Freeing shipping info tracking_id=%s", info->tracking_id);
        free(info);
    }
}

/* =========================
 * Print Shipping Info
 * ========================= */

void wren_shipping_print(const ShippingInfo* info) {
    if (!info) {
        WREN_DEBUG("Shipping info is NULL");
        return;
    }

    char est_delivery_str[26];
    char act_delivery_str[26];
    ctime_r(&info->estimated_delivery, est_delivery_str);
    if (info->actual_delivery != 0) {
        ctime_r(&info->actual_delivery, act_delivery_str);
    } else {
        strncpy(act_delivery_str, "Not delivered yet", sizeof(act_delivery_str));
    }

    printf("Shipping Info:\n");
    printf("  Tracking ID: %s\n", info->tracking_id);
    printf("  Method: %s\n", info->method == SHIPPING_STANDARD ? "Standard" : "Express");
    printf("  Carrier: %s\n", info->carrier);
    printf("  Shipping Cost: %llu kobo\n", info->shipping_cost.kobo);
    printf("  Estimated Delivery: %s", est_delivery_str);
    printf("  Actual Delivery: %s\n", act_delivery_str);
    printf("  Destination: %s, %s, %s, %s, %s, %s\n",
           info->destination.street,
           info->destination.city,
           info->destination.state,
           info->destination.postal_code,
           info->destination.country,
           info->destination.phone);

    WREN_DEBUG("Printed shipping info tracking_id=%s", info->tracking_id);
    return info
}

/* =========================
 * Validate Nigerian Phone Number
 * =========================
 * Basic checks: starts with +234 or 0, length, digits only
 */
bool wren_validate_phone_number(const char* phone) {
    if (!phone) {
        WREN_DEBUG("Phone validation failed: NULL input");
        return false;
    }

    size_t len = strlen(phone);
    if (len < 10 || len > 15) {
        WREN_DEBUG("Phone validation failed: invalid length");
        return false;
    }

    const char* ptr = phone;

    // Check for +234 or leading 0
    if (strncmp(phone, "+234", 4) == 0) {
        if (len < 13) {
            WREN_DEBUG("Phone validation failed: invalid international length");
            return false;
        }   

        ptr += 4; // skip +234
    } else if (phone[0] == '0') {
        ptr++; // skip leading 0
    } else {
        WREN_DEBUG("Phone validation failed: must start with +234 or 0");
        return false;
    }
    // Check remaining characters are digits
    while (*ptr) {
        if (!isdigit((unsigned char)*ptr)) {
            WREN_DEBUG("Phone validation failed: non-digit character found");
            return false;
        }
        ptr++;
    }   
    WREN_DEBUG("Phone validation passed for %s", phone);
    return true;
}

/* =========================
 * Validate Nigerian Address
 * =========================
 * Basic checks: required fields non-empty, postal code <= 10
 */

bool wren_validate_address(const NigerianAddress* addr) {
    if (!addr) {
        WREN_DEBUG("Address validation failed: NULL input");
        return false;
    }

    if (strlen(addr->house_number) == 0 ||
        strlen(addr->street) == 0 ||
        strlen(addr->city) == 0 ||
        strlen(addr->state) == 0 ||
        strlen(addr->postal_code) == 0 ||
        strlen(addr->country) == 0) {
        WREN_DEBUG("Address validation failed: required fields missing");
        return false;
    }

    if (strlen(addr->postal_code) > 10) {
        WREN_DEBUG("Address validation failed: postal code too long");
        return false;
    }

    if (!wren_validate_phone_number(addr->phone)) {
        WREN_DEBUG("Address validation failed: invalid phone number");
        return false;
    }

    WREN_DEBUG("Address validation passed for %s, %s", addr->street, addr->city);
    return true;    

}

/* =========================
 * Format Nigerian Address
 * =========================
 * Output: "house_number, street, area, landmark, city, state, postal_code"
 */void wren_format_address(const NigerianAddress* addr, char* buffer, size_t size) {
    if (!addr || !buffer || size == 0) {
        WREN_DEBUG("Cannot format address: invalid input");
        return;
    }

    snprintf(buffer, size, "%s, %s, %s, %s, %s, %s, %s",
             addr->house_number,
             addr->street,
             addr->area,
             addr->landmark,
             addr->city,
             addr->state,
             addr->postal_code);

    WREN_DEBUG("Formatted address: %s", buffer);

}


/* =========================
 * Allocate a block from the pool
 * ========================= */ 

void* wren_pool_alloc(MemoryPool* pool, size_t size) {
    if (!pool || size == 0 || size > WREN_POOL_BLOCK_SIZE) {
        WREN_DEBUG("Invalid allocation request: size=%zu", size);
        return NULL;
    }
#if WREN_POOL_THREAD_SAFE
    pthread_mutex_lock(pool_lock(pool));
#endif
    if (pool->free_top < 0) {
#if WREN_POOL_THREAD_SAFE

        pthread_mutex_unlock(pool_lock(pool));

#endif
        WREN_DEBUG("Memory pool exhausted");
        return NULL;
    }
    int index = pool->free_indices[pool->free_top--];
    pool->allocations++;
#if WREN_POOL_THREAD_SAFE
    pthread_mutex_unlock(pool_lock(pool));
#endif

    WREN_DEBUG("Allocated block %d, used=%zu, free=%zu", 
               index, pool->allocations, pool->free_top + 1);
    return (void*)pool->blocks[index];
}

/* =========================
 * Free a block back to the pool
 * ========================= */

void wren_pool_free(MemoryPool* pool, void* ptr) {
    if (!pool || !ptr) {
        WREN_DEBUG("Invalid free request");
        return;
    }

    uintptr_t offset = (uint8_t*)ptr - (uint8_t*)pool->blocks;
    if (offset >= sizeof(pool->blocks)) {
        WREN_FATAL("Attempted to free pointer outside pool");
        return;
    }

    int index = offset / WREN_POOL_BLOCK_SIZE;      
#if WREN_POOL_THREAD_SAFE
    pthread_mutex_lock(pool_lock(pool));
#endif
    pool->free_indices[++pool->free_top] = index;
    pool->frees++;
#if WREN_POOL_THREAD_SAFE
    pthread_mutex_unlock(pool_lock(pool));
#endif
    WREN_DEBUG("Freed block %d, used=%zu, free=%zu", 
               index, pool->allocations, pool->free_top + 1);
}

/* =========================
 * Find Product by ID
 * ========================= */

ProductNode* wren_catalog_find(ProductCatalog* catalog, int id) {
    if (!catalog) return NULL;

#if WREN_CATALOG_THREAD_SAFE
    pthread_mutex_lock(&catalog->_lock);


#endif  

    ProductNode* node = catalog->head;
    while (node) {
        if (node->id == id) {

#if WREN_CATALOG_THREAD_SAFE
            pthread_mutex_unlock(&catalog->_lock);

#endif

            WREN_DEBUG("Found product id=%d name=%s", id, node->name);
            return node;
        }
        node = node->next;
    }


#if WREN_CATALOG_THREAD_SAFE

    pthread_mutex_unlock(&catalog->_lock);

#endif

    WREN_DEBUG("Product id=%d not found", id);
    return NULL;
}

/* =========================
 * Remove Product by ID
 * ========================= */

bool wren_catalog_remove(ProductCatalog* catalog, int id) {
    if (!catalog) return false;
#if WREN_CATALOG_THREAD_SAFE
    pthread_mutex_lock(&catalog->_lock);
#endif

    ProductNode* prev = NULL;
    ProductNode* node = catalog->head;
    while (node) {
        if (node->id == id) {
            if (prev) prev->next = node->next;
            else catalog->head = node->next;

            if (catalog->tail == node) catalog->tail = prev;

            free(node);
            WREN_DEBUG("Removed product id=%d", id);
            catalog->count--;
#if WREN_CATALOG_THREAD_SAFE
            pthread_mutex_unlock(&catalog->_lock);  
#endif
            return true;
        }
        prev = node;
        node = node->next;
    }
#if WREN_CATALOG_THREAD_SAFE
    pthread_mutex_unlock(&catalog->_lock);
#endif


    WREN_DEBUG("Cannot remove, product id=%d not found", id);
    return false;
}


/* =========================
 * Sort Catalog by Price (ascending/descending)
 * ========================= */

static int compare_price_asc(const void* a, const void* b) {
    ProductNode* pa = *(ProductNode**)a;
    ProductNode* pb = *(ProductNode**)b;
    return (pa->price.kobo > pb->price.kobo) - (pa->price.kobo < pb->price.kobo);

}

static int compare_price_desc(const void* a, const void* b) {
    ProductNode* pa = *(ProductNode**)a;
    ProductNode* pb = *(ProductNode**)b;
    return (pa->price.kobo < pb->price.kobo) - (pa->price.kobo > pb->price.kobo);
}

void wren_catalog_sort_by_price(ProductCatalog* catalog, bool ascending) {
    if (!catalog || catalog->count == 0) return;    
#if WREN_CATALOG_THREAD_SAFE
    pthread_mutex_lock(&catalog->_lock);
#endif
    ProductNode** nodes = (ProductNode**)malloc(sizeof(ProductNode*) * catalog->count);
    if (!nodes) {
        WREN_FATAL("Failed to allocate memory for sorting");

#if WREN_CATALOG_THREAD_SAFE
        pthread_mutex_unlock(&catalog->_lock);

#endif

        return;
    }

    ProductNode* current = catalog->head;
    for (size_t i = 0; i < catalog->count; i++) {
        nodes[i] = current;
        current = current->next;
    }

    if (ascending) {
        qsort(nodes, catalog->count, sizeof(ProductNode*), compare_price_asc);
    } else {
        qsort(nodes, catalog->count, sizeof(ProductNode*), compare_price_desc);
    }

    catalog->head = nodes[0];
    for (size_t i = 0; i < catalog->count - 1; i++) {
        nodes[i]->next = nodes[i + 1];
    }
    nodes[catalog->count - 1]->next = NULL;
    catalog->tail = nodes[catalog->count - 1];

    free(nodes);
#if WREN_CATALOG_THREAD_SAFE
    pthread_mutex_unlock(&catalog->_lock);
#endif  
    WREN_DEBUG("Catalog sorted by price (%s)", ascending ? "asc" : "desc");

}

/* =========================
 * Free a block back to the pool
 * ========================= */

void wren_pool_free(MemoryPool* pool, void* ptr) {
    if (!pool || !ptr) {
        WREN_DEBUG("Invalid free request");
        return;
    }

    uintptr_t offset = (uint8_t*)ptr - (uint8_t*)pool->blocks;
    if (offset >= sizeof(pool->blocks)) {
        WREN_FATAL("Attempted to free pointer outside pool");
        return;
    }

    int index = offset / WREN_POOL_BLOCK_SIZE;
    if (index < 0 || index >= WREN_POOL_BLOCK_COUNT) {  

        WREN_FATAL("Attempted to free invalid block index %d", index);
        return;
    }

#if WREN_POOL_THREAD_SAFE

    pthread_mutex_lock(pool_lock(pool));

#endif

    pool->free_indices[++pool->free_top] = index;
    pool->frees++;

#if WREN_POOL_THREAD_SAFE

    pthread_mutex_unlock(pool_lock(pool));

#endif  

    WREN_DEBUG("Freed block %d, used=%zu, free=%zu", 
               index, pool->allocations - pool->frees, pool->free_top + 1);
    }


