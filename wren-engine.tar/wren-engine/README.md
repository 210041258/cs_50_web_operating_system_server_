# WREN Engine

WREN is a modular, high-performance C engine designed for scalable e-commerce systems.
It focuses on clean architecture, memory efficiency, and extensibility.

## Structure
- include/ : Public headers
- src/     : Core implementations
- tests/   : Unit tests
- libs/    : External dependencies
