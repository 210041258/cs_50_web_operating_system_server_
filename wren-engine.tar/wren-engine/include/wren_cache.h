#ifndef WREN_CACHE_H
#define WREN_CACHE_H

/*
 * =========================================================
 *  WREN ENGINE – LRU CACHE
 *
 *  Improvements applied:
 *  - Removed time-based access (true O(1) LRU)
 *  - Optional thread safety
 *  - Clean ownership rules
 *  - No platform-specific headers
 * =========================================================
 */

#include "wren_common.h"
#include "wren_debug.h"

/* =========================
 * Configuration
 * ========================= */

/*
 * 0 = single-threaded
 * 1 = thread-safe (internal lock)
 */
#ifndef WREN_CACHE_THREAD_SAFE
#define WREN_CACHE_THREAD_SAFE 1
#endif

/* =========================
 * Cache Node
 * ========================= */

typedef struct CacheNode {
    int product_id;
    void* data;

    struct CacheNode* prev;
    struct CacheNode* next;
} CacheNode;

/* =========================
 * Cache Structure
 * ========================= */

typedef struct {
    CacheNode* head;    /* Most Recently Used */
    CacheNode* tail;    /* Least Recently Used */

    int size;
    int capacity;

#if WREN_CACHE_THREAD_SAFE
    void* _lock;        /* opaque internal mutex */
#endif
} LRUCache;

/* =========================
 * Lifecycle
 * ========================= */

WrenStatus wren_cache_init(
    LRUCache* cache,
    int capacity
);

void wren_cache_destroy(
    LRUCache* cache
);

/* =========================
 * Core Operations
 * ========================= */

/*
 * Returns:
 *  - data pointer if found
 *  - NULL if not found
 *
 * Side-effect:
 *  - Promotes entry to MRU
 */
void* wren_cache_get(
    LRUCache* cache,
    int product_id
);

/*
 * Inserts or updates entry.
 * Evicts LRU entry when capacity exceeded.
 *
 * NOTE:
 *  - Cache does NOT free `data`
 */
WrenStatus wren_cache_put(
    LRUCache* cache,
    int product_id,
    void* data
);

/* =========================
 * Maintenance
 * ========================= */

/* Clears nodes only (data untouched) */
void wren_cache_clear(
    LRUCache* cache
);

#endif /* WREN_CACHE_H */
