#ifndef WREN_AI_H
#define WREN_AI_H

/*
 * =========================================================
 *  WREN ENGINE – AI REQUEST SYSTEM (PUBLIC API)
 *
 *  Applied:
 *  - Thread-safe queue (optional)
 *  - Clear ownership rules
 *  - Engine-wide types & status codes
 *  - No platform headers leaked
 * =========================================================
 */

#include "wren_common.h"
#include "wren_debug.h"

/* =========================
 * Configuration
 * ========================= */

/*
 * 0 = single-threaded
 * 1 = thread-safe (mutex + condition variable)
 */
#ifndef WREN_AI_THREAD_SAFE
#define WREN_AI_THREAD_SAFE 1
#endif

/* =========================
 * Target Audience
 * ========================= */

typedef enum {
    WREN_AI_AUDIENCE_MEN = 0,
    WREN_AI_AUDIENCE_WOMEN,
    WREN_AI_AUDIENCE_UNISEX,
    WREN_AI_AUDIENCE_CHILDREN
} WrenAIAudience;

/* =========================
 * AI Request
 * ========================= */

typedef struct AIRequest {
    int request_id;

    char prompt[512];
    char style[50];
    char color_scheme[100];

    WrenAIAudience target_audience;

    size_t generated_image_size;
    unsigned char* generated_image;

    struct AIRequest* next;
} AIRequest;

/* =========================
 * AI Request Queue
 * ========================= */

typedef struct {
    AIRequest* head;
    AIRequest* tail;

    int max_concurrent;
    int current_requests;
    bool active;

#if WREN_AI_THREAD_SAFE
    void* _lock;   /* internal mutex */
    void* _cond;   /* internal condition variable */
#endif
} AIRequestQueue;

/* =========================
 * Lifecycle
 * ========================= */

/*
 * Initializes queue and internal sync primitives
 */
WrenStatus wren_ai_queue_init(
    AIRequestQueue* queue,
    int max_concurrent
);

/*
 * Stops queue and releases internal resources
 * Does NOT free pending AIRequest nodes
 */
void wren_ai_queue_shutdown(
    AIRequestQueue* queue
);

/* =========================
 * Queue Operations
 * ========================= */

/*
 * Enqueue AI request
 * Returns WREN_OK or error
 */
WrenStatus wren_ai_enqueue(
    AIRequestQueue* queue,
    AIRequest* request
);

/*
 * Dequeue next AI request
 * Blocks if empty (when thread-safe enabled)
 */
AIRequest* wren_ai_dequeue(
    AIRequestQueue* queue
);

#endif /* WREN_AI_H */
