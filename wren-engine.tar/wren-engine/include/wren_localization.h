#ifndef WREN_LOCALIZATION_H
#define WREN_LOCALIZATION_H

/*
 * =========================================================
 *  WREN ENGINE – LOCALIZATION & CURRENCY (Nigeria)
 *
 *  Responsibilities:
 *  - Nigerian addresses
 *  - Phone validation
 *  - Currency formatting
 * =========================================================
 */

#include "wren_common.h"
#include "wren_debug.h"
#include <stdbool.h>

/* =========================
 * Nigerian Address
 * ========================= */
typedef struct {
    char house_number[20];
    char street[60];
    char area[50];       /* e.g., Victoria Island, Ikeja */
    char landmark[60];   /* e.g., Opposite Eko Hotel */
    char city[30];       /* Usually Lagos */
    char state[30];      /* Usually Lagos State */
    char postal_code[10];
} NigerianAddress;

/* =========================
 * Phone Validation
 * ========================= */

/*
 * Validates standard Nigerian phone numbers:
 *  - 08012345678, +2348012345678, 2348012345678
 */
bool wren_validate_phone(const char* phone);

/* =========================
 * Address Validation
 * ========================= */

/*
 * Returns true if address fields are non-empty and valid
 */
bool wren_validate_address(const NigerianAddress* addr);

/* =========================
 * Address Formatting
 * ========================= */

/*
 * Formats a NigerianAddress into a single line:
 * "12 Bourdillon Rd, Victoria Island, Lagos, Lagos State, 101241"
 */
void wren_format_address(
    const NigerianAddress* addr,
    char* buffer,
    size_t buf_size
);

/* =========================
 * Currency Utilities
 * ========================= */

/*
 * Format Naira to string:
 * e.g., 3200.50 Naira => "₦3,200.50"
 */
void wren_format_naira(
    Naira amount,
    char* buffer,
    size_t buf_size
);

#endif /* WREN_LOCALIZATION_H */
