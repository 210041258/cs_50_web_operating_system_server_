#ifndef WREN_SHIPPING_H
#define WREN_SHIPPING_H

/*
 * =========================================================
 *  WREN ENGINE – SHIPPING & LOGISTICS
 *
 *  Responsibilities:
 *  - Shipping methods (Standard / Express)
 *  - Tracking creation
 *  - Shipping cost calculation
 *  - Destination validation
 * =========================================================
 */

#include "wren_common.h"
#include "wren_localization.h"
#include "wren_debug.h"
#include <stdbool.h>
#include <time.h>

/* =========================
 * Shipping Methods
 * ========================= */
typedef enum {
    SHIPPING_STANDARD = 0,  /* 3–5 days, free */
    SHIPPING_EXPRESS         /* 1–2 days, paid */
} ShippingMethod;

/* =========================
 * Shipping Information
 * ========================= */
typedef struct {
    char tracking_id[20];       /* Unique tracking code */
    ShippingMethod method;      /* Standard or Express */
    NigerianAddress destination;
    WrenTime estimated_delivery;
    WrenTime actual_delivery;
    Naira shipping_cost;        /* Stored in kobo */
    char carrier[30];           /* e.g., DHL, UPS, Local */
} ShippingInfo;

/* =========================
 * Public API
 * ========================= */

/* Create a new shipping info object (caller must free) */
ShippingInfo* wren_shipping_create(
    ShippingMethod method,
    const NigerianAddress* dest
);

/* Calculate shipping cost based on method and destination */
Naira wren_shipping_calculate_cost(
    ShippingMethod method,
    const NigerianAddress* dest
);

/* Validate NigerianAddress for shipping */
bool wren_shipping_validate_address(
    const NigerianAddress* addr
);

/* Generate a unique tracking ID */
void wren_shipping_generate_tracking_id(
    char* buffer,
    size_t buf_size
);

#endif /* WREN_SHIPPING_H */
