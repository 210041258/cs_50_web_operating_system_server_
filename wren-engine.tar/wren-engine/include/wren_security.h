#ifndef WREN_SECURITY_H
#define WREN_SECURITY_H

/*
 * =========================================================
 *  WREN ENGINE – SECURITY MODULE
 *
 *  Responsibilities:
 *  - Transaction verification (COD, Card, Transfer, USSD)
 *  - Optional AES / encryption support (IV stored)
 *  - Review integrity (SHA-256 hash placeholder)
 * =========================================================
 */

#include "wren_common.h"
#include "wren_debug.h"
#include <stdbool.h>
#include <stdint.h>
#include <time.h>

/* =========================
 * Payment Methods
 * ========================= */
typedef enum {
    PAYMENT_COD = 0,
    PAYMENT_CARD,
    PAYMENT_TRANSFER,
    PAYMENT_USSD
} PaymentMethod;

/* =========================
 * Transaction Header
 * ========================= */
typedef struct {
    char transaction_id[32];    /* Unique transaction ID */
    PaymentMethod method;       /* Payment type */
    Naira amount;               /* Stored in kobo */
    WrenTime timestamp;         /* Unix epoch */
    char customer_phone[15];    /* Nigerian phone format */
    uint8_t iv[16];             /* AES Initialization Vector */
} TransactionHeader;

/* =========================
 * Verified Review
 * ========================= */
typedef struct {
    char review_id[20];         /* Unique review ID */
    char user_id[32];           /* User identifier */
    int product_id;             /* Linked product */
    int rating;                 /* 1–5 stars */
    char hash[65];              /* SHA-256 hash */
    bool is_verified;
} VerifiedReview;

/* =========================
 * Public API
 * ========================= */

/* Initialize security module (AES keys, hashes, etc.) */
WrenStatus wren_security_init(void);

/* Secure and verify transactions */
bool wren_verify_transaction(const TransactionHeader* trans);

/* Hash a review content into SHA-256 hash field */
WrenStatus wren_hash_review(VerifiedReview* review, const char* content);

/* Verify review integrity (hash matches content) */
bool wren_verify_review_integrity(const VerifiedReview* review);

#endif /* WREN_SECURITY_H */
