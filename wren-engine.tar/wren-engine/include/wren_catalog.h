#ifndef WREN_CATALOG_H
#define WREN_CATALOG_H

/*
 * =========================================================
 *  WREN ENGINE – PRODUCT CATALOG (PUBLIC API)
 *
 *  Responsibilities:
 *  - Product storage & lookup
 *  - Inventory state
 *  - Price & discount handling
 *
 *  Notes:
 *  - Threading is OPTIONAL and controlled at build time
 *  - No platform-specific headers included here
 * =========================================================
 */

#include "wren_common.h"
#include "wren_debug.h"

/* =========================
 * Configuration
 * ========================= */

/*
 * 0 = single-threaded (fastest)
 * 1 = thread-safe (locks handled internally)
 */
#ifndef WREN_CATALOG_THREAD_SAFE
    #define WREN_CATALOG_THREAD_SAFE 1
#endif

/* =========================
 * Product Structure
 * ========================= */

typedef struct ProductNode {
    int id;
    char name[100];
    char category[30];

    Naira price;
    Naira discount_price;   /* 0.kobo => no discount */

    int stock_count;

    struct ProductNode* next;
} ProductNode;

/* =========================
 * Catalog Structure
 * ========================= */

typedef struct {
    ProductNode* head;
    ProductNode* tail;
    int count;

#if WREN_CATALOG_THREAD_SAFE
    void* _lock;   /* Opaque lock (defined internally) */
#endif
} ProductCatalog;

/* =========================
 * Lifecycle
 * ========================= */

void wren_catalog_init(ProductCatalog* catalog);
void wren_catalog_destroy(ProductCatalog* catalog);

/* =========================
 * CRUD Operations
 * ========================= */

WrenStatus wren_catalog_add(
    ProductCatalog* catalog,
    int id,
    const char* name,
    const char* category,
    Naira price,
    int stock
);

WrenStatus wren_catalog_remove(ProductCatalog* catalog, int id);

ProductNode* wren_catalog_find(
    ProductCatalog* catalog,
    int id
);

/* =========================
 * Inventory & Pricing
 * ========================= */

bool wren_catalog_in_stock(const ProductNode* product);

void wren_catalog_apply_discount(
    ProductNode* product,
    uint8_t percent   /* 0–100 */
);

#endif /* WREN_CATALOG_H */
