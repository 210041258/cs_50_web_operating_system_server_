#ifndef WREN_MEMORY_H
#define WREN_MEMORY_H

/*
 * =========================================================
 *  WREN ENGINE – MEMORY POOL
 *
 *  Features:
 *  - Fixed-size block allocator
 *  - Optional thread-safe mode
 *  - Lock-free option possible via atomics
 *  - Debug and profiling support
 * =========================================================
 */

#include "wren_common.h"
#include "wren_debug.h"
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

/* =========================
 * Configuration
 * ========================= */

/* Enable thread safety for pool operations */
#ifndef WREN_POOL_THREAD_SAFE
#define WREN_POOL_THREAD_SAFE 1
#endif

/* Enable debug tracking */
#ifndef WREN_POOL_DEBUG
#define WREN_POOL_DEBUG 1
#endif

#define WREN_POOL_BLOCK_SIZE 128
#define WREN_POOL_BLOCK_COUNT 500

/* =========================
 * Memory Pool Structure
 * ========================= */

typedef struct MemoryPool {
    uint8_t blocks[WREN_POOL_BLOCK_COUNT][WREN_POOL_BLOCK_SIZE];

    int free_indices[WREN_POOL_BLOCK_COUNT];
    int free_top;

    size_t allocations;   /* total alloc calls */
    size_t frees;         /* total free calls */

#if WREN_POOL_THREAD_SAFE
    void* _lock;          /* opaque lock (mutex/spinlock) */
#endif
} MemoryPool;

/* =========================
 * Public API
 * ========================= */

/* Initialize pool and internal structures */
WrenStatus wren_pool_init(MemoryPool* pool);

/* Allocate a block from the pool */
void* wren_pool_alloc(MemoryPool* pool, size_t size);

/* Free a block back to the pool */
void wren_pool_free(MemoryPool* pool, void* ptr);

/* =========================
 * Debug / Statistics Utilities
 * ========================= */

/* Returns number of used blocks */
static inline size_t wren_pool_used(const MemoryPool* pool) {
    return pool->allocations - pool->frees;
}

/* Returns number of free blocks */
static inline size_t wren_pool_free_count(const MemoryPool* pool) {
    return pool->free_top + 1;
}

#endif /* WREN_MEMORY_H */
