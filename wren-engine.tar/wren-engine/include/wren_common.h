#ifndef WREN_COMMON_H
#define WREN_COMMON_H

/*
 * =========================================================
 *  WREN ENGINE – COMMON TYPES & UTILITIES
 *
 *  Purpose:
 *  - Shared, lightweight definitions used across all modules
 *  - NO heavy system headers
 *  - NO threading, IO, or platform-specific code
 *
 *  MUST remain stable and minimal.
 * =========================================================
 */

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <time.h>

/* =========================
 * Versioning
 * ========================= */
#define WREN_VERSION_MAJOR 1
#define WREN_VERSION_MINOR 0
#define WREN_VERSION_PATCH 0

/* =========================
 * Engine Status Codes
 * ========================= */
typedef enum {
    WREN_OK = 0,
    WREN_ERR_INVALID_ARG,
    WREN_ERR_OUT_OF_MEMORY,
    WREN_ERR_NOT_FOUND,
    WREN_ERR_IO,
    WREN_ERR_SECURITY,
    WREN_ERR_INTERNAL
} WrenStatus;

/* =========================
 * Currency (Nigeria-safe)
 * ========================= */
/*
 * Stored in kobo to avoid floating-point precision issues
 * 100 kobo = 1 naira
 */
typedef struct {
    uint64_t kobo;
} Naira;

/* =========================
 * Time Helpers
 * ========================= */
typedef time_t WrenTime;

/* =========================
 * Forward Declarations
 * ========================= */
struct ProductNode;
struct ProductCatalog;
struct AIRequest;
struct AIRequestQueue;
struct MemoryPool;
struct LRUCache;

/* =========================
 * Utility Macros
 * ========================= */
#define WREN_ARRAY_SIZE(x)  (sizeof(x) / sizeof((x)[0]))
#define WREN_UNUSED(x)      ((void)(x))
#define WREN_MIN(a,b)       (((a)<(b))?(a):(b))
#define WREN_MAX(a,b)       (((a)>(b))?(a):(b))

/* =========================
 * Compile-Time Platform Detection
 * ========================= */

#if defined(_WIN32) || defined(_WIN64)
    #define WREN_PLATFORM_WINDOWS 1
#else
    #define WREN_PLATFORM_WINDOWS 0
#endif

#if defined(__linux__)
    #define WREN_PLATFORM_LINUX 1
#else
    #define WREN_PLATFORM_LINUX 0
#endif

#if defined(__APPLE__)
    #define WREN_PLATFORM_APPLE 1
#else
    #define WREN_PLATFORM_APPLE 0
#endif

/* =========================
 * Compiler Detection
 * ========================= */

#if defined(__clang__)
    #define WREN_COMPILER_CLANG 1
#else
    #define WREN_COMPILER_CLANG 0
#endif

#if defined(__GNUC__) && !defined(__clang__)
    #define WREN_COMPILER_GCC 1
#else
    #define WREN_COMPILER_GCC 0
#endif

#if defined(_MSC_VER)
    #define WREN_COMPILER_MSVC 1
#else
    #define WREN_COMPILER_MSVC 0
#endif

/* =========================
 * Architecture
 * ========================= */
#if defined(__x86_64__) || defined(_M_X64) || defined(_M_AMD64)
    #define WREN_ARCH_64 1
#else
    #define WREN_ARCH_64 0
#endif

#endif /* WREN_COMMON_H */
