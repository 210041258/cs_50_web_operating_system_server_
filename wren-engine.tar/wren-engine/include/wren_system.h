#ifndef WREN_SYSTEM_H
#define WREN_SYSTEM_H

/*
 * =========================================================
 *  WREN ENGINE – SYSTEM MODULE
 *
 *  Responsibilities:
 *  - System initialization / shutdown
 *  - Logging and event tracking
 *  - Thread pool management
 *  - AI request queue integration
 *  - Inventory load/save
 * =========================================================
 */

#include "wren_common.h"
#include "wren_debug.h"
#include "wren_catalog.h"
#include "wren_ai.h"
#include <stdbool.h>

/* =========================
 * Logging
 * ========================= */
typedef enum {
    WREN_LOG_INFO = 0,
    WREN_LOG_WARN,
    WREN_LOG_ERROR
} WrenLogLevel;

/* Log a system event */
void wren_log_event(const char* event, WrenLogLevel level);

/* =========================
 * System Lifecycle
 * ========================= */

/* Initialize engine (memory pools, AI queue, threads, etc.) */
WrenStatus wren_system_init(void);

/* Shutdown engine and cleanup resources */
void wren_system_shutdown(void);

/* =========================
 * Thread Pool Management
 * ========================= */

/* Initialize internal thread pool (number of worker threads) */
WrenStatus wren_thread_pool_init(int num_threads);

/* Submit a task to the internal thread pool */
WrenStatus wren_thread_pool_submit(void* (*task)(void*), void* arg);

/* Cleanup thread pool resources */
void wren_thread_pool_cleanup(void);

/* =========================
 * Inventory Management
 * ========================= */

/* Load inventory from file into catalog */
WrenStatus wren_load_inventory(ProductCatalog* catalog, const char* filename);

/* Save inventory from catalog into file */
WrenStatus wren_save_inventory(ProductCatalog* catalog, const char* filename);

#endif /* WREN_SYSTEM_H */
