# Wren Engine Module Implementation Roadmap

This document outlines the next steps for implementing the Wren Engine modules. Headers define APIs, but logic is still needed in the corresponding `.c` source files.

## 1️⃣ Implement Source Files (.c) for All Modules

| Module               | Next Implementation Tasks                                                                                      |
|----------------------|---------------------------------------------------------------------------------------------------------------|
| **wren_memory.c**        | Thread-safe memory pool, optional lock-free mode, debug logging for allocations/frees                        |
| **wren_cache.c**         | LRU cache logic, optional thread-safe mutex or lock-free atomics, integrate WREN_DEBUG logs                  |
| **wren_catalog.c**       | Linked-list operations: init, add, remove, find, search; sorting and flash sale support                      |
| **wren_localization.c**  | Phone/address validation and formatting; use WREN_ASSERT and WREN_DEBUG                                      |
| **wren_security.c**      | Implement `wren_security_init`, transaction verification, review hash verification (SHA-256 placeholders)     |
| **wren_ai.c**            | AI request queue: enqueue/dequeue, thread-safe, optional max concurrency, integrate with thread pool         |
| **wren_shipping.c**      | Create, calculate_cost, validate_address, and generate_tracking_id functions                                 |
| **wren_system.c**        | Engine init/shutdown, thread pool, task submission, inventory load/save, logging with levels                 |

## 2️⃣ Integrate `wren_debug.h` Across All Modules

- Add debug logs at function entry/exit, critical operations, and error cases.
- Use `WREN_ASSERT` for pointer, count, and critical assumption checks.
- Use `WREN_FATAL` for unrecoverable errors (e.g., out-of-memory).

## 3️⃣ Unit Tests (`tests/`)

After implementing `.c` files, add unit tests for every module:

- `test_memory.c`: alloc/free, pool exhaustion, thread safety
- `test_cache.c`: LRU insertions, eviction, thread safety
- `test_catalog.c`: add/find/remove/search/sort/flash sale
- `test_localization.c`: address/phone validation, formatting
- `test_security.c`: transaction and review integrity
- `test_shipping.c`: shipping creation, validation, cost calculation
- `test_system.c`: init/shutdown, thread pool, AI queue

## 4️⃣ Optional Advanced Updates

- Lock-free memory pool (atomic operations)
- AI request prioritization (urgent vs normal)
- Persistent inventory (JSON/Binary file format)
- Platform detection macros (`#ifdef _WIN32`, etc.)
- Logging to file/rotation (not just stderr)

---

### ✅ Suggested Update Sequence

1. `wren_debug.h` (done)
2. Implement `wren_memory.c` (critical for other modules)
3. Implement `wren_cache.c` (depends on memory)
4. Implement `wren_catalog.c` (uses memory, cache)
5. Implement `wren_localization.c` (standalone)
6. Implement `wren_security.c` (standalone)
7. Implement `wren_shipping.c` (uses localization & currency)
8. Implement `wren_ai.c` (thread-safe queue + memory)
9. Implement `wren_system.c` (ties all modules together)
10. Unit tests for all modules
 