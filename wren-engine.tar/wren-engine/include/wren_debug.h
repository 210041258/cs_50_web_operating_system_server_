#ifndef WREN_DEBUG_H
#define WREN_DEBUG_H

/*
 * =========================================================
 *  WREN ENGINE – DEBUG / ASSERT UTILITIES
 *
 *  Purpose:
 *  - Engine-wide assert and debug macros
 *  - Optional runtime logging
 *  - Configurable: enable/disable debug in production
 * =========================================================
 */

#include "wren_common.h"
#include <stdio.h>
#include <stdlib.h>

/* =========================
 * Configuration
 * ========================= */

/* Enable debug logging (set to 0 to disable in production) */
#ifndef WREN_DEBUG_ENABLED
#define WREN_DEBUG_ENABLED 1
#endif

/* Enable assert checks (set to 0 to disable) */
#ifndef WREN_ASSERT_ENABLED
#define WREN_ASSERT_ENABLED 1
#endif

/* =========================
 * Debug Logging Macro
 * ========================= */

#if WREN_DEBUG_ENABLED
#define WREN_DEBUG(fmt, ...) \
    do { \
        fprintf(stderr, "[WREN DEBUG] %s:%d: " fmt "\n", \
                __FILE__, __LINE__, ##__VA_ARGS__); \
    } while (0)
#else
#define WREN_DEBUG(fmt, ...) do { } while (0)
#endif

/* =========================
 * Assert Macro
 * ========================= */

#if WREN_ASSERT_ENABLED
#define WREN_ASSERT(expr) \
    do { \
        if (!(expr)) { \
            fprintf(stderr, "[WREN ASSERT FAILED] %s:%d: %s\n", \
                    __FILE__, __LINE__, #expr); \
            abort(); \
        } \
    } while (0)
#else
#define WREN_ASSERT(expr) do { (void)(expr); } while (0)
#endif

/* =========================
 * Fatal Error Macro
 * ========================= */
#define WREN_FATAL(msg) \
    do { \
        fprintf(stderr, "[WREN FATAL] %s:%d: %s\n", __FILE__, __LINE__, msg); \
        abort(); \
    } while (0)

#endif /* WREN_DEBUG_H */
