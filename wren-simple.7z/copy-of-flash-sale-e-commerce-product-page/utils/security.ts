/**
 * Security Utilities
 * Provides input sanitization and validation to prevent common web vulnerabilities (XSS, Injection).
 */

/**
 * Escape map and single-regex replacement for HTML escaping.
 * Always returns a string.
 */
export const escapeHtml = (value: unknown): string => {
  if (value === null || value === undefined) return "";
  const str = String(value).trim(); // guarantee string
  // map of chars to entity equivalents
  const map: Record<string, string> = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;",
    "/": "&#x2F;" // optional: helps avoid closing tags in some cases
  };
  // replace all occurrences in a single pass
  return str.replace(/[&<>"'\/]/g, (ch) => map[ch]);
};

/**
 * Alias for backward compatibility with components using sanitizeInput
 */
export const sanitizeInput = escapeHtml;

/**
 * Strip HTML tags (useful if you want to remove all HTML instead of escaping).
 * Note: naive — won't handle malformed HTML perfectly; use a parser (DOMParser) or DOMPurify if available.
 */
export const stripHtmlTags = (value: unknown): string => {
  const str = String(value ?? "");
  // Remove tags and entities left by mistake, then trim
  return str.replace(/<\/?[^>]+(>|$)/g, "").trim();
};

/**
 * Validate email format (improved):
 * - Normalizes by trimming and lower-casing local part/domain-only for comparison.
 * - Uses a commonly used (but not perfect) regex - good for client-side validation.
 * For highest reliability combine with server-side verification or a validator library.
 */
export const validateEmail = (email: string): boolean => {
  if (!email || typeof email !== "string") return false;
  const normalized = email.trim();
  // This regex is intentionally conservative & simple. For strict RFC compliance use a library.
  const re =
    /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return re.test(normalized);
};

/**
 * Stronger password validator with options:
 * - minLength: minimum characters
 * - requireUppercase, requireLowercase, requireNumber, requireSpecial
 *
 * Returns { valid, reasons } for better UX messages.
 */
export const validatePassword = (
  password: string,
  options?: {
    minLength?: number;
    requireUppercase?: boolean;
    requireLowercase?: boolean;
    requireNumber?: boolean;
    requireSpecial?: boolean;
  }
): { valid: boolean; reasons: string[] } => {
  const {
    minLength = 8,
    requireUppercase = true,
    requireLowercase = true,
    requireNumber = true,
    requireSpecial = false
  } = options ?? {};

  const reasons: string[] = [];
  if (typeof password !== "string") {
    reasons.push("Password must be a string.");
    return { valid: false, reasons };
  }

  if (password.length < minLength) {
    reasons.push(`Password must be at least ${minLength} characters.`);
  }
  if (requireUppercase && !/[A-Z]/.test(password)) {
    reasons.push("Include at least one uppercase letter.");
  }
  if (requireLowercase && !/[a-z]/.test(password)) {
    reasons.push("Include at least one lowercase letter.");
  }
  if (requireNumber && !/[0-9]/.test(password)) {
    reasons.push("Include at least one number.");
  }
  if (requireSpecial && !/[^\w\s]/.test(password)) {
    reasons.push("Include at least one special character.");
  }

  // Example additional check: avoid extremely common passwords (replace with a better list in prod)
  const common = ["123456", "password", "qwerty", "letmein"];
  if (common.includes(password.toLowerCase())) {
    reasons.push("Password is too common.");
  }

  return { valid: reasons.length === 0, reasons };
};
