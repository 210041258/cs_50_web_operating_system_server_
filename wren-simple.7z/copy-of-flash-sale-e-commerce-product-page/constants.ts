import React from 'react';
import type { Product, Review, PageContent, ShopProduct } from './types';

// Delivery Options
export const DELIVERY_OPTIONS = [
    { 
      id: 'standard', 
      label: 'Standard Shipping', 
      description: '3-5 business days',
      cost: 0 
    },
    { 
      id: 'express', 
      label: 'Express Shipping', 
      description: '1-2 business days',
      cost: 1500 
    },
];

// Product Data
export const PRODUCT_DATA: Product = {
  id: 1,
  category: "Women's Sandals",
  name: "Wren Black Leather Casual Sandals",
  description: "Experience the perfect blend of style and comfort with the Wren Black Leather Casual Sandals. Meticulously handcrafted from premium full-grain calfskin, these sandals are designed to provide all-day support without compromising on elegance.",
  highlights: [
    "Handcrafted from 100% Full-Grain Calfskin",
    "Ergonomic Memory Foam Insole for Max Comfort",
    "Lightweight & Anti-Slip TPR Outsole",
    "Water-Resistant Coating for Longevity"
  ],
  rating: 4.5,
  reviewCount: 128,
  inStock: true,
  originalPrice: 2950,
  salePrice: 1770,
  salePercentage: 40,
  images: [
    { 
      id: 1, 
      thumbnail: "https://picsum.photos/id/1060/100/100", 
      full: "https://picsum.photos/id/1060/600/600", 
      alt: "Black leather sandals front view" 
    },
    { 
      id: 2, 
      thumbnail: "https://picsum.photos/id/1061/100/100", 
      full: "https://picsum.photos/id/1061/600/600", 
      alt: "Black leather sandals side view" 
    },
    { 
      id: 3, 
      thumbnail: "https://picsum.photos/id/1062/100/100", 
      full: "https://picsum.photos/id/1062/600/600", 
      alt: "Black leather sandals back view" 
    },
    { 
      id: 4, 
      thumbnail: "https://picsum.photos/id/211/100/100", 
      full: "https://picsum.photos/id/211/600/600", 
      alt: "Person wearing black leather sandals" 
    },
  ],
  specifications: [
    { 
      icon: "fa-solid fa-palette", 
      label: "Color", 
      value: "Black", 
      valueComponent: React.createElement('div', { 
        className: "w-5 h-5 bg-black rounded-full border border-gray-300",
        title: "Black",
        'aria-label': "Black color swatch"
      }) 
    },
    { 
      icon: "fa-solid fa-gem", 
      label: "Material", 
      value: "Genuine Leather" 
    },
    { 
      icon: "fa-solid fa-ruler-horizontal", 
      label: "Size", 
      value: "38-45" 
    },
    { 
      icon: "fa-solid fa-certificate", 
      label: "Condition", 
      value: "Brand New" 
    },
    { 
      icon: "fa-solid fa-tag", 
      label: "Brand", 
      value: "Wren" 
    },
    { 
      icon: "fa-solid fa-shoe-prints", 
      label: "Style", 
      value: "Casual" 
    },
  ],
};

// Reviews Data
export const REVIEWS_DATA: Review[] = [
  {
    id: 1,
    rating: 5,
    author: "Amina Yusuf",
    date: "Verified Purchase • August 2024",
    text: "Absolutely love these sandals! The comfort level surprised me — I wore them the whole day without any discomfort. The stitching and leather quality feel premium. They look even better in real life than in the photos."
  },
  {
    id: 2,
    rating: 4.5,
    author: "Chinedu Okafor",
    date: "Customer Review • August 2024",
    text: "Very comfortable and lightweight. Perfect for long walks and casual outings. Delivery was slightly delayed, but the packaging was neat and the sandals were worth the wait."
  },
  {
    id: 3,
    rating: 5,
    author: "Fatima Bello",
    date: "Verified Buyer • July 2024",
    text: "The design is simple but elegant. I appreciate the soft inner sole — it makes a big difference. I've used them daily for a week now and they still look brand new."
  },
  {
    id: 4,
    rating: 4,
    author: "Omar Hassan",
    date: "Purchase Confirmed • July 2024",
    text: "Good quality for the price. The fit was slightly snug at first, but after a day of use they adjusted well. Overall a solid purchase."
  },
  {
    id: 5,
    rating: 5,
    author: "Zainab Ali",
    date: "Verified Order • June 2024",
    text: "Super stylish and surprisingly durable. I've worn them on different surfaces and they hold up really well. Definitely ordering another pair in a different color."
  },
  {
    id: 6,
    rating: 4.5,
    author: "Yusuf Ibrahim",
    date: "Satisfied Customer • June 2024",
    text: "Comfortable right out of the box — no break-in period needed. The sole grip is good, even on smooth floors. Would recommend to anyone looking for everyday sandals."
  }
];

// Helper function to create React elements safely in .ts files
const createElement = (
  tag: string, 
  props: Record<string, any> | null, 
  ...children: any[]
) => React.createElement(tag, props, ...children);


// Contact Us content
const contactUsContent = createElement('div', { className: "space-y-4" },
  createElement('p', null, "We're here to help! Reach out to us through any of the following channels:"),
  createElement('ul', { className: "space-y-2 list-disc list-inside" },
    createElement('li', null, 
      createElement('strong', null, "Email:"), " ",
      createElement('a', { 
        href: "mailto:support@wren.com", 
        className: "text-red-600 hover:underline" 
      }, "support@wren.com"),
      " (Replies within 24 hours)"
    ),
    createElement('li', null, 
      createElement('strong', null, "Phone:"), 
      " +234-800-123-4567 (Mon-Fri, 9am - 5pm)"
    ),
    createElement('li', null, 
      createElement('strong', null, "Live Chat:"), 
      " Click the chat icon at the bottom right of our main website."
    )
  )
);

// FAQ content
const faqContent = createElement('div', { className: "space-y-4" },
  createElement('div', null,
    createElement('h4', { className: "font-semibold" }, "What are my payment options?"),
    createElement('p', null, 
      "We accept Cash on Delivery, Credit/Debit Cards (Visa, Mastercard), " +
      "and direct Bank Transfers."
    )
  ),
  createElement('div', null,
    createElement('h4', { className: "font-semibold" }, "How long does delivery take?"),
    createElement('p', null, "Standard delivery takes 3-5 business days nationwide.")
  ),
  createElement('div', null,
    createElement('h4', { className: "font-semibold" }, "What is your return policy?"),
    createElement('p', null, 
      "We offer a 30-day hassle-free return policy for unworn items in their original packaging."
    )
  )
);

// Terms of Service content
const termsContent = createElement('div', { className: "space-y-4 text-xs" },
  createElement('p', null, 
    "Welcome to Wren. By accessing our website, creating an account, or purchasing from our store, " +
    "you agree to comply with and be legally bound by the terms and conditions outlined here. " +
    "These Terms of Service govern your use of our platform, and we encourage you to review them carefully."
  ),
  createElement('p', null, 
    "We reserve the right to decline service, suspend or terminate user accounts, restrict access, " +
    "or cancel orders at our sole discretion. Such actions may be taken if we believe user activity " +
    "violates these terms, applicable laws, or disrupts the integrity, security, or operation of our services."
  ),
  createElement('p', null, 
    "All materials presented on this website — including but not limited to product images, " +
    "graphics, branding elements, written content, layout design, and logos — are the intellectual " +
    "property of Wren Inc. or its content suppliers. These materials are protected under international " +
    "copyright, trademark, and intellectual property regulations."
  ),
  createElement('p', null, 
    "You may not reproduce, distribute, modify, display, transmit, republish, or otherwise " +
    "exploit any content from this site without prior written permission. Unauthorized use of " +
    "our materials may result in legal action and termination of your access to our services."
  ),
  createElement('p', null, 
    "We strive to ensure that all information on our website is accurate and up to date; however, " +
    "we do not guarantee that product descriptions, pricing details, availability, or other content " +
    "is free from errors. We reserve the right to correct inaccuracies, update information, " +
    "or modify offerings at any time without prior notice."
  ),
  createElement('p', null, 
    "By continuing to use our services, you acknowledge that your use of the website is at your own risk. " +
    "Wren shall not be held liable for any indirect, incidental, or consequential damages arising from " +
    "the use of our platform, to the extent permitted by applicable law."
  )
);

// Privacy Policy content
const privacyContent = createElement('div', { className: "space-y-4 text-xs" },
  createElement('p', null, 
    "We recognize the importance of your privacy and are committed to protecting the personal " +
    "information you share with us while using our website. This policy describes how data is " +
    "collected, handled, and secured to maintain a safe and trustworthy experience for all users."
  ),
  createElement('p', null, 
    "When you place an order, register an account, or communicate with our support team, " +
    "we may collect certain personal details such as your name, email address, contact information, " +
    "and delivery address. This information is used strictly for operational purposes, including " +
    "order processing, service communication, and improving the overall functionality of our store."
  ),
  createElement('p', null, 
    "We do not sell, trade, or distribute your personal data to external organizations. " +
    "In some situations, limited information may be shared with trusted service providers " +
    "like payment processors or shipping partners, but only when necessary to complete a transaction " +
    "or deliver a service on our behalf."
  ),
  createElement('p', null, 
    "To keep your sensitive information secure, our systems use modern protection measures " +
    "such as encrypted connections and secure data handling practices. These safeguards help " +
    "reduce risks related to unauthorized access, misuse, or data exposure."
  ),
  createElement('p', null, 
    "We may also gather non-personal technical details, including browser type, device information, " +
    "and general interaction patterns. This data helps us analyze site performance, detect " +
    "technical issues, and enhance user experience without identifying individual visitors."
  ),
  createElement('p', null, 
    "You remain in control of your information. If you wish to update, correct, or request " +
    "deletion of your personal data, you can contact us through our support channels, " +
    "and we will handle your request in line with responsible data practices."
  )
);

// Page Content Definitions
export const PAGE_CONTENT: Record<string, PageContent> = {
  'contact-us': { 
    title: 'Contact Us', 
    content: contactUsContent 
  },
  'faqs': { 
    title: 'Frequently Asked Questions', 
    content: faqContent 
  },
  'shipping': { 
    title: 'Shipping Information',
    content: createElement('div', { className: "space-y-4" },
      createElement('p', null, 
        "We are pleased to offer ", 
        createElement('strong', null, "FREE"), 
        " standard shipping on all orders across the country."
      ),
      createElement('p', null, 
        "Orders are processed within 1 business day. You will receive a tracking number via email " +
        "once your order has been shipped. Please allow 3-5 business days for your order to arrive."
      )
    ),
  },
  'returns': { 
    title: 'Returns Policy',
    content: createElement('div', { className: "space-y-4" },
      createElement('p', null, 
        "Your satisfaction is our priority. If you're not completely happy with your purchase, " +
        "you can return it within 30 days of delivery."
      ),
      createElement('p', null, 
        "To be eligible for a return, your item must be unused, in the same condition that you " +
        "received it, and in its original packaging. To initiate a return, please contact our support team."
      )
    ),
  },
  'about-us': { 
    title: 'About Wren',
    content: createElement('div', { className: "space-y-4" },
      createElement('p', null, 
        "Founded on the principle of stylish comfort, Wren is dedicated to crafting " +
        "high-quality leather sandals that you can wear all day, every day. We believe that " +
        "you shouldn't have to choose between looking good and feeling good."
      ),
      createElement('p', null, 
        "Our sandals are designed with passion and made from carefully sourced, " +
        "premium materials to ensure durability and a perfect fit."
      )
    ),
  },
  'careers': { 
    title: 'Careers at Wren',
    content: createElement('div', { className: "space-y-4" },
      createElement('p', null, 
        "Join a passionate team dedicated to redefining comfort and style. " +
        "We're always looking for talented individuals to join our family."
      ),
      createElement('p', null, 
        "While we have no open positions at the moment, we encourage you to send your resume to ",
        createElement('a', { 
          href: "mailto:careers@wren.com", 
          className: "text-red-600 hover:underline" 
        }, "careers@wren.com"),
        " for future consideration."
      )
    ),
  },
  'terms-of-service': { 
    title: 'Terms of Service', 
    content: termsContent 
  },
  'privacy-policy': { 
    title: 'Privacy Policy', 
    content: privacyContent 
  },
};

// Fictional Shop Products for Modals
export const SHOP_PRODUCTS: ShopProduct[] = [
  { id: 101, name: 'Aria Suede Loafers', price: 3200, image: 'https://picsum.photos/id/237/400/400', category: 'womens-shoes', isNew: true },
  { id: 102, name: 'Celeste Summer Wedges', price: 2800, image: 'https://picsum.photos/id/238/400/400', category: 'sandals', isNew: true },
  { id: 103, name: 'Nova Running Sneakers', price: 4500, image: 'https://picsum.photos/id/239/400/400', category: 'womens-shoes', isNew: true },
  { id: 104, name: 'Luna Beach Flip-Flops', price: 1500, image: 'https://picsum.photos/id/240/400/400', category: 'sandals' },
  { id: 105, name: 'Helia Classic Pumps', price: 3800, image: 'https://picsum.photos/id/241/400/400', category: 'womens-shoes' },
  { id: 106, name: 'Orion Leather Slides', price: 2200, image: 'https://picsum.photos/id/242/400/400', category: 'sandals' },
  { id: 107, name: 'Terra Hiking Sandals', price: 3100, originalPrice: 4000, image: 'https://picsum.photos/id/243/400/400', category: 'sandals' },
  { id: 108, name: 'Ivy Ankle Boots', price: 4200, originalPrice: 5500, image: 'https://picsum.photos/id/244/400/400', category: 'womens-shoes' },
];