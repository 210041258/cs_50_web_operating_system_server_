import React from 'react';
import { Icon } from './Icon';

const featureData = [
  { icon: 'fa-solid fa-medal', title: 'Premium Quality', description: 'Crafted from the finest genuine leather for durability and comfort.' },
  { icon: 'fa-solid fa-shipping-fast', title: 'Free Shipping', description: 'Enjoy complimentary shipping on all orders nationwide.' },
  { icon: 'fa-solid fa-right-left', title: 'Easy Returns', description: '30-day hassle-free return policy if you are not satisfied.' },
  { icon: 'fa-solid fa-headset', title: '24/7 Support', description: 'Our customer service team is here to help you around the clock.' }
];

export const Features: React.FC = () => {
  return (
    <section className="py-16 bg-white mt-12 rounded-lg shadow-md">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-montserrat font-bold text-center text-gray-900 mb-10">Why Choose Wren Sandals?</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {featureData.map(feature => (
            <div key={feature.title} className="text-center p-6 bg-gray-50 rounded-lg transition-all duration-300 hover:bg-white hover:shadow-xl hover:-translate-y-2 border border-transparent hover:border-red-100 group cursor-default">
              <Icon name={feature.icon} className="text-4xl text-red-600 mb-4 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-6" />
              <h3 className="text-lg font-semibold mb-2 group-hover:text-red-700 transition-colors">{feature.title}</h3>
              <p className="text-sm text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};