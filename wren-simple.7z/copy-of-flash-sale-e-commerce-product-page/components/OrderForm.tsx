import React, { useState, useMemo, useEffect, useRef } from 'react';
import type { FormData } from '../types';
import { Icon } from './Icon';
import { DELIVERY_OPTIONS } from '../constants';

interface OrderFormProps {
    productSalePrice: number;
    quantity: number;
    setQuantity: React.Dispatch<React.SetStateAction<number>>;
    onOrderSubmit: (formData: FormData, totalPrice: number) => void;
    onLinkClick: (page: string) => void;
    onAddToCart: (quantity: number) => void;
}

interface InputFieldProps {
    id: string;
    label: string;
    type: string;
    placeholder: string;
    value: string;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    error?: string;
}

const InputField: React.FC<InputFieldProps> = ({id, label, type, placeholder, value, onChange, error}) => (
    <div>
        <label htmlFor={id} className="block text-sm font-semibold text-gray-700 mb-1.5 ml-1">{label}</label>
        <input 
            type={type} 
            id={id} 
            name={id} 
            value={value} 
            onChange={onChange} 
            placeholder={placeholder} 
            required 
            className={`w-full px-4 py-3 border rounded-lg shadow-sm text-gray-900 placeholder-gray-400 bg-white transition-all duration-200 ease-in-out focus:outline-none focus:ring-4 ${error 
                ? 'border-red-300 focus:border-red-500 focus:ring-red-100 hover:border-red-400' 
                : 'border-gray-200 hover:border-gray-400 focus:border-red-500 focus:ring-red-50'
            }`} 
        />
        {error && <p className="text-red-600 text-xs mt-1.5 ml-1 flex items-center gap-1"><Icon name="fa-solid fa-circle-exclamation" /> {error}</p>}
    </div>
);


export const OrderForm: React.FC<OrderFormProps> = ({ productSalePrice, quantity, setQuantity, onOrderSubmit, onLinkClick, onAddToCart }) => {
  const [formData, setFormData] = useState<FormData>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    paymentMethod: 'cod',
    deliveryMethod: 'standard',
    termsAccepted: false,
    newsletterSubscribed: false
  });
  
  const [errors, setErrors] = useState<Partial<Record<keyof FormData, string>>>({});
  const [isAnimating, setIsAnimating] = useState(false);
  const [isAddedToWishlist, setIsAddedToWishlist] = useState(false);
  const [isAddedToCart, setIsAddedToCart] = useState(false);
  const isInitialMount = useRef(true);
  const [addressSuggestions, setAddressSuggestions] = useState<any[]>([]);
  const [isSearchingAddress, setIsSearchingAddress] = useState(false);

  const totalPrice = useMemo(() => {
    const deliveryCost = DELIVERY_OPTIONS.find(opt => opt.id === formData.deliveryMethod)?.cost || 0;
    return (productSalePrice * quantity) + deliveryCost;
  }, [productSalePrice, quantity, formData.deliveryMethod]);

  useEffect(() => {
    if (isInitialMount.current) {
        isInitialMount.current = false;
        return;
    }
    setIsAnimating(true);
    const timer = setTimeout(() => setIsAnimating(false), 200); // Duration matches transition
    return () => clearTimeout(timer);
  }, [quantity]);

  // Debounced address search
  useEffect(() => {
    const handler = setTimeout(async () => {
        if (formData.address.length > 2) {
            setIsSearchingAddress(true);
            setAddressSuggestions([]);
            try {
                const response = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(formData.address)}&format=json&addressdetails=1&limit=5`);
                if (!response.ok) throw new Error('Network response was not ok');
                const data = await response.json();
                setAddressSuggestions(data);
            } catch (error) {
                console.error("Failed to fetch address suggestions:", error);
                setAddressSuggestions([]);
            } finally {
                setIsSearchingAddress(false);
            }
        } else {
            setAddressSuggestions([]);
        }
    }, 500); // 500ms debounce

    return () => {
        clearTimeout(handler);
    };
}, [formData.address]);


  const getValidationError = (name: keyof FormData, value: string | boolean): string => {
    switch (name) {
        case 'firstName':
            if (typeof value === 'string' && !value.trim()) return "First name is required.";
            break;
        case 'lastName':
            if (typeof value === 'string' && !value.trim()) return "Last name is required.";
            break;
        case 'email':
            if (typeof value === 'string' && !value.trim()) {
                return "Email is required.";
            } else if (typeof value === 'string' && !/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(value)) {
                return "Invalid email format. Please use a valid address (e.g., name@domain.com).";
            }
            break;
        case 'phone':
            if (typeof value === 'string' && !value.trim()) {
                return "Phone number is required.";
            } else if (typeof value === 'string' && !/^\+?[\d\s\-()]{7,20}$/.test(value)) {
                return "Invalid phone number. Please enter a valid number (e.g., +234 801 234 5678).";
            }
            break;
        case 'address':
            if (typeof value === 'string' && !value.trim()) return "Delivery address is required.";
            break;
        case 'termsAccepted':
             if (value === false) return "You must accept the terms and conditions.";
             break;
    }
    return ''; // No error
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    const error = getValidationError(name as keyof FormData, value);
    setErrors(prev => ({ ...prev, [name]: error }));
  };
  
  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData(prev => ({ ...prev, [name]: checked }));
    if (name === 'termsAccepted') {
        const error = getValidationError(name as keyof FormData, checked);
        setErrors(prev => ({ ...prev, [name]: error }));
    }
  };

  const handleSuggestionClick = (suggestion: any) => {
    const fullAddress = suggestion.display_name;
    setFormData(prev => ({ ...prev, address: fullAddress }));
    setAddressSuggestions([]); // Hide suggestions after selection
    setErrors(prev => ({ ...prev, address: '' })); // Clear error on selection
  };
  
  const handleAddressBlur = (e: React.FocusEvent<HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    // Validate the field on blur
    const error = getValidationError(name as keyof FormData, value);
    setErrors(prev => ({ ...prev, [name]: error }));

    // Hide the suggestions dropdown, with a small delay to allow for clicks on suggestions
    setTimeout(() => {
      setAddressSuggestions([]);
    }, 150);
  };

  const validateForm = () => {
      const newErrors: Partial<Record<keyof FormData, string>> = {};
      (Object.keys(formData) as Array<keyof FormData>).forEach(key => {
          const error = getValidationError(key, formData[key]);
          if (error) {
              newErrors[key] = error;
          }
      });
      
      setErrors(newErrors);
      return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
        onOrderSubmit(formData, totalPrice);
        setFormData({
             firstName: '', lastName: '', email: '', phone: '', address: '',
             paymentMethod: 'cod', deliveryMethod: 'standard', termsAccepted: false, newsletterSubscribed: false
        });
        setErrors({});
    }
  };

  const handleAddToWishlist = () => {
    console.log(`Added ${quantity} item(s) to wishlist.`);
    setIsAddedToWishlist(true);
    setTimeout(() => setIsAddedToWishlist(false), 2000);
  };

  const handleAddToCart = () => {
    onAddToCart(quantity);
    setIsAddedToCart(true);
    setTimeout(() => setIsAddedToCart(false), 2000);
  };

  return (
    <form onSubmit={handleSubmit} className="border-t border-gray-200 pt-6 space-y-6">
        {/* Quantity and Total */}
        <div className="flex justify-between items-center gap-4">
            <div className="flex items-center gap-2">
                <label className="font-semibold text-gray-800">Quantity:</label>
                <div className="flex items-center border border-gray-300 rounded-lg overflow-hidden shadow-sm">
                    <button type="button" onClick={() => setQuantity(q => Math.max(1, q - 1))} className="px-4 py-2 text-lg hover:bg-gray-100 transition-colors border-r border-gray-200 bg-gray-50">-</button>
                    <input 
                        type="text" 
                        readOnly 
                        value={quantity} 
                        className={`w-14 text-center font-semibold transition-all duration-200 transform ${isAnimating ? 'scale-125 text-red-600 bg-red-50' : 'scale-100 bg-white text-gray-900'}`} 
                    />
                    <button type="button" onClick={() => setQuantity(q => q + 1)} className="px-4 py-2 text-lg hover:bg-gray-100 transition-colors border-l border-gray-200 bg-gray-50">+</button>
                </div>
            </div>
            <div className="text-right">
                <span className="text-sm text-gray-500 block mb-1">Total Price</span>
                <p className="font-bold text-3xl text-red-700">₦{totalPrice.toLocaleString()}</p>
            </div>
        </div>
        
        {/* Personal Info */}
        <div className="space-y-5">
            <h3 className="font-bold text-xl text-gray-800 border-b pb-2">Personal Information</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <InputField id="firstName" label="First Name" type="text" placeholder="John" value={formData.firstName} onChange={handleInputChange} error={errors.firstName} />
                <InputField id="lastName" label="Last Name" type="text" placeholder="Doe" value={formData.lastName} onChange={handleInputChange} error={errors.lastName} />
            </div>
            <InputField id="email" label="Email Address" type="email" placeholder="you@example.com" value={formData.email} onChange={handleInputChange} error={errors.email} />
            <InputField id="phone" label="Phone Number" type="tel" placeholder="+234 801 234 5678" value={formData.phone} onChange={handleInputChange} error={errors.phone} />
            <div className="relative">
                <label htmlFor="address" className="block text-sm font-semibold text-gray-700 mb-1.5 ml-1 flex items-center gap-2">
                    <span>Delivery Address</span>
                    {isSearchingAddress && <Icon name="fa-solid fa-spinner fa-spin" className="text-gray-400" />}
                </label>
                <textarea 
                    id="address" 
                    name="address" 
                    rows={3} 
                    value={formData.address} 
                    onChange={handleInputChange}
                    onBlur={handleAddressBlur} 
                    placeholder="Start typing your address..." 
                    required 
                    autoComplete="off"
                    className={`w-full px-4 py-3 border rounded-lg shadow-sm text-gray-900 placeholder-gray-400 bg-white transition-all duration-200 ease-in-out focus:outline-none focus:ring-4 ${errors.address 
                        ? 'border-red-300 focus:border-red-500 focus:ring-red-100 hover:border-red-400' 
                        : 'border-gray-200 hover:border-gray-400 focus:border-red-500 focus:ring-red-50'
                    }`}
                ></textarea>
                {errors.address && <p className="text-red-600 text-xs mt-1.5 ml-1 flex items-center gap-1"><Icon name="fa-solid fa-circle-exclamation" /> {errors.address}</p>}
                
                {addressSuggestions.length > 0 && (
                    <div className="absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-xl max-h-48 overflow-y-auto ring-1 ring-black ring-opacity-5">
                        <ul>
                            {addressSuggestions.map((suggestion) => (
                                <li key={suggestion.place_id} className="border-b border-gray-100 last:border-none">
                                    <button 
                                        type="button" 
                                        onClick={() => handleSuggestionClick(suggestion)}
                                        className="w-full text-left px-4 py-3 text-sm text-gray-700 hover:bg-red-50 hover:text-red-700 transition-colors"
                                    >
                                        <div className="font-medium truncate">{suggestion.display_name.split(',')[0]}</div>
                                        <div className="text-xs text-gray-500 truncate">{suggestion.display_name}</div>
                                    </button>
                                </li>
                            ))}
                        </ul>
                    </div>
                )}
            </div>
        </div>

        {/* Delivery Method */}
        <div>
            <h3 className="font-bold text-xl text-gray-800 mb-4 border-b pb-2">Delivery Options</h3>
            <div className="space-y-3">
                {DELIVERY_OPTIONS.map(option => (
                    <label key={option.id} className={`flex items-start gap-3 p-4 border rounded-lg cursor-pointer transition-all duration-200 hover:shadow-md ${formData.deliveryMethod === option.id ? 'bg-red-50 border-red-500 ring-1 ring-red-500 shadow-sm' : 'border-gray-200 hover:border-gray-400 hover:bg-gray-50'}`}>
                        <div className="flex h-5 items-center">
                            <input type="radio" name="deliveryMethod" value={option.id} checked={formData.deliveryMethod === option.id} onChange={handleInputChange} className="h-4 w-4 text-red-600 focus:ring-red-500 border-gray-300" />
                        </div>
                        <div className="flex-grow">
                            <div className="flex justify-between items-center">
                                <span className={`font-semibold ${formData.deliveryMethod === option.id ? 'text-red-900' : 'text-gray-900'}`}>{option.label}</span>
                                <span className="font-bold text-gray-900">{option.cost > 0 ? `₦${option.cost.toLocaleString()}` : 'FREE'}</span>
                            </div>
                            <p className="text-xs text-gray-500 mt-1">{option.description}</p>
                        </div>
                    </label>
                ))}
            </div>
        </div>

        {/* Payment Method */}
        <div>
            <h3 className="font-bold text-xl text-gray-800 mb-4 border-b pb-2">Payment Method</h3>
            <div className="space-y-3">
                {['cod', 'card', 'transfer'].map(method => {
                    const labels = { cod: 'Cash on Delivery', card: 'Credit/Debit Card', transfer: 'Bank Transfer' };
                    const icons = { cod: 'fa-money-bill-wave', card: 'fa-credit-card', transfer: 'fa-university' };
                    const isSelected = formData.paymentMethod === method;
                    return (
                        <label key={method} className={`flex items-center gap-4 p-4 border rounded-lg cursor-pointer transition-all duration-200 hover:shadow-md ${isSelected ? 'bg-red-50 border-red-500 ring-1 ring-red-500 shadow-sm' : 'border-gray-200 hover:border-gray-400 hover:bg-gray-50'}`}>
                            <div className="flex h-5 items-center">
                                <input type="radio" name="paymentMethod" value={method} checked={isSelected} onChange={handleInputChange} className="h-4 w-4 text-red-600 focus:ring-red-500 border-gray-300" />
                            </div>
                            <div className={`flex items-center justify-center w-10 h-10 rounded-full ${isSelected ? 'bg-white text-red-600 shadow-sm' : 'bg-gray-100 text-gray-500'}`}>
                                <Icon name={`fa-solid ${icons[method]}`} />
                            </div>
                            <span className={`font-semibold ${isSelected ? 'text-red-900' : 'text-gray-900'}`}>{labels[method]}</span>
                        </label>
                    );
                })}
            </div>
        </div>

        {/* Terms and Actions */}
        <div className="space-y-4 pt-2">
            <div className="flex items-start bg-gray-50 p-3 rounded-lg border border-gray-100">
                <div className="flex h-5 items-center">
                    <input id="termsAccepted" name="termsAccepted" type="checkbox" checked={formData.termsAccepted} onChange={handleCheckboxChange} className="h-4 w-4 text-red-600 focus:ring-red-500 border-gray-300 rounded" />
                </div>
                <label htmlFor="termsAccepted" className="ml-3 text-sm text-gray-600">
                    I agree to the <button type="button" onClick={() => onLinkClick('terms-of-service')} className="font-medium text-red-600 hover:underline">Terms of Service</button> and <button type="button" onClick={() => onLinkClick('privacy-policy')} className="font-medium text-red-600 hover:underline">Privacy Policy</button>.
                </label>
            </div>
             {errors.termsAccepted && <p className="text-red-600 text-xs ml-1 flex items-center gap-1"><Icon name="fa-solid fa-circle-exclamation" /> {errors.termsAccepted}</p>}
            
            <div className="flex items-start bg-gray-50 p-3 rounded-lg border border-gray-100">
                <div className="flex h-5 items-center">
                    <input id="newsletterSubscribed" name="newsletterSubscribed" type="checkbox" checked={formData.newsletterSubscribed} onChange={handleCheckboxChange} className="h-4 w-4 text-red-600 focus:ring-red-500 border-gray-300 rounded" />
                </div>
                <label htmlFor="newsletterSubscribed" className="ml-3 text-sm text-gray-600">Subscribe to our newsletter for exclusive offers and updates.</label>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch gap-4 pt-4">
                <button type="submit" className="w-full bg-gradient-to-r from-red-600 to-red-700 text-white font-bold py-4 px-6 rounded-xl shadow-lg hover:shadow-red-500/30 hover:from-red-700 hover:to-red-800 focus:outline-none focus:ring-4 focus:ring-red-300 transition-all duration-300 transform hover:-translate-y-1 flex flex-col items-center justify-center flex-grow">
                    <div className="flex items-center gap-2">
                        <Icon name="fa-solid fa-bolt" />
                        <span className="text-xl font-montserrat tracking-wide">PLACE ORDER NOW</span>
                    </div>
                    <span className="text-xs font-normal opacity-90 mt-1">Limited Time Offer - Secure Yours Today</span>
                </button>

                <div className="flex flex-col gap-3 sm:w-auto flex-shrink-0">
                    <button 
                        type="button" 
                        onClick={handleAddToWishlist}
                        disabled={isAddedToWishlist}
                        className={`w-full font-bold py-3 px-5 rounded-lg border transition-all duration-200 flex items-center justify-center gap-2
                            ${isAddedToWishlist 
                                ? 'bg-green-100 text-green-700 border-green-300 cursor-not-allowed transform-none shadow-inner' 
                                : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50 hover:border-gray-400 focus:outline-none focus:ring-4 focus:ring-gray-100 shadow-sm hover:shadow'}`
                        }
                    >
                        {isAddedToWishlist ? (
                           <>
                             <Icon name="fa-solid fa-check" className="text-lg" />
                             <span className="whitespace-nowrap">Added</span>
                           </>
                        ) : (
                           <>
                             <Icon name="fa-regular fa-heart" className="text-lg" />
                             <span className="whitespace-nowrap">Wishlist</span>
                           </>
                        )}
                    </button>

                    <button 
                        type="button"
                        onClick={handleAddToCart}
                        disabled={isAddedToCart}
                        className={`w-full font-bold py-3 px-5 rounded-lg border transition-all duration-200 flex items-center justify-center gap-2
                            ${isAddedToCart
                                ? 'bg-green-100 text-green-700 border-green-300 cursor-not-allowed transform-none shadow-inner'
                                : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50 hover:border-gray-400 focus:outline-none focus:ring-4 focus:ring-gray-100 shadow-sm hover:shadow'}`
                        }
                    >
                        {isAddedToCart ? (
                           <>
                            <Icon name="fa-solid fa-check" className="text-lg" />
                            <span className="whitespace-nowrap">Added</span>
                           </>
                        ) : (
                           <>
                            <Icon name="fa-solid fa-cart-plus" className="text-lg" />
                            <span className="whitespace-nowrap">Add to Cart</span>
                           </>
                        )}
                    </button>
                </div>
            </div>
        </div>

        {/* Trust Badges */}
        <div className="grid grid-cols-3 gap-4 text-center text-xs text-gray-500 pt-6 border-t border-dashed border-gray-200">
            <div className="flex flex-col items-center gap-2 group">
                <div className="w-10 h-10 rounded-full bg-green-50 flex items-center justify-center group-hover:bg-green-100 transition-colors">
                    <Icon name="fa-solid fa-lock" className="text-lg text-green-600 transition-transform group-hover:scale-110" />
                </div>
                <span className="font-medium">Secure Payment</span>
            </div>
            <div className="flex flex-col items-center gap-2 group">
                 <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center group-hover:bg-blue-100 transition-colors">
                    <Icon name="fa-solid fa-truck-fast" className="text-lg text-blue-600 transition-transform group-hover:scale-110" />
                </div>
                <span className="font-medium">Free Shipping</span>
            </div>
            <div className="flex flex-col items-center gap-2 group">
                 <div className="w-10 h-10 rounded-full bg-orange-50 flex items-center justify-center group-hover:bg-orange-100 transition-colors">
                    <Icon name="fa-solid fa-rotate-left" className="text-lg text-orange-600 transition-transform group-hover:scale-110" />
                </div>
                <span className="font-medium">30-Day Returns</span>
            </div>
        </div>
    </form>
  );
};