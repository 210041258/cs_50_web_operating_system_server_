import React from 'react';
import { Icon } from '../ui/Icon';

interface HeroProps {
  onShopNowClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onShopNowClick }) => {
  return (
    <section 
      className="relative bg-cover bg-center text-white py-24 md:py-32" 
      style={{ backgroundImage: "url('https://picsum.photos/id/447/1600/900')" }}
    >
      <div className="absolute inset-0 bg-black bg-opacity-50"></div>
      <div className="container mx-auto px-4 relative z-10 text-center">
        <h1 className="text-4xl md:text-6xl font-montserrat font-extrabold tracking-tight drop-shadow-lg">
          The Ultimate Comfort Sandal
        </h1>
        <p className="mt-4 text-lg md:text-2xl font-semibold font-montserrat text-gray-200 drop-shadow-md">
          Wren Black Leather Casuals
        </p>
        <p className="mt-6 text-xl md:text-3xl text-amber-300 font-bold drop-shadow-lg animate-pulse">
          Limited Time Flash Sale: 40% OFF!
        </p>
        <button 
          onClick={onShopNowClick}
          className="mt-8 bg-red-600 text-white font-bold py-4 px-8 rounded-lg shadow-lg hover:bg-red-700 focus:outline-none focus:ring-4 focus:ring-red-300 transition transform hover:-translate-y-1 text-lg flex items-center gap-3 mx-auto"
        >
          <Icon name="fa-solid fa-tag" />
          <span>View Deal & Order Now</span>
        </button>
      </div>
    </section>
  );
};