import React from 'react';
import type { Product } from '../../types';
import { Icon } from '../ui/Icon';

interface ProductSpecsProps {
  product: Product;
}

export const ProductSpecs: React.FC<ProductSpecsProps> = ({ product }) => {
  return (
    <section className="py-12 bg-gray-50 border-t border-gray-200">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-montserrat font-bold text-gray-900 mb-8 text-center">Technical Specifications</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {product.specifications.map((spec, index) => (
            <div 
              key={spec.label} 
              className="bg-white p-5 rounded-xl shadow-sm border border-gray-100 flex items-start gap-4 transition-all duration-300 hover:shadow-md hover:border-red-100 hover:-translate-y-1"
            >
              <div className="w-12 h-12 rounded-full bg-red-50 text-red-600 flex items-center justify-center text-xl flex-shrink-0">
                <Icon name={spec.icon} />
              </div>
              <div>
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">{spec.label}</h4>
                <div className="flex items-center gap-2">
                   {spec.valueComponent}
                   <p className="font-semibold text-gray-900 text-lg leading-tight">{spec.value}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};