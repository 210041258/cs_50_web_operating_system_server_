import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import type { Review, Product } from '../../types';
import { Icon } from '../ui/Icon';

interface StarRatingProps {
  rating: number;
}

const StarRating: React.FC<StarRatingProps> = ({ rating }) => {
    const fullStars = Math.floor(rating);
    const halfStar = rating % 1 !== 0;
    const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);
  
    return (
      <div className="flex items-center text-amber-400">
        {[...Array(fullStars)].map((_, i) => <Icon key={`full-${i}`} name="fa-solid fa-star" />)}
        {halfStar && <Icon name="fa-solid fa-star-half-stroke" />}
        {[...Array(emptyStars)].map((_, i) => <Icon key={`empty-${i}`} name="fa-regular fa-star" />)}
      </div>
    );
};

const MarkdownRenderer: React.FC<{ content: string }> = ({ content }) => {
    const lines = content.split('\n');
    const elements: React.ReactNode[] = [];
    let listItems: React.ReactNode[] = [];

    const flushList = () => {
        if (listItems.length > 0) {
            elements.push(<ul key={`ul-${elements.length}`} className="list-disc list-inside space-y-2 mb-4 pl-4 text-gray-700">{listItems}</ul>);
            listItems = [];
        }
    };

    const renderTextWithBold = (text: string) => {
        return text.split('**').map((part, i) =>
            i % 2 === 1 ? <strong key={i} className="font-semibold text-gray-800">{part}</strong> : part
        );
    };

    lines.forEach((line, index) => {
        if (line.startsWith('# ')) {
            flushList();
            elements.push(<h2 key={index} className="text-2xl font-bold font-montserrat text-gray-800 mt-6 mb-3 first:mt-0">{renderTextWithBold(line.substring(2))}</h2>);
        } else if (line.startsWith('## ')) {
            flushList();
            elements.push(<h3 key={index} className="text-xl font-bold font-montserrat text-gray-800 mt-5 mb-2">{renderTextWithBold(line.substring(3))}</h3>);
        } else if (line.startsWith('### ')) {
            flushList();
            elements.push(<h4 key={index} className="text-lg font-semibold text-gray-700 mt-4 mb-1">{renderTextWithBold(line.substring(4))}</h4>);
        } else if (line.trim() === '***') {
            flushList();
            elements.push(<hr key={index} className="my-6 border-gray-300" />);
        } else if (line.trim().startsWith('* ') || line.trim().startsWith('- ')) {
            listItems.push(<li key={index}>{renderTextWithBold(line.trim().substring(2))}</li>);
        } else if (line.trim()) {
            flushList();
            elements.push(<p key={index} className="mb-3 text-gray-700 leading-relaxed">{renderTextWithBold(line.trim())}</p>);
        } else {
            flushList();
        }
    });

    flushList(); 

    return <>{elements}</>;
};

interface ReviewsProps {
  reviews: Review[];
  product: Product;
}

export const Reviews: React.FC<ReviewsProps> = ({ reviews, product }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [aiInsight, setAiInsight] = useState('');
  const [error, setError] = useState('');

  const handleGetAIInsights = async () => {
    setIsLoading(true);
    setError('');
    setAiInsight('');

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const reviewTexts = reviews.map(r => `- ${r.author} (${r.date}): "${r.text}"`).join('\n');
        
        const productDetails = product.specifications
            .map(spec => `- ${spec.label}: ${spec.value}`)
            .join('\n');
            
        const materialSpec = product.specifications.find(s => s.label === 'Material')?.value || 'the material';
        const colorSpec = product.specifications.find(s => s.label === 'Color')?.value || 'the color';
        const styleSpec = product.specifications.find(s => s.label === 'Style')?.value || 'the style';

        const prompt = `
            You are an expert product analyst. Your task is to analyze customer reviews for a product and create a summary for a potential buyer.
            
            **Product Information:**
            - Product Name: ${product.name}
            - Category: ${product.category}
            - Key Specifications:
${productDetails}
            
            Based on the **product information** and the following **customer reviews**, provide a detailed summary.
            Analyze the main points of praise and any recurring complaints or concerns.
            Crucially, try to connect the review comments to the product's specifications (e.g., comments on the '${materialSpec}' material, the '${colorSpec}' color, or the '${styleSpec}' style).
            Also analyze general aspects like comfort, quality, sizing/fit, value for money, and delivery experience.
            
            Structure the output with clear headings using markdown (e.g., '# Overall Summary', '## Key Positives').
            
            Conclude with a final recommendation or a "who is this product for?" section under a '## Final Verdict' heading.

            **Customer Reviews:**
            ${reviewTexts}
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-preview',
            contents: prompt,
            config: {
                thinkingConfig: { thinkingBudget: 32768 },
            },
        });

        if (response.text) {
            setAiInsight(response.text);
        } else {
            setError("Couldn't generate insights. The model returned an empty response.");
        }
    } catch (e) {
        console.error(e);
        setError("An error occurred while generating insights. Please try again later.");
    } finally {
        setIsLoading(false);
    }
  };

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-montserrat font-bold text-gray-900">What Our Customers Say</h2>
          <p className="text-gray-600 mt-2">Real reviews from verified buyers.</p>
        </div>

        <div className="mb-12 bg-slate-50 p-6 rounded-lg border border-slate-200 text-center transition-all duration-300 hover:shadow-lg hover:border-purple-200">
            <div className="flex justify-center items-center gap-3">
                <Icon name="fa-solid fa-wand-magic-sparkles" className="text-xl text-purple-600" />
                <h3 className="text-xl font-semibold text-gray-800">AI-Powered Review Insights</h3>
            </div>
            <p className="text-sm text-gray-600 mt-2 mb-4 max-w-2xl mx-auto">
                Let AI summarize all reviews to highlight key points on comfort, quality, and fit.
            </p>
            <button
                onClick={handleGetAIInsights}
                disabled={isLoading}
                className="bg-purple-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-purple-700 transition disabled:bg-purple-300 disabled:cursor-not-allowed flex items-center justify-center gap-2 mx-auto shadow-md hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0"
            >
                {isLoading ? (
                    <>
                        <Icon name="fa-solid fa-spinner fa-spin" />
                        <span>Analyzing...</span>
                    </>
                ) : (
                    <>
                        <Icon name="fa-solid fa-brain" />
                        <span>Generate Summary</span>
                    </>
                )}
            </button>

            {error && <div className="mt-4 text-red-600 bg-red-100 p-3 rounded-md text-sm">{error}</div>}

            {aiInsight && (
                <div className="mt-6 text-left bg-white p-6 rounded-lg border border-gray-200 shadow-inner">
                    <MarkdownRenderer content={aiInsight} />
                </div>
            )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {reviews.map(review => (
            <div key={review.id} className="bg-white p-6 rounded-lg shadow-md border border-gray-200 transition-all duration-300 hover:shadow-xl hover:border-red-200 hover:-translate-y-1 hover:bg-red-50/10">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="font-semibold text-lg text-gray-900">{review.author}</h3>
                  <p className="text-xs text-gray-500">{review.date}</p>
                </div>
                <StarRating rating={review.rating} />
              </div>
              <p className="text-gray-600 italic">"{review.text}"</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};