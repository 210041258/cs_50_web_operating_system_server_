import React from 'react';
import { ProductCard } from '../product/ProductCard';
import type { ShopProduct } from '../../types';

interface RelatedProductsProps {
  products: ShopProduct[];
  onViewProduct: (product: ShopProduct) => void;
}

export const RelatedProducts: React.FC<RelatedProductsProps> = ({ products, onViewProduct }) => {
  return (
    <section className="py-16 bg-white mt-12 rounded-lg shadow-md">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-montserrat font-bold text-center text-gray-900 mb-10">You Might Also Like</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map(product => (
            // Pass onViewProduct to maintain legacy compatibility if parent provides it, 
            // though ProductCard now defaults to UIContext if not provided.
            <ProductCard key={product.id} product={product} onViewProduct={onViewProduct} />
          ))}
        </div>
      </div>
    </section>
  );
};