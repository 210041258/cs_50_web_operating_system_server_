import React, { useState } from 'react';
import { Icon } from '../ui/Icon';
import { PRODUCT_ANATOMY_DATA } from '../../data/constants';

export const ProductAnatomy: React.FC = () => {
  const [activePoint, setActivePoint] = useState<string>(PRODUCT_ANATOMY_DATA[0].id);

  return (
    <section className="py-16 bg-gray-50 overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
            <span className="text-red-600 font-bold tracking-wider text-sm uppercase">Engineering & Craftsmanship</span>
            <h2 className="text-3xl md:text-4xl font-montserrat font-bold text-gray-900 mt-2">Anatomy of Comfort</h2>
            <p className="text-gray-600 mt-3 max-w-2xl mx-auto">
                Explore the working principles behind the Wren sandal. Every layer is meticulously designed for support, durability, and style.
            </p>
        </div>

        <div className="flex flex-col lg:flex-row items-center gap-12">
            {/* Visual Diagram Area */}
            <div className="w-full lg:w-1/2 relative min-h-[400px] flex items-center justify-center bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
                {/* Abstract Shoe Representation (Using Image as base) */}
                <div className="relative w-full max-w-md aspect-[4/3]">
                     <img 
                        src="https://picsum.photos/id/1061/800/600" 
                        alt="Shoe Anatomy Diagram" 
                        className="w-full h-full object-contain opacity-90" 
                     />
                     
                     {/* Interactive Hotspots */}
                     {PRODUCT_ANATOMY_DATA.map((point) => (
                         <button
                            key={point.id}
                            onClick={() => setActivePoint(point.id)}
                            style={{ top: point.position.top, left: point.position.left }}
                            className={`absolute w-8 h-8 -ml-4 -mt-4 rounded-full flex items-center justify-center transition-all duration-300 shadow-lg border-2 z-10
                                ${activePoint === point.id 
                                    ? 'bg-red-600 border-white text-white scale-125 ring-4 ring-red-100' 
                                    : 'bg-white border-red-600 text-red-600 hover:scale-110'
                                }`}
                            aria-label={`View details for ${point.title}`}
                         >
                             <Icon name="fa-solid fa-plus" className={`text-xs transition-transform duration-300 ${activePoint === point.id ? 'rotate-45' : ''}`} />
                         </button>
                     ))}

                     {/* Connecting Lines (Decorative CSS) */}
                     <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-20 hidden md:block">
                         {/* Placeholder for SVG lines connecting points to text if needed in future */}
                     </svg>
                </div>
            </div>

            {/* Info Panel */}
            <div className="w-full lg:w-1/2 space-y-6">
                {PRODUCT_ANATOMY_DATA.map((point) => (
                    <div 
                        key={point.id}
                        onClick={() => setActivePoint(point.id)}
                        className={`p-6 rounded-xl border transition-all duration-300 cursor-pointer flex items-start gap-4 group
                            ${activePoint === point.id 
                                ? 'bg-white border-red-200 shadow-lg scale-100' 
                                : 'bg-transparent border-transparent hover:bg-white hover:shadow-md opacity-70 hover:opacity-100'
                            }`}
                    >
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 transition-colors duration-300
                             ${activePoint === point.id ? 'bg-red-100 text-red-600' : 'bg-gray-200 text-gray-500 group-hover:bg-gray-300'}`}>
                            <Icon name={point.icon} className="text-xl" />
                        </div>
                        <div>
                            <h3 className={`font-bold text-lg mb-1 transition-colors ${activePoint === point.id ? 'text-gray-900' : 'text-gray-700'}`}>
                                {point.title}
                            </h3>
                            <p className="text-gray-600 text-sm leading-relaxed">
                                {point.description}
                            </p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
      </div>
    </section>
  );
};
