import React from 'react';
import { useUI } from '../../context/UIContext';
import { useShop } from '../../context/ShopContext';
import { SuccessModal } from '../modals/SuccessModal';
import { SizeGuideModal } from '../modals/SizeGuideModal';
import { InfoModal } from '../modals/InfoModal';
import { QuickViewModal } from '../modals/QuickViewModal';
import { SearchModal } from '../modals/SearchModal';
import { ShopCategoryModal } from '../modals/ShopCategoryModal';
import { ViewProductModal } from '../modals/ViewProductModal';
import { PAGE_CONTENT, SHOP_PRODUCTS, PRODUCT_DATA } from '../../data/constants';

// Helper for main product details in quick view
const MAIN_PRODUCT_DETAILS = {
    name: PRODUCT_DATA.name,
    salePrice: PRODUCT_DATA.salePrice,
    originalPrice: PRODUCT_DATA.originalPrice
};

export const ModalManager: React.FC = () => {
  const { 
    isSearchOpen, closeSearch,
    isSizeGuideOpen, closeSizeGuide,
    quickViewImage, closeQuickView,
    viewingProduct, closeViewProduct,
    activeInfoPage, closeInfoPage,
    activeShopCategory, closeShopCategory,
    successData, closeSuccessModal,
    openViewProduct
  } = useUI();

  const { addToCart } = useShop();

  const handleScrollToShop = () => {
    // Dispatch a custom event or use a ref from Context if stricter coupling is needed.
    // For simplicity, we'll use a window event or simple scroll here.
    const hero = document.getElementById('shop-hero');
    hero?.scrollIntoView({ behavior: 'smooth' });
  };

  const getShopModalData = () => {
    if (!activeShopCategory) return null;
    switch (activeShopCategory) {
      case 'new-arrivals':
        return { title: 'New Arrivals', products: SHOP_PRODUCTS.filter(p => p.isNew) };
      case 'sandals':
        return { title: 'Sandals Collection', products: SHOP_PRODUCTS.filter(p => p.category === 'sandals') };
      case 'womens-shoes':
        return { title: "Women's Shoes", products: SHOP_PRODUCTS.filter(p => p.category === 'womens-shoes') };
      case 'sale':
        return { title: 'Sale Items', products: SHOP_PRODUCTS.filter(p => p.originalPrice) };
      default:
        return null;
    }
  };

  const shopModalData = getShopModalData();
  const currentInfoContent = activeInfoPage ? PAGE_CONTENT[activeInfoPage] : null;

  return (
    <>
      {successData && (
        <SuccessModal
          orderNumber={successData.orderNumber}
          formData={successData.formData}
          totalPrice={successData.totalPrice}
          onClose={closeSuccessModal}
          cartItems={successData.cartItems}
        />
      )}

      {isSizeGuideOpen && <SizeGuideModal onClose={closeSizeGuide} />}

      {currentInfoContent && (
        <InfoModal title={currentInfoContent.title} onClose={closeInfoPage}>
          {currentInfoContent.content}
        </InfoModal>
      )}

      {shopModalData && (
        <ShopCategoryModal
            title={shopModalData.title}
            products={shopModalData.products}
            onClose={closeShopCategory}
            onGoToFlashSale={() => {
                closeShopCategory();
                handleScrollToShop();
            }}
            onViewProduct={(p) => {
                // If viewing from category, we might want to close category or stack modals.
                // Closing category for cleaner mobile UX.
                // closeShopCategory(); 
                openViewProduct(p);
            }}
        />
      )}

      {viewingProduct && (
          <ViewProductModal 
            product={viewingProduct} 
            onClose={closeViewProduct} 
            onAddToCart={() => addToCart(viewingProduct, 1)}
            onViewDetails={() => {
                closeViewProduct();
                handleScrollToShop();
            }}
          />
      )}

      {quickViewImage && (
        <QuickViewModal
          image={quickViewImage}
          productName={MAIN_PRODUCT_DETAILS.name}
          salePrice={MAIN_PRODUCT_DETAILS.salePrice}
          originalPrice={MAIN_PRODUCT_DETAILS.originalPrice}
          onClose={closeQuickView}
          onGoToDetails={handleScrollToShop}
        />
      )}
      
      {isSearchOpen && (
        <SearchModal 
            onClose={closeSearch} 
            onViewProduct={(p) => {
                closeSearch();
                openViewProduct(p);
            }} 
        />
      )}
    </>
  );
};