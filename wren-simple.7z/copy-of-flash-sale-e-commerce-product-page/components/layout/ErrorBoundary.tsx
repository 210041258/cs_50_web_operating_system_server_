import React, { ErrorInfo, ReactNode } from 'react';
import { Icon } from '../ui/Icon';

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
}

export class ErrorBoundary extends React.Component<Props, State> {
  public state: State = {
    hasError: false
  };

  public static getDerivedStateFromError(_: Error): State {
    return { hasError: true };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 text-center p-4">
          <div className="bg-white p-8 rounded-lg shadow-xl max-w-md w-full border border-gray-200">
            <Icon name="fa-solid fa-triangle-exclamation" className="text-6xl text-red-500 mb-6" />
            <h1 className="text-2xl font-montserrat font-bold text-gray-900 mb-2">Something went wrong.</h1>
            <p className="text-gray-600 mb-6">We're sorry, but an unexpected error has occurred. Our team has been notified.</p>
            <button
              onClick={() => window.location.reload()}
              className="w-full bg-gray-900 text-white font-bold py-3 px-6 rounded-lg hover:bg-gray-800 transition focus:outline-none focus:ring-4 focus:ring-gray-300"
            >
              Refresh Page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}