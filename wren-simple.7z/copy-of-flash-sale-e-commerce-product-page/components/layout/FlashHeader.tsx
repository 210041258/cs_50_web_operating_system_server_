import React, { useState, useEffect } from 'react';
import { Icon } from '../ui/Icon';

interface TimeLeft {
    hours: number;
    minutes: number;
    seconds: number;
}

export const FlashHeader: React.FC = () => {
  const calculateTimeLeft = (): TimeLeft => {
    const difference = +new Date("2025-01-01") - +new Date();

    if (difference > 0) {
      return {
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60)
      };
    }
    return { hours: 0, minutes: 0, seconds: 0 };
  };

  const [timeLeft, setTimeLeft] = useState<TimeLeft>(calculateTimeLeft());

  useEffect(() => {
    const timer = setTimeout(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);
    return () => clearTimeout(timer);
  });

  const formatTime = (time: number) => time.toString().padStart(2, '0');

  return (
    <header className="bg-gray-800 text-white p-3">
      <div className="container mx-auto flex justify-between items-center flex-wrap gap-4">
        <div className="bg-red-600 font-montserrat font-bold text-sm px-3 py-1.5 rounded-md flex items-center gap-2">
          <Icon name="fa-solid fa-bolt" />
          <span>FLASH SALE</span>
        </div>
        <div className="flex items-center gap-4">
            <span className="hidden sm:inline font-semibold">Ends in:</span>
            <div className="flex items-center gap-2 font-montserrat text-lg">
                <div className="bg-white text-gray-800 rounded px-2 py-1">{formatTime(timeLeft.hours)}</div>
                <span className="text-white">:</span>
                <div className="bg-white text-gray-800 rounded px-2 py-1">{formatTime(timeLeft.minutes)}</div>
                <span className="text-white">:</span>
                <div className="bg-white text-gray-800 rounded px-2 py-1">{formatTime(timeLeft.seconds)}</div>
            </div>
        </div>
        <div className="text-sm flex items-center gap-2">
            <Icon name="fa-solid fa-phone" />
            <span>Need help? Call +234-800-123-4567</span>
        </div>
      </div>
    </header>
  );
};