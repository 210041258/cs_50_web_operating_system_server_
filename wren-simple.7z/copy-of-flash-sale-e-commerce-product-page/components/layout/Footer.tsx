import React from 'react';
import { Icon } from '../ui/Icon';
import { useUI } from '../../context/UIContext';

interface FooterLinkProps {
  onClick: () => void;
  children: React.ReactNode;
}

const FooterLink: React.FC<FooterLinkProps> = ({ onClick, children }) => (
    <li>
        <button onClick={onClick} className="text-gray-400 hover:text-red-400 transition-all duration-300 text-left w-full hover:translate-x-2 flex items-center group">
            <span className="opacity-0 -ml-2 group-hover:opacity-100 group-hover:ml-0 transition-all duration-300 mr-2 text-xs">›</span>
            {children}
        </button>
    </li>
);

interface FooterProps {
    onLinkClick?: (page: string) => void; // Optional now as we use Context
}

export const Footer: React.FC<FooterProps> = () => {
  const { openInfoPage, openShopCategory } = useUI();

  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand Info */}
          <div className="space-y-4">
            <h3 className="font-montserrat text-2xl font-bold tracking-wider">WREN</h3>
            <p className="text-gray-400 text-sm leading-relaxed">Premium leather sandals for every occasion. Quality and comfort, guaranteed.</p>
            <div className="flex space-x-4 pt-2">
              <a href="#" aria-label="Facebook" className="text-gray-400 hover:text-white transition-colors transform hover:scale-110"><Icon name="fa-brands fa-facebook-f" /></a>
              <a href="#" aria-label="Instagram" className="text-gray-400 hover:text-white transition-colors transform hover:scale-110"><Icon name="fa-brands fa-instagram" /></a>
              <a href="#" aria-label="Twitter" className="text-gray-400 hover:text-white transition-colors transform hover:scale-110"><Icon name="fa-brands fa-twitter" /></a>
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-semibold mb-4 text-gray-200">Shop</h4>
            <ul className="space-y-2 text-sm">
              <FooterLink onClick={() => openShopCategory('new-arrivals')}>New Arrivals</FooterLink>
              <FooterLink onClick={() => openShopCategory('sandals')}>Sandals</FooterLink>
              <FooterLink onClick={() => openShopCategory('womens-shoes')}>Women's Shoes</FooterLink>
              <FooterLink onClick={() => openShopCategory('sale')}>Sale</FooterLink>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4 text-gray-200">Help</h4>
            <ul className="space-y-2 text-sm">
              <FooterLink onClick={() => openInfoPage('contact-us')}>Contact Us</FooterLink>
              <FooterLink onClick={() => openInfoPage('faqs')}>FAQs</FooterLink>
              <FooterLink onClick={() => openInfoPage('shipping')}>Shipping</FooterLink>
              <FooterLink onClick={() => openInfoPage('returns')}>Returns</FooterLink>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4 text-gray-200">Company</h4>
            <ul className="space-y-2 text-sm">
              <FooterLink onClick={() => openInfoPage('about-us')}>About Us</FooterLink>
              <FooterLink onClick={() => openInfoPage('careers')}>Careers</FooterLink>
              <FooterLink onClick={() => openInfoPage('terms-of-service')}>Terms of Service</FooterLink>
              <FooterLink onClick={() => openInfoPage('privacy-policy')}>Privacy Policy</FooterLink>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-gray-500">
            <p>&copy; {new Date().getFullYear()} Wren Inc. All rights reserved.</p>
            <div className="flex items-center space-x-4 mt-4 md:mt-0 text-2xl opacity-75 hover:opacity-100 transition-opacity">
                <Icon name="fa-brands fa-cc-visa" />
                <Icon name="fa-brands fa-cc-mastercard" />
                <Icon name="fa-brands fa-paypal" />
            </div>
        </div>
      </div>
    </footer>
  );
};