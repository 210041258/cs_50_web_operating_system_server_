import React, { useState, useEffect, useRef } from 'react';
import { Icon } from '../ui/Icon';
import { useShop } from '../../context/ShopContext';
import { useUI } from '../../context/UIContext';

interface NavLinkProps {
  onClick: () => void;
  children: React.ReactNode;
}

const NavLink: React.FC<NavLinkProps> = ({ onClick, children }) => (
    <li>
        <button 
            onClick={onClick} 
            className="text-gray-600 hover:text-red-600 font-semibold transition duration-300 ease-in-out py-2"
        >
            {children}
        </button>
    </li>
);

export const Navigation: React.FC = () => {
    const { cartTotalCount, openCart, openProfile, openWishlist, wishlistItems } = useShop();
    const { openSearch, openShopCategory } = useUI();
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [isAnimating, setIsAnimating] = useState(false);
    const prevCartCount = useRef(cartTotalCount);

    useEffect(() => {
        if (cartTotalCount > prevCartCount.current) {
            setIsAnimating(true);
            const timer = setTimeout(() => setIsAnimating(false), 300);
            return () => clearTimeout(timer);
        }
        prevCartCount.current = cartTotalCount;
    }, [cartTotalCount]);

    const handleLinkClick = (category: string) => {
        openShopCategory(category);
        setIsMenuOpen(false);
    };

    return (
        <nav className="bg-white shadow-md sticky top-0 z-40">
            <div className="container mx-auto px-4 flex justify-between items-center py-4">
                <div className="font-montserrat text-3xl font-bold text-gray-900">
                    <a href="#">WREN</a>
                </div>
                
                <ul className="hidden md:flex items-center space-x-8 text-sm uppercase tracking-wider">
                    <NavLink onClick={() => openShopCategory('new-arrivals')}>New Arrivals</NavLink>
                    <NavLink onClick={() => openShopCategory('sandals')}>Sandals</NavLink>
                    <NavLink onClick={() => openShopCategory('womens-shoes')}>Women's Shoes</NavLink>
                    <NavLink onClick={() => openShopCategory('sale')}>Sale</NavLink>
                </ul>

                <div className="hidden md:flex items-center space-x-6">
                    <button onClick={openSearch} className="text-gray-600 hover:text-red-600" aria-label="Search" title="Search">
                        <Icon name="fa-solid fa-search" className="text-lg" />
                    </button>
                    <button onClick={openWishlist} className="relative text-gray-600 hover:text-red-600" aria-label="Wishlist" title="Wishlist">
                        <Icon name="fa-regular fa-heart" className="text-lg" />
                        {wishlistItems.length > 0 && (
                            <span className="absolute -top-1.5 -right-1.5 bg-gray-700 text-white text-[10px] rounded-full h-4 w-4 flex items-center justify-center font-bold">
                                {wishlistItems.length}
                            </span>
                        )}
                    </button>
                    <button onClick={openProfile} className="text-gray-600 hover:text-red-600" aria-label="My Account" title="My Account">
                        <Icon name="fa-solid fa-user" className="text-lg" />
                    </button>
                    <button onClick={openCart} className="relative text-gray-600 hover:text-red-600" aria-label="Shopping Bag" title="Cart">
                        <Icon name="fa-solid fa-shopping-bag" className="text-lg" />
                        {cartTotalCount > 0 && (
                             <span 
                                key={cartTotalCount}
                                className={`absolute -top-2 -right-2 bg-red-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-bold ${isAnimating ? 'animate-bounce-short' : ''}`}
                            >
                                {cartTotalCount}
                            </span>
                        )}
                    </button>
                </div>

                <div className="md:hidden">
                    <button onClick={() => setIsMenuOpen(!isMenuOpen)} aria-label="Open menu" aria-expanded={isMenuOpen}>
                        <Icon name={isMenuOpen ? "fa-solid fa-times" : "fa-solid fa-bars"} className="text-2xl text-gray-800" />
                    </button>
                </div>
            </div>

            <div className={`md:hidden bg-white border-t border-gray-200 transition-all duration-300 ease-in-out ${isMenuOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'} overflow-hidden`}>
                <ul className="flex flex-col items-center space-y-4 py-4">
                    <NavLink onClick={() => handleLinkClick('new-arrivals')}>New Arrivals</NavLink>
                    <NavLink onClick={() => handleLinkClick('sandals')}>Sandals</NavLink>
                    <NavLink onClick={() => handleLinkClick('womens-shoes')}>Women's Shoes</NavLink>
                    <NavLink onClick={() => handleLinkClick('sale')}>Sale</NavLink>
                    <button onClick={() => { openWishlist(); setIsMenuOpen(false); }} className="text-gray-600 font-semibold hover:text-red-600 py-2">Wishlist ({wishlistItems.length})</button>
                    <button onClick={() => { openProfile(); setIsMenuOpen(false); }} className="text-gray-600 font-semibold hover:text-red-600 py-2">My Account</button>
                    <button onClick={() => { openCart(); setIsMenuOpen(false); }} className="text-gray-600 font-semibold hover:text-red-600 py-2">Cart ({cartTotalCount})</button>
                </ul>
            </div>
        </nav>
    );
};