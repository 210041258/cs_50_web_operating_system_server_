
import React from 'react';
import { Icon } from './Icon';

export const Breadcrumbs: React.FC = () => {
  const crumbs = ["Sandals", "Black Leather Sandals"];
  
  return (
    <nav aria-label="breadcrumb">
      <ol className="flex items-center space-x-2 text-sm text-gray-500">
        {crumbs.map((crumb, index) => (
          <li key={index} className="flex items-center">
            {index < crumbs.length - 1 ? (
              <>
                <a href="#" className="hover:underline hover:text-gray-700">{crumb}</a>
                <Icon name="fa-solid fa-chevron-right" className="text-xs mx-2" />
              </>
            ) : (
              <span className="font-semibold text-gray-700">{crumb}</span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
};
