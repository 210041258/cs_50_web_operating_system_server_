import React from 'react';
import { Icon } from './Icon';
import type { ShopProduct } from '../types';

interface ProductCardProps {
    product: ShopProduct;
    onViewProduct: (product: ShopProduct) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onViewProduct }) => (
    <div className="border border-gray-200 rounded-lg overflow-hidden group bg-white transition-all duration-300 hover:shadow-2xl hover:-translate-y-2 hover:border-red-200">
        <div className="aspect-square bg-gray-100 relative overflow-hidden">
            <img src={product.image} alt={product.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
             <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all duration-300 flex items-center justify-center">
                <button 
                    onClick={() => onViewProduct(product)}
                    className="flex items-center gap-2 bg-white text-gray-800 font-bold py-2 px-4 rounded-lg shadow-md opacity-0 group-hover:opacity-100 transition-all duration-300 transform scale-90 group-hover:scale-100 cursor-pointer hover:bg-red-600 hover:text-white"
                    title="View this product"
                >
                    <Icon name="fa-solid fa-eye" />
                    <span>View Product</span>
                </button>
            </div>
            {product.isNew && (
                <span className="absolute top-2 left-2 bg-blue-500 text-white text-xs font-bold px-2 py-1 rounded shadow-sm">NEW</span>
            )}
             {product.originalPrice && (
                <span className="absolute top-2 right-2 bg-red-600 text-white text-xs font-bold px-2 py-1 rounded shadow-sm">SALE</span>
            )}
        </div>
        <div className="p-4 transition-colors duration-300 group-hover:bg-red-50/10">
            <h4 className="font-semibold text-gray-800 truncate group-hover:text-red-700 transition-colors">{product.name}</h4>
            <div className="flex items-baseline gap-2 mt-1">
                <p className="font-bold text-lg text-red-600">₦{product.price.toLocaleString()}</p>
                {product.originalPrice && (
                    <p className="text-sm text-gray-400 line-through">₦{product.originalPrice.toLocaleString()}</p>
                )}
            </div>
        </div>
    </div>
);