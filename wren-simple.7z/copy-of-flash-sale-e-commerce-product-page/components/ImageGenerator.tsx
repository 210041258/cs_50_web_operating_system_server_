import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Icon } from './Icon';

export const ImageGenerator: React.FC = () => {
  const [hasKey, setHasKey] = useState(false);
  const [prompt, setPrompt] = useState('');
  const [imageSize, setImageSize] = useState<'1K' | '2K' | '4K'>('1K');
  const [isLoading, setIsLoading] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const checkKey = async () => {
        const aistudio = (window as any).aistudio;
        if (aistudio) {
            try {
                const has = await aistudio.hasSelectedApiKey();
                setHasKey(has);
            } catch (e) {
                console.error("Error checking API key status", e);
            }
        }
    };
    checkKey();
  }, []);

  const handleConnect = async () => {
    const aistudio = (window as any).aistudio;
    if (aistudio) {
        try {
            await aistudio.openSelectKey();
            // Assume success after opening dialog as per instructions to mitigate race conditions
            setHasKey(true);
        } catch (e) {
            console.error("Error opening key selector", e);
        }
    }
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) return;

    setIsLoading(true);
    setError(null);
    setGeneratedImage(null);

    try {
        // Create new instance right before call to ensure fresh API key
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        
        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-image-preview',
            contents: {
                parts: [{ text: `High quality product photography of shoes: ${prompt}` }]
            },
            config: {
                imageConfig: {
                    imageSize: imageSize,
                    aspectRatio: "1:1"
                }
            }
        });

        let found = false;
        if (response.candidates?.[0]?.content?.parts) {
            for (const part of response.candidates[0].content.parts) {
                if (part.inlineData) {
                    setGeneratedImage(`data:image/png;base64,${part.inlineData.data}`);
                    found = true;
                    break;
                }
            }
        }
        
        if (!found) {
            throw new Error("No image generated.");
        }

    } catch (e: any) {
        console.error(e);
        if (e.message?.includes("Requested entity was not found")) {
            setHasKey(false);
            setError("API Key session expired or invalid. Please connect again.");
        } else {
            setError("Failed to generate image. Please try a different prompt or check your connection.");
        }
    } finally {
        setIsLoading(false);
    }
  };

  return (
    <section className="py-12 bg-gray-900 text-white rounded-lg my-12 overflow-hidden relative shadow-2xl">
        <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
        <div className="container mx-auto px-6 relative z-10">
            <div className="flex flex-col md:flex-row gap-12 items-center">
                <div className="w-full md:w-1/2 space-y-6">
                    <div>
                        <div className="inline-flex items-center gap-2 bg-purple-600 text-white px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-4 shadow-lg shadow-purple-900/50">
                            <Icon name="fa-solid fa-wand-magic-sparkles" />
                            <span>AI Design Studio</span>
                        </div>
                        <h2 className="text-3xl md:text-4xl font-montserrat font-bold">Design Your Dream Shoes</h2>
                        <p className="text-gray-400 mt-2 text-lg">
                            Visualize custom colorways, materials, or futuristic concepts for the Wren collection using our advanced AI.
                        </p>
                    </div>

                    {!hasKey ? (
                        <div className="bg-gray-800 p-6 rounded-lg border border-gray-700 animate-fade-in-slow hover:border-purple-500/50 transition-colors duration-300">
                            <h3 className="text-xl font-semibold mb-2">Get Started</h3>
                            <p className="mb-6 text-gray-300">To start designing, please connect a valid Google Cloud API key from a paid project.</p>
                            <button 
                                onClick={handleConnect}
                                className="bg-white text-gray-900 font-bold py-3 px-6 rounded hover:bg-gray-100 transition flex items-center gap-2 shadow-lg hover:shadow-xl hover:-translate-y-0.5"
                            >
                                <Icon name="fa-brands fa-google" />
                                <span>Connect API Key</span>
                            </button>
                            <p className="mt-4 text-xs text-gray-500">
                                <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noreferrer" className="underline hover:text-white transition-colors">Learn about billing</a>. 
                                Standard rates apply.
                            </p>
                        </div>
                    ) : (
                        <div className="space-y-4 animate-fade-in-slow">
                            <div>
                                <label htmlFor="prompt" className="block text-sm font-medium text-gray-400 mb-1">Describe your design</label>
                                <textarea 
                                    id="prompt"
                                    value={prompt}
                                    onChange={(e) => setPrompt(e.target.value)}
                                    placeholder="E.g., A golden version of the sandals with diamond studs and neon lights..."
                                    className="w-full bg-gray-800 border border-gray-700 rounded-lg p-4 text-white placeholder-gray-500 focus:ring-2 focus:ring-purple-500 focus:outline-none h-32 resize-none transition-colors hover:border-gray-600"
                                />
                            </div>
                            
                            <div>
                                <label className="block text-sm font-medium text-gray-400 mb-2">Image Quality</label>
                                <div className="flex gap-4">
                                    {(['1K', '2K', '4K'] as const).map(size => (
                                        <label key={size} className={`flex-1 cursor-pointer border rounded-lg p-3 text-center transition-all duration-200 transform hover:scale-105 select-none ${imageSize === size ? 'bg-purple-600 border-purple-600 text-white shadow-md scale-105' : 'bg-gray-800 border-gray-700 text-gray-400 hover:border-purple-400 hover:text-white hover:bg-gray-700 hover:shadow-lg'}`}>
                                            <input 
                                                type="radio" 
                                                name="imageSize" 
                                                value={size} 
                                                checked={imageSize === size} 
                                                onChange={() => setImageSize(size)} 
                                                className="hidden" 
                                            />
                                            <span className="font-bold">{size}</span>
                                        </label>
                                    ))}
                                </div>
                            </div>

                            <button 
                                onClick={handleGenerate}
                                disabled={isLoading || !prompt.trim()}
                                className={`w-full py-4 rounded-lg font-bold text-lg flex items-center justify-center gap-2 transition-all duration-300 transform hover:-translate-y-0.5 ${isLoading || !prompt.trim() ? 'bg-gray-700 text-gray-500 cursor-not-allowed transform-none' : 'bg-purple-600 text-white hover:bg-purple-700 shadow-lg hover:shadow-purple-500/25 active:scale-95'}`}
                            >
                                {isLoading ? (
                                    <>
                                        <Icon name="fa-solid fa-spinner fa-spin" />
                                        <span>Generating Magic...</span>
                                    </>
                                ) : (
                                    <>
                                        <Icon name="fa-solid fa-paint-brush" />
                                        <span>Generate Design</span>
                                    </>
                                )}
                            </button>
                            {error && (
                                <div className="bg-red-900/30 border border-red-800 rounded p-3 text-red-300 text-sm mt-2 flex items-start gap-2">
                                    <Icon name="fa-solid fa-circle-exclamation" className="mt-0.5 shrink-0"/>
                                    <p>{error}</p>
                                </div>
                            )}
                        </div>
                    )}
                </div>

                <div className="w-full md:w-1/2 flex justify-center">
                    <div className="relative w-full aspect-square max-w-md bg-gray-800 rounded-xl border-2 border-dashed border-gray-700 flex items-center justify-center overflow-hidden shadow-inner transition-colors duration-300 hover:border-gray-600 group">
                        {generatedImage ? (
                            <img src={generatedImage} alt="AI Generated Shoe Design" className="w-full h-full object-cover animate-fade-in-slow" />
                        ) : (
                            <div className="text-center text-gray-600 p-8 group-hover:text-gray-500 transition-colors">
                                <Icon name="fa-solid fa-image" className="text-6xl mb-4 opacity-50 group-hover:scale-110 transition-transform duration-300" />
                                <p className="text-lg font-medium">Your custom design will appear here.</p>
                                <p className="text-sm mt-2 opacity-70">Enter a prompt and click Generate</p>
                            </div>
                        )}
                        {isLoading && (
                            <div className="absolute inset-0 bg-black bg-opacity-80 flex flex-col items-center justify-center text-white backdrop-blur-sm">
                                <Icon name="fa-solid fa-circle-notch fa-spin" className="text-5xl text-purple-500 mb-6" />
                                <p className="animate-pulse font-medium text-lg">Designing your masterpiece...</p>
                                <p className="text-sm text-gray-400 mt-2">This may take a moment</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    </section>
  );
};