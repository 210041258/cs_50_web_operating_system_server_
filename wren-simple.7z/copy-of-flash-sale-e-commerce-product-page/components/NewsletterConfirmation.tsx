import React, { useEffect } from 'react';
import { Icon } from './Icon';

interface NotificationToastProps {
  title: string;
  message: string;
  onClose: () => void;
}

export const NotificationToast: React.FC<NotificationToastProps> = ({ title, message, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 5000); // Auto-close after 5 seconds
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className="fixed bottom-6 left-6 z-50 bg-gray-800 text-white rounded-lg shadow-lg p-4 flex items-center gap-4 animate-slide-in-up w-full max-w-sm border-l-4 border-green-500">
      <Icon name="fa-solid fa-circle-check" className="text-2xl text-green-400 flex-shrink-0" />
      <div>
        <h4 className="font-semibold">{title}</h4>
        <p className="text-sm text-gray-300">{message}</p>
      </div>
      <button onClick={onClose} className="text-gray-400 hover:text-white ml-auto flex-shrink-0">
        <Icon name="fa-solid fa-times" />
      </button>
    </div>
  );
};