import React, { useEffect, useRef, useState, useMemo } from 'react';
import { Icon } from './Icon';
import { SHOP_PRODUCTS, PRODUCT_DATA } from '../constants';
import type { ShopProduct } from '../types';
import { ProductCard } from './ProductCard';

interface SearchModalProps {
  onClose: () => void;
  onViewProduct: (product: ShopProduct) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({ onClose, onViewProduct }) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const [query, setQuery] = useState('');

  // Combine main product and shop products for search
  const allProducts = useMemo(() => {
    const mainProductAsShopProduct: ShopProduct = {
        id: 999,
        name: PRODUCT_DATA.name,
        price: PRODUCT_DATA.salePrice,
        originalPrice: PRODUCT_DATA.originalPrice,
        image: PRODUCT_DATA.images[0].thumbnail,
        category: 'sandals', // Fallback for type compatibility
        isNew: false
    };
    return [mainProductAsShopProduct, ...SHOP_PRODUCTS];
  }, []);

  const filteredProducts = useMemo(() => {
    if (!query.trim()) return [];
    const lowerQuery = query.toLowerCase();
    return allProducts.filter(p => 
        p.name.toLowerCase().includes(lowerQuery) || 
        p.category.toLowerCase().includes(lowerQuery)
    );
  }, [query, allProducts]);

  useEffect(() => {
    // Auto-focus the input field when the modal opens
    inputRef.current?.focus();

    // Handle the 'Escape' key to close the modal
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [onClose]);

  return (
    <div 
        className="fixed inset-0 bg-black bg-opacity-80 flex flex-col items-center p-4 z-50 animate-fade-in overflow-hidden" 
        onClick={onClose}
    >
      <div 
        className="w-full max-w-4xl mt-12 flex flex-col max-h-full"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="relative mb-6 flex-shrink-0">
            <input
                ref={inputRef}
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search for sandals, shoes, etc..."
                className="w-full pl-6 pr-14 py-4 text-lg bg-white text-gray-900 border-2 border-transparent rounded-lg shadow-lg focus:outline-none focus:ring-4 focus:ring-red-300 focus:border-red-500"
            />
            <div className="absolute inset-y-0 right-0 flex items-center pr-5">
                {query ? (
                     <button onClick={() => setQuery('')} className="text-gray-400 hover:text-gray-600">
                        <Icon name="fa-solid fa-times-circle" className="text-xl" />
                     </button>
                ) : (
                    <Icon name="fa-solid fa-search" className="text-gray-400 text-xl" />
                )}
            </div>
        </div>

        <div className="overflow-y-auto flex-grow pr-2 pb-20 custom-scrollbar">
            {query.trim() === '' ? (
                <div className="text-center text-white opacity-70 mt-10">
                    <Icon name="fa-solid fa-magnifying-glass" className="text-5xl mb-4" />
                    <p className="text-lg">Start typing to search for products.</p>
                </div>
            ) : filteredProducts.length > 0 ? (
                <div>
                     <p className="text-white mb-4 text-sm opacity-90">Found {filteredProducts.length} result(s)</p>
                     <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                        {filteredProducts.map(product => (
                            <ProductCard 
                                key={product.id} 
                                product={product} 
                                onViewProduct={(p) => {
                                    onViewProduct(p);
                                    onClose(); // Close search when product is clicked
                                }} 
                            />
                        ))}
                     </div>
                </div>
            ) : (
                <div className="text-center text-white mt-10">
                    <Icon name="fa-regular fa-face-frown" className="text-5xl mb-4 opacity-70" />
                    <p className="text-lg font-semibold">No results found for "{query}"</p>
                    <p className="text-sm opacity-70 mt-2">Try checking for typos or using different keywords.</p>
                </div>
            )}
        </div>
      </div>

      <button onClick={onClose} className="absolute top-6 right-6 text-white hover:text-red-300 transition z-50" aria-label="Close search">
          <Icon name="fa-solid fa-times" className="text-4xl" />
      </button>
    </div>
  );
};