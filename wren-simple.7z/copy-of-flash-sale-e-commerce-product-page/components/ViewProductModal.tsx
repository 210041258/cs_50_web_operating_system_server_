import React, { useState } from 'react';
import { Icon } from './Icon';
import type { ShopProduct } from '../types';

interface ViewProductModalProps {
  product: ShopProduct | null;
  onClose: () => void;
  onAddToCart: () => void;
  onViewDetails: () => void;
}

export const ViewProductModal: React.FC<ViewProductModalProps> = ({ product, onClose, onAddToCart, onViewDetails }) => {
  const [isAdded, setIsAdded] = useState(false);

  if (!product) return null;

  const description = `Discover the ${product.name}, a perfect blend of style and comfort. Crafted from premium materials, this item from our ${product.category} collection is designed for the modern individual. Available now at an incredible price.`;

  const handleAddToCartClick = () => {
    onAddToCart();
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center p-4 z-50" onClick={onClose}>
      <div 
        className="bg-white rounded-lg shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col animate-scale-in overflow-hidden" 
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex flex-col md:flex-row flex-grow overflow-y-auto">
            <div className="w-full md:w-1/2 relative min-h-[300px] md:min-h-auto bg-gray-100">
                <img src={product.image} alt={product.name} className="absolute inset-0 w-full h-full object-cover" />
            </div>
            <div className="w-full md:w-1/2 p-8 flex flex-col relative bg-white">
                <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
                    <Icon name="fa-solid fa-times" className="text-2xl" />
                </button>
                
                <div className="flex-grow flex flex-col justify-center">
                    {product.isNew && (
                        <span className="text-sm text-blue-500 font-bold mb-2 uppercase tracking-wide">New Arrival</span>
                    )}
                    <h2 className="text-3xl font-montserrat font-bold text-gray-900 mb-2 leading-tight">{product.name}</h2>
                    
                    <div className="flex items-baseline gap-3 mb-6">
                        <p className="text-3xl font-montserrat font-extrabold text-red-400">₦{product.price.toLocaleString()}</p>
                        {product.originalPrice && (
                            <p className="text-lg text-gray-400 line-through">₦{product.originalPrice.toLocaleString()}</p>
                        )}
                    </div>

                    <p className="text-gray-600 mb-8 leading-relaxed text-sm">
                        {description}
                    </p>

                    <div className="flex flex-col gap-3">
                        <button 
                            onClick={handleAddToCartClick}
                            disabled={isAdded}
                            className={`w-full font-bold py-3 px-6 text-lg rounded-lg shadow-sm transition flex items-center justify-center gap-2 ${
                                isAdded 
                                ? 'bg-green-600 text-white cursor-default' 
                                : 'bg-red-400 text-white hover:bg-red-500 hover:shadow-md'
                            }`}
                        >
                             {isAdded ? (
                                <>
                                    <Icon name="fa-solid fa-check" />
                                    <span>Added to Cart</span>
                                </>
                            ) : (
                                <>
                                    <Icon name="fa-solid fa-cart-plus" />
                                    <span>Add to Cart</span>
                                </>
                            )}
                        </button>
                        <button 
                            onClick={onViewDetails}
                            className="w-full bg-gray-200 text-gray-700 font-bold py-3 px-6 rounded-lg hover:bg-gray-300 transition flex items-center justify-center gap-2"
                        >
                            <span>View Full Details on Main Site</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        {/* Footer with Close Button */}
        <div className="bg-gray-50 px-6 py-4 border-t border-gray-200 flex justify-end shrink-0">
             <button 
                onClick={onClose} 
                className="bg-gray-800 text-white font-bold py-2 px-6 rounded-lg hover:bg-gray-900 transition shadow-sm"
            >
              Close
            </button>
        </div>
      </div>
    </div>
  );
};