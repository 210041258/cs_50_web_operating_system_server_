import React from 'react';
import { Icon } from './Icon';
import type { CartItem } from '../types';

interface CartModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onRemoveItem: (id: number) => void;
  onUpdateQuantity: (id: number, delta: number) => void;
  onCheckout: () => void;
}

export const CartModal: React.FC<CartModalProps> = ({ 
  isOpen, 
  onClose, 
  cartItems, 
  onRemoveItem, 
  onUpdateQuantity,
  onCheckout
}) => {
  if (!isOpen) return null;

  const total = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div className="absolute inset-0 bg-black bg-opacity-50 transition-opacity" onClick={onClose}></div>
      
      <div className="absolute inset-y-0 right-0 max-w-full flex">
        <div className="relative w-screen max-w-md bg-white shadow-xl flex flex-col animate-slide-in-right">
          
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-6 bg-gray-50 border-b border-gray-200">
            <h2 className="text-lg font-montserrat font-bold text-gray-900">Shopping Cart ({cartItems.length})</h2>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-500">
              <Icon name="fa-solid fa-times" className="text-2xl" />
            </button>
          </div>

          {/* Cart Items */}
          <div className="flex-1 overflow-y-auto p-4">
            {cartItems.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-gray-500">
                <Icon name="fa-solid fa-shopping-basket" className="text-6xl mb-4 opacity-20" />
                <p className="text-lg">Your cart is empty.</p>
                <button onClick={onClose} className="mt-4 text-red-600 font-semibold hover:underline">
                  Start Shopping
                </button>
              </div>
            ) : (
              <ul className="space-y-6">
                {cartItems.map((item) => (
                  <li key={item.id} className="flex py-2">
                    <div className="h-24 w-24 flex-shrink-0 overflow-hidden rounded-md border border-gray-200">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="h-full w-full object-cover object-center"
                      />
                    </div>

                    <div className="ml-4 flex flex-1 flex-col">
                      <div>
                        <div className="flex justify-between text-base font-medium text-gray-900">
                          <h3 className="line-clamp-2 pr-4"><a href="#">{item.name}</a></h3>
                          <p className="ml-4">₦{(item.price * item.quantity).toLocaleString()}</p>
                        </div>
                        <p className="mt-1 text-sm text-gray-500 capitalize">{item.category}</p>
                      </div>
                      <div className="flex flex-1 items-end justify-between text-sm">
                        <div className="flex items-center border border-gray-300 rounded">
                            <button 
                                onClick={() => onUpdateQuantity(item.id, -1)}
                                className="px-2 py-1 hover:bg-gray-100 text-gray-600"
                                disabled={item.quantity <= 1}
                            >-</button>
                            <span className="px-2 font-semibold">{item.quantity}</span>
                            <button 
                                onClick={() => onUpdateQuantity(item.id, 1)}
                                className="px-2 py-1 hover:bg-gray-100 text-gray-600"
                            >+</button>
                        </div>

                        <button
                          type="button"
                          onClick={() => onRemoveItem(item.id)}
                          className="font-medium text-red-600 hover:text-red-500 flex items-center gap-1"
                        >
                          <Icon name="fa-solid fa-trash-can" />
                          <span>Remove</span>
                        </button>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Footer */}
          {cartItems.length > 0 && (
            <div className="border-t border-gray-200 px-4 py-6 sm:px-6 bg-gray-50">
                <div className="flex justify-between text-base font-medium text-gray-900 mb-4">
                <p>Subtotal</p>
                <p>₦{total.toLocaleString()}</p>
                </div>
                <p className="mt-0.5 text-sm text-gray-500 mb-6">Shipping and taxes calculated at checkout.</p>
                <button
                onClick={onCheckout}
                className="flex w-full items-center justify-center rounded-md border border-transparent bg-red-600 px-6 py-3 text-base font-medium text-white shadow-sm hover:bg-red-700 transition"
                >
                Checkout
                </button>
                <div className="mt-6 flex justify-center text-center text-sm text-gray-500">
                <p>
                    or{' '}
                    <button
                    type="button"
                    className="font-medium text-red-600 hover:text-red-500"
                    onClick={onClose}
                    >
                    Continue Shopping
                    <span aria-hidden="true"> &rarr;</span>
                    </button>
                </p>
                </div>
            </div>
          )}
        </div>
      </div>
      <style>{`
        @keyframes slide-in-right {
            from { transform: translateX(100%); }
            to { transform: translateX(0); }
        }
        .animate-slide-in-right {
            animation: slide-in-right 0.3s ease-out forwards;
        }
      `}</style>
    </div>
  );
};
