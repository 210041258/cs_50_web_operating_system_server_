
import React from 'react';
import type { Product } from '../types';
import { Icon } from './Icon';
import { OrderForm } from './OrderForm';
import type { FormData } from '../types';

interface ProductInfoProps {
  product: Product;
  quantity: number;
  setQuantity: React.Dispatch<React.SetStateAction<number>>;
  onOrderSubmit: (formData: FormData, totalPrice: number) => void;
  onOpenSizeGuide: () => void;
  onLinkClick: (page: string) => void;
  onAddToCart: (quantity: number) => void;
}

interface StarRatingProps {
  rating: number;
}

const StarRating: React.FC<StarRatingProps> = ({ rating }) => {
  const fullStars = Math.floor(rating);
  const halfStar = rating % 1 !== 0;
  const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);

  return (
    <div className="flex items-center text-amber-400">
      {[...Array(fullStars)].map((_, i) => <Icon key={`full-${i}`} name="fa-solid fa-star" />)}
      {halfStar && <Icon name="fa-solid fa-star-half-stroke" />}
      {[...Array(emptyStars)].map((_, i) => <Icon key={`empty-${i}`} name="fa-regular fa-star" />)}
    </div>
  );
};

export const ProductInfo: React.FC<ProductInfoProps> = ({ product, quantity, setQuantity, onOrderSubmit, onOpenSizeGuide, onLinkClick, onAddToCart }) => {
  return (
    <div className="flex flex-col gap-6 mt-8 lg:mt-0">
      {/* Product Header */}
      <div>
        <span className="text-sm text-gray-500 font-medium">{product.category}</span>
        <h1 className="text-3xl font-montserrat font-bold text-gray-900 mt-1">{product.name}</h1>
        <div className="flex items-center gap-4 mt-3">
          <div className="flex items-center gap-2">
            <StarRating rating={product.rating} />
            <span className="font-semibold">{product.rating}</span>
          </div>
          <span className="text-gray-500">({product.reviewCount} reviews)</span>
          <span className="w-px h-4 bg-gray-300"></span>
          {product.inStock && (
            <span className="text-green-600 font-semibold flex items-center gap-1.5 text-sm">
              <Icon name="fa-solid fa-check-circle" /> In Stock
            </span>
          )}
        </div>
      </div>
      
      {/* Pricing */}
      <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded-r-lg">
        <div className="flex items-baseline gap-4">
          <div>
            <span className="text-gray-500 text-sm">WAS</span>
            <p className="text-xl text-gray-500 line-through">₦{product.originalPrice.toLocaleString()}</p>
          </div>
          <div>
            <span className="text-red-600 text-sm font-semibold">NOW</span>
            <p className="text-4xl font-montserrat font-extrabold text-red-700">₦{product.salePrice.toLocaleString()}</p>
          </div>
        </div>
        <div className="mt-3 bg-green-100 text-green-800 text-sm font-semibold px-3 py-1.5 rounded-md inline-flex items-center gap-2">
          <Icon name="fa-solid fa-tag" />
          <span>You save ₦{(product.originalPrice - product.salePrice).toLocaleString()} ({product.salePercentage}% OFF)</span>
        </div>
        <p className="text-xs text-gray-600 mt-3">Price will increase after the sale ends.</p>
      </div>

      {/* Specifications */}
      <div>
        <h3 className="text-lg font-semibold mb-3">Product Details</h3>
        <ul className="space-y-2 text-sm">
          {product.specifications.map(spec => (
            <li key={spec.label} className="flex items-center gap-3">
              <Icon name={spec.icon} className="text-gray-400 w-5 text-center" />
              <span className="font-semibold text-gray-600 w-24">{spec.label}:</span>
              <div className="flex items-center gap-2">
                {spec.valueComponent}
                <span className="text-gray-800">{spec.value}</span>
                {spec.label === 'Size' && (
                  <button onClick={onOpenSizeGuide} className="text-xs text-red-600 hover:underline flex items-center gap-1 ml-2">
                    <Icon name="fa-solid fa-ruler-horizontal" />
                    Size Guide
                  </button>
                )}
              </div>
            </li>
          ))}
        </ul>
      </div>

      {/* Order Form */}
      <OrderForm 
        productSalePrice={product.salePrice}
        quantity={quantity}
        setQuantity={setQuantity}
        onOrderSubmit={onOrderSubmit}
        onLinkClick={onLinkClick}
        onAddToCart={onAddToCart}
      />
    </div>
  );
};
