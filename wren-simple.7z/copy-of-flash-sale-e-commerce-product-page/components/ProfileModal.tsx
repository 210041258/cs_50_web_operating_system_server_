import React, { useState } from 'react';
import { Icon } from './Icon';

interface ProfileModalProps {
  onClose: () => void;
  onSuccess: (isLogin: boolean) => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({ onClose, onSuccess }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;

    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
        setIsLoading(false);
        onSuccess(isLogin);
        onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center p-4 z-50" onClick={onClose}>
      <div 
        className="bg-white rounded-lg shadow-2xl max-w-sm w-full p-8 relative animate-fade-in-up" 
        onClick={(e) => e.stopPropagation()}
      >
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
          <Icon name="fa-solid fa-times" className="text-2xl" />
        </button>

        <div className="text-center mb-6">
            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Icon name="fa-solid fa-user" className="text-4xl text-gray-400" />
            </div>
            <h2 className="text-2xl font-montserrat font-bold text-gray-900">{isLogin ? 'Welcome Back' : 'Create Account'}</h2>
            <p className="text-sm text-gray-500 mt-1">
                {isLogin ? 'Please sign in to continue' : 'Join us for exclusive offers'}
            </p>
        </div>

        <form className="space-y-4" onSubmit={handleSubmit}>
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400">
                        <Icon name="fa-solid fa-envelope" />
                    </span>
                    <input 
                        type="email" 
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="you@example.com" 
                        required
                        className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-red-500 focus:border-red-500 bg-white" 
                    />
                </div>
            </div>
            
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
                <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400">
                        <Icon name="fa-solid fa-lock" />
                    </span>
                    <input 
                        type="password" 
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••" 
                        required
                        className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-red-500 focus:border-red-500 bg-white" 
                    />
                </div>
            </div>

            <button 
                type="submit" 
                disabled={isLoading}
                className="w-full bg-red-600 text-white font-bold py-3 rounded-lg hover:bg-red-700 transition shadow-md flex items-center justify-center gap-2 disabled:bg-red-400 disabled:cursor-not-allowed"
            >
                {isLoading ? (
                    <>
                        <Icon name="fa-solid fa-circle-notch fa-spin" />
                        <span>Processing...</span>
                    </>
                ) : (
                    <span>{isLogin ? 'Sign In' : 'Sign Up'}</span>
                )}
            </button>
        </form>

        <div className="mt-6 text-center text-sm">
            <p className="text-gray-600">
                {isLogin ? "Don't have an account? " : "Already have an account? "}
                <button 
                    onClick={() => { setIsLogin(!isLogin); setEmail(''); setPassword(''); }} 
                    className="text-red-600 font-semibold hover:underline"
                >
                    {isLogin ? 'Sign Up' : 'Sign In'}
                </button>
            </p>
        </div>
      </div>
    </div>
  );
};