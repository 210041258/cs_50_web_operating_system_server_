import React, { useCallback } from 'react';
import type { Product, FormData } from '../../types';
import { Icon } from '../ui/Icon';
import { OrderForm } from './OrderForm';
import { useShop } from '../../context/ShopContext';
import { useUI } from '../../context/UIContext';

interface ProductInfoProps {
  product: Product;
  quantity: number;
  setQuantity: React.Dispatch<React.SetStateAction<number>>;
  onOrderSubmit: (formData: FormData, totalPrice: number) => void;
  // Props onOpenSizeGuide and onLinkClick removed as they are now handled by UIContext internally or via OrderForm
  onLinkClick?: (page: string) => void; 
}

interface StarRatingProps {
  rating: number;
}

const StarRating: React.FC<StarRatingProps> = ({ rating }) => {
  const fullStars = Math.floor(rating);
  const halfStar = rating % 1 !== 0;
  const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);

  return (
    <div className="flex items-center text-amber-400">
      {[...Array(fullStars)].map((_, i) => <Icon key={`full-${i}`} name="fa-solid fa-star" />)}
      {halfStar && <Icon name="fa-solid fa-star-half-stroke" />}
      {[...Array(emptyStars)].map((_, i) => <Icon key={`empty-${i}`} name="fa-regular fa-star" />)}
    </div>
  );
};

export const ProductInfo: React.FC<ProductInfoProps> = ({ product, quantity, setQuantity, onOrderSubmit }) => {
  const { addToCart } = useShop();
  const { openSizeGuide, openInfoPage } = useUI();

  const handleLinkClick = useCallback((page: string) => {
    openInfoPage(page);
  }, [openInfoPage]);

  // Extract Color Spec
  const colorSpec = product.specifications.find(s => s.label === 'Color');

  return (
    <div className="flex flex-col gap-6 mt-8 lg:mt-0">
      {/* Product Header */}
      <div>
        <span className="text-sm text-gray-500 font-medium">{product.category}</span>
        <h1 className="text-3xl font-montserrat font-bold text-gray-900 mt-1">{product.name}</h1>
        <div className="flex items-center gap-4 mt-3">
          <div className="flex items-center gap-2">
            <StarRating rating={product.rating} />
            <span className="font-semibold">{product.rating}</span>
          </div>
          <span className="text-gray-500">({product.reviewCount} reviews)</span>
          <span className="w-px h-4 bg-gray-300"></span>
          {product.inStock && (
            <span className="text-green-600 font-semibold flex items-center gap-1.5 text-sm">
              <Icon name="fa-solid fa-check-circle" /> In Stock
            </span>
          )}
        </div>
      </div>
      
      {/* Pricing with Animation */}
      <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded-r-lg">
        <div className="flex items-baseline gap-4">
          <div>
            <span className="text-gray-500 text-sm">WAS</span>
            <p className="text-xl text-gray-500 line-through">₦{product.originalPrice.toLocaleString()}</p>
          </div>
          <div>
            <span className="text-red-600 text-sm font-semibold">NOW</span>
            <p className="text-4xl font-montserrat font-extrabold text-red-700 animate-pulse-slow">₦{product.salePrice.toLocaleString()}</p>
          </div>
        </div>
        <div className="mt-3 bg-green-100 text-green-800 text-sm font-semibold px-3 py-1.5 rounded-md inline-flex items-center gap-2">
          <Icon name="fa-solid fa-tag" />
          <span>You save ₦{(product.originalPrice - product.salePrice).toLocaleString()} ({product.salePercentage}% OFF)</span>
        </div>
        <p className="text-xs text-gray-600 mt-3">Price will increase after the sale ends.</p>
      </div>

      {/* Description & Highlights */}
      <div className="text-gray-600 space-y-4">
        <p className="leading-relaxed">{product.description}</p>
        <ul className="space-y-2">
          {product.highlights.map((highlight, index) => (
            <li key={index} className="flex items-center gap-2 text-sm font-medium">
              <Icon name="fa-solid fa-check" className="text-red-500" />
              {highlight}
            </li>
          ))}
        </ul>
        <button onClick={openSizeGuide} className="text-sm text-red-600 font-bold hover:underline flex items-center gap-1 mt-2">
           <Icon name="fa-solid fa-ruler-horizontal" />
           View Size Guide
        </button>
      </div>

      {/* Color Selection (Visual Swatch) */}
      {colorSpec && (
        <div className="border-t border-gray-100 pt-4">
           <h3 className="text-sm font-bold text-gray-900 mb-2">{colorSpec.label}</h3>
           <div className="flex items-center gap-3">
              <button 
                className="w-8 h-8 rounded-full bg-black border border-gray-300 shadow-sm ring-2 ring-offset-2 ring-red-500 focus:outline-none transition-transform hover:scale-110"
                aria-label={`Selected Color: ${colorSpec.value}`}
                title={colorSpec.value}
              ></button>
              <span className="text-sm font-medium text-gray-700">{colorSpec.value}</span>
           </div>
        </div>
      )}

      {/* Order Form */}
      <OrderForm 
        productSalePrice={product.salePrice}
        quantity={quantity}
        setQuantity={setQuantity}
        onOrderSubmit={onOrderSubmit}
        onLinkClick={handleLinkClick}
        onAddToCart={(qty) => addToCart(product, qty)}
      />
    </div>
  );
};