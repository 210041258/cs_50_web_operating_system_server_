import React, { useState } from 'react';
import type { ProductImage } from '../../types';
import { Icon } from '../ui/Icon';
import { useUI } from '../../context/UIContext';

interface ProductGalleryProps {
  images: ProductImage[];
  salePercentage: number;
  onQuickViewClick?: (image: ProductImage) => void; // Optional, handled by Context
}

export const ProductGallery: React.FC<ProductGalleryProps> = ({ images, salePercentage }) => {
  const [mainImage, setMainImage] = useState(images[0]);
  const { openQuickView } = useUI();

  return (
    <div className="flex flex-col gap-4">
      <div className="relative group aspect-square w-full rounded-lg overflow-hidden border border-gray-200 shadow-sm hover:shadow-lg transition-shadow duration-300">
        <img src={mainImage.full} alt={mainImage.alt} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all duration-300 flex items-center justify-center">
            <button 
                onClick={() => openQuickView(mainImage)}
                className="flex items-center gap-2 bg-white text-gray-800 font-bold py-3 px-6 rounded-lg shadow-md opacity-0 group-hover:opacity-100 transition-all duration-300 transform scale-90 group-hover:scale-100 hover:bg-red-600 hover:text-white"
            >
                <Icon name="fa-solid fa-eye" />
                <span>Quick View</span>
            </button>
        </div>
        <div className="absolute top-4 left-4 bg-red-600 text-white font-montserrat font-bold text-lg px-4 py-2 rounded-md pointer-events-none shadow-md">
          {salePercentage}% OFF
        </div>
      </div>
      <div className="grid grid-cols-4 gap-4">
        {images.map(image => (
          <button
            key={image.id}
            onClick={() => setMainImage(image)}
            className={`aspect-square w-full rounded-md overflow-hidden border-2 transition-all duration-300 transform hover:scale-105 hover:shadow-lg ${mainImage.id === image.id ? 'border-red-500 ring-2 ring-red-300 scale-105 shadow-md' : 'border-gray-200 hover:border-red-400 opacity-80 hover:opacity-100'}`}
          >
            <img src={image.thumbnail} alt={image.alt} className="w-full h-full object-cover" />
          </button>
        ))}
      </div>
    </div>
  );
};