import React, { useState, useMemo, useEffect, useRef } from 'react';
import type { FormData } from '../../types';
import { Icon } from '../ui/Icon';
import { DELIVERY_OPTIONS, PRODUCT_DATA } from '../../data/constants';
import { useShop } from '../../context/ShopContext';
import { sanitizeInput } from '../../utils/security';

interface OrderFormProps {
    productSalePrice: number;
    quantity: number;
    setQuantity: React.Dispatch<React.SetStateAction<number>>;
    onOrderSubmit: (formData: FormData, totalPrice: number) => void;
    onLinkClick: (page: string) => void;
    onAddToCart: (quantity: number) => void;
}

interface InputFieldProps {
    id: string;
    label: string;
    type: string;
    placeholder: string;
    value: string;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    error?: string;
}

const InputField: React.FC<InputFieldProps> = ({id, label, type, placeholder, value, onChange, error}) => (
    <div>
        <label htmlFor={id} className="block text-sm font-semibold text-gray-700 mb-1.5 ml-1">{label}</label>
        <input 
            type={type} 
            id={id} 
            name={id} 
            value={value} 
            onChange={onChange} 
            placeholder={placeholder} 
            required 
            className={`w-full px-4 py-3 border rounded-lg shadow-sm text-gray-900 placeholder-gray-400 bg-white transition-all duration-200 ease-in-out focus:outline-none focus:ring-4 ${error 
                ? 'border-red-300 focus:border-red-500 focus:ring-red-100 hover:border-red-400' 
                : 'border-gray-200 hover:border-gray-400 focus:border-red-500 focus:ring-red-50'
            }`} 
        />
        {error && <p className="text-red-600 text-xs mt-1.5 ml-1 flex items-center gap-1"><Icon name="fa-solid fa-circle-exclamation" /> {error}</p>}
    </div>
);


export const OrderForm: React.FC<OrderFormProps> = ({ productSalePrice, quantity, setQuantity, onOrderSubmit, onLinkClick, onAddToCart }) => {
  const { addToWishlist, isInWishlist, removeFromWishlist } = useShop();
  
  const [formData, setFormData] = useState<FormData>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    paymentMethod: 'cod',
    deliveryMethod: 'standard',
    termsAccepted: false,
    newsletterSubscribed: false
  });
  
  const [errors, setErrors] = useState<Partial<Record<keyof FormData, string>>>({});
  const [isAnimating, setIsAnimating] = useState(false);
  const [isAddedToCart, setIsAddedToCart] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const isInitialMount = useRef(true);
  const [addressSuggestions, setAddressSuggestions] = useState<any[]>([]);
  const [isSearchingAddress, setIsSearchingAddress] = useState(false);
  
  // Check if main product is in wishlist
  const isWishlisted = isInWishlist(PRODUCT_DATA.id);

  const totalPrice = useMemo(() => {
    const deliveryCost = DELIVERY_OPTIONS.find(opt => opt.id === formData.deliveryMethod)?.cost || 0;
    return (productSalePrice * quantity) + deliveryCost;
  }, [productSalePrice, quantity, formData.deliveryMethod]);

  useEffect(() => {
    if (isInitialMount.current) {
        isInitialMount.current = false;
        return;
    }
    setIsAnimating(true);
    const timer = setTimeout(() => setIsAnimating(false), 200);
    return () => clearTimeout(timer);
  }, [quantity]);

  // Debounced address search
  useEffect(() => {
    const handler = setTimeout(async () => {
        if (formData.address.length > 2) {
            setIsSearchingAddress(true);
            setAddressSuggestions([]);
            try {
                // Using OpenStreetMap Nominatim for address suggestions
                // Added countrycodes=ng to bias results towards Nigeria based on currency context
                const response = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(formData.address)}&format=json&addressdetails=1&limit=5&countrycodes=ng`);
                if (!response.ok) throw new Error('Network response was not ok');
                const data = await response.json();
                setAddressSuggestions(data);
            } catch (error) {
                console.error("Failed to fetch address suggestions:", error);
                setAddressSuggestions([]);
            } finally {
                setIsSearchingAddress(false);
            }
        } else {
            setAddressSuggestions([]);
        }
    }, 500); 

    return () => {
        clearTimeout(handler);
    };
}, [formData.address]);


  const getValidationError = (name: keyof FormData, value: string | boolean): string => {
    switch (name) {
        case 'firstName':
            if (typeof value === 'string' && !value.trim()) return "First name is required.";
            break;
        case 'lastName':
            if (typeof value === 'string' && !value.trim()) return "Last name is required.";
            break;
        case 'email':
            if (typeof value === 'string' && !value.trim()) {
                return "Email is required.";
            } else if (typeof value === 'string' && !/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(value)) {
                return "Invalid email format.";
            }
            break;
        case 'phone':
            if (typeof value === 'string' && !value.trim()) {
                return "Phone number is required.";
            }
            break;
        case 'address':
            if (typeof value === 'string' && !value.trim()) return "Delivery address is required.";
            break;
        case 'termsAccepted':
             if (value === false) return "You must accept the terms.";
             break;
    }
    return ''; // No error
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    const error = getValidationError(name as keyof FormData, value);
    setErrors(prev => ({ ...prev, [name]: error }));
  };
  
  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData(prev => ({ ...prev, [name]: checked }));
    if (name === 'termsAccepted') {
        const error = getValidationError(name as keyof FormData, checked);
        setErrors(prev => ({ ...prev, [name]: error }));
    }
  };

  const handleSuggestionClick = (suggestion: any) => {
    const fullAddress = suggestion.display_name;
    setFormData(prev => ({ ...prev, address: fullAddress }));
    setAddressSuggestions([]); 
    setErrors(prev => ({ ...prev, address: '' }));
  };
  
  const handleAddressBlur = (e: React.FocusEvent<HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    const error = getValidationError(name as keyof FormData, value);
    setErrors(prev => ({ ...prev, [name]: error }));

    setTimeout(() => {
      setAddressSuggestions([]);
    }, 200);
  };

  const handleUseLocation = () => {
    if (!navigator.geolocation) {
        alert("Geolocation is not supported by your browser");
        return;
    }

    setIsSearchingAddress(true);
    navigator.geolocation.getCurrentPosition(
        async (position) => {
            const { latitude, longitude } = position.coords;
            try {
                const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&addressdetails=1`);
                const data = await response.json();
                if (data && data.display_name) {
                    setFormData(prev => ({ ...prev, address: data.display_name }));
                    setErrors(prev => ({ ...prev, address: '' }));
                }
            } catch (e) {
                console.error("Geocoding failed", e);
            } finally {
                setIsSearchingAddress(false);
            }
        },
        (err) => {
            console.error(err);
            setIsSearchingAddress(false);
            alert("Unable to retrieve your location. Please type your address manually.");
        }
    );
  };

  const validateForm = () => {
      const newErrors: Partial<Record<keyof FormData, string>> = {};
      (Object.keys(formData) as Array<keyof FormData>).forEach(key => {
          const error = getValidationError(key, formData[key]);
          if (error) {
              newErrors[key] = error;
          }
      });
      
      setErrors(newErrors);
      return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
        setIsSubmitting(true);
        
        // Simulate network request
        setTimeout(() => {
            // Sanitize data before submission
            const sanitizedData: FormData = {
                ...formData,
                firstName: sanitizeInput(formData.firstName),
                lastName: sanitizeInput(formData.lastName),
                email: sanitizeInput(formData.email),
                phone: sanitizeInput(formData.phone),
                address: sanitizeInput(formData.address),
            };

            onOrderSubmit(sanitizedData, totalPrice);
            
            // Reset form safely
            setFormData({
                 firstName: '', lastName: '', email: '', phone: '', address: '',
                 paymentMethod: 'cod', deliveryMethod: 'standard', termsAccepted: false, newsletterSubscribed: false
            });
            setErrors({});
            setIsSubmitting(false);
        }, 1500);
    }
  };

  const handleToggleWishlist = () => {
      if (isWishlisted) {
          removeFromWishlist(PRODUCT_DATA.id);
      } else {
          addToWishlist(PRODUCT_DATA);
      }
  };

  const handleAddToCart = () => {
    onAddToCart(quantity);
    setIsAddedToCart(true);
    setTimeout(() => setIsAddedToCart(false), 2000);
  };

  const formatSuggestion = (suggestion: any) => {
      const parts = suggestion.address || {};
      const main = parts.road || parts.building || parts.amenity || suggestion.display_name.split(',')[0];
      // Construct subtitle from remaining parts
      const remaining = suggestion.display_name.replace(main, '').replace(/^,\s*/, '');
      return { main, sub: remaining };
  };

  return (
    <form onSubmit={handleSubmit} className="border-t border-gray-200 pt-6 space-y-6">
        {/* Quantity and Total */}
        <div className="flex justify-between items-center gap-4">
            <div className="flex items-center gap-2">
                <label className="font-semibold text-gray-800">Quantity:</label>
                <div className="flex items-center border border-gray-300 rounded-lg overflow-hidden shadow-sm bg-white">
                    <button type="button" onClick={() => setQuantity(q => Math.max(1, q - 1))} className="px-4 py-2 text-lg hover:bg-gray-100 transition-colors border-r border-gray-200 bg-gray-50">-</button>
                    <input 
                        type="text" 
                        readOnly 
                        value={quantity} 
                        className={`w-14 text-center font-semibold transition-all duration-200 transform ${isAnimating ? 'scale-110 bg-red-50 text-red-600 opacity-80' : 'bg-white text-gray-900 opacity-100'}`} 
                    />
                    <button type="button" onClick={() => setQuantity(q => q + 1)} className="px-4 py-2 text-lg hover:bg-gray-100 transition-colors border-l border-gray-200 bg-gray-50">+</button>
                </div>
            </div>
            <div className="text-right">
                <span className="text-sm text-gray-500 block mb-1">Total Price</span>
                <p className="font-bold text-3xl text-red-700">₦{totalPrice.toLocaleString()}</p>
            </div>
        </div>
        
        {/* Personal Info */}
        <div className="space-y-5">
            <h3 className="font-bold text-xl text-gray-800 border-b pb-2">Personal Information</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <InputField id="firstName" label="First Name" type="text" placeholder="John" value={formData.firstName} onChange={handleInputChange} error={errors.firstName} />
                <InputField id="lastName" label="Last Name" type="text" placeholder="Doe" value={formData.lastName} onChange={handleInputChange} error={errors.lastName} />
            </div>
            <InputField id="email" label="Email Address" type="email" placeholder="you@example.com" value={formData.email} onChange={handleInputChange} error={errors.email} />
            <InputField id