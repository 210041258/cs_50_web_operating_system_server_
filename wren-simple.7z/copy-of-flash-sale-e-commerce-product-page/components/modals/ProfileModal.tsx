import React, { useState, useEffect } from 'react';
import { Icon } from '../ui/Icon';
import { useShop } from '../../context/ShopContext';
import { sanitizeInput, validateEmail, validatePassword } from '../../utils/security';

interface ProfileModalProps {
  onSuccess: (isLogin: boolean) => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({ onSuccess }) => {
  const { isProfileOpen, closeProfile, user, login, logout, orders } = useShop();
  const [isLoginView, setIsLoginView] = useState(true); // Toggle between Login and Signup form
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<{email?: string; password?: string}>({});
  
  // Analytics State
  const [activeTab, setActiveTab] = useState<'orders' | 'analytics'>('orders');
  const [probabilityData, setProbabilityData] = useState<number[]>([]);

  useEffect(() => {
      if (isProfileOpen) {
          // Generate random "probability" data for the graph
          setProbabilityData(Array.from({ length: 20 }, () => Math.floor(Math.random() * 60) + 20));
      }
  }, [isProfileOpen]);

  if (!isProfileOpen) return null;

  const validate = (): boolean => {
      const newErrors: {email?: string; password?: string} = {};
      
      if (!email) {
          newErrors.email = "Email is required.";
      } else if (!validateEmail(email)) {
          newErrors.email = "Please enter a valid email address.";
      }

      if (!password) {
          newErrors.password = "Password is required.";
      } else if (!isLoginView) {
          const { valid, reasons } = validatePassword(password);
          if (!valid) {
             newErrors.password = reasons[0];
          }
      }

      setErrors(newErrors);
      return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setIsLoading(true);

    const cleanEmail = sanitizeInput(email);
    
    // Simulate API call
    setTimeout(() => {
        setIsLoading(false);
        const mockUser = {
            name: cleanEmail.split('@')[0],
            email: cleanEmail
        };
        login(mockUser);
        onSuccess(isLoginView);
        setEmail('');
        setPassword('');
        setErrors({});
    }, 1500);
  };

  if (user) {
      // Authenticated View: Dashboard & Orders & Analytics
      return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center p-4 z-50" onClick={closeProfile}>
            <div 
                className="bg-white rounded-lg shadow-2xl max-w-2xl w-full p-8 relative animate-fade-in-up max-h-[85vh] overflow-y-auto" 
                onClick={(e) => e.stopPropagation()}
            >
                <button onClick={closeProfile} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
                    <Icon name="fa-solid fa-times" className="text-2xl" />
                </button>

                <div className="flex items-center gap-4 mb-8 pb-6 border-b border-gray-100">
                    <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center font-bold text-2xl uppercase">
                        {user.name[0]}
                    </div>
                    <div>
                        <h2 className="text-2xl font-montserrat font-bold text-gray-900">Hello, {user.name}</h2>
                        <p className="text-sm text-gray-500">{user.email}</p>
                    </div>
                    <button onClick={logout} className="ml-auto text-sm text-red-600 hover:underline">
                        Sign Out
                    </button>
                </div>

                {/* Tabs */}
                <div className="flex border-b border-gray-200 mb-6">
                    <button 
                        onClick={() => setActiveTab('orders')} 
                        className={`pb-3 px-4 font-semibold text-sm transition-colors relative ${activeTab === 'orders' ? 'text-red-600' : 'text-gray-500 hover:text-gray-700'}`}
                    >
                        <span className="flex items-center gap-2"><Icon name="fa-solid fa-box-open" /> Order History</span>
                        {activeTab === 'orders' && <span className="absolute bottom-0 left-0 w-full h-0.5 bg-red-600"></span>}
                    </button>
                    <button 
                        onClick={() => setActiveTab('analytics')} 
                        className={`pb-3 px-4 font-semibold text-sm transition-colors relative ${activeTab === 'analytics' ? 'text-red-600' : 'text-gray-500 hover:text-gray-700'}`}
                    >
                        <span className="flex items-center gap-2"><Icon name="fa-solid fa-chart-line" /> Network Analytics</span>
                        {activeTab === 'analytics' && <span className="absolute bottom-0 left-0 w-full h-0.5 bg-red-600"></span>}
                    </button>
                </div>

                {/* Tab Content */}
                <div className="min-h-[300px]">
                    {activeTab === 'orders' ? (
                        <div className="space-y-6 animate-fade-in">
                            {orders.length === 0 ? (
                                <div className="text-center py-12 bg-gray-50 rounded-lg border border-dashed border-gray-200">
                                    <Icon name="fa-solid fa-receipt" className="text-4xl text-gray-300 mb-3" />
                                    <p className="text-gray-500">You haven't placed any orders yet.</p>
                                </div>
                            ) : (
                                <div className="space-y-4">
                                    {orders.map((order) => (
                                        <div key={order.id} className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow">
                                            <div className="flex justify-between items-start mb-3">
                                                <div>
                                                    <p className="font-bold text-gray-900">{order.id}</p>
                                                    <p className="text-xs text-gray-500">{new Date(order.date).toLocaleDateString()} • {new Date(order.date).toLocaleTimeString()}</p>
                                                </div>
                                                <div className="text-right">
                                                    <p className="font-bold text-red-600">₦{order.total.toLocaleString()}</p>
                                                    <span className={`inline-block px-2 py-0.5 rounded text-xs font-semibold mt-1 
                                                        ${order.status === 'Delivered' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}`}>
                                                        {order.status}
                                                    </span>
                                                </div>
                                            </div>
                                            <div className="border-t border-gray-100 pt-3">
                                                <p className="text-sm text-gray-600 mb-2 font-medium">Items:</p>
                                                <ul className="space-y-1 text-sm text-gray-500">
                                                    {order.items.map((item, idx) => (
                                                        <li key={idx} className="flex justify-between">
                                                            <span>{item.name} <span className="text-gray-400">x{item.quantity}</span></span>
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                    ) : (
                        <div className="space-y-6 animate-fade-in">
                            {/* Probability Detection Section */}
                            <div className="bg-gray-900 p-5 rounded-lg border border-gray-800 text-white shadow-inner">
                                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-6 flex items-center justify-between">
                                    <span className="flex items-center gap-2"><Icon name="fa-solid fa-wave-square" /> Probability Detection</span>
                                    <span className="text-red-500 bg-red-900/30 border border-red-500/30 px-2 py-0.5 rounded text-[10px] animate-pulse">LIVE</span>
                                </h4>
                                
                                <div className="flex items-end gap-1 h-32 border-b border-gray-700 pb-1">
                                    {probabilityData.map((val, i) => (
                                        <div key={i} className="flex-1 flex flex-col justify-end group h-full">
                                            <div 
                                                className="w-full bg-gradient-to-t from-red-600 to-red-400 rounded-t-sm hover:from-red-500 hover:to-red-300 transition-all duration-300 relative" 
                                                style={{ height: `${val}%` }}
                                            >
                                                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 bg-white text-black text-[9px] font-mono px-1 rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity">
                                                    {val}%
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                                <div className="flex justify-between mt-2 text-[9px] text-gray-500 font-mono tracking-tighter">
                                    <span>T-0</span>
                                    <span>NETWORK_USAGE_PROBABILITY</span>
                                    <span>T-NOW</span>
                                </div>
                            </div>

                            {/* System Internals (Enclosed Parts) */}
                            <div>
                                <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 flex items-center gap-2">
                                    <Icon name="fa-solid fa-microchip" /> System Internals (Enclosed Parts)
                                </h4>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="border border-gray-200 rounded-lg p-4 flex flex-col justify-between hover:border-red-200 transition-colors bg-white hover:shadow-sm">
                                        <div className="flex justify-between items-start">
                                            <span className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">Latency</span>
                                            <Icon name="fa-solid fa-stopwatch" className="text-gray-300" />
                                        </div>
                                        <p className="text-2xl font-mono font-bold text-gray-800 mt-2">24<span className="text-xs text-gray-400 font-sans ml-1">ms</span></p>
                                    </div>
                                    <div className="border border-gray-200 rounded-lg p-4 flex flex-col justify-between hover:border-red-200 transition-colors bg-white hover:shadow-sm">
                                        <div className="flex justify-between items-start">
                                            <span className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">Packets</span>
                                            <Icon name="fa-solid fa-cube" className="text-gray-300" />
                                        </div>
                                        <p className="text-2xl font-mono font-bold text-gray-800 mt-2">1.2<span className="text-xs text-gray-400 font-sans ml-1">k</span></p>
                                    </div>
                                    <div className="border border-gray-200 rounded-lg p-4 flex flex-col justify-between hover:border-red-200 transition-colors bg-white hover:shadow-sm">
                                        <div className="flex justify-between items-start">
                                            <span className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">Bandwidth</span>
                                            <Icon name="fa-solid fa-bolt" className="text-green-500" />
                                        </div>
                                        <div className="mt-2">
                                            <div className="w-full bg-gray-100 rounded-full h-1.5 mb-1">
                                                <div className="bg-green-500 h-1.5 rounded-full" style={{ width: '85%' }}></div>
                                            </div>
                                            <span className="text-xs text-green-600 font-bold">OPTIMAL</span>
                                        </div>
                                    </div>
                                    <div className="border border-gray-200 rounded-lg p-4 flex flex-col justify-between hover:border-red-200 transition-colors bg-white hover:shadow-sm">
                                        <div className="flex justify-between items-start">
                                            <span className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">Encryption</span>
                                            <Icon name="fa-solid fa-lock" className="text-gray-300" />
                                        </div>
                                        <p className="text-xl font-mono font-bold text-gray-800 mt-2">AES-256</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
      );
  }

  // Unauthenticated View: Login/Signup
  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center p-4 z-50" onClick={closeProfile}>
      <div 
        className="bg-white rounded-lg shadow-2xl max-w-sm w-full p-8 relative animate-fade-in-up" 
        onClick={(e) => e.stopPropagation()}
      >
        <button onClick={closeProfile} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
          <Icon name="fa-solid fa-times" className="text-2xl" />
        </button>

        <div className="text-center mb-6">
            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Icon name="fa-solid fa-user" className="text-4xl text-gray-400" />
            </div>
            <h2 className="text-2xl font-montserrat font-bold text-gray-900">{isLoginView ? 'Welcome Back' : 'Create Account'}</h2>
            <p className="text-sm text-gray-500 mt-1">
                {isLoginView ? 'Please sign in to continue' : 'Join us for exclusive offers'}
            </p>
        </div>

        <form className="space-y-4" onSubmit={handleSubmit}>
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400">
                        <Icon name="fa-solid fa-envelope" />
                    </span>
                    <input 
                        type="email" 
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="you@example.com" 
                        className={`w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 bg-white transition-colors ${errors.email ? 'border-red-300' : 'border-gray-300'}`}
                    />
                </div>
                {errors.email && <p className="text-xs text-red-500 mt-1">{errors.email}</p>}
            </div>
            
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
                <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400">
                        <Icon name="fa-solid fa-lock" />
                    </span>
                    <input 
                        type="password" 
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••" 
                        className={`w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 bg-white transition-colors ${errors.password ? 'border-red-300' : 'border-gray-300'}`}
                    />
                </div>
                {errors.password && <p className="text-xs text-red-500 mt-1">{errors.password}</p>}
            </div>

            <button 
                type="submit" 
                disabled={isLoading}
                className="w-full bg-red-600 text-white font-bold py-3 rounded-lg hover:bg-red-700 transition shadow-md flex items-center justify-center gap-2 disabled:bg-red-400 disabled:cursor-not-allowed"
            >
                {isLoading ? (
                    <>
                        <Icon name="fa-solid fa-circle-notch fa-spin" />
                        <span>Processing...</span>
                    </>
                ) : (
                    <span>{isLoginView ? 'Sign In' : 'Sign Up'}</span>
                )}
            </button>
        </form>

        <div className="mt-6 text-center text-sm">
            <p className="text-gray-600">
                {isLoginView ? "Don't have an account? " : "Already have an account? "}
                <button 
                    onClick={() => { setIsLoginView(!isLoginView); setEmail(''); setPassword(''); setErrors({}); }} 
                    className="text-red-600 font-semibold hover:underline"
                >
                    {isLoginView ? 'Sign Up' : 'Sign In'}
                </button>
            </p>
        </div>
      </div>
    </div>
  );
};