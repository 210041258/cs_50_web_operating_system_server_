import React, { useState, useMemo } from 'react';
import { Icon } from '../ui/Icon';
import type { ShopProduct } from '../../types';
import { ProductCard } from '../product/ProductCard';

interface ShopCategoryModalProps {
  title: string;
  products: ShopProduct[];
  onClose: () => void;
  onGoToFlashSale: () => void;
  onViewProduct: (product: ShopProduct) => void;
}

type SortOrder = 'default' | 'newest' | 'price-asc' | 'price-desc';

export const ShopCategoryModal: React.FC<ShopCategoryModalProps> = ({ title, products, onClose, onGoToFlashSale, onViewProduct }) => {
  const [sortOrder, setSortOrder] = useState<SortOrder>('default');

  const sortedProducts = useMemo(() => {
    const sortableProducts = [...products];
    switch (sortOrder) {
      case 'price-asc':
        return sortableProducts.sort((a, b) => a.price - b.price);
      case 'price-desc':
        return sortableProducts.sort((a, b) => b.price - a.price);
      case 'newest':
        // Assuming higher ID is newer
        return sortableProducts.sort((a, b) => b.id - a.id);
      case 'default':
      default:
        return products;
    }
  }, [products, sortOrder]);


  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center p-4 z-50" onClick={onClose}>
      <div 
        className="bg-white rounded-lg shadow-2xl max-w-4xl w-full h-[90vh] flex flex-col animate-fade-in-up" 
        onClick={(e) => e.stopPropagation()}
      >
        <header className="p-4 border-b border-gray-200 flex justify-between items-center flex-shrink-0">
          <h2 className="text-2xl font-montserrat font-bold text-gray-900">{title}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <Icon name="fa-solid fa-times" className="text-2xl" />
          </button>
        </header>

        <div 
            onClick={onGoToFlashSale}
            className="p-3 bg-red-50 border-b border-red-200 text-center cursor-pointer hover:bg-red-100 transition"
        >
            <p className="text-sm font-semibold text-red-700">
                <Icon name="fa-solid fa-bolt" className="mr-2" />
                While you browse, don't miss our FLASH SALE: <strong>40% OFF Wren Leather Sandals!</strong> Click to view.
            </p>
        </div>
        
        <main className="overflow-y-auto p-6 flex-grow flex flex-col">
            {products.length > 0 && (
                <div className="flex justify-between items-center mb-4 flex-shrink-0">
                    <span className="text-sm text-gray-600">{sortedProducts.length} products</span>
                    <div className="flex items-center gap-2">
                        <label htmlFor="sort-select" className="text-sm font-medium text-gray-600">Sort by:</label>
                        <select
                            id="sort-select"
                            value={sortOrder}
                            onChange={(e) => setSortOrder(e.target.value as SortOrder)}
                            className="bg-white rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 text-sm py-1.5"
                        >
                            <option value="default">Default</option>
                            <option value="newest">Newest</option>
                            <option value="price-asc">Price: Low to High</option>
                            <option value="price-desc">Price: High to Low</option>
                        </select>
                    </div>
                </div>
            )}

            {sortedProducts.length > 0 ? (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    {sortedProducts.map(product => (
                        <ProductCard key={product.id} product={product} onViewProduct={onViewProduct} />
                    ))}
                </div>
            ) : (
                <div className="flex flex-col items-center justify-center h-full text-center text-gray-500 flex-grow">
                    <Icon name="fa-solid fa-box-open" className="text-5xl mb-4" />
                    <h3 className="text-xl font-semibold">No Products Found</h3>
                    <p className="mt-1">Check back soon for new items in this category.</p>
                </div>
            )}
        </main>

        <footer className="p-4 border-t border-gray-200 flex-shrink-0 text-right">
            <button 
                onClick={onClose} 
                className="bg-gray-700 text-white font-bold py-2 px-6 rounded-lg hover:bg-gray-800 focus:outline-none focus:ring-4 focus:ring-gray-300 transition"
            >
              Close
            </button>
        </footer>
      </div>
    </div>
  );
};