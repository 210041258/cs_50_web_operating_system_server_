import React from 'react';
import { Icon } from '../ui/Icon';
import { useShop } from '../../context/ShopContext';

export const WishlistModal: React.FC = () => {
  const { 
    isWishlistOpen, 
    closeWishlist, 
    wishlistItems, 
    removeFromWishlist, 
    addToCart 
  } = useShop();

  if (!isWishlistOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div className="absolute inset-0 bg-black bg-opacity-50 transition-opacity" onClick={closeWishlist}></div>
      
      <div className="absolute inset-y-0 right-0 max-w-full flex">
        <div className="relative w-screen max-w-md bg-white shadow-xl flex flex-col animate-slide-in-right">
          
          <div className="flex items-center justify-between px-4 py-6 bg-gray-50 border-b border-gray-200">
            <h2 className="text-lg font-montserrat font-bold text-gray-900">My Wishlist ({wishlistItems.length})</h2>
            <button onClick={closeWishlist} className="text-gray-400 hover:text-gray-500">
              <Icon name="fa-solid fa-times" className="text-2xl" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4">
            {wishlistItems.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-gray-500">
                <Icon name="fa-regular fa-heart" className="text-6xl mb-4 opacity-20" />
                <p className="text-lg">Your wishlist is empty.</p>
                <button onClick={closeWishlist} className="mt-4 text-red-600 font-semibold hover:underline">
                  Browse Products
                </button>
              </div>
            ) : (
              <ul className="space-y-6">
                {wishlistItems.map((item) => (
                  <li key={item.id} className="flex py-2">
                    <div className="h-24 w-24 flex-shrink-0 overflow-hidden rounded-md border border-gray-200">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="h-full w-full object-cover object-center"
                      />
                    </div>

                    <div className="ml-4 flex flex-1 flex-col">
                      <div>
                        <div className="flex justify-between text-base font-medium text-gray-900">
                          <h3 className="line-clamp-2 pr-4"><a href="#">{item.name}</a></h3>
                          <p className="ml-4">₦{item.price.toLocaleString()}</p>
                        </div>
                        <p className="mt-1 text-sm text-gray-500 capitalize">{item.category}</p>
                      </div>
                      <div className="flex flex-1 items-end justify-between text-sm mt-4">
                        <button
                          type="button"
                          onClick={() => {
                              addToCart(item, 1);
                              removeFromWishlist(item.id);
                          }}
                          className="font-medium text-white bg-red-600 px-3 py-1.5 rounded hover:bg-red-700 text-xs flex items-center gap-1"
                        >
                          <Icon name="fa-solid fa-cart-plus" />
                          <span>Add to Cart</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => removeFromWishlist(item.id)}
                          className="font-medium text-gray-400 hover:text-red-500 flex items-center gap-1"
                          title="Remove from Wishlist"
                        >
                          <Icon name="fa-solid fa-trash-can" />
                        </button>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
      <style>{`
        @keyframes slide-in-right {
            from { transform: translateX(100%); }
            to { transform: translateX(0); }
        }
        .animate-slide-in-right {
            animation: slide-in-right 0.3s ease-out forwards;
        }
      `}</style>
    </div>
  );
};