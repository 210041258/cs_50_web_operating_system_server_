import React from 'react';
import { Icon } from '../ui/Icon';

interface SizeGuideModalProps {
  onClose: () => void;
}

const sizeData = [
  { eu: '38', us: '6', uk: '5', cm: '24.1' },
  { eu: '39', us: '7', uk: '6', cm: '25.1' },
  { eu: '40', us: '7.5', uk: '6.5', cm: '25.4' },
  { eu: '41', us: '8.5', uk: '7.5', cm: '25.7' },
  { eu: '42', us: '9', uk: '8', cm: '26.0' },
  { eu: '43', us: '10', uk: '9', cm: '26.7' },
  { eu: '44', us: '10.5', uk: '9.5', cm: '27.3' },
  { eu: '45', us: '11.5', uk: '10.5', cm: '27.9' },
];

export const SizeGuideModal: React.FC<SizeGuideModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center p-4 z-50" onClick={onClose}>
      <div className="bg-white rounded-lg shadow-2xl max-w-lg w-full p-6 relative animate-fade-in-up" onClick={(e) => e.stopPropagation()}>

        <h2 className="text-2xl font-montserrat font-bold text-gray-900 mb-4">Sandal Size Guide</h2>
        <p className="text-sm text-gray-600 mb-6">Use this chart to find the best fit. Measurements are in centimeters and refer to the length of the foot.</p>
        
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-gray-100 text-gray-600 uppercase font-semibold">
              <tr>
                <th className="p-3">EU</th>
                <th className="p-3">US (Women)</th>
                <th className="p-3">UK</th>
                <th className="p-3">Foot Length (cm)</th>
              </tr>
            </thead>
            <tbody>
              {sizeData.map((size, index) => (
                <tr key={size.eu} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                  <td className="p-3 font-medium text-gray-800">{size.eu}</td>
                  <td className="p-3 text-gray-700">{size.us}</td>
                  <td className="p-3 text-gray-700">{size.uk}</td>
                  <td className="p-3 text-gray-700">{size.cm}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <button 
            onClick={onClose} 
            className="mt-6 w-full bg-gray-800 text-white font-bold py-3 px-4 rounded-lg hover:bg-gray-900 focus:outline-none focus:ring-4 focus:ring-gray-300 transition"
        >
          Close
        </button>
      </div>
    </div>
  );
};