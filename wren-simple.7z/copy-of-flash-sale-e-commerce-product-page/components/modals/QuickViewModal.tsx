import React from 'react';
import { Icon } from '../ui/Icon';
import type { ProductImage } from '../../types';

interface QuickViewModalProps {
  image: ProductImage;
  productName: string;
  salePrice: number;
  originalPrice: number;
  onClose: () => void;
  onGoToDetails: () => void;
}

export const QuickViewModal: React.FC<QuickViewModalProps> = ({ image, productName, salePrice, originalPrice, onClose, onGoToDetails }) => {
  
  const handleGoToDetailsClick = () => {
    onClose();
    onGoToDetails();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center p-4 z-50" onClick={onClose}>
      <div 
        className="bg-white rounded-lg shadow-2xl max-w-4xl w-full flex flex-col md:flex-row animate-scale-in overflow-hidden" 
        onClick={(e) => e.stopPropagation()}
      >
        <div className="w-full md:w-1/2">
            <img src={image.full} alt={image.alt} className="w-full h-full object-cover" />
        </div>
        <div className="w-full md:w-1/2 p-8 flex flex-col justify-center relative">
            <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
                <Icon name="fa-solid fa-times" className="text-2xl" />
            </button>
            
            <h2 className="text-3xl font-montserrat font-bold text-gray-900">{productName}</h2>
            
            <div className="flex items-baseline gap-4 my-4">
                <p className="text-3xl font-montserrat font-extrabold text-red-700">₦{salePrice.toLocaleString()}</p>
                <p className="text-xl text-gray-500 line-through">₦{originalPrice.toLocaleString()}</p>
            </div>

            <p className="text-sm text-gray-600 mb-6">
                You're viewing a quick preview. For full details, specifications, and to place an order, please view the full product details.
            </p>

            <button 
                onClick={handleGoToDetailsClick} 
                className="w-full bg-red-600 text-white font-bold py-3 px-6 text-lg rounded-lg shadow-lg hover:bg-red-700 focus:outline-none focus:ring-4 focus:ring-red-300 transition transform hover:-translate-y-1 flex items-center justify-center gap-2"
            >
                <Icon name="fa-solid fa-arrow-right" />
                <span>View Full Details & Order</span>
            </button>
        </div>
      </div>
    </div>
  );
};