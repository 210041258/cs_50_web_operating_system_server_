import React from 'react';
import { Icon } from './Icon';

interface InfoModalProps {
  title: string;
  children: React.ReactNode;
  onClose: () => void;
}

export const InfoModal: React.FC<InfoModalProps> = ({ title, children, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center p-4 z-50" onClick={onClose}>
      <div 
        className="bg-white rounded-lg shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col p-6 relative animate-fade-in-up" 
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-start mb-4">
            <h2 className="text-2xl font-montserrat font-bold text-gray-900">{title}</h2>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
              <Icon name="fa-solid fa-times" className="text-2xl" />
            </button>
        </div>
        
        <div className="overflow-y-auto pr-4 text-gray-700">
            {children}
        </div>

        <button 
            onClick={onClose} 
            className="mt-6 w-full bg-gray-800 text-white font-bold py-3 px-4 rounded-lg hover:bg-gray-900 focus:outline-none focus:ring-4 focus:ring-gray-300 transition"
        >
          Close
        </button>
      </div>
    </div>
  );
};