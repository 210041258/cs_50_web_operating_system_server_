import React, { useState, useEffect, useRef } from 'react';
import { Icon } from './Icon';

interface NavLinkProps {
  onClick: () => void;
  children: React.ReactNode;
}

const NavLink: React.FC<NavLinkProps> = ({ onClick, children }) => (
    <li>
        <button 
            onClick={onClick} 
            className="text-gray-600 hover:text-red-600 font-semibold transition duration-300 ease-in-out py-2"
        >
            {children}
        </button>
    </li>
);

interface NavigationProps {
    onLinkClick: (page: string) => void;
    onSearchClick: () => void;
    cartItemCount: number;
    onCartClick: () => void;
    onProfileClick: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({ onLinkClick, onSearchClick, cartItemCount, onCartClick, onProfileClick }) => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [isAnimating, setIsAnimating] = useState(false);
    const prevCartCount = useRef(cartItemCount);

    useEffect(() => {
        // Trigger animation only when items are added
        if (cartItemCount > prevCartCount.current) {
            setIsAnimating(true);
            const timer = setTimeout(() => setIsAnimating(false), 300); // Duration of the animation
            return () => clearTimeout(timer);
        }
        prevCartCount.current = cartItemCount;
    }, [cartItemCount]);

    return (
        <nav className="bg-white shadow-md sticky top-0 z-40">
            <div className="container mx-auto px-4 flex justify-between items-center py-4">
                <div className="font-montserrat text-3xl font-bold text-gray-900">
                    <a href="#">WREN</a>
                </div>
                
                {/* Desktop Menu */}
                <ul className="hidden md:flex items-center space-x-8 text-sm uppercase tracking-wider">
                    <NavLink onClick={() => onLinkClick('new-arrivals')}>New Arrivals</NavLink>
                    <NavLink onClick={() => onLinkClick('sandals')}>Sandals</NavLink>
                    <NavLink onClick={() => onLinkClick('womens-shoes')}>Women's Shoes</NavLink>
                    <NavLink onClick={() => onLinkClick('sale')}>Sale</NavLink>
                </ul>

                <div className="hidden md:flex items-center space-x-6">
                    <button onClick={onSearchClick} className="text-gray-600 hover:text-red-600" aria-label="Search">
                        <Icon name="fa-solid fa-search" className="text-lg" />
                    </button>
                    <button onClick={onProfileClick} className="text-gray-600 hover:text-red-600" aria-label="My Account">
                        <Icon name="fa-solid fa-user" className="text-lg" />
                    </button>
                    <button onClick={onCartClick} className="relative text-gray-600 hover:text-red-600" aria-label="Shopping Bag">
                        <Icon name="fa-solid fa-shopping-bag" className="text-lg" />
                        {cartItemCount > 0 && (
                             <span 
                                key={cartItemCount}
                                className={`absolute -top-2 -right-2 bg-red-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-bold ${isAnimating ? 'animate-bounce-short' : ''}`}
                            >
                                {cartItemCount}
                            </span>
                        )}
                    </button>
                </div>

                {/* Mobile Menu Button */}
                <div className="md:hidden">
                    <button onClick={() => setIsMenuOpen(!isMenuOpen)} aria-label="Open menu" aria-expanded={isMenuOpen}>
                        <Icon name={isMenuOpen ? "fa-solid fa-times" : "fa-solid fa-bars"} className="text-2xl text-gray-800" />
                    </button>
                </div>
            </div>

            {/* Mobile Menu */}
            <div className={`md:hidden bg-white border-t border-gray-200 transition-all duration-300 ease-in-out ${isMenuOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'} overflow-hidden`}>
                <ul className="flex flex-col items-center space-y-4 py-4">
                    <NavLink onClick={() => { onLinkClick('new-arrivals'); setIsMenuOpen(false); }}>New Arrivals</NavLink>
                    <NavLink onClick={() => { onLinkClick('sandals'); setIsMenuOpen(false); }}>Sandals</NavLink>
                    <NavLink onClick={() => { onLinkClick('womens-shoes'); setIsMenuOpen(false); }}>Women's Shoes</NavLink>
                    <NavLink onClick={() => { onLinkClick('sale'); setIsMenuOpen(false); }}>Sale</NavLink>
                    <button onClick={() => { onProfileClick(); setIsMenuOpen(false); }} className="text-gray-600 font-semibold hover:text-red-600 py-2">My Account</button>
                </ul>
            </div>
        </nav>
    );
};