import React from 'react';
import type { FormData, CartItem } from '../types';
import { Icon } from './Icon';
import { DELIVERY_OPTIONS } from '../constants';

interface SuccessModalProps {
  orderNumber: string;
  formData: FormData;
  quantity?: number; // Optional now
  totalPrice: number;
  onClose: () => void;
  cartItems?: CartItem[]; // New prop
}

export const SuccessModal: React.FC<SuccessModalProps> = ({ orderNumber, formData, quantity, totalPrice, onClose, cartItems }) => {
  const selectedDeliveryOption = DELIVERY_OPTIONS.find(opt => opt.id === formData.deliveryMethod);
  const deliveryCost = selectedDeliveryOption?.cost || 0;
  const subtotal = totalPrice - deliveryCost;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-2xl max-w-lg w-full p-8 relative animate-fade-in-up max-h-[90vh] overflow-y-auto">
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
          <Icon name="fa-solid fa-times" className="text-2xl" />
        </button>

        <div className="text-center">
            <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-green-100 mb-4">
                <Icon name="fa-solid fa-check" className="text-4xl text-green-600" />
            </div>
            <h2 className="text-2xl font-montserrat font-bold text-gray-900">Order Placed Successfully!</h2>
            <p className="text-gray-600 mt-2">Thank you for your purchase. Your order is being processed.</p>
        </div>

        <div className="mt-6 space-y-4 text-sm bg-gray-50 p-4 rounded-md border border-gray-200">
            <p><strong>Order Number:</strong> <span className="font-mono text-green-700">{orderNumber}</span></p>
            <p><strong>Confirmation Email:</strong> A confirmation has been sent to <span className="font-semibold text-gray-800">{formData.email}</span>.</p>
        </div>

        <div className="mt-4 border-t pt-4">
            <h3 className="font-semibold mb-2">Order Summary</h3>
            <div className="space-y-2 text-sm">
                {cartItems ? (
                    cartItems.map(item => (
                        <div key={item.id} className="flex justify-between items-center">
                            <span className="truncate pr-4">{item.name} (x{item.quantity})</span>
                            <span className="font-semibold">₦{(item.price * item.quantity).toLocaleString()}</span>
                        </div>
                    ))
                ) : (
                    <div className="flex justify-between items-center">
                        <span>Wren Black Leather Casual Sandals (x{quantity})</span>
                        <span className="font-semibold">₦{subtotal.toLocaleString()}</span>
                    </div>
                )}
                
                <div className="flex justify-between items-center text-gray-600 pt-2 border-t border-dashed border-gray-200 mt-2">
                    <span>Shipping ({selectedDeliveryOption?.label}):</span>
                    <span className="font-semibold">{deliveryCost === 0 ? 'FREE' : `₦${deliveryCost.toLocaleString()}`}</span>
                </div>
            </div>
            <div className="flex justify-between items-center mt-3 font-bold text-lg border-t pt-2">
                <span>Total:</span>
                <span>₦{totalPrice.toLocaleString()}</span>
            </div>
        </div>

        <div className="mt-6 text-center text-sm text-gray-600">
            <p><Icon name="fa-solid fa-truck" className="mr-2" />Estimated Delivery: 3-5 business days.</p>
        </div>

        <button 
            onClick={onClose} 
            className="mt-8 w-full bg-gray-800 text-white font-bold py-3 px-4 rounded-lg hover:bg-gray-900 focus:outline-none focus:ring-4 focus:ring-gray-300 transition"
        >
          Continue Shopping
        </button>
      </div>
    </div>
  );
};