
// FIX: Import `ReactNode` to use as a type.
import type { ReactNode } from 'react';

export interface ProductImage {
  id: number;
  thumbnail: string;
  full: string;
  alt: string;
}

export interface Product {
  id: number;
  category: string;
  name: string;
  description: string;
  highlights: string[];
  rating: number;
  reviewCount: number;
  inStock: boolean;
  originalPrice: number;
  salePrice: number;
  salePercentage: number;
  specifications: {
    icon: string;
    label: string;
    value: string;
    valueComponent?: ReactNode;
  }[];
  images: ProductImage[];
}

export interface AnatomyPoint {
  id: string;
  title: string;
  description: string;
  position: { top: string; left: string }; // CSS position percentages
  icon: string;
}

export interface Review {
  id: number;
  rating: number;
  author: string;
  date: string;
  text: string;
}

export interface FormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address: string;
  paymentMethod: string;
  deliveryMethod: string;
  termsAccepted: boolean;
  newsletterSubscribed: boolean;
}

export interface PageContent {
  title: string;
  content: ReactNode;
}

export interface ShopProduct {
  id: number;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  category: 'sandals' | 'womens-shoes';
  isNew?: boolean;
  rating?: number;
}

export interface CartItem {
  id: number;
  name: string;
  price: number;
  image: string;
  quantity: number;
  category: string;
}

export interface User {
  name: string;
  email: string;
}

export interface Order {
  id: string;
  date: string;
  items: CartItem[];
  total: number;
  status: 'Processing' | 'Shipped' | 'Delivered';
  customer: {
    name: string;
    email: string;
  };
}
