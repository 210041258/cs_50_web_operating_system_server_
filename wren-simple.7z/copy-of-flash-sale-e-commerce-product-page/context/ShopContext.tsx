import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import type { CartItem, Product, ShopProduct, User, Order } from '../types';

interface ToastData {
  title: string;
  message: string;
}

interface ShopContextType {
  // Cart State
  cartItems: CartItem[];
  cartTotalCount: number;
  cartTotalPrice: number;
  isCartOpen: boolean;
  openCart: () => void;
  closeCart: () => void;
  addToCart: (product: Product | ShopProduct, qty: number) => void;
  removeFromCart: (id: number) => void;
  updateCartQuantity: (id: number, delta: number) => void;
  clearCart: () => void;

  // Wishlist State
  wishlistItems: ShopProduct[];
  isWishlistOpen: boolean;
  openWishlist: () => void;
  closeWishlist: () => void;
  addToWishlist: (product: Product | ShopProduct) => void;
  removeFromWishlist: (id: number) => void;
  isInWishlist: (id: number) => boolean;

  // User & Order State
  user: User | null;
  login: (user: User) => void;
  logout: () => void;
  orders: Order[];
  addOrder: (order: Order) => void;

  // Notification State
  toast: ToastData | null;
  showToast: (title: string, message: string) => void;
  hideToast: () => void;

  // Modal State
  isProfileOpen: boolean;
  openProfile: () => void;
  closeProfile: () => void;
}

const ShopContext = createContext<ShopContextType | undefined>(undefined);

export const ShopProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Cart State
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('wren_cart');
      return saved ? JSON.parse(saved) : [];
    } catch { return []; }
  });

  // Wishlist State
  const [wishlistItems, setWishlistItems] = useState<ShopProduct[]>(() => {
    try {
      const saved = localStorage.getItem('wren_wishlist');
      return saved ? JSON.parse(saved) : [];
    } catch { return []; }
  });

  // User State
  const [user, setUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('wren_user');
      return saved ? JSON.parse(saved) : null;
    } catch { return null; }
  });

  // Order History State
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('wren_orders');
      return saved ? JSON.parse(saved) : [];
    } catch { return []; }
  });
  
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [toast, setToast] = useState<ToastData | null>(null);
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  // Persistence Effects
  useEffect(() => localStorage.setItem('wren_cart', JSON.stringify(cartItems)), [cartItems]);
  useEffect(() => localStorage.setItem('wren_wishlist', JSON.stringify(wishlistItems)), [wishlistItems]);
  useEffect(() => {
      if (user) localStorage.setItem('wren_user', JSON.stringify(user));
      else localStorage.removeItem('wren_user');
  }, [user]);
  useEffect(() => localStorage.setItem('wren_orders', JSON.stringify(orders)), [orders]);

  // Computed Values
  const cartTotalCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  const cartTotalPrice = cartItems.reduce((acc, item) => acc + (item.price * item.quantity), 0);

  // Actions
  const openCart = () => setIsCartOpen(true);
  const closeCart = () => setIsCartOpen(false);
  const openWishlist = () => setIsWishlistOpen(true);
  const closeWishlist = () => setIsWishlistOpen(false);
  const openProfile = () => setIsProfileOpen(true);
  const closeProfile = () => setIsProfileOpen(false);

  const showToast = useCallback((title: string, message: string) => {
    setToast({ title, message });
  }, []);

  const hideToast = useCallback(() => setToast(null), []);

  const addToCart = (product: Product | ShopProduct, qty: number) => {
    setCartItems(prev => {
      const productId = product.id || 999; 
      const existing = prev.find(item => item.id === productId);
      
      if (existing) {
        return prev.map(item => item.id === productId ? { ...item, quantity: item.quantity + qty } : item);
      } else {
        let newItem: CartItem;
        if ('images' in product) {
            newItem = {
                id: productId,
                name: product.name,
                price: product.salePrice,
                image: product.images[0].thumbnail,
                category: product.category,
                quantity: qty
            };
        } else {
            newItem = {
                id: productId,
                name: product.name,
                price: product.price,
                image: product.image,
                category: product.category,
                quantity: qty
            };
        }
        return [...prev, newItem];
      }
    });
    showToast('Added to Cart', `${qty}x ${product.name} added.`);
  };

  const removeFromCart = (id: number) => {
    setCartItems(prev => prev.filter(item => item.id !== id));
  };

  const updateCartQuantity = (id: number, delta: number) => {
    setCartItems(prev => prev.map(item => {
        if (item.id === id) {
            return { ...item, quantity: Math.max(1, item.quantity + delta) };
        }
        return item;
    }));
  };

  const clearCart = () => setCartItems([]);

  const addToWishlist = (product: Product | ShopProduct) => {
    const productId = product.id || 999;
    if (wishlistItems.some(item => item.id === productId)) {
        showToast('Info', 'This item is already in your wishlist.');
        return;
    }
    let newItem: ShopProduct;
    if ('images' in product) {
        newItem = {
            id: productId,
            name: product.name,
            price: product.salePrice,
            originalPrice: product.originalPrice,
            image: product.images[0].thumbnail,
            category: product.category === "Women's Sandals" ? 'sandals' : 'womens-shoes',
        };
    } else {
        newItem = product;
    }
    setWishlistItems(prev => [...prev, newItem]);
    showToast('Saved to Wishlist', `${newItem.name} saved.`);
  };

  const removeFromWishlist = (id: number) => {
    setWishlistItems(prev => prev.filter(item => item.id !== id));
  };

  const isInWishlist = (id: number) => wishlistItems.some(item => item.id === id);

  const login = (userData: User) => setUser(userData);
  const logout = () => setUser(null);
  
  const addOrder = (order: Order) => {
      setOrders(prev => [order, ...prev]);
  };

  const value = {
    cartItems, cartTotalCount, cartTotalPrice, isCartOpen, openCart, closeCart,
    addToCart, removeFromCart, updateCartQuantity, clearCart,
    wishlistItems, isWishlistOpen, openWishlist, closeWishlist, addToWishlist, removeFromWishlist, isInWishlist,
    user, login, logout, orders, addOrder,
    toast, showToast, hideToast, isProfileOpen, openProfile, closeProfile
  };

  return <ShopContext.Provider value={value}>{children}</ShopContext.Provider>;
};

export const useShop = () => {
  const context = useContext(ShopContext);
  if (context === undefined) throw new Error('useShop must be used within a ShopProvider');
  return context;
};
