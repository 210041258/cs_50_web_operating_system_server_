import React, { createContext, useContext, useState, ReactNode } from 'react';
import type { FormData, ProductImage, ShopProduct, CartItem } from '../types';

interface SuccessData {
  orderNumber: string;
  formData: FormData;
  totalPrice: number;
  cartItems?: CartItem[];
}

interface UIContextType {
  // Search
  isSearchOpen: boolean;
  openSearch: () => void;
  closeSearch: () => void;

  // Size Guide
  isSizeGuideOpen: boolean;
  openSizeGuide: () => void;
  closeSizeGuide: () => void;

  // Quick View (Image)
  quickViewImage: ProductImage | null;
  openQuickView: (image: ProductImage) => void;
  closeQuickView: () => void;

  // Product View (ShopProduct)
  viewingProduct: ShopProduct | null;
  openViewProduct: (product: ShopProduct) => void;
  closeViewProduct: () => void;

  // Info Pages (Terms, FAQ, etc)
  activeInfoPage: string | null;
  openInfoPage: (page: string) => void;
  closeInfoPage: () => void;

  // Shop Categories (New Arrivals, etc)
  activeShopCategory: string | null;
  openShopCategory: (category: string) => void;
  closeShopCategory: () => void;

  // Success Modal
  successData: SuccessData | null;
  openSuccessModal: (data: SuccessData) => void;
  closeSuccessModal: () => void;
}

const UIContext = createContext<UIContextType | undefined>(undefined);

export const UIProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState(false);
  const [quickViewImage, setQuickViewImage] = useState<ProductImage | null>(null);
  const [viewingProduct, setViewingProduct] = useState<ShopProduct | null>(null);
  const [activeInfoPage, setActiveInfoPage] = useState<string | null>(null);
  const [activeShopCategory, setActiveShopCategory] = useState<string | null>(null);
  const [successData, setSuccessData] = useState<SuccessData | null>(null);

  const value = {
    isSearchOpen,
    openSearch: () => setIsSearchOpen(true),
    closeSearch: () => setIsSearchOpen(false),

    isSizeGuideOpen,
    openSizeGuide: () => setIsSizeGuideOpen(true),
    closeSizeGuide: () => setIsSizeGuideOpen(false),

    quickViewImage,
    openQuickView: (img: ProductImage) => setQuickViewImage(img),
    closeQuickView: () => setQuickViewImage(null),

    viewingProduct,
    openViewProduct: (p: ShopProduct) => setViewingProduct(p),
    closeViewProduct: () => setViewingProduct(null),

    activeInfoPage,
    openInfoPage: (page: string) => setActiveInfoPage(page),
    closeInfoPage: () => setActiveInfoPage(null),

    activeShopCategory,
    openShopCategory: (cat: string) => setActiveShopCategory(cat),
    closeShopCategory: () => setActiveShopCategory(null),

    successData,
    openSuccessModal: (data: SuccessData) => setSuccessData(data),
    closeSuccessModal: () => setSuccessData(null),
  };

  return <UIContext.Provider value={value}>{children}</UIContext.Provider>;
};

export const useUI = () => {
  const context = useContext(UIContext);
  if (context === undefined) {
    throw new Error('useUI must be used within a UIProvider');
  }
  return context;
};