import React, { useState, useCallback, useRef, useEffect } from 'react';
import { ShopProvider, useShop } from './context/ShopContext';
import { UIProvider, useUI } from './context/UIContext';

// Layout Components
import { FlashHeader } from './components/layout/FlashHeader';
import { Navigation } from './components/layout/Navigation';
import { Footer } from './components/layout/Footer';
import { Breadcrumbs } from './components/layout/Breadcrumbs';
import { BackToTopButton } from './components/layout/BackToTopButton';
import { ModalManager } from './components/layout/ModalManager';

// Section Components
import { Hero } from './components/sections/Hero';
import { Features } from './components/sections/Features';
import { ProductAnatomy } from './components/sections/ProductAnatomy';
import { ProductSpecs } from './components/sections/ProductSpecs';
import { Reviews } from './components/sections/Reviews';
import { RelatedProducts } from './components/sections/RelatedProducts';
import { ImageGenerator } from './components/sections/ImageGenerator';

// Product Components
import { ProductGallery } from './components/product/ProductGallery';
import { ProductInfo } from './components/product/ProductInfo';

// Modals
import { NotificationToast } from './components/modals/NotificationToast';
import { CartModal } from './components/modals/CartModal';
import { WishlistModal } from './components/modals/WishlistModal';
import { ProfileModal } from './components/modals/ProfileModal';

// Types & Data
import type { FormData, CartItem, Order } from './types';
import { PRODUCT_DATA, REVIEWS_DATA, SHOP_PRODUCTS } from './data/constants';

// Main product configuration
const MAIN_PRODUCT = PRODUCT_DATA;

const AppContent: React.FC = () => {
  const { 
    closeCart, 
    clearCart,
    cartTotalPrice,
    cartItems,
    toast,
    hideToast,
    showToast,
    closeWishlist,
    closeProfile,
    addOrder
  } = useShop();

  const { 
    openSuccessModal, 
    openViewProduct, 
    openSearch, 
    closeSearch, 
    closeSizeGuide, 
    closeQuickView, 
    closeViewProduct, 
    closeInfoPage, 
    closeShopCategory, 
    closeSuccessModal 
  } = useUI();

  const [quantity, setQuantity] = useState(1);
  const productSectionRef = useRef<HTMLElement>(null);

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
        // Search Shortcut: '/'
        if (e.key === '/' && !['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) {
            e.preventDefault();
            openSearch();
        }

        // Close Shortcut: 'Escape'
        if (e.key === 'Escape') {
            closeSearch();
            closeSizeGuide();
            closeQuickView();
            closeViewProduct();
            closeInfoPage();
            closeShopCategory();
            closeSuccessModal();
            closeCart();
            closeWishlist();
            closeProfile();
        }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
      openSearch, closeSearch, closeSizeGuide, closeQuickView, closeViewProduct, 
      closeInfoPage, closeShopCategory, closeSuccessModal, closeCart, closeWishlist, closeProfile
  ]);

  // Order & Checkout Logic
  const handleOrderSubmit = useCallback((formData: FormData, totalPrice: number) => {
    const newOrderNumber = `WREN-${Math.floor(Math.random() * 90000) + 10000}`;
    
    // Create single item cart item for this direct order
    const directItem: CartItem = {
        id: MAIN_PRODUCT.id,
        name: MAIN_PRODUCT.name,
        price: MAIN_PRODUCT.salePrice,
        image: MAIN_PRODUCT.images[0].thumbnail,
        quantity: quantity,
        category: MAIN_PRODUCT.category
    };

    const newOrder: Order = {
        id: newOrderNumber,
        date: new Date().toISOString(),
        items: [directItem],
        total: totalPrice,
        status: 'Processing',
        customer: {
            name: `${formData.firstName} ${formData.lastName}`,
            email: formData.email
        }
    };

    addOrder(newOrder);

    openSuccessModal({
        orderNumber: newOrderNumber,
        formData,
        totalPrice,
        cartItems: [directItem]
    });
    
    if (formData.newsletterSubscribed) {
      showToast("Subscription Confirmed!", "You're on the list for exclusive offers.");
    }
  }, [quantity, showToast, openSuccessModal, addOrder]);

  const handleCartCheckout = () => {
    const newOrderNumber = `WREN-${Math.floor(Math.random() * 90000) + 10000}`;
    // Mock data for cart checkout simulation (In real app, we'd show a checkout form for cart too)
    const mockFormData: FormData = {
        firstName: 'Guest', lastName: 'User', email: 'guest@example.com', 
        phone: '', address: '123 Test St', paymentMethod: 'Card', deliveryMethod: 'standard', 
        termsAccepted: true, newsletterSubscribed: false
    };

    const newOrder: Order = {
        id: newOrderNumber,
        date: new Date().toISOString(),
        items: [...cartItems],
        total: cartTotalPrice,
        status: 'Processing',
        customer: {
            name: 'Guest User',
            email: 'guest@example.com'
        }
    };

    addOrder(newOrder);

    openSuccessModal({
        orderNumber: newOrderNumber,
        formData: mockFormData,
        totalPrice: cartTotalPrice,
        cartItems: [...cartItems]
    });

    closeCart();
    clearCart();
  };

  const handleProfileSuccess = (isLogin: boolean) => {
    showToast(
        isLogin ? "Welcome Back!" : "Account Created!",
        isLogin ? "You have successfully logged in." : "Your account has been created successfully."
    );
  };

  const handleShopNowClick = () => {
    productSectionRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const relatedProducts = SHOP_PRODUCTS.slice(0, 4);

  return (
    <div className="bg-gray-50 text-gray-800 min-h-screen flex flex-col font-sans">
      <FlashHeader />
      <Navigation />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <Hero onShopNowClick={handleShopNowClick} />
        
        {/* Main Product Details */}
        <section id="shop-hero" ref={productSectionRef} className="container mx-auto px-4 py-8 lg:py-12">
            <Breadcrumbs />

            <div className="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 mb-16">
                <ProductGallery 
                    images={MAIN_PRODUCT.images} 
                    salePercentage={MAIN_PRODUCT.salePercentage}
                />
                <ProductInfo
                    product={MAIN_PRODUCT}
                    quantity={quantity}
                    setQuantity={setQuantity}
                    onOrderSubmit={handleOrderSubmit}
                />
            </div>
        </section>
        
        {/* Technical Specs - Full Width */}
        <ProductSpecs product={MAIN_PRODUCT} />
        
        {/* Product Deep Dive & Content */}
        <div className="container mx-auto px-4 py-16 space-y-24">
            <ProductAnatomy />
            <ImageGenerator />
            <Features />
            <Reviews reviews={REVIEWS_DATA} product={MAIN_PRODUCT} />
            <RelatedProducts products={relatedProducts} onViewProduct={openViewProduct} />
        </div>
      </main>

      <Footer />

      {/* Global Modals & Utilities */}
      <ModalManager />
      <CartModal onCheckout={handleCartCheckout} />
      <WishlistModal />
      <ProfileModal onSuccess={handleProfileSuccess} />
      <BackToTopButton />

      {toast && (
        <NotificationToast 
            title={toast.title} 
            message={toast.message} 
            onClose={hideToast} 
        />
      )}
    </div>
  );
};

const App: React.FC = () => (
  <ShopProvider>
    <UIProvider>
      <AppContent />
    </UIProvider>
  </ShopProvider>
);

export default App;