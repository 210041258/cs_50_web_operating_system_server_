# Flash Sale E-Commerce Product Page

A production-ready, high-conversion e-commerce landing page built with React, TypeScript, and Tailwind CSS. This project features a responsive design, interactive product galleries, and AI-powered features using the Google Gemini API.

## Features

- **Responsive Design**: Optimized for mobile, tablet, and desktop.
- **Interactive UI**: Image zoom, quick view, size guide, and cart functionality.
- **AI Integrations**:
  - **Review Summarization**: Uses Gemini Pro to summarize customer reviews.
  - **Image Generation**: Allows users to design custom shoe concepts using Gemini Pro Vision/Image models.
- **State Management**: Handles cart, wishlist, and complex form states.
- **Tailwind CSS**: Utility-first styling for rapid UI development.

## Prerequisites

- **Node.js**: Version 18 or higher.
- **npm**: Included with Node.js.
- **Google Cloud API Key**: Required for AI features (Gemini API).

## Installation

1.  **Install Dependencies**

    Run the following command in the project root to install the necessary packages:

    ```bash
    npm install
    ```

2.  **Configure Environment Variables**

    Create a `.env` file in the root directory to store your API key. This key is used for the AI review summaries and image generation features.

    ```bash
    touch .env
    ```

    Add the following line to the `.env` file:

    ```env
    API_KEY=your_google_gemini_api_key_here
    ```

    > **Note**: You can obtain an API key from [Google AI Studio](https://aistudio.google.com/).

## Running the Application

Start the development server with:

```bash
npm run dev
```

The application will be available at [http://localhost:5173](http://localhost:5173).

## Building for Production

To build the application for production deployment:

```bash
npm run build
```

The build artifacts will be stored in the `dist/` directory.

## Project Structure

- `index.html`: Entry point.
- `App.tsx`: Main application component.
- `components/`: UI components (Hero, ProductGallery, Reviews, etc.).
- `types.ts`: TypeScript definitions.
- `constants.ts`: Static data (Product details, mock reviews).
- `styles.css`: Custom CSS animations and overrides.
