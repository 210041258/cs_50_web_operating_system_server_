/**
 * @file storage_perf.h
 * @brief Storage Performance Monitoring and Optimization Module
 * 
 * This module provides comprehensive storage performance monitoring, analysis,
 * and optimization for HDDs, SSDs, NVMe, RAID arrays, SAN, NAS, and cloud storage.
 * Includes latency, throughput, IOPS, queue depth, wear leveling, and health monitoring.
 * 
 * @author Storage Performance Team
 * @date 2024-01-31
 * @version 3.5.0
 * 
 * @license Apache 2.0
 * @copyright Copyright (c) 2024 Storage Solutions
 */

#ifndef STORAGE_PERF_H
#define STORAGE_PERF_H

#ifdef __cplusplus
extern "C" {
#endif

// ============================================================================
// Includes and Dependencies
// ============================================================================
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <time.h>

// Platform-specific headers
#if defined(_WIN32)
    #include <windows.h>
    #include <winioctl.h>
    #define STORAGE_PLATFORM_WINDOWS 1
#elif defined(__linux__)
    #include <sys/ioctl.h>
    #include <sys/stat.h>
    #include <sys/mount.h>
    #include <scsi/sg.h>
    #include <linux/fs.h>
    #define STORAGE_PLATFORM_LINUX 1
#elif defined(__APPLE__)
    #include <sys/disk.h>
    #include <sys/mount.h>
    #include <IOKit/storage/IOStorageProtocolCharacteristics.h>
    #define STORAGE_PLATFORM_MACOS 1
#endif

// ============================================================================
// Configuration Constants
// ============================================================================
/**
 * @def STORAGE_PERF_VERSION_MAJOR
 * @brief Major version number
 */
#define STORAGE_PERF_VERSION_MAJOR 3

/**
 * @def STORAGE_PERF_VERSION_MINOR
 * @brief Minor version number
 */
#define STORAGE_PERF_VERSION_MINOR 5

/**
 * @def STORAGE_PERF_VERSION_PATCH
 * @brief Patch version number
 */
#define STORAGE_PERF_VERSION_PATCH 0

/**
 * @def STORAGE_MAX_DEVICES
 * @brief Maximum number of storage devices supported
 */
#define STORAGE_MAX_DEVICES 256

/**
 * @def STORAGE_MAX_PARTITIONS
 * @brief Maximum partitions per device
 */
#define STORAGE_MAX_PARTITIONS 128

/**
 * @def STORAGE_MAX_RAID_MEMBERS
 * @brief Maximum RAID array members
 */
#define STORAGE_MAX_RAID_MEMBERS 64

/**
 * @def STORAGE_MAX_LUNS
 * @brief Maximum LUNs per storage controller
 */
#define STORAGE_MAX_LUNS 256

/**
 * @def STORAGE_MAX_FILESYSTEMS
 * @brief Maximum filesystem types supported
 */
#define STORAGE_MAX_FILESYSTEMS 32

/**
 * @def STORAGE_MAX_IO_PATTERNS
 * @brief Maximum IO patterns to analyze
 */
#define STORAGE_MAX_IO_PATTERNS 16

/**
 * @def STORAGE_DEFAULT_SAMPLE_INTERVAL_MS
 * @brief Default sampling interval in milliseconds
 */
#define STORAGE_DEFAULT_SAMPLE_INTERVAL_MS 1000

/**
 * @def STORAGE_BUFFER_SIZE_SAMPLES
 * @brief Default buffer size for historical samples
 */
#define STORAGE_BUFFER_SIZE_SAMPLES 3600  // 1 hour at 1 sample/sec

// ============================================================================
// Type Definitions
// ============================================================================

/**
 * @enum storage_status_t
 * @brief Status codes for storage operations
 */
typedef enum {
    STORAGE_SUCCESS = 0,                 /**< Operation successful */
    STORAGE_ERROR_INIT_FAILED,           /**< Initialization failed */
    STORAGE_ERROR_DEVICE_NOT_FOUND,      /**< Storage device not found */
    STORAGE_ERROR_INVALID_DEVICE,        /**< Invalid device identifier */
    STORAGE_ERROR_INVALID_PARAMETER,     /**< Invalid parameter */
    STORAGE_ERROR_NOT_INITIALIZED,       /**< Storage module not initialized */
    STORAGE_ERROR_IO_OPERATION,          /**< I/O operation failed */
    STORAGE_ERROR_PERMISSION_DENIED,     /**< Insufficient permissions */
    STORAGE_ERROR_NOT_SUPPORTED,         /**< Operation not supported */
    STORAGE_ERROR_FILESYSTEM,            /**< Filesystem error */
    STORAGE_ERROR_RAID,                  /**< RAID operation failed */
    STORAGE_ERROR_SMART,                 /**< SMART operation failed */
    STORAGE_ERROR_NVME,                  /**< NVMe operation failed */
    STORAGE_ERROR_BUFFER_FULL,           /**< Data buffer full */
    STORAGE_ERROR_TIMEOUT,               /**< Operation timeout */
    STORAGE_ERROR_BAD_SECTOR,            /**< Bad sector detected */
    STORAGE_ERROR_WEAR_LIMIT,            /**< Wear limit reached */
    STORAGE_ERROR_TEMPERATURE,           /**< Temperature warning/critical */
    STORAGE_ERROR_CAPACITY_EXCEEDED,     /**< Capacity limit exceeded */
    STORAGE_ERROR_DEGRADED_PERFORMANCE,  /**< Performance degraded */
    STORAGE_ERROR_CORRUPTION_DETECTED    /**< Data corruption detected */
} storage_status_t;

/**
 * @enum storage_type_t
 * @brief Storage device types
 */
typedef enum {
    STORAGE_TYPE_HDD,                    /**< Hard Disk Drive */
    STORAGE_TYPE_SSD,                    /**< Solid State Drive (SATA) */
    STORAGE_TYPE_NVME,                   /**< NVMe SSD */
    STORAGE_TYPE_NVME_OF,                /**< NVMe over Fabrics */
    STORAGE_TYPE_SAS,                    /**< SAS drive */
    STORAGE_TYPE_SATA,                   /**< SATA drive */
    STORAGE_TYPE_SCSI,                   /**< SCSI drive */
    STORAGE_TYPE_USB,                    /**< USB storage */
    STORAGE_TYPE_SD_CARD,                /**< SD/MicroSD card */
    STORAGE_TYPE_OPTICAL,                /**< Optical drive (CD/DVD/Blu-ray) */
    STORAGE_TYPE_TAPE,                   /**< Tape drive */
    STORAGE_TYPE_VIRTUAL,                /**< Virtual disk */
    STORAGE_TYPE_CLOUD,                  /**< Cloud storage */
    STORAGE_TYPE_RAID_ARRAY,             /**< RAID array */
    STORAGE_TYPE_NAS,                    /**< Network Attached Storage */
    STORAGE_TYPE_SAN,                    /**< Storage Area Network */
    STORAGE_TYPE_UNKNOWN                 /**< Unknown storage type */
} storage_type_t;

/**
 * @enum storage_interface_t
 * @brief Storage interface types
 */
typedef enum {
    STORAGE_INTERFACE_SATA,              /**< SATA interface */
    STORAGE_INTERFACE_SAS,               /**< SAS interface */
    STORAGE_INTERFACE_NVME,              /**< NVMe interface */
    STORAGE_INTERFACE_PCIE,              /**< PCI Express */
    STORAGE_INTERFACE_USB,               /**< USB interface */
    STORAGE_INTERFACE_THUNDERBOLT,       /**< Thunderbolt interface */
    STORAGE_INTERFACE_FIBRE_CHANNEL,     /**< Fibre Channel */
    STORAGE_INTERFACE_ISCSI,             /**< iSCSI */
    STORAGE_INTERFACE_NFS,               /**< Network File System */
    STORAGE_INTERFACE_SMB,               /**< SMB/CIFS */
    STORAGE_INTERFACE_AHCI,              /**< AHCI */
    STORAGE_INTERFACE_UFS,               /**< Universal Flash Storage */
    STORAGE_INTERFACE_UNKNOWN            /**< Unknown interface */
} storage_interface_t;

/**
 * @enum storage_raid_level_t
 * @brief RAID levels
 */
typedef enum {
    RAID_LEVEL_0,                        /**< RAID 0 (striping) */
    RAID_LEVEL_1,                        /**< RAID 1 (mirroring) */
    RAID_LEVEL_5,                        /**< RAID 5 (striping with parity) */
    RAID_LEVEL_6,                        /**< RAID 6 (double parity) */
    RAID_LEVEL_10,                       /**< RAID 10 (mirrored stripes) */
    RAID_LEVEL_01,                       /**< RAID 01 (striped mirrors) */
    RAID_LEVEL_50,                       /**< RAID 50 (RAID 5 + RAID 0) */
    RAID_LEVEL_60,                       /**< RAID 60 (RAID 6 + RAID 0) */
    RAID_LEVEL_JBOD,                     /**< Just a Bunch Of Disks */
    RAID_LEVEL_SINGLE,                   /**< Single disk (no RAID) */
    RAID_LEVEL_UNKNOWN                   /**< Unknown RAID level */
} storage_raid_level_t;

/**
 * @enum storage_filesystem_t
 * @brief Filesystem types
 */
typedef enum {
    FILESYSTEM_NTFS,                     /**< NTFS (Windows) */
    FILESYSTEM_FAT32,                    /**< FAT32 */
    FILESYSTEM_EXFAT,                    /**< exFAT */
    FILESYSTEM_EXT2,                     /**< ext2 */
    FILESYSTEM_EXT3,                     /**< ext3 */
    FILESYSTEM_EXT4,                     /**< ext4 */
    FILESYSTEM_XFS,                      /**< XFS */
    FILESYSTEM_BTRFS,                    /**< Btrfs */
    FILESYSTEM_ZFS,                      /**< ZFS */
    FILESYSTEM_HFS,                      /**< HFS/HFS+ (macOS) */
    FILESYSTEM_APFS,                     /**< APFS (Apple) */
    FILESYSTEM_REFS,                     /**< ReFS (Windows) */
    FILESYSTEM_UDF,                      /**< UDF (optical) */
    FILESYSTEM_ISO9660,                  /**< ISO 9660 (CD/DVD) */
    FILESYSTEM_NFS,                      /**< NFS (network) */
    FILESYSTEM_SMB,                      /**< SMB/CIFS (network) */
    FILESYSTEM_UNKNOWN                   /**< Unknown filesystem */
} storage_filesystem_t;

/**
 * @enum storage_io_type_t
 * @brief I/O operation types
 */
typedef enum {
    IO_TYPE_READ,                        /**< Read operation */
    IO_TYPE_WRITE,                       /**< Write operation */
    IO_TYPE_RANDOM_READ,                 /**< Random read */
    IO_TYPE_RANDOM_WRITE,                /**< Random write */
    IO_TYPE_SEQUENTIAL_READ,             /**< Sequential read */
    IO_TYPE_SEQUENTIAL_WRITE,            /**< Sequential write */
    IO_TYPE_METADATA,                    /**< Metadata operation */
    IO_TYPE_FLUSH,                       /**< Flush/cache sync */
    IO_TYPE_TRIM,                        /**< TRIM/UNMAP operation */
    IO_TYPE_VERIFY,                      /**< Verify/checksum operation */
    IO_TYPE_FORMAT,                      /**< Format operation */
    IO_TYPE_DISCARD                      /**< Discard operation */
} storage_io_type_t;

/**
 * @enum storage_cache_type_t
 * @brief Cache types
 */
typedef enum {
    CACHE_TYPE_NONE,                     /**< No cache */
    CACHE_TYPE_WRITE_BACK,               /**< Write-back cache */
    CACHE_TYPE_WRITE_THROUGH,            /**< Write-through cache */
    CACHE_TYPE_WRITE_AROUND,             /**< Write-around cache */
    CACHE_TYPE_READ_AHEAD,               /**< Read-ahead cache */
    CACHE_TYPE_WRITE_COMBINING,          /**< Write combining */
    CACHE_TYPE_TIERED,                   /**< Tiered cache */
    CACHE_TYPE_UNKNOWN                   /**< Unknown cache type */
} storage_cache_type_t;

/**
 * @enum storage_health_status_t
 * @brief Storage health status
 */
typedef enum {
    HEALTH_EXCELLENT,                    /**< Excellent health */
    HEALTH_GOOD,                         /**< Good health */
    HEALTH_FAIR,                         /**< Fair health */
    HEALTH_POOR,                         /**< Poor health */
    HEALTH_WARNING,                      /**< Warning state */
    HEALTH_CRITICAL,                     /**< Critical state */
    HEALTH_FAILED,                       /**< Failed/dead */
    HEALTH_UNKNOWN                       /**< Unknown health */
} storage_health_status_t;

/**
 * @struct storage_device_info_t
 * @brief Storage device information
 */
typedef struct {
    char device_path[256];               /**< Device path/identifier */
    char vendor[64];                     /**< Vendor name */
    char model[128];                     /**< Device model */
    char serial_number[64];              /**< Serial number */
    char firmware_version[32];           /**< Firmware version */
    storage_type_t type;                 /**< Device type */
    storage_interface_t interface;       /**< Interface type */
    uint64_t capacity_bytes;             /**< Total capacity in bytes */
    uint64_t sector_size;                /**< Sector size in bytes */
    uint64_t logical_sector_size;        /**< Logical sector size */
    uint64_t physical_sector_size;       /**< Physical sector size */
    uint32_t max_queue_depth;            /**< Maximum queue depth */
    uint32_t rotation_rate_rpm;          /**< Rotation rate (HDD only, 0 for SSD) */
    uint64_t nvme_namespace_id;          /**< NVMe namespace ID */
    bool is_removable;                   /**< Is device removable? */
    bool is_read_only;                   /**< Is device read-only? */
    bool is_boot_device;                 /**< Is boot device? */
    bool supports_trim;                  /**< Supports TRIM/UNMAP */
    bool supports_ncq;                   /**< Supports Native Command Queuing */
    bool supports_smart;                 /**< Supports SMART */
    bool supports_encryption;            /**< Supports hardware encryption */
    bool supports_power_management;      /**< Supports power management */
} storage_device_info_t;

/**
 * @struct storage_partition_info_t
 * @brief Partition information
 */
typedef struct {
    char partition_path[256];            /**< Partition path */
    uint64_t start_sector;               /**< Start sector */
    uint64_t size_sectors;               /**< Size in sectors */
    uint64_t size_bytes;                 /**< Size in bytes */
    storage_filesystem_t filesystem;     /**< Filesystem type */
    char filesystem_version[32];         /**< Filesystem version */
    char mount_point[256];               /**< Mount point/path */
    char label[64];                      /**< Partition label */
    char uuid[64];                       /**< Partition UUID */
    bool is_mounted;                     /**< Is partition mounted? */
    bool is_bootable;                    /**< Is partition bootable? */
    bool is_system;                      /**< Is system partition? */
    bool is_encrypted;                   /**< Is partition encrypted? */
    bool is_compressed;                  /**< Is partition compressed? */
    bool is_journaled;                   /**< Is filesystem journaled? */
    uint64_t block_size;                 /**< Filesystem block size */
    uint64_t inode_count;                /**< Number of inodes */
    uint64_t free_inodes;                /**< Free inodes */
} storage_partition_info_t;

/**
 * @struct storage_raid_info_t
 * @brief RAID array information
 */
typedef struct {
    char raid_path[256];                 /**< RAID device path */
    storage_raid_level_t raid_level;     /**< RAID level */
    char raid_type[32];                  /**< RAID type (hardware/software) */
    uint32_t member_count;               /**< Number of member disks */
    uint64_t stripe_size;                /**< Stripe size in bytes */
    uint64_t chunk_size;                 /**< Chunk size in bytes */
    uint64_t parity_size;                /**< Parity size in bytes */
    bool is_degraded;                    /**< Is array degraded? */
    bool is_rebuilding;                  /**< Is array rebuilding? */
    uint32_t rebuild_progress;           /**< Rebuild progress percentage */
    bool has_hot_spare;                  /**< Has hot spare disk? */
    bool is_consistent;                  /**< Is array consistent? */
    char controller_model[64];           /**< RAID controller model */
    char controller_firmware[32];        /**< Controller firmware */
    uint64_t cache_size;                 /**< RAID cache size in bytes */
    storage_cache_type_t cache_type;     /**< RAID cache type */
} storage_raid_info_t;

/**
 * @struct storage_performance_metrics_t
 * @brief Storage performance metrics
 */
typedef struct {
    // Throughput
    uint64_t read_bytes_per_sec;         /**< Read throughput (bytes/sec) */
    uint64_t write_bytes_per_sec;        /**< Write throughput (bytes/sec) */
    uint64_t total_bytes_per_sec;        /**< Total throughput (bytes/sec) */
    
    // IOPS (Input/Output Operations Per Second)
    uint64_t read_iops;                  /**< Read IOPS */
    uint64_t write_iops;                 /**< Write IOPS */
    uint64_t total_iops;                 /**< Total IOPS */
    
    // Latency (in microseconds)
    uint64_t read_latency_avg_us;        /**< Average read latency */
    uint64_t write_latency_avg_us;       /**< Average write latency */
    uint64_t read_latency_max_us;        /**< Maximum read latency */
    uint64_t write_latency_max_us;       /**< Maximum write latency */
    uint64_t read_latency_min_us;        /**< Minimum read latency */
    uint64_t write_latency_min_us;       /**< Minimum write latency */
    uint64_t read_latency_95th_us;       /**< 95th percentile read latency */
    uint64_t write_latency_95th_us;      /**< 95th percentile write latency */
    
    // Queue depth and utilization
    uint32_t queue_depth;                /**< Current queue depth */
    uint32_t max_queue_depth;            /**< Maximum queue depth */
    float queue_utilization;             /**< Queue utilization percentage */
    
    // Disk busy time
    float busy_percentage;               /**< Disk busy time percentage */
    uint64_t busy_time_ms;               /**< Total busy time in ms */
    
    // Transfer sizes
    uint64_t avg_read_size_bytes;        /**< Average read size */
    uint64_t avg_write_size_bytes;       /**< Average write size */
    uint64_t max_read_size_bytes;        /**< Maximum read size */
    uint64_t max_write_size_bytes;       /**< Maximum write size */
    
    // Error rates
    uint64_t read_errors;                /**< Read errors */
    uint64_t write_errors;               /**< Write errors */
    uint64_t retry_count;                /**< Retry operations */
    uint64_t timeout_count;              /**< Timeout operations */
    
    // Cache statistics
    uint64_t cache_hits;                 /**< Cache hits */
    uint64_t cache_misses;               /**< Cache misses */
    float cache_hit_ratio;               /**< Cache hit ratio */
    
    // Timestamp
    uint64_t timestamp_ns;               /**< Sample timestamp in nanoseconds */
} storage_performance_metrics_t;

/**
 * @struct storage_smart_data_t
 * @brief SMART (Self-Monitoring, Analysis and Reporting Technology) data
 */
typedef struct {
    // Basic health indicators
    storage_health_status_t health;      /**< Overall health status */
    uint8_t raw_read_error_rate;         /**< Raw read error rate */
    uint8_t spin_up_time;                /**< Spin up time */
    uint8_t start_stop_count;            /**< Start/stop count */
    uint8_t reallocated_sectors_count;   /**< Reallocated sectors count */
    uint8_t seek_error_rate;             /**< Seek error rate */
    uint8_t power_on_hours;              /**< Power on hours */
    uint8_t spin_retry_count;            /**< Spin retry count */
    uint8_t calibration_retry_count;     /**< Calibration retry count */
    uint8_t power_cycle_count;           /**< Power cycle count */
    uint8_t g_sense_error_rate;          /**< G-sense error rate */
    uint8_t powered_off_retract_count;   /**< Power-off retract count */
    uint8_t load_unload_cycle_count;     /**< Load/unload cycle count */
    uint8_t temperature_celsius;         /**< Temperature in Celsius */
    uint8_t reallocation_event_count;    /**< Reallocation event count */
    uint8_t current_pending_sector_count;/**< Current pending sector count */
    uint8_t offline_uncorrectable_count; /**< Offline uncorrectable count */
    uint8_t udma_crc_error_count;        /**< UDMA CRC error count */
    uint8_t multi_zone_error_rate;       /**< Multi-zone error rate */
    
    // SSD-specific attributes
    uint8_t wear_leveling_count;         /**< Wear leveling count */
    uint8_t used_reserved_block_count;   /**< Used reserved block count */
    uint8_t program_fail_count;          /**< Program fail count */
    uint8_t erase_fail_count;            /**< Erase fail count */
    uint8_t runtime_bad_block_count;     /**< Runtime bad block count */
    uint8_t end_to_end_error_count;      /**< End-to-end error count */
    uint8_t reported_uncorrectable_errors; /**< Reported uncorrectable errors */
    uint8_t thermal_throttle_status;     /**< Thermal throttle status */
    uint8_t percent_lifetime_used;       /**< Percentage of lifetime used */
    uint8_t spare_block_percent_remaining; /**< Spare block % remaining */
    uint8_t nand_bytes_written;          /**< NAND bytes written */
    uint8_t host_bytes_written;          /**< Host bytes written */
    
    // Raw values
    uint64_t raw_power_on_hours;         /**< Raw power on hours */
    uint64_t raw_power_cycle_count;      /**< Raw power cycle count */
    uint64_t raw_bytes_written;          /**< Raw bytes written */
    uint64_t raw_bytes_read;             /**< Raw bytes read */
    
    // Temperature monitoring
    float temperature_min_c;             /**< Minimum temperature */
    float temperature_max_c;             /**< Maximum temperature */
    float temperature_avg_c;             /**< Average temperature */
    float temperature_current_c;         /**< Current temperature */
    
    // Thresholds
    uint8_t temperature_threshold;       /**< Temperature threshold */
    uint8_t reallocated_sector_threshold; /**< Reallocated sector threshold */
    uint8_t spin_up_time_threshold;      /**< Spin up time threshold */
    
    // Timestamp
    time_t last_self_test_time;          /**< Last self-test time */
    uint8_t self_test_status;            /**< Self-test status */
    uint16_t self_test_progress;         /**< Self-test progress % */
} storage_smart_data_t;

/**
 * @struct storage_nvme_health_t
 * @brief NVMe-specific health information
 */
typedef struct {
    uint8_t critical_warning;            /**< Critical warning */
    uint16_t composite_temp;             /**< Composite temperature */
    uint8_t available_spare;             /**< Available spare */
    uint8_t available_spare_threshold;   /**< Available spare threshold */
    uint8_t percent_used;                /**< Percentage used */
    uint64_t data_units_read;            /**< Data units read */
    uint64_t data_units_written;         /**< Data units written */
    uint64_t host_read_commands;         /**< Host read commands */
    uint64_t host_write_commands;        /**< Host write commands */
    uint64_t controller_busy_time;       /**< Controller busy time */
    uint64_t power_cycles;               /**< Power cycles */
    uint64_t power_on_hours;             /**< Power on hours */
    uint64_t unsafe_shutdowns;           /**< Unsafe shutdowns */
    uint64_t media_errors;               /**< Media errors */
    uint64_t num_error_log_entries;      /**< Number of error log entries */
    uint32_t warning_temp_time;          /**< Warning temperature time */
    uint32_t critical_temp_time;         /**< Critical temperature time */
    uint16_t temp_sensor[8];             /**< Temperature sensors */
    uint32_t thermal_management_temp;    /**< Thermal management temperature */
    uint64_t total_bytes_read;           /**< Total bytes read */
    uint64_t total_bytes_written;        /**< Total bytes written */
    uint64_t nand_bytes_written;         /**< NAND bytes written */
    uint64_t host_bytes_written;         /**< Host bytes written */
    uint32_t pcie_error_count;           /**< PCIe error count */
    uint32_t pcie_link_width;            /**< PCIe link width */
    uint32_t pcie_link_speed;            /**< PCIe link speed (GT/s) */
} storage_nvme_health_t;

/**
 * @struct storage_capacity_info_t
 * @brief Storage capacity information
 */
typedef struct {
    uint64_t total_bytes;                /**< Total capacity in bytes */
    uint64_t used_bytes;                 /**< Used bytes */
    uint64_t free_bytes;                 /**< Free bytes */
    uint64_t available_bytes;            /**< Available bytes (free + reserved) */
    uint64_t reserved_bytes;             /**< Reserved bytes */
    uint64_t system_bytes;               /**< System files bytes */
    uint64_t user_bytes;                 /**< User data bytes */
    uint64_t metadata_bytes;             /**< Metadata bytes */
    uint64_t snapshot_bytes;             /**< Snapshot bytes */
    uint64_t deduplicated_bytes;         /**< Deduplicated bytes */
    uint64_t compressed_bytes;           /**< Compressed bytes */
    float usage_percentage;              /**< Usage percentage */
    float inode_usage_percentage;        /**< Inode usage percentage */
    uint64_t total_inodes;               /**< Total inodes */
    uint64_t used_inodes;                /**< Used inodes */
    uint64_t free_inodes;                /**< Free inodes */
    bool is_nearly_full;                 /**< Is storage nearly full? */
    uint64_t threshold_bytes;            /**< Warning threshold in bytes */
    uint64_t critical_bytes;             /**< Critical threshold in bytes */
} storage_capacity_info_t;

/**
 * @struct storage_benchmark_result_t
 * @brief Storage benchmark results
 */
typedef struct {
    // Sequential performance
    uint64_t seq_read_speed_mbps;        /**< Sequential read speed (MB/s) */
    uint64_t seq_write_speed_mbps;       /**< Sequential write speed (MB/s) */
    
    // Random performance (4KB blocks)
    uint64_t random_read_iops;           /**< Random read IOPS (4KB) */
    uint64_t random_write_iops;          /**< Random write IOPS (4KB) */
    
    // Mixed workload
    uint64_t mixed_70_30_iops;           /**< 70% read, 30% write IOPS */
    uint64_t mixed_50_50_iops;           /**< 50% read, 50% write IOPS */
    
    // Latency profiles
    uint64_t read_latency_avg_us;        /**< Average read latency */
    uint64_t write_latency_avg_us;       /**< Average write latency */
    uint64_t read_latency_99th_us;       /**< 99th percentile read latency */
    uint64_t write_latency_99th_us;      /**< 99th percentile write latency */
    
    // Queue depth scaling
    uint64_t iops_at_qd1;                /**< IOPS at queue depth 1 */
    uint64_t iops_at_qd8;                /**< IOPS at queue depth 8 */
    uint64_t iops_at_qd32;               /**< IOPS at queue depth 32 */
    uint64_t iops_at_qd128;              /**< IOPS at queue depth 128 */
    
    // Endurance (for SSDs)
    uint64_t write_endurance_tbw;        /**< Write endurance in TB written */
    uint64_t write_endurance_dwpd;       /**< Drive writes per day */
    
    // Consistency
    float performance_variation;         /**< Performance variation % */
    uint64_t worst_case_latency_us;      /**< Worst-case latency */
    
    // Score
    float overall_score;                 /**< Overall benchmark score (0-100) */
    uint64_t benchmark_duration_ms;      /**< Benchmark duration in ms */
    time_t benchmark_timestamp;          /**< Benchmark timestamp */
} storage_benchmark_result_t;

/**
 * @struct storage_io_pattern_t
 * @brief I/O access pattern analysis
 */
typedef struct {
    float sequentiality_percentage;      /**< Sequential access percentage */
    float randomness_percentage;         /**< Random access percentage */
    float read_write_ratio;              /**< Read/write ratio */
    uint64_t avg_request_size_bytes;     /**< Average request size */
    uint64_t most_common_request_size;   /**< Most common request size */
    float spatial_locality;              /**< Spatial locality score */
    float temporal_locality;             /**< Temporal locality score */
    uint64_t working_set_size_bytes;     /**< Working set size */
    bool is_mostly_reads;                /**< Mostly read workload */
    bool is_mostly_writes;               /**< Mostly write workload */
    bool is_mostly_random;               /**< Mostly random workload */
    bool is_mostly_sequential;           /**< Mostly sequential workload */
    uint32_t hot_data_percentage;        /**< Hot data percentage */
    uint32_t warm_data_percentage;       /**< Warm data percentage */
    uint32_t cold_data_percentage;       /**< Cold data percentage */
} storage_io_pattern_t;

/**
 * @struct storage_cache_info_t
 * @brief Cache information and statistics
 */
typedef struct {
    uint64_t total_cache_size_bytes;     /**< Total cache size */
    uint64_t used_cache_bytes;           /**< Used cache bytes */
    uint64_t free_cache_bytes;           /**< Free cache bytes */
    uint64_t read_cache_size;            /**< Read cache size */
    uint64_t write_cache_size;           /**< Write cache size */
    storage_cache_type_t cache_type;     /**< Cache type */
    uint32_t cache_line_size;            /**< Cache line size */
    uint32_t associativity;              /**< Cache associativity */
    float read_cache_hit_rate;           /**< Read cache hit rate */
    float write_cache_hit_rate;          /**< Write cache hit rate */
    uint64_t cache_flush_count;          /**< Cache flush count */
    uint64_t cache_invalidate_count;     /**< Cache invalidate count */
    uint64_t cache_prefetch_count;       /**< Cache prefetch count */
    bool write_cache_enabled;            /**< Write cache enabled */
    bool read_ahead_enabled;             /**< Read-ahead enabled */
    bool cache_battery_backed;           /**< Cache battery backed */
} storage_cache_info_t;

/**
 * @struct storage_config_t
 * @brief Storage performance monitoring configuration
 */
typedef struct {
    uint32_t sample_interval_ms;         /**< Sampling interval in ms */
    bool enable_smart_monitoring;        /**< Enable SMART monitoring */
    bool enable_nvme_health;             /**< Enable NVMe health monitoring */
    bool enable_raid_monitoring;         /**< Enable RAID monitoring */
    bool enable_capacity_alerts;         /**< Enable capacity alerts */
    bool enable_performance_counters;    /**< Enable performance counters */
    bool enable_io_pattern_analysis;     /**< Enable I/O pattern analysis */
    bool enable_cache_monitoring;        /**< Enable cache monitoring */
    bool enable_benchmarking;            /**< Enable benchmarking */
    uint64_t capacity_warning_threshold; /**< Capacity warning threshold (bytes) */
    uint64_t capacity_critical_threshold; /**< Capacity critical threshold */
    float performance_degradation_threshold; /**< Performance degradation threshold % */
    uint32_t max_samples_stored;         /**< Maximum samples to store */
    void* user_context;                  /**< User-defined context */
    void (*alert_callback)(const char* device_path, 
                          storage_status_t alert_type, 
                          const char* message, 
                          void* context);
} storage_config_t;

/**
 * @struct storage_handle_t
 * @brief Opaque handle for storage performance module
 */
typedef struct storage_handle storage_handle_t;

// ============================================================================
// Initialization and Configuration
// ============================================================================

/**
 * @brief Initialize storage performance monitoring
 * 
 * @param config Pointer to configuration structure (NULL for defaults)
 * @param handle Output parameter for storage handle
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_init(const storage_config_t* config, 
                                  storage_handle_t** handle);

/**
 * @brief Get default configuration for storage monitoring
 * 
 * @param config Output parameter for default configuration
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_get_default_config(storage_config_t* config);

/**
 * @brief Detect storage devices
 * 
 * @param handle Storage handle
 * @param device_count Output parameter for number of devices found
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_detect_devices(storage_handle_t* handle, 
                                            uint32_t* device_count);

/**
 * @brief Start storage performance monitoring
 * 
 * @param handle Storage handle
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_start_monitoring(storage_handle_t* handle);

/**
 * @brief Stop storage performance monitoring
 * 
 * @param handle Storage handle
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_stop_monitoring(storage_handle_t* handle);

/**
 * @brief Clean up storage monitoring resources
 * 
 * @param handle Storage handle
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_deinit(storage_handle_t* handle);

// ============================================================================
// Device Information and Enumeration
// ============================================================================

/**
 * @brief Get storage device information
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param info Output parameter for device info
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_get_device_info(storage_handle_t* handle,
                                             uint32_t device_index,
                                             storage_device_info_t* info);

/**
 * @brief Get device information by path
 * 
 * @param handle Storage handle
 * @param device_path Device path
 * @param info Output parameter for device info
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_get_device_info_by_path(storage_handle_t* handle,
                                                     const char* device_path,
                                                     storage_device_info_t* info);

/**
 * @brief Get partition information
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param partitions Array to store partition info
 * @param max_partitions Maximum partitions to retrieve
 * @param actual_count Output parameter for actual partition count
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_get_partitions(storage_handle_t* handle,
                                            uint32_t device_index,
                                            storage_partition_info_t* partitions,
                                            uint32_t max_partitions,
                                            uint32_t* actual_count);

/**
 * @brief Get RAID array information
 * 
 * @param handle Storage handle
 * @param raid_index RAID array index
 * @param raid_info Output parameter for RAID info
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_get_raid_info(storage_handle_t* handle,
                                           uint32_t raid_index,
                                           storage_raid_info_t* raid_info);

// ============================================================================
// Performance Monitoring
// ============================================================================

/**
 * @brief Get current performance metrics
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param metrics Output parameter for performance metrics
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_get_metrics(storage_handle_t* handle,
                                         uint32_t device_index,
                                         storage_performance_metrics_t* metrics);

/**
 * @brief Get historical performance data
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param metrics_buffer Array to store metrics
 * @param max_samples Maximum samples to retrieve
 * @param start_time Start timestamp (0 for all available)
 * @param end_time End timestamp (0 for current time)
 * @param actual_samples Output parameter for actual samples retrieved
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_get_history(storage_handle_t* handle,
                                         uint32_t device_index,
                                         storage_performance_metrics_t* metrics_buffer,
                                         uint32_t max_samples,
                                         time_t start_time,
                                         time_t end_time,
                                         uint32_t* actual_samples);

/**
 * @brief Get performance statistics
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param start_time Start time for statistics
 * @param end_time End time for statistics
 * @param avg_iops Output parameter for average IOPS
 * @param avg_throughput Output parameter for average throughput
 * @param avg_latency Output parameter for average latency
 * @param peak_iops Output parameter for peak IOPS
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_get_statistics(storage_handle_t* handle,
                                            uint32_t device_index,
                                            time_t start_time,
                                            time_t end_time,
                                            uint64_t* avg_iops,
                                            uint64_t* avg_throughput,
                                            uint64_t* avg_latency,
                                            uint64_t* peak_iops);

// ============================================================================
// Health and SMART Monitoring
// ============================================================================

/**
 * @brief Get SMART data for device
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param smart_data Output parameter for SMART data
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_get_smart_data(storage_handle_t* handle,
                                            uint32_t device_index,
                                            storage_smart_data_t* smart_data);

/**
 * @brief Get NVMe health data
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param nvme_health Output parameter for NVMe health data
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_get_nvme_health(storage_handle_t* handle,
                                             uint32_t device_index,
                                             storage_nvme_health_t* nvme_health);

/**
 * @brief Run SMART self-test
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param test_type Self-test type (0=short, 1=long, 2=conveyance)
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_run_smart_test(storage_handle_t* handle,
                                            uint32_t device_index,
                                            uint8_t test_type);

/**
 * @brief Check storage health status
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param health_status Output parameter for health status
 * @param health_score Output parameter for health score (0-100)
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_check_health(storage_handle_t* handle,
                                          uint32_t device_index,
                                          storage_health_status_t* health_status,
                                          uint8_t* health_score);

// ============================================================================
// Capacity Monitoring
// ============================================================================

/**
 * @brief Get capacity information
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param capacity_info Output parameter for capacity info
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_get_capacity_info(storage_handle_t* handle,
                                               uint32_t device_index,
                                               storage_capacity_info_t* capacity_info);

/**
 * @brief Get partition capacity information
 * 
 * @param handle Storage handle
 * @param partition_path Partition path
 * @param capacity_info Output parameter for capacity info
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_get_partition_capacity(storage_handle_t* handle,
                                                    const char* partition_path,
                                                    storage_capacity_info_t* capacity_info);

/**
 * @brief Set capacity alert thresholds
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param warning_threshold Warning threshold in bytes
 * @param critical_threshold Critical threshold in bytes
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_set_capacity_thresholds(storage_handle_t* handle,
                                                     uint32_t device_index,
                                                     uint64_t warning_threshold,
                                                     uint64_t critical_threshold);

// ============================================================================
// I/O Pattern Analysis
// ============================================================================

/**
 * @brief Analyze I/O patterns
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param pattern Output parameter for I/O pattern analysis
 * @param analysis_duration_ms Duration of analysis in ms
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_analyze_io_pattern(storage_handle_t* handle,
                                                uint32_t device_index,
                                                storage_io_pattern_t* pattern,
                                                uint32_t analysis_duration_ms);

/**
 * @brief Get recommended optimization based on I/O pattern
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param recommendations Buffer for recommendations
 * @param buffer_size Size of recommendations buffer
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_get_optimization_recommendations(storage_handle_t* handle,
                                                              uint32_t device_index,
                                                              char* recommendations,
                                                              size_t buffer_size);

/**
 * @brief Detect hot and cold data regions
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param hot_regions Array for hot region addresses
 * @param max_regions Maximum regions to detect
 * @param actual_regions Output parameter for actual regions found
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_detect_hot_data(storage_handle_t* handle,
                                             uint32_t device_index,
                                             uint64_t* hot_regions,
                                             uint32_t max_regions,
                                             uint32_t* actual_regions);

// ============================================================================
// Benchmarking
// ============================================================================

/**
 * @brief Run comprehensive storage benchmark
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param benchmark_type Bitmask of benchmarks to run
 * @param result Output parameter for benchmark results
 * @param progress_callback Callback for benchmark progress (NULL for none)
 * @param user_data User data for callback
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_run_benchmark(storage_handle_t* handle,
                                           uint32_t device_index,
                                           uint32_t benchmark_type,
                                           storage_benchmark_result_t* result,
                                           void (*progress_callback)(uint32_t progress, void* user_data),
                                           void* user_data);

/**
 * @brief Run quick benchmark
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param result Output parameter for benchmark results
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_run_quick_benchmark(storage_handle_t* handle,
                                                 uint32_t device_index,
                                                 storage_benchmark_result_t* result);

/**
 * @brief Compare benchmark results
 * 
 * @param handle Storage handle
 * @param result1 First benchmark result
 * @param result2 Second benchmark result
 * @param comparison Buffer for comparison results
 * @param buffer_size Size of comparison buffer
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_compare_benchmarks(storage_handle_t* handle,
                                                const storage_benchmark_result_t* result1,
                                                const storage_benchmark_result_t* result2,
                                                char* comparison,
                                                size_t buffer_size);

// ============================================================================
// Cache Management
// ============================================================================

/**
 * @brief Get cache information
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param cache_info Output parameter for cache info
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_get_cache_info(storage_handle_t* handle,
                                            uint32_t device_index,
                                            storage_cache_info_t* cache_info);

/**
 * @brief Flush cache
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param flush_type Type of flush (0=write cache, 1=read cache, 2=both)
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_flush_cache(storage_handle_t* handle,
                                         uint32_t device_index,
                                         uint8_t flush_type);

/**
 * @brief Enable/disable write cache
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param enable Enable or disable write cache
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_set_write_cache(storage_handle_t* handle,
                                             uint32_t device_index,
                                             bool enable);

/**
 * @brief Enable/disable read-ahead cache
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param enable Enable or disable read-ahead
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_set_read_ahead(storage_handle_t* handle,
                                            uint32_t device_index,
                                            bool enable);

// ============================================================================
// Optimization and Tuning
// ============================================================================

/**
 * @brief Optimize storage performance
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param optimization_type Bitmask of optimizations to apply
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_optimize(storage_handle_t* handle,
                                      uint32_t device_index,
                                      uint32_t optimization_type);

/**
 * @brief Defragment storage (HDD only)
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param progress_callback Callback for defrag progress
 * @param user_data User data for callback
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_defragment(storage_handle_t* handle,
                                        uint32_t device_index,
                                        void (*progress_callback)(uint32_t progress, void* user_data),
                                        void* user_data);

/**
 * @brief TRIM/UNMAP storage (SSD only)
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_trim(storage_handle_t* handle,
                                  uint32_t device_index);

/**
 * @brief Set power management mode
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param power_mode Power mode (0=performance, 1=balanced, 2=power saving)
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_set_power_mode(storage_handle_t* handle,
                                            uint32_t device_index,
                                            uint8_t power_mode);

// ============================================================================
// RAID Management
// ============================================================================

/**
 * @brief Create RAID array
 * 
 * @param handle Storage handle
 * @param raid_level RAID level to create
 * @param member_devices Array of member device indices
 * @param member_count Number of member devices
 * @param stripe_size Stripe size in bytes
 * @param raid_path Output parameter for RAID device path
 * @param raid_path_size Size of RAID path buffer
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_create_raid(storage_handle_t* handle,
                                         storage_raid_level_t raid_level,
                                         const uint32_t* member_devices,
                                         uint32_t member_count,
                                         uint64_t stripe_size,
                                         char* raid_path,
                                         size_t raid_path_size);

/**
 * @brief Add hot spare to RAID array
 * 
 * @param handle Storage handle
 * @param raid_index RAID array index
 * @param spare_device_index Spare device index
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_add_hot_spare(storage_handle_t* handle,
                                           uint32_t raid_index,
                                           uint32_t spare_device_index);

/**
 * @brief Start RAID rebuild
 * 
 * @param handle Storage handle
 * @param raid_index RAID array index
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_start_raid_rebuild(storage_handle_t* handle,
                                                uint32_t raid_index);

/**
 * @brief Check RAID consistency
 * 
 * @param handle Storage handle
 * @param raid_index RAID array index
 * @param is_consistent Output parameter for consistency status
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_check_raid_consistency(storage_handle_t* handle,
                                                    uint32_t raid_index,
                                                    bool* is_consistent);

// ============================================================================
// Diagnostics and Troubleshooting
// ============================================================================

/**
 * @brief Run storage diagnostics
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param test_mask Bitmask of diagnostic tests to run
 * @param results Buffer for diagnostic results
 * @param results_size Size of results buffer
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_run_diagnostics(storage_handle_t* handle,
                                             uint32_t device_index,
                                             uint64_t test_mask,
                                             char* results,
                                             size_t results_size);

/**
 * @brief Check for bad sectors
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param bad_sectors Array for bad sector locations
 * @param max_sectors Maximum sectors to report
 * @param actual_count Output parameter for actual bad sectors found
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_scan_bad_sectors(storage_handle_t* handle,
                                              uint32_t device_index,
                                              uint64_t* bad_sectors,
                                              uint32_t max_sectors,
                                              uint32_t* actual_count);

/**
 * @brief Repair storage errors
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param repair_type Type of repair to perform
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_repair_errors(storage_handle_t* handle,
                                           uint32_t device_index,
                                           uint32_t repair_type);

/**
 * @brief Get storage error log
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param error_log Buffer for error log
 * @param log_size Size of error log buffer
 * @param actual_size Output parameter for actual log size
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_get_error_log(storage_handle_t* handle,
                                           uint32_t device_index,
                                           char* error_log,
                                           size_t log_size,
                                           size_t* actual_size);

// ============================================================================
// Inline Utility Functions
// ============================================================================

/**
 * @brief Check if storage monitoring is active
 * 
 * @param handle Storage handle to check
 * @return true if monitoring is active, false otherwise
 */
static inline bool storage_perf_is_monitoring_active(const storage_handle_t* handle) {
    return (handle != NULL);
}

/**
 * @brief Convert bytes to gigabytes
 * 
 * @param bytes Number of bytes
 * @return Size in gigabytes
 */
static inline double storage_bytes_to_gb(uint64_t bytes) {
    return (double)bytes / (1024.0 * 1024.0 * 1024.0);
}

/**
 * @brief Convert bytes to terabytes
 * 
 * @param bytes Number of bytes
 * @return Size in terabytes
 */
static inline double storage_bytes_to_tb(uint64_t bytes) {
    return (double)bytes / (1024.0 * 1024.0 * 1024.0 * 1024.0);
}

/**
 * @brief Convert megabytes per second to gigabits per second
 * 
 * @param mbps Speed in MB/s
 * @return Speed in Gb/s
 */
static inline double storage_mbps_to_gbps(uint64_t mbps) {
    return (double)mbps * 8.0 / 1000.0;
}

/**
 * @brief Calculate latency percentile from sorted array
 * 
 * @param latencies Array of latencies
 * @param count Number of latencies
 * @param percentile Percentile to calculate (0-100)
 * @return Latency at specified percentile
 */
static inline uint64_t storage_calculate_latency_percentile(const uint64_t* latencies,
                                                           uint32_t count,
                                                           float percentile) {
    if (count == 0) return 0;
    if (count == 1) return latencies[0];
    
    float index = (percentile / 100.0f) * (count - 1);
    uint32_t lower = (uint32_t)index;
    uint32_t upper = lower + 1;
    
    if (upper >= count) return latencies[count - 1];
    
    float weight = index - lower;
    return (uint64_t)(latencies[lower] * (1 - weight) + latencies[upper] * weight);
}

/**
 * @brief Calculate cache hit ratio
 * 
 * @param hits Number of cache hits
 * @param misses Number of cache misses
 * @return Cache hit ratio (0.0-1.0)
 */
static inline float storage_calculate_hit_ratio(uint64_t hits, uint64_t misses) {
    uint64_t total = hits + misses;
    if (total == 0) return 0.0f;
    return (float)hits / (float)total;
}

/**
 * @brief Get API version string
 * 
 * @return const char* Version string
 */
static inline const char* storage_perf_get_version_string(void) {
    return "3.5.0";
}

// ============================================================================
// Platform-Specific Extensions
// ============================================================================

#if defined(STORAGE_PLATFORM_WINDOWS)
/**
 * @brief Get Windows storage performance counters
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param counters Buffer for performance counters
 * @param counters_size Size of counters buffer
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_get_windows_counters(storage_handle_t* handle,
                                                  uint32_t device_index,
                                                  char* counters,
                                                  size_t counters_size);
#endif

#if defined(STORAGE_PLATFORM_LINUX)
/**
 * @brief Get Linux block device statistics from sysfs
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param sysfs_stats Buffer for sysfs statistics
 * @param stats_size Size of stats buffer
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_get_linux_sysfs_stats(storage_handle_t* handle,
                                                   uint32_t device_index,
                                                   char* sysfs_stats,
                                                   size_t stats_size);
#endif

#if defined(STORAGE_PLATFORM_MACOS)
/**
 * @brief Get macOS IOKit storage information
 * 
 * @param handle Storage handle
 * @param device_index Device index
 * @param iokit_info Buffer for IOKit information
 * @param info_size Size of info buffer
 * @return storage_status_t Status code
 */
storage_status_t storage_perf_get_macos_iokit_info(storage_handle_t* handle,
                                                  uint32_t device_index,
                                                  char* iokit_info,
                                                  size_t info_size);
#endif

// ============================================================================
// Export Macros for Shared Libraries
// ============================================================================
#ifdef BUILDING_STORAGE_PERF_DLL
    #define STORAGE_PERF_API __declspec(dllexport)
#elif defined(USING_STORAGE_PERF_DLL)
    #define STORAGE_PERF_API __declspec(dllimport)
#else
    #define STORAGE_PERF_API
#endif

#ifdef __cplusplus
}
#endif

#endif // STORAGE_PERF_H

// ============================================================================
// Implementation Notes:
// ============================================================================
// 1. Platform Support: Windows, Linux, macOS with platform-specific optimizations
// 2. Storage Types: HDD, SSD, NVMe, RAID, SAN, NAS, cloud storage
// 3. Performance Metrics: Latency, throughput, IOPS, queue depth, cache statistics
// 4. Health Monitoring: SMART, NVMe health, temperature, wear leveling, bad sectors
// 5. Capacity Management: Usage tracking, threshold alerts, compression, deduplication
// 6. I/O Analysis: Pattern detection, hot/cold data, sequentiality, randomness
// 7. Benchmarking: Comprehensive performance testing with scoring
// 8. Optimization: Defragmentation, TRIM, cache tuning, power management
// 9. RAID Support: Creation, management, monitoring, rebuild, consistency checking
// 10. Diagnostics: Error detection, repair, bad sector scanning, error logs