/**
 * @file filename.h
 * @brief Brief description of the module/component
 * 
 * Detailed description explaining the purpose, functionality,
 * and usage of this header file.
 * 
 * @author Your Name or Team
 * @date Last Modified Date
 * @version 1.0.0
 * 
 * @license MIT License
 * @copyright Copyright (c) 2024 Your Company
 */

#ifndef FILENAME_H
#define FILENAME_H

#ifdef __cplusplus
extern "C" {
#endif

// ============================================================================
// Includes
// ============================================================================
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

// Project-specific includes
#include "common_defs.h"

// ============================================================================
// Configuration Macros
// ============================================================================
/**
 * @def MODULE_VERSION
 * @brief Current version of this module
 */
#define MODULE_VERSION_MAJOR 1
#define MODULE_VERSION_MINOR 0
#define MODULE_VERSION_PATCH 0

/**
 * @def FEATURE_ENABLED
 * @brief Enable/disable specific feature
 */
#ifndef FEATURE_ENABLED
#define FEATURE_ENABLED 1
#endif

// ============================================================================
// Type Definitions
// ============================================================================
/**
 * @enum module_status_t
 * @brief Status codes returned by module functions
 */
typedef enum {
    MODULE_SUCCESS = 0,      /**< Operation completed successfully */
    MODULE_ERROR_INVALID,    /**< Invalid parameter or state */
    MODULE_ERROR_MEMORY,     /**< Memory allocation failure */
    MODULE_ERROR_IO,         /**< I/O operation failure */
    MODULE_ERROR_TIMEOUT,    /**< Operation timeout */
    MODULE_ERROR_UNKNOWN     /**< Unknown error */
} module_status_t;

/**
 * @struct module_config_t
 * @brief Configuration structure for module initialization
 */
typedef struct {
    uint32_t timeout_ms;     /**< Operation timeout in milliseconds */
    uint8_t retry_count;     /**< Number of retry attempts */
    bool enable_logging;     /**< Enable debug logging */
    void* user_context;      /**< User-defined context pointer */
} module_config_t;

/**
 * @struct module_handle_t
 * @brief Opaque handle for module instance
 */
typedef struct module_handle module_handle_t;

// ============================================================================
// Function Declarations
// ============================================================================

/**
 * @brief Initialize the module with provided configuration
 * 
 * @param config Pointer to configuration structure
 * @param handle Output parameter for module handle
 * @return module_status_t Status code
 */
module_status_t module_init(const module_config_t* config, 
                           module_handle_t** handle);

/**
 * @brief Clean up and deinitialize module
 * 
 * @param handle Module handle to deinitialize
 * @return module_status_t Status code
 */
module_status_t module_deinit(module_handle_t* handle);

/**
 * @brief Process data using the module
 * 
 * @param handle Initialized module handle
 * @param input_data Pointer to input data buffer
 * @param input_size Size of input data in bytes
 * @param output_data Pointer to output data buffer
 * @param output_size Pointer to output size (in/out parameter)
 * @return module_status_t Status code
 */
module_status_t module_process(module_handle_t* handle,
                              const void* input_data,
                              size_t input_size,
                              void* output_data,
                              size_t* output_size);

/**
 * @brief Get module status information
 * 
 * @param handle Module handle
 * @param status_string Buffer for status string
 * @param buffer_size Size of status buffer
 * @return module_status_t Status code
 */
module_status_t module_get_status(module_handle_t* handle,
                                 char* status_string,
                                 size_t buffer_size);

/**
 * @brief Set module runtime parameter
 * 
 * @param handle Module handle
 * @param param_id Parameter identifier
 * @param value Parameter value
 * @return module_status_t Status code
 */
module_status_t module_set_parameter(module_handle_t* handle,
                                    uint32_t param_id,
                                    intptr_t value);

/**
 * @brief Get module runtime parameter
 * 
 * @param handle Module handle
 * @param param_id Parameter identifier
 * @param value Output parameter for value
 * @return module_status_t Status code
 */
module_status_t module_get_parameter(module_handle_t* handle,
                                    uint32_t param_id,
                                    intptr_t* value);

// ============================================================================
// Inline Functions
// ============================================================================
/**
 * @brief Check if module is initialized
 * 
 * @param handle Module handle to check
 * @return true if initialized, false otherwise
 */
static inline bool module_is_initialized(const module_handle_t* handle) {
    return (handle != NULL);
}

/**
 * @brief Convert status code to string
 * 
 * @param status Status code to convert
 * @return const char* String representation
 */
static inline const char* module_status_to_string(module_status_t status) {
    switch (status) {
        case MODULE_SUCCESS:         return "Success";
        case MODULE_ERROR_INVALID:   return "Invalid parameter";
        case MODULE_ERROR_MEMORY:    return "Memory error";
        case MODULE_ERROR_IO:        return "I/O error";
        case MODULE_ERROR_TIMEOUT:   return "Timeout";
        case MODULE_ERROR_UNKNOWN:   return "Unknown error";
        default:                     return "Invalid status code";
    }
}

// ============================================================================
// Deprecated Functions (for backward compatibility)
// ============================================================================
#if defined(ENABLE_DEPRECATED) || defined(DOXYGEN)
/**
 * @deprecated Use module_init() instead
 * @brief Legacy initialization function
 */
module_status_t legacy_module_init(uint32_t flags) 
    __attribute__((deprecated("Use module_init() instead")));
#endif

// ============================================================================
// Export Macros (for shared libraries)
// ============================================================================
#ifdef BUILDING_DLL
    #define MODULE_API __declspec(dllexport)
#elif defined(USING_DLL)
    #define MODULE_API __declspec(dllimport)
#else
    #define MODULE_API
#endif

#ifdef __cplusplus
}
#endif

#endif // FILENAME_H

// ============================================================================
// Additional Notes:
// ============================================================================
// 1. Add Doxygen comments for all public APIs
// 2. Use include guards with unique names (FILENAME_H)
// 3. Add extern "C" for C++ compatibility
// 4. Use standard integer types (stdint.h)
// 5. Add configuration macros for compile-time options
// 6. Use opaque pointers for data hiding
// 7. Add inline functions for simple operations
// 8. Mark deprecated functions appropriately
// 9. Add export macros for shared library support
// 10. Consider thread safety annotations if needed