/**
 * @file cpu.h
 * @brief CPU Information, Monitoring, and Management Module
 * 
 * This module provides detailed CPU information, performance monitoring,
 * architecture detection, feature enumeration, and low-level control
 * for modern multi-core processors across x86, ARM, and RISC-V architectures.
 * 
 * @author CPU Architecture Team
 * @date 2024-01-31
 * @version 4.0.0
 * 
 * @license Apache 2.0
 * @copyright Copyright (c) 2024 CPU Solutions
 */

#ifndef CPU_H
#define CPU_H

#ifdef __cplusplus
extern "C" {
#endif

// ============================================================================
// Includes and Dependencies
// ============================================================================
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <time.h>

// Platform-specific headers
#if defined(_WIN32) || defined(_WIN64)
    #include <windows.h>
    #include <intrin.h>
    #define CPU_PLATFORM_WINDOWS 1
#elif defined(__linux__)
    #include <unistd.h>
    #include <sys/sysinfo.h>
    #include <cpuid.h>
    #define CPU_PLATFORM_LINUX 1
#elif defined(__APPLE__)
    #include <sys/sysctl.h>
    #include <mach/mach.h>
    #include <mach/mach_time.h>
    #define CPU_PLATFORM_MACOS 1
#elif defined(__FreeBSD__)
    #include <sys/types.h>
    #include <sys/sysctl.h>
    #include <sys/resource.h>
    #define CPU_PLATFORM_FREEBSD 1
#endif

// ============================================================================
// Configuration Constants
// ============================================================================
/**
 * @def CPU_API_VERSION_MAJOR
 * @brief Major version number
 */
#define CPU_API_VERSION_MAJOR 4

/**
 * @def CPU_API_VERSION_MINOR
 * @brief Minor version number
 */
#define CPU_API_VERSION_MINOR 0

/**
 * @def CPU_API_VERSION_PATCH
 * @brief Patch version number
 */
#define CPU_API_VERSION_PATCH 0

/**
 * @def CPU_MAX_CORES
 * @brief Maximum number of CPU cores supported
 */
#define CPU_MAX_CORES 1024

/**
 * @def CPU_MAX_THREADS_PER_CORE
 * @brief Maximum threads per core (SMT/HT)
 */
#define CPU_MAX_THREADS_PER_CORE 8

/**
 * @def CPU_MAX_CACHE_LEVELS
 * @brief Maximum cache levels supported
 */
#define CPU_MAX_CACHE_LEVELS 4

/**
 * @def CPU_MAX_FEATURE_BITS
 * @brief Maximum feature bits supported
 */
#define CPU_MAX_FEATURE_BITS 512

/**
 * @def CPU_MAX_MEMORY_NODES
 * @brief Maximum NUMA nodes supported
 */
#define CPU_MAX_MEMORY_NODES 256

/**
 * @def CPU_MAX_MICROCODE_SIZE
 * @brief Maximum microcode patch size
 */
#define CPU_MAX_MICROCODE_SIZE 65536

/**
 * @def CPU_DEFAULT_SAMPLE_INTERVAL_MS
 * @brief Default sampling interval in milliseconds
 */
#define CPU_DEFAULT_SAMPLE_INTERVAL_MS 100

// ============================================================================
// Type Definitions
// ============================================================================

/**
 * @enum cpu_status_t
 * @brief Status codes for CPU operations
 */
typedef enum {
    CPU_SUCCESS = 0,                     /**< Operation successful */
    CPU_ERROR_INIT_FAILED,               /**< Initialization failed */
    CPU_ERROR_INVALID_PARAMETER,         /**< Invalid parameter */
    CPU_ERROR_NOT_INITIALIZED,           /**< CPU module not initialized */
    CPU_ERROR_UNSUPPORTED_ARCHITECTURE,  /**< Unsupported CPU architecture */
    CPU_ERROR_CPUID_UNAVAILABLE,         /**< CPUID instruction unavailable */
    CPU_ERROR_INSUFFICIENT_PRIVILEGE,    /**< Insufficient privilege level */
    CPU_ERROR_HYPERVISOR_DETECTED,       /**< Running under hypervisor */
    CPU_ERROR_MEMORY_ALLOCATION,         /**< Memory allocation failed */
    CPU_ERROR_PERFORMANCE_COUNTERS,      /**< Performance counters unavailable */
    CPU_ERROR_MICROCODE_UPDATE,          /**< Microcode update failed */
    CPU_ERROR_THERMAL_THROTTLING,        /**< CPU thermal throttling active */
    CPU_ERROR_POWER_LIMIT,               /**< Power limit exceeded */
    CPU_ERROR_FREQUENCY_LIMIT,           /**< Frequency limit reached */
    CPU_ERROR_OVERCLOCK_FAILED,          /**< Overclocking operation failed */
    CPU_ERROR_TIMEOUT,                   /**< Operation timeout */
    CPU_ERROR_IO_ERROR,                  /**< I/O operation failed */
    CPU_ERROR_SECURE_MODE_REQUIRED,      /**< Operation requires secure mode */
    CPU_ERROR_FEATURE_DISABLED           /**< Feature disabled in BIOS */
} cpu_status_t;

/**
 * @enum cpu_architecture_t
 * @brief CPU architecture family
 */
typedef enum {
    CPU_ARCH_X86,                        /**< Intel x86 (32-bit) */
    CPU_ARCH_X86_64,                     /**< AMD64/Intel 64 (64-bit) */
    CPU_ARCH_IA64,                       /**< Intel Itanium (IA-64) */
    CPU_ARCH_ARM,                        /**< ARM (32-bit) */
    CPU_ARCH_ARM64,                      /**< ARM64/AArch64 */
    CPU_ARCH_POWERPC,                    /**< PowerPC (32-bit) */
    CPU_ARCH_POWERPC64,                  /**< PowerPC 64-bit */
    CPU_ARCH_MIPS,                       /**< MIPS */
    CPU_ARCH_RISCV32,                    /**< RISC-V (32-bit) */
    CPU_ARCH_RISCV64,                    /**< RISC-V (64-bit) */
    CPU_ARCH_SPARC,                      /**< SPARC */
    CPU_ARCH_ALPHA,                      /**< Alpha */
    CPU_ARCH_UNKNOWN                     /**< Unknown architecture */
} cpu_architecture_t;

/**
 * @enum cpu_vendor_t
 * @brief CPU vendor/manufacturer
 */
typedef enum {
    CPU_VENDOR_INTEL,                    /**< Intel Corporation */
    CPU_VENDOR_AMD,                      /**< Advanced Micro Devices */
    CPU_VENDOR_ARM,                      /**< ARM Holdings */
    CPU_VENDOR_APPLE,                    /**< Apple Inc. */
    CPU_VENDOR_QUALCOMM,                 /**< Qualcomm */
    CPU_VENDOR_SAMSUNG,                  /**< Samsung */
    CPU_VENDOR_NVIDIA,                   /**< NVIDIA */
    CPU_VENDOR_IBM,                      /**< IBM */
    CPU_VENDOR_FUJITSU,                  /**< Fujitsu */
    CPU_VENDOR_HUAWEI,                   /**< Huawei */
    CPU_VENDOR_PHYTIUM,                  /**< Phytium */
    CPU_VENDOR_ZHAOXIN,                  /**< Zhaoxin */
    CPU_VENDOR_VIA,                      /**< VIA Technologies */
    CPU_VENDOR_HYGON,                    /**< Hygon */
    CPU_VENDOR_UNKNOWN                   /**< Unknown vendor */
} cpu_vendor_t;

/**
 * @enum cpu_feature_t
 * @brief CPU feature flags
 */
typedef enum {
    // x86/x64 Features
    CPU_FEATURE_MMX = 0,                 /**< MMX instructions */
    CPU_FEATURE_SSE,                     /**< Streaming SIMD Extensions */
    CPU_FEATURE_SSE2,                    /**< SSE2 extensions */
    CPU_FEATURE_SSE3,                    /**< SSE3 extensions */
    CPU_FEATURE_SSSE3,                   /**< Supplemental SSE3 */
    CPU_FEATURE_SSE4_1,                  /**< SSE4.1 extensions */
    CPU_FEATURE_SSE4_2,                  /**< SSE4.2 extensions */
    CPU_FEATURE_AVX,                     /**< Advanced Vector Extensions */
    CPU_FEATURE_AVX2,                    /**< AVX2 extensions */
    CPU_FEATURE_AVX512F,                 /**< AVX-512 Foundation */
    CPU_FEATURE_FMA,                     /**< Fused Multiply-Add */
    CPU_FEATURE_AES,                     /**< AES instructions */
    CPU_FEATURE_SHA,                     /**< SHA extensions */
    
    // Virtualization Features
    CPU_FEATURE_VMX,                     /**< Intel VT-x */
    CPU_FEATURE_SVM,                     /**< AMD-V */
    
    // Security Features
    CPU_FEATURE_SGX,                     /**< Software Guard Extensions */
    CPU_FEATURE_TXT,                     /**< Trusted Execution Technology */
    CPU_FEATURE_TPM,                     /**< Trusted Platform Module */
    CPU_FEATURE_SEV,                     /**< Secure Encrypted Virtualization */
    
    // Power Management
    CPU_FEATURE_SPEEDSTEP,               /**< SpeedStep technology */
    CPU_FEATURE_TURBO_BOOST,             /**< Turbo Boost technology */
    CPU_FEATURE_POWER_NOW,               /**< PowerNow! technology */
    
    // ARM Features
    CPU_FEATURE_NEON,                    /**< ARM NEON SIMD */
    CPU_FEATURE_SVE,                     /**< Scalable Vector Extension */
    CPU_FEATURE_SME,                     /**< Scalable Matrix Extension */
    
    // Advanced Features
    CPU_FEATURE_HYPER_THREADING,         /**< Hyper-Threading Technology */
    CPU_FEATURE_MULTI_CORE,              /**< Multi-core processor */
    CPU_FEATURE_64BIT,                   /**< 64-bit architecture */
    CPU_FEATURE_NX_BIT,                  /**< No-eXecute bit */
    CPU_FEATURE_SPECULATION_CONTROL,     /**< Speculation control */
    CPU_FEATURE_MELTDOWN_PATCHED,        /**< Meltdown vulnerability patched */
    CPU_FEATURE_SPECTRE_PATCHED,         /**< Spectre vulnerability patched */
    
    // Performance Monitoring
    CPU_FEATURE_PERFORMANCE_COUNTERS,    /**< Performance monitoring counters */
    CPU_FEATURE_ENERGY_EFFICIENCY,       /**< Energy efficiency features */
    
    CPU_FEATURE_COUNT                    /**< Total number of features */
} cpu_feature_t;

/**
 * @enum cpu_cache_type_t
 * @brief CPU cache types
 */
typedef enum {
    CPU_CACHE_TYPE_DATA,                 /**< Data cache */
    CPU_CACHE_TYPE_INSTRUCTION,          /**< Instruction cache */
    CPU_CACHE_TYPE_UNIFIED,              /**< Unified cache */
    CPU_CACHE_TYPE_TRACE,                /**< Trace cache */
    CPU_CACHE_TYPE_PREFETCH,             /**< Prefetch cache */
    CPU_CACHE_TYPE_SNOOP_FILTER          /**< Snoop filter */
} cpu_cache_type_t;

/**
 * @enum cpu_topology_type_t
 * @brief CPU topology types
 */
typedef enum {
    CPU_TOPOLOGY_PHYSICAL_CORE,          /**< Physical CPU core */
    CPU_TOPOLOGY_LOGICAL_CORE,           /**< Logical CPU core */
    CPU_TOPOLOGY_SOCKET,                 /**< CPU socket/package */
    CPU_TOPOLOGY_NUMA_NODE,              /**< NUMA node */
    CPU_TOPOLOGY_CACHE,                  /**< Cache domain */
    CPU_TOPOLOGY_DIE,                    /**< CPU die */
    CPU_TOPOLOGY_MODULE,                 /**< CPU module */
    CPU_TOPOLOGY_TILE,                   /**< CPU tile */
    CPU_TOPOLOGY_CCX,                    /**< AMD Core Complex */
    CPU_TOPOLOGY_CCD                     /**< AMD Core Complex Die */
} cpu_topology_type_t;

/**
 * @struct cpu_register_set_t
 * @brief CPU register values
 */
typedef struct {
    uint64_t rax;                       /**< RAX/EAX register */
    uint64_t rbx;                       /**< RBX/EBX register */
    uint64_t rcx;                       /**< RCX/ECX register */
    uint64_t rdx;                       /**< RDX/EDX register */
    uint64_t rsi;                       /**< RSI/ESI register */
    uint64_t rdi;                       /**< RDI/EDI register */
    uint64_t rbp;                       /**< RBP/EBP register */
    uint64_t rsp;                       /**< RSP/ESP register */
    uint64_t rip;                       /**< RIP/EIP register */
    uint64_t rflags;                    /**< RFLAGS/EFLAGS register */
    uint64_t cr0;                       /**< Control register 0 */
    uint64_t cr2;                       /**< Control register 2 */
    uint64_t cr3;                       /**< Control register 3 */
    uint64_t cr4;                       /**< Control register 4 */
    uint64_t xcr0;                      /**< Extended control register 0 */
} cpu_register_set_t;

/**
 * @struct cpu_id_info_t
 * @brief CPU identification information from CPUID
 */
typedef struct {
    uint32_t eax;                       /**< EAX register value */
    uint32_t ebx;                       /**< EBX register value */
    uint32_t ecx;                       /**< ECX register value */
    uint32_t edx;                       /**< EDX register value */
    char vendor_string[13];             /**< Vendor ID string */
    char brand_string[49];              /**< Processor brand string */
    uint32_t family;                    /**< CPU family */
    uint32_t model;                     /**< CPU model */
    uint32_t stepping;                  /**< CPU stepping */
    uint32_t extended_family;           /**< Extended family */
    uint32_t extended_model;            /**< Extended model */
    uint32_t signature;                 /**< CPU signature */
    uint32_t type;                      /**< Processor type */
} cpu_id_info_t;

/**
 * @struct cpu_cache_info_t
 * @brief CPU cache information
 */
typedef struct {
    uint8_t level;                      /**< Cache level (1, 2, 3, 4) */
    cpu_cache_type_t type;              /**< Cache type */
    uint32_t size_kb;                   /**< Cache size in KB */
    uint32_t line_size_bytes;           /**< Cache line size in bytes */
    uint32_t associativity;             /**< Cache associativity */
    uint32_t sets;                      /**< Number of cache sets */
    bool is_self_initializing;          /**< Self-initializing cache */
    bool is_fully_associative;          /**< Fully associative cache */
    bool is_inclusive;                  /**< Inclusive cache */
    bool is_write_back;                 /**< Write-back cache */
    bool is_write_through;              /**< Write-through cache */
    uint32_t shared_cpus;               /**< Bitmask of sharing CPUs */
    uint32_t partitioning;              /**< Cache partitioning */
} cpu_cache_info_t;

/**
 * @struct cpu_topology_info_t
 * @brief CPU topology information
 */
typedef struct {
    uint32_t package_id;                /**< Physical package ID */
    uint32_t core_id;                   /**< Physical core ID */
    uint32_t thread_id;                 /**< Logical thread ID */
    uint32_t numa_node_id;              /**< NUMA node ID */
    uint32_t die_id;                    /**< Die ID */
    uint32_t module_id;                 /**< Module ID */
    uint32_t tile_id;                   /**< Tile ID */
    uint32_t ccx_id;                    /**< Core Complex ID (AMD) */
    uint32_t ccd_id;                    /**< Core Complex Die ID (AMD) */
    uint32_t smt_id;                    /**< SMT/HT thread ID */
    uint32_t apic_id;                   /**< APIC ID */
    uint32_t initial_apic_id;           /**< Initial APIC ID */
} cpu_topology_info_t;

/**
 * @struct cpu_frequency_info_t
 * @brief CPU frequency information
 */
typedef struct {
    uint64_t base_frequency_hz;         /**< Base frequency in Hz */
    uint64_t max_frequency_hz;          /**< Maximum frequency in Hz */
    uint64_t min_frequency_hz;          /**< Minimum frequency in Hz */
    uint64_t current_frequency_hz;      /**< Current frequency in Hz */
    uint64_t bus_frequency_hz;          /**< Bus frequency in Hz */
    uint64_t turbo_frequency_hz;        /**< Turbo frequency in Hz */
    float frequency_multiplier;         /**< Frequency multiplier */
    bool is_turbo_active;               /**< Is turbo boost active? */
    bool is_overclocked;                /**< Is CPU overclocked? */
    uint32_t p_state;                   /**< Current P-state */
    uint32_t c_state;                   /**< Current C-state */
} cpu_frequency_info_t;

/**
 * @struct cpu_thermal_info_t
 * @brief CPU thermal information
 */
typedef struct {
    float temperature_c;                /**< Temperature in Celsius */
    float temperature_f;                /**< Temperature in Fahrenheit */
    float temperature_k;                /**< Temperature in Kelvin */
    float tjmax;                        /**< TjMax (maximum junction temp) */
    float tcontrol;                     /**< Tcontrol (control temperature) */
    float tcc_offset;                   /**< Thermal Control Circuit offset */
    float dts_offset;                   /**< Digital Thermal Sensor offset */
    float critical_temp;                /**< Critical temperature threshold */
    float thermal_margin;               /**< Thermal margin (distance to TjMax) */
    bool is_throttling;                 /**< Is CPU thermal throttling? */
    uint32_t throttle_reason;           /**< Throttling reason bitmask */
    float power_limit_1_watts;          /**< PL1 power limit (long term) */
    float power_limit_2_watts;          /**< PL2 power limit (short term) */
    float power_limit_4_watts;          /**< PL4 power limit (peak) */
} cpu_thermal_info_t;

/**
 * @struct cpu_power_info_t
 * @brief CPU power information
 */
typedef struct {
    float package_power_watts;          /**< Package power in watts */
    float core_power_watts;             /**< Core power in watts */
    float uncore_power_watts;           /**< Uncore power in watts */
    float dram_power_watts;             /**< DRAM power in watts */
    float total_power_watts;            /**< Total power in watts */
    float power_limit_watts;            /**< Power limit in watts */
    float min_power_watts;              /**< Minimum power in watts */
    float max_power_watts;              /**< Maximum power in watts */
    float energy_joules;                /**< Energy consumed in joules */
    float voltage_v;                    /**< CPU voltage in volts */
    float current_a;                    /**< CPU current in amperes */
    bool is_power_limited;              /**< Is CPU power limited? */
    uint32_t power_state;               /**< Current power state */
} cpu_power_info_t;

/**
 * @struct cpu_performance_counters_t
 * @brief CPU performance counters
 */
typedef struct {
    uint64_t instructions_retired;      /**< Instructions retired */
    uint64_t cycles;                    /**< CPU cycles */
    uint64_t reference_cycles;          /**< Reference cycles */
    uint64_t llc_references;            /**< Last-level cache references */
    uint64_t llc_misses;                /**< Last-level cache misses */
    uint64_t branch_instructions;       /**< Branch instructions */
    uint64_t branch_misses;             /**< Branch mispredictions */
    uint64_t l1d_cache_references;      /**< L1 data cache references */
    uint64_t l1d_cache_misses;          /**< L1 data cache misses */
    uint64_t l1i_cache_references;      /**< L1 instruction cache references */
    uint64_t l1i_cache_misses;          /**< L1 instruction cache misses */
    uint64_t dtlb_references;           /**< DTLB references */
    uint64_t dtlb_misses;               /**< DTLB misses */
    uint64_t itlb_references;           /**< ITLB references */
    uint64_t itlb_misses;               /**< ITLB misses */
    uint64_t context_switches;          /**< Context switches */
    uint64_t page_faults;               /**< Page faults */
    uint64_t alignment_faults;          /**< Alignment faults */
    uint64_t emulation_faults;          /**< Emulation faults */
} cpu_performance_counters_t;

/**
 * @struct cpu_microcode_info_t
 * @brief CPU microcode information
 */
typedef struct {
    uint32_t revision;                  /**< Microcode revision */
    uint32_t date;                      /**< Microcode date (YYMMDD) */
    uint32_t processor_signature;       /**< Processor signature */
    uint32_t platform_id;               /**< Platform ID */
    uint32_t data_size;                 /**< Microcode data size */
    uint32_t total_size;                /**< Total microcode size */
    uint32_t update_revision;           /**< Update revision */
    uint32_t loader_revision;           /**< Loader revision */
    bool is_update_pending;             /**< Is update pending? */
    bool is_update_supported;           /**< Is update supported? */
} cpu_microcode_info_t;

/**
 * @struct cpu_security_info_t
 * @brief CPU security features and vulnerabilities
 */
typedef struct {
    bool spectre_v1_mitigated;          /**< Spectre V1 mitigated */
    bool spectre_v2_mitigated;          /**< Spectre V2 mitigated */
    bool meltdown_mitigated;            /**< Meltdown mitigated */
    bool l1tf_mitigated;                /**< L1 Terminal Fault mitigated */
    bool mds_mitigated;                 /**< Microarchitectural Data Sampling mitigated */
    bool tsx_async_abort_mitigated;     /**< TSX Async Abort mitigated */
    bool itlb_multihit_mitigated;       /**< iTLB multihit mitigated */
    bool srbds_mitigated;               /**< Special Register Buffer Data Sampling mitigated */
    bool smt_vulnerable;                /**< SMT vulnerable */
    bool sgx_enabled;                   /**< Software Guard Extensions enabled */
    bool txt_enabled;                   /**< Trusted Execution Technology enabled */
    bool sev_enabled;                   /**< Secure Encrypted Virtualization enabled */
    bool smep_enabled;                  /**< Supervisor Mode Execution Prevention */
    bool smap_enabled;                  /**< Supervisor Mode Access Prevention */
    bool cet_enabled;                   /**< Control-flow Enforcement Technology */
    uint32_t security_features;         /**< Security features bitmask */
} cpu_security_info_t;

/**
 * @struct cpu_comprehensive_info_t
 * @brief Comprehensive CPU information
 */
typedef struct {
    cpu_id_info_t id_info;              /**< CPU identification info */
    cpu_topology_info_t topology;       /**< CPU topology info */
    cpu_cache_info_t caches[CPU_MAX_CACHE_LEVELS]; /**< Cache info */
    cpu_frequency_info_t frequency;     /**< Frequency info */
    cpu_thermal_info_t thermal;         /**< Thermal info */
    cpu_power_info_t power;             /**< Power info */
    cpu_microcode_info_t microcode;     /**< Microcode info */
    cpu_security_info_t security;       /**< Security info */
    bool features[CPU_FEATURE_COUNT];   /**< Feature flags */
    uint32_t core_count;                /**< Number of physical cores */
    uint32_t thread_count;              /**< Number of logical threads */
    uint32_t socket_count;              /**< Number of sockets */
    uint32_t numa_node_count;           /**< Number of NUMA nodes */
    char architecture_name[64];         /**< Architecture name string */
    char uarch_name[64];                /**< Microarchitecture name */
    uint64_t timestamp_counter_freq;    /**< Time Stamp Counter frequency */
} cpu_comprehensive_info_t;

/**
 * @struct cpu_config_t
 * @brief CPU module configuration
 */
typedef struct {
    uint32_t sample_interval_ms;        /**< Sampling interval in ms */
    bool enable_performance_counters;   /**< Enable performance counters */
    bool enable_thermal_monitoring;     /**< Enable thermal monitoring */
    bool enable_power_monitoring;       /**< Enable power monitoring */
    bool enable_frequency_control;      /**< Enable frequency control */
    bool enable_microcode_updates;      /**< Enable microcode updates */
    bool enable_security_scan;          /**< Enable security vulnerability scan */
    bool enable_topology_detection;     /**< Enable topology detection */
    bool enable_cache_monitoring;       /**< Enable cache monitoring */
    float critical_temperature;         /**< Critical temperature threshold */
    float critical_power_limit;         /**< Critical power threshold */
    uint32_t max_samples_stored;        /**< Maximum samples to store */
    void* user_context;                 /**< User-defined context */
    void (*alert_callback)(uint32_t cpu_id, const char* message, void* context);
} cpu_config_t;

/**
 * @struct cpu_handle_t
 * @brief Opaque handle for CPU module instance
 */
typedef struct cpu_handle cpu_handle_t;

// ============================================================================
// Initialization and Configuration
// ============================================================================

/**
 * @brief Initialize CPU module
 * 
 * @param config Pointer to configuration structure (NULL for defaults)
 * @param handle Output parameter for CPU handle
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_init(const cpu_config_t* config, cpu_handle_t** handle);

/**
 * @brief Get default configuration for CPU module
 * 
 * @param config Output parameter for default configuration
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_get_default_config(cpu_config_t* config);

/**
 * @brief Detect CPU and gather information
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier (0 for first CPU)
 * @param info Output parameter for CPU info
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_detect(cpu_handle_t* handle, uint32_t cpu_id, 
                       cpu_comprehensive_info_t* info);

/**
 * @brief Start CPU monitoring
 * 
 * @param handle CPU handle
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_start_monitoring(cpu_handle_t* handle);

/**
 * @brief Stop CPU monitoring
 * 
 * @param handle CPU handle
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_stop_monitoring(cpu_handle_t* handle);

/**
 * @brief Clean up CPU module resources
 * 
 * @param handle CPU handle
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_deinit(cpu_handle_t* handle);

// ============================================================================
// CPU Identification and Information
// ============================================================================

/**
 * @brief Get CPU vendor string
 * 
 * @param handle CPU handle
 * @param vendor_string Buffer for vendor string
 * @param buffer_size Size of buffer
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_get_vendor_string(cpu_handle_t* handle, char* vendor_string,
                                  size_t buffer_size);

/**
 * @brief Get CPU brand string
 * 
 * @param handle CPU handle
 * @param brand_string Buffer for brand string
 * @param buffer_size Size of buffer
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_get_brand_string(cpu_handle_t* handle, char* brand_string,
                                 size_t buffer_size);

/**
 * @brief Get CPU architecture
 * 
 * @param handle CPU handle
 * @param architecture Output parameter for architecture
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_get_architecture(cpu_handle_t* handle,
                                 cpu_architecture_t* architecture);

/**
 * @brief Get CPU vendor
 * 
 * @param handle CPU handle
 * @param vendor Output parameter for vendor
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_get_vendor(cpu_handle_t* handle, cpu_vendor_t* vendor);

/**
 * @brief Get CPU feature support
 * 
 * @param handle CPU handle
 * @param feature Feature to check
 * @param supported Output parameter for feature support
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_has_feature(cpu_handle_t* handle, cpu_feature_t feature,
                            bool* supported);

/**
 * @brief Get all CPU features as bitmask
 * 
 * @param handle CPU handle
 * @param features_bitmask Output parameter for features bitmask
 * @param bitmask_size Size of bitmask in bytes
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_get_features_bitmask(cpu_handle_t* handle, uint8_t* features_bitmask,
                                     size_t bitmask_size);

// ============================================================================
// CPU Topology and Core Information
// ============================================================================

/**
 * @brief Get number of physical CPU cores
 * 
 * @param handle CPU handle
 * @param core_count Output parameter for core count
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_get_core_count(cpu_handle_t* handle, uint32_t* core_count);

/**
 * @brief Get number of logical CPU threads
 * 
 * @param handle CPU handle
 * @param thread_count Output parameter for thread count
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_get_thread_count(cpu_handle_t* handle, uint32_t* thread_count);

/**
 * @brief Get number of CPU sockets/packages
 * 
 * @param handle CPU handle
 * @param socket_count Output parameter for socket count
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_get_socket_count(cpu_handle_t* handle, uint32_t* socket_count);

/**
 * @brief Get CPU topology information
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param topology Output parameter for topology info
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_get_topology(cpu_handle_t* handle, uint32_t cpu_id,
                             cpu_topology_info_t* topology);

/**
 * @brief Get NUMA node information
 * 
 * @param handle CPU handle
 * @param node_id NUMA node identifier
 * @param cpu_count Output parameter for CPU count in node
 * @param cpu_list Output parameter for CPU list
 * @param max_cpus Maximum CPUs to list
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_get_numa_node_info(cpu_handle_t* handle, uint32_t node_id,
                                   uint32_t* cpu_count, uint32_t* cpu_list,
                                   uint32_t max_cpus);

// ============================================================================
// CPU Cache Information
// ============================================================================

/**
 * @brief Get CPU cache information
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param cache_level Cache level (1, 2, 3, 4)
 * @param cache_info Output parameter for cache info
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_get_cache_info(cpu_handle_t* handle, uint32_t cpu_id,
                               uint8_t cache_level, cpu_cache_info_t* cache_info);

/**
 * @brief Get all CPU cache levels information
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param cache_info Array for cache info
 * @param max_levels Maximum cache levels to retrieve
 * @param actual_levels Output parameter for actual levels
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_get_all_cache_info(cpu_handle_t* handle, uint32_t cpu_id,
                                   cpu_cache_info_t* cache_info,
                                   uint32_t max_levels, uint32_t* actual_levels);

/**
 * @brief Flush CPU cache
 * 
 * @param handle CPU handle
 * @param cache_level Cache level to flush (0 for all)
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_flush_cache(cpu_handle_t* handle, uint8_t cache_level);

// ============================================================================
// CPU Frequency and Voltage Control
// ============================================================================

/**
 * @brief Get CPU frequency information
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param frequency Output parameter for frequency info
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_get_frequency_info(cpu_handle_t* handle, uint32_t cpu_id,
                                   cpu_frequency_info_t* frequency);

/**
 * @brief Set CPU frequency
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param frequency_hz Target frequency in Hz
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_set_frequency(cpu_handle_t* handle, uint32_t cpu_id,
                              uint64_t frequency_hz);

/**
 * @brief Set CPU frequency multiplier
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param multiplier Frequency multiplier
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_set_frequency_multiplier(cpu_handle_t* handle, uint32_t cpu_id,
                                         float multiplier);

/**
 * @brief Enable/disable turbo boost
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param enable Enable or disable turbo boost
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_set_turbo_boost(cpu_handle_t* handle, uint32_t cpu_id,
                                bool enable);

/**
 * @brief Set CPU voltage
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param voltage_v Target voltage in volts
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_set_voltage(cpu_handle_t* handle, uint32_t cpu_id,
                            float voltage_v);

// ============================================================================
// CPU Power Management
// ============================================================================

/**
 * @brief Get CPU power information
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param power Output parameter for power info
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_get_power_info(cpu_handle_t* handle, uint32_t cpu_id,
                               cpu_power_info_t* power);

/**
 * @brief Set CPU power limit
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param power_limit_watts Power limit in watts
 * @param limit_type Power limit type (0=PL1, 1=PL2, 2=PL4)
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_set_power_limit(cpu_handle_t* handle, uint32_t cpu_id,
                                float power_limit_watts, uint8_t limit_type);

/**
 * @brief Set CPU power plan
 * 
 * @param handle CPU handle
 * @param plan_type Power plan type (0=Performance, 1=Balanced, 2=Power Saving)
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_set_power_plan(cpu_handle_t* handle, uint8_t plan_type);

// ============================================================================
// CPU Thermal Management
// ============================================================================

/**
 * @brief Get CPU thermal information
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param thermal Output parameter for thermal info
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_get_thermal_info(cpu_handle_t* handle, uint32_t cpu_id,
                                 cpu_thermal_info_t* thermal);

/**
 * @brief Set CPU temperature limit
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param temperature_c Temperature limit in Celsius
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_set_temperature_limit(cpu_handle_t* handle, uint32_t cpu_id,
                                      float temperature_c);

/**
 * @brief Enable/disable thermal throttling
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param enable Enable or disable throttling
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_set_thermal_throttling(cpu_handle_t* handle, uint32_t cpu_id,
                                       bool enable);

// ============================================================================
// CPU Performance Monitoring
// ============================================================================

/**
 * @brief Start performance counter collection
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param counter_mask Bitmask of counters to collect
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_start_performance_counters(cpu_handle_t* handle, uint32_t cpu_id,
                                           uint64_t counter_mask);

/**
 * @brief Stop performance counter collection
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_stop_performance_counters(cpu_handle_t* handle, uint32_t cpu_id);

/**
 * @brief Read performance counters
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param counters Output parameter for performance counters
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_read_performance_counters(cpu_handle_t* handle, uint32_t cpu_id,
                                          cpu_performance_counters_t* counters);

/**
 * @brief Reset performance counters
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_reset_performance_counters(cpu_handle_t* handle, uint32_t cpu_id);

// ============================================================================
// CPU Microcode Management
// ============================================================================

/**
 * @brief Get CPU microcode information
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param microcode Output parameter for microcode info
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_get_microcode_info(cpu_handle_t* handle, uint32_t cpu_id,
                                   cpu_microcode_info_t* microcode);

/**
 * @brief Update CPU microcode
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param microcode_data Microcode data buffer
 * @param data_size Size of microcode data
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_update_microcode(cpu_handle_t* handle, uint32_t cpu_id,
                                 const uint8_t* microcode_data, size_t data_size);

/**
 * @brief Check for microcode updates
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param update_available Output parameter for update availability
 * @param update_revision Output parameter for update revision
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_check_microcode_update(cpu_handle_t* handle, uint32_t cpu_id,
                                       bool* update_available,
                                       uint32_t* update_revision);

// ============================================================================
// CPU Security Management
// ============================================================================

/**
 * @brief Get CPU security information
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param security Output parameter for security info
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_get_security_info(cpu_handle_t* handle, uint32_t cpu_id,
                                  cpu_security_info_t* security);

/**
 * @brief Enable CPU security feature
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param feature Security feature to enable
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_enable_security_feature(cpu_handle_t* handle, uint32_t cpu_id,
                                        uint32_t feature);

/**
 * @brief Disable CPU security feature
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param feature Security feature to disable
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_disable_security_feature(cpu_handle_t* handle, uint32_t cpu_id,
                                         uint32_t feature);

/**
 * @brief Scan CPU for security vulnerabilities
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param vulnerabilities Output parameter for vulnerabilities found
 * @param max_vulns Maximum vulnerabilities to report
 * @param actual_vulns Output parameter for actual vulnerabilities
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_scan_vulnerabilities(cpu_handle_t* handle, uint32_t cpu_id,
                                     char** vulnerabilities, uint32_t max_vulns,
                                     uint32_t* actual_vulns);

// ============================================================================
// CPU Register Operations
// ============================================================================

/**
 * @brief Read CPU registers
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param registers Output parameter for register values
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_read_registers(cpu_handle_t* handle, uint32_t cpu_id,
                               cpu_register_set_t* registers);

/**
 * @brief Write CPU registers
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param registers Register values to write
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_write_registers(cpu_handle_t* handle, uint32_t cpu_id,
                                const cpu_register_set_t* registers);

/**
 * @brief Execute CPUID instruction
 * 
 * @param handle CPU handle
 * @param leaf CPUID leaf (EAX input)
 * @param subleaf CPUID subleaf (ECX input)
 * @param result Output parameter for CPUID result
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_execute_cpuid(cpu_handle_t* handle, uint32_t leaf,
                              uint32_t subleaf, cpu_id_info_t* result);

// ============================================================================
// CPU Advanced Operations
// ============================================================================

/**
 * @brief Put CPU into sleep state
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param c_state C-state to enter (0-10)
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_enter_sleep_state(cpu_handle_t* handle, uint32_t cpu_id,
                                  uint8_t c_state);

/**
 * @brief Wake CPU from sleep state
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_wake_from_sleep(cpu_handle_t* handle, uint32_t cpu_id);

/**
 * @brief Enable/disable CPU core
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param enable Enable or disable core
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_enable_core(cpu_handle_t* handle, uint32_t cpu_id, bool enable);

/**
 * @brief Reset CPU core
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_reset_core(cpu_handle_t* handle, uint32_t cpu_id);

// ============================================================================
// CPU Benchmarking and Testing
// ============================================================================

/**
 * @brief Run CPU benchmark
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param benchmark_type Type of benchmark to run
 * @param score Output parameter for benchmark score
 * @param duration_ms Output parameter for benchmark duration
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_run_benchmark(cpu_handle_t* handle, uint32_t cpu_id,
                              uint32_t benchmark_type, float* score,
                              uint32_t* duration_ms);

/**
 * @brief Run CPU stress test
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param duration_ms Test duration in milliseconds
 * @param stability_score Output parameter for stability score
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_run_stress_test(cpu_handle_t* handle, uint32_t cpu_id,
                                uint32_t duration_ms, float* stability_score);

/**
 * @brief Run CPU diagnostic tests
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param test_mask Bitmask of tests to run
 * @param results Output parameter for test results
 * @param results_size Size of results buffer
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_run_diagnostics(cpu_handle_t* handle, uint32_t cpu_id,
                                uint64_t test_mask, char* results,
                                size_t results_size);

// ============================================================================
// Inline Utility Functions
// ============================================================================

/**
 * @brief Check if CPU module is initialized
 * 
 * @param handle CPU handle to check
 * @return true if initialized, false otherwise
 */
static inline bool cpu_is_initialized(const cpu_handle_t* handle) {
    return (handle != NULL);
}

/**
 * @brief Convert frequency from Hz to GHz
 * 
 * @param hz Frequency in Hz
 * @return Frequency in GHz
 */
static inline double cpu_hz_to_ghz(uint64_t hz) {
    return (double)hz / 1000000000.0;
}

/**
 * @brief Convert GHz to Hz
 * 
 * @param ghz Frequency in GHz
 * @return Frequency in Hz
 */
static inline uint64_t cpu_ghz_to_hz(double ghz) {
    return (uint64_t)(ghz * 1000000000.0);
}

/**
 * @brief Calculate CPU efficiency (performance per watt)
 * 
 * @param performance_score Performance score (0-100)
 * @param power_watts Power consumption in watts
 * @return Efficiency score
 */
static inline float cpu_calculate_efficiency(float performance_score, float power_watts) {
    if (power_watts < 0.1f) return 0.0f;
    return performance_score / power_watts;
}

/**
 * @brief Calculate IPC (Instructions Per Cycle)
 * 
 * @param instructions Number of instructions retired
 * @param cycles Number of CPU cycles
 * @return IPC value
 */
static inline float cpu_calculate_ipc(uint64_t instructions, uint64_t cycles) {
    if (cycles == 0) return 0.0f;
    return (float)instructions / (float)cycles;
}

/**
 * @brief Convert temperature from Celsius to Fahrenheit
 * 
 * @param celsius Temperature in Celsius
 * @return Temperature in Fahrenheit
 */
static inline float cpu_celsius_to_fahrenheit(float celsius) {
    return (celsius * 9.0f / 5.0f) + 32.0f;
}

/**
 * @brief Convert temperature from Celsius to Kelvin
 * 
 * @param celsius Temperature in Celsius
 * @return Temperature in Kelvin
 */
static inline float cpu_celsius_to_kelvin(float celsius) {
    return celsius + 273.15f;
}

/**
 * @brief Get API version string
 * 
 * @return const char* Version string
 */
static inline const char* cpu_get_api_version_string(void) {
    return "4.0.0";
}

// ============================================================================
// Platform-Specific Extensions
// ============================================================================

#if defined(CPU_PLATFORM_WINDOWS)
/**
 * @brief Get Windows-specific CPU information
 * 
 * @param handle CPU handle
 * @param win_info Output parameter for Windows info
 * @param info_size Size of info buffer
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_get_windows_info(cpu_handle_t* handle, char* win_info,
                                 size_t info_size);
#endif

#if defined(CPU_PLATFORM_LINUX)
/**
 * @brief Get Linux-specific CPU information from sysfs
 * 
 * @param handle CPU handle
 * @param cpu_id CPU identifier
 * @param sysfs_info Output parameter for sysfs info
 * @param info_size Size of info buffer
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_get_linux_sysfs_info(cpu_handle_t* handle, uint32_t cpu_id,
                                     char* sysfs_info, size_t info_size);
#endif

#if defined(CPU_PLATFORM_MACOS)
/**
 * @brief Get macOS-specific CPU information
 * 
 * @param handle CPU handle
 * @param mac_info Output parameter for macOS info
 * @param info_size Size of info buffer
 * @return cpu_status_t Status code
 */
cpu_status_t cpu_get_macos_info(cpu_handle_t* handle, char* mac_info,
                               size_t info_size);
#endif

// ============================================================================
// Export Macros for Shared Libraries
// ============================================================================
#ifdef BUILDING_CPU_DLL
    #define CPU_API __declspec(dllexport)
#elif defined(USING_CPU_DLL)
    #define CPU_API __declspec(dllimport)
#else
    #define CPU_API
#endif

#ifdef __cplusplus
}
#endif

#endif // CPU_H

// ============================================================================
// Implementation Notes:
// ============================================================================
// 1. Architecture Support: x86, x86-64, ARM, ARM64, RISC-V, PowerPC, MIPS
// 2. Platform Support: Windows, Linux, macOS, FreeBSD
// 3. Thread Safety: Designed for concurrent access from multiple threads
// 4. Performance: Optimized for minimal overhead in monitoring operations
// 5. Security: Includes vulnerability scanning and mitigation controls
// 6. Power Management: Comprehensive power and thermal control
// 7. Extensibility: Modular design for adding new architectures and features
// 8. Reliability: Error handling and recovery mechanisms
// 9. Documentation: Comprehensive Doxygen comments
// 10. Compatibility: Backward compatibility with existing applications