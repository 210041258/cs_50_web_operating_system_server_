/**
 * @file export.h
 * @brief Data Export and Integration Module
 * 
 * This module provides comprehensive data export, reporting, and integration
 * capabilities for system monitoring data to various formats, protocols,
 * and destinations including files, databases, cloud services, and APIs.
 * 
 * @author Data Integration Team
 * @date 2024-01-31
 * @version 4.1.0
 * 
 * @license Apache 2.0
 * @copyright Copyright (c) 2024 Integration Solutions
 */

#ifndef EXPORT_H
#define EXPORT_H

#ifdef __cplusplus
extern "C" {
#endif

// ============================================================================
// Includes and Dependencies
// ============================================================================
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <time.h>
#include <stdio.h>

// Network and protocol headers
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

// JSON support
#if defined(USE_JANSSON)
    #include <jansson.h>
#elif defined(USE_CJSON)
    #include <cjson/cJSON.h>
#endif

// Database support
#if defined(USE_SQLITE)
    #include <sqlite3.h>
#endif

// ============================================================================
// Configuration Constants
// ============================================================================
/**
 * @def EXPORT_VERSION_MAJOR
 * @brief Major version number
 */
#define EXPORT_VERSION_MAJOR 4

/**
 * @def EXPORT_VERSION_MINOR
 * @brief Minor version number
 */
#define EXPORT_VERSION_MINOR 1

/**
 * @def EXPORT_VERSION_PATCH
 * @brief Patch version number
 */
#define EXPORT_VERSION_PATCH 0

/**
 * @def EXPORT_MAX_FORMATS
 * @brief Maximum number of export formats supported
 */
#define EXPORT_MAX_FORMATS 32

/**
 * @def EXPORT_MAX_DESTINATIONS
 * @brief Maximum number of export destinations
 */
#define EXPORT_MAX_DESTINATIONS 256

/**
 * @def EXPORT_MAX_TRANSFORMATIONS
 * @brief Maximum number of data transformations
 */
#define EXPORT_MAX_TRANSFORMATIONS 100

/**
 * @def EXPORT_MAX_FIELDS
 * @brief Maximum fields per export
 */
#define EXPORT_MAX_FIELDS 1024

/**
 * @def EXPORT_MAX_RECORDS_PER_BATCH
 * @brief Maximum records per batch export
 */
#define EXPORT_MAX_RECORDS_PER_BATCH 10000

/**
 * @def EXPORT_MAX_QUERY_LENGTH
 * @brief Maximum query length for database exports
 */
#define EXPORT_MAX_QUERY_LENGTH 65536

/**
 * @def EXPORT_MAX_HEADERS
 * @brief Maximum HTTP headers
 */
#define EXPORT_MAX_HEADERS 50

/**
 * @def EXPORT_MAX_CONNECTIONS
 * @brief Maximum concurrent connections
 */
#define EXPORT_MAX_CONNECTIONS 100

/**
 * @def EXPORT_DEFAULT_BUFFER_SIZE
 * @brief Default buffer size for data processing
 */
#define EXPORT_DEFAULT_BUFFER_SIZE 1048576  // 1 MB

/**
 * @def EXPORT_DEFAULT_TIMEOUT_MS
 * @brief Default timeout in milliseconds
 */
#define EXPORT_DEFAULT_TIMEOUT_MS 30000

// ============================================================================
// Type Definitions
// ============================================================================

/**
 * @enum export_status_t
 * @brief Status codes for export operations
 */
typedef enum {
    EXPORT_SUCCESS = 0,                  /**< Export successful */
    EXPORT_ERROR_INIT_FAILED,            /**< Initialization failed */
    EXPORT_ERROR_INVALID_PARAMETER,      /**< Invalid parameter */
    EXPORT_ERROR_NOT_INITIALIZED,        /**< Export module not initialized */
    EXPORT_ERROR_FORMAT_NOT_SUPPORTED,   /**< Format not supported */
    EXPORT_ERROR_DESTINATION_FAILED,     /**< Destination connection failed */
    EXPORT_ERROR_FILE_IO,                /**< File I/O error */
    EXPORT_ERROR_NETWORK,                /**< Network error */
    EXPORT_ERROR_DATABASE,               /**< Database error */
    EXPORT_ERROR_AUTHENTICATION,         /**< Authentication failed */
    EXPORT_ERROR_AUTHORIZATION,          /**< Authorization failed */
    EXPORT_ERROR_RATE_LIMITED,           /**< Rate limited */
    EXPORT_ERROR_QUOTA_EXCEEDED,         /**< Quota exceeded */
    EXPORT_ERROR_TRANSFORMATION_FAILED,  /**< Data transformation failed */
    EXPORT_ERROR_VALIDATION_FAILED,      /**< Data validation failed */
    EXPORT_ERROR_SERIALIZATION_FAILED,   /**< Serialization failed */
    EXPORT_ERROR_COMPRESSION_FAILED,     /**< Compression failed */
    EXPORT_ERROR_ENCRYPTION_FAILED,      /**< Encryption failed */
    EXPORT_ERROR_TIMEOUT,                /**< Operation timeout */
    EXPORT_ERROR_PARTIAL_SUCCESS,        /**< Partial success (some records failed) */
    EXPORT_ERROR_BUFFER_OVERFLOW,        /**< Buffer overflow */
    EXPORT_ERROR_MEMORY_ALLOCATION       /**< Memory allocation failed */
} export_status_t;

/**
 * @enum export_format_t
 * @brief Export data formats
 */
typedef enum {
    FORMAT_CSV,                          /**< Comma-Separated Values */
    FORMAT_JSON,                         /**< JavaScript Object Notation */
    FORMAT_XML,                          /**< Extensible Markup Language */
    FORMAT_YAML,                         /**< YAML Ain't Markup Language */
    FORMAT_PROTOBUF,                     /**< Protocol Buffers */
    FORMAT_AVRO,                         /**< Apache Avro */
    FORMAT_PARQUET,                      /**< Apache Parquet */
    FORMAT_ORC,                          /**< Apache ORC */
    FORMAT_EXCEL,                        /**< Microsoft Excel */
    FORMAT_PDF,                          /**< Portable Document Format */
    FORMAT_HTML,                         /**< HyperText Markup Language */
    FORMAT_MARKDOWN,                     /**< Markdown */
    FORMAT_PLAIN_TEXT,                   /**< Plain text */
    FORMAT_BINARY,                       /**< Binary format */
    FORMAT_SQL,                          /**< SQL statements */
    FORMAT_GRAPHQL,                      /**< GraphQL queries */
    FORMAT_PROMETHEUS,                   /**< Prometheus metrics format */
    FORMAT_INFLUXDB,                     /**< InfluxDB line protocol */
    FORMAT_OPENTSDB,                     /**< OpenTSDB format */
    FORMAT_LOGFMT,                       /**< Logfmt format */
    FORMAT_SYSLOG,                       /**< Syslog format */
    FORMAT_CUSTOM                        /**< Custom/plugin format */
} export_format_t;

/**
 * @enum export_destination_t
 * @brief Export destinations
 */
typedef enum {
    DESTINATION_FILE,                    /**< Local file */
    DESTINATION_HTTP,                    /**< HTTP/HTTPS endpoint */
    DESTINATION_FTP,                     /**< FTP server */
    DESTINATION_SFTP,                    /**< SFTP server */
    DESTINATION_S3,                      /**< Amazon S3 */
    DESTINATION_GCS,                     /**< Google Cloud Storage */
    DESTINATION_AZURE_BLOB,              /**< Azure Blob Storage */
    DESTINATION_KAFKA,                   /**< Apache Kafka */
    DESTINATION_RABBITMQ,                /**< RabbitMQ */
    DESTINATION_REDIS,                   /**< Redis */
    DESTINATION_MYSQL,                   /**< MySQL database */
    DESTINATION_POSTGRESQL,              /**< PostgreSQL database */
    DESTINATION_SQLITE,                  /**< SQLite database */
    DESTINATION_MONGODB,                 /**< MongoDB */
    DESTINATION_ELASTICSEARCH,           /**< Elasticsearch */
    DESTINATION_SPLUNK,                  /**< Splunk */
    DESTINATION_DATADOG,                 /**< Datadog */
    DESTINATION_NEW_RELIC,               /**< New Relic */
    DESTINATION_PROMETHEUS,              /**< Prometheus */
    DESTINATION_GRAFANA,                 /**< Grafana */
    DESTINATION_CLOUDWATCH,              /**< AWS CloudWatch */
    DESTINATION_STACKDRIVER,             /**< Google Stackdriver */
    DESTINATION_EMAIL,                   /**< Email */
    DESTINATION_WEBHOOK,                 /**< Webhook */
    DESTINATION_GRPC,                    /**< gRPC endpoint */
    DESTINATION_STDOUT,                  /**< Standard output */
    DESTINATION_SYSLOG,                  /**< Syslog server */
    DESTINATION_CUSTOM                   /**< Custom/plugin destination */
} export_destination_t;

/**
 * @enum export_compression_t
 * @brief Compression algorithms
 */
typedef enum {
    COMPRESSION_NONE,                    /**< No compression */
    COMPRESSION_GZIP,                    /**< Gzip compression */
    COMPRESSION_ZLIB,                    /**< Zlib compression */
    COMPRESSION_BZIP2,                   /**< Bzip2 compression */
    COMPRESSION_LZ4,                     /**< LZ4 compression */
    COMPRESSION_SNAPPY,                  /**< Snappy compression */
    COMPRESSION_ZSTD,                    /**< Zstandard compression */
    COMPRESSION_LZMA                     /**< LZMA compression */
} export_compression_t;

/**
 * @enum export_encryption_t
 * @brief Encryption algorithms
 */
typedef enum {
    ENCRYPTION_NONE,                     /**< No encryption */
    ENCRYPTION_AES_128,                  /**< AES-128 */
    ENCRYPTION_AES_256,                  /**< AES-256 */
    ENCRYPTION_RSA,                      /**< RSA encryption */
    ENCRYPTION_CHACHA20,                 /**< ChaCha20 */
    ENCRYPTION_PGP                       /**< PGP encryption */
} export_encryption_t;

/**
 * @enum export_schedule_t
 * @brief Export scheduling options
 */
typedef enum {
    SCHEDULE_MANUAL,                     /**< Manual export */
    SCHEDULE_REALTIME,                   /**< Real-time streaming */
    SCHEDULE_INTERVAL,                   /**< Regular intervals */
    SCHEDULE_CRON,                       /**< Cron expression */
    SCHEDULE_EVENT_TRIGGERED,            /**< Event-triggered */
    SCHEDULE_DAILY,                      /**< Daily export */
    SCHEDULE_WEEKLY,                     /**< Weekly export */
    SCHEDULE_MONTHLY,                    /**< Monthly export */
    SCHEDULE_YEARLY                      /**< Yearly export */
} export_schedule_t;

/**
 * @enum export_data_type_t
 * @brief Data types for export fields
 */
typedef enum {
    DATA_TYPE_INT8,                      /**< 8-bit integer */
    DATA_TYPE_UINT8,                     /**< 8-bit unsigned integer */
    DATA_TYPE_INT16,                     /**< 16-bit integer */
    DATA_TYPE_UINT16,                    /**< 16-bit unsigned integer */
    DATA_TYPE_INT32,                     /**< 32-bit integer */
    DATA_TYPE_UINT32,                    /**< 32-bit unsigned integer */
    DATA_TYPE_INT64,                     /**< 64-bit integer */
    DATA_TYPE_UINT64,                    /**< 64-bit unsigned integer */
    DATA_TYPE_FLOAT,                     /**< Single-precision float */
    DATA_TYPE_DOUBLE,                    /**< Double-precision float */
    DATA_TYPE_BOOLEAN,                   /**< Boolean */
    DATA_TYPE_STRING,                    /**< String */
    DATA_TYPE_TIMESTAMP,                 /**< Timestamp */
    DATA_TYPE_DATETIME,                  /**< Date and time */
    DATA_TYPE_BINARY,                    /**< Binary data */
    DATA_TYPE_JSON,                      /**< JSON data */
    DATA_TYPE_ARRAY,                     /**< Array */
    DATA_TYPE_MAP                        /**< Map/dictionary */
} export_data_type_t;

/**
 * @enum export_protocol_t
 * @brief Network protocols
 */
typedef enum {
    PROTOCOL_HTTP,                       /**< HTTP */
    PROTOCOL_HTTPS,                      /**< HTTPS */
    PROTOCOL_FTP,                        /**< FTP */
    PROTOCOL_SFTP,                       /**< SFTP */
    PROTOCOL_WS,                         /**< WebSocket */
    PROTOCOL_WSS,                        /**< Secure WebSocket */
    PROTOCOL_TCP,                        /**< TCP */
    PROTOCOL_UDP,                        /**< UDP */
    PROTOCOL_MQTT,                       /**< MQTT */
    PROTOCOL_AMQP,                       /**< AMQP */
    PROTOCOL_GRPC,                       /**< gRPC */
    PROTOCOL_KAFKA,                      /**< Kafka protocol */
    PROTOCOL_CUSTOM                      /**< Custom protocol */
} export_protocol_t;

/**
 * @struct export_field_t
 * @brief Export field definition
 */
typedef struct {
    char name[256];                      /**< Field name */
    export_data_type_t type;             /**< Field data type */
    char format[128];                    /**< Format string (for dates, numbers) */
    bool required;                       /**< Is field required? */
    char default_value[512];             /**< Default value if missing */
    char description[512];               /**< Field description */
    char validation_rule[256];           /**< Validation rule */
    bool is_key;                         /**< Is primary key? */
    bool is_index;                       /**< Is index field? */
    bool is_unique;                      /**< Is unique constraint? */
    char transform_function[256];        /**< Transformation function */
} export_field_t;

/**
 * @struct export_schema_t
 * @brief Export data schema
 */
typedef struct {
    char name[256];                      /**< Schema name */
    char version[32];                    /**< Schema version */
    export_field_t fields[EXPORT_MAX_FIELDS]; /**< Field definitions */
    uint32_t field_count;                /**< Number of fields */
    time_t created_time;                 /**< Creation timestamp */
    time_t modified_time;                /**< Last modification */
    char creator[64];                    /**< Schema creator */
    bool strict_validation;              /**< Strict validation */
    char validation_rules[1024];         /**< Global validation rules */
    char metadata[4096];                 /**< Schema metadata (JSON) */
} export_schema_t;

/**
 * @struct export_data_record_t
 * @brief Data record for export
 */
typedef struct {
    char record_id[64];                  /**< Record identifier */
    time_t timestamp;                    /**< Record timestamp */
    void** field_values;                 /**< Array of field values */
    uint32_t field_count;                /**< Number of fields */
    bool is_valid;                       /**< Is record valid? */
    char validation_errors[1024];        /**< Validation errors */
    char metadata[2048];                 /**< Record metadata (JSON) */
    void* raw_data;                      /**< Raw data pointer */
    size_t raw_data_size;                /**< Raw data size */
} export_data_record_t;

/**
 * @struct export_batch_t
 * @brief Data batch for export
 */
typedef struct {
    char batch_id[64];                   /**< Batch identifier */
    time_t start_time;                   /**< Batch start time */
    time_t end_time;                     /**< Batch end time */
    export_data_record_t* records;       /**< Array of records */
    uint32_t record_count;               /**< Number of records */
    uint32_t valid_records;              /**< Number of valid records */
    uint32_t failed_records;             /**< Number of failed records */
    double processing_time;              /**< Processing time in seconds */
    char source[256];                    /**< Data source */
    char metadata[4096];                 /**< Batch metadata (JSON) */
} export_batch_t;

/**
 * @struct export_config_t
 * @brief Export configuration
 */
typedef struct {
    // Basic configuration
    export_format_t format;              /**< Export format */
    export_destination_t destination;    /**< Export destination */
    export_schedule_t schedule;          /**< Export schedule */
    
    // File configuration
    char file_path[1024];                /**< File path (for file destination) */
    char file_pattern[256];              /**< File naming pattern */
    bool append_mode;                    /**< Append to existing file */
    bool create_backup;                  /**< Create backup before overwriting */
    
    // Network configuration
    char host[256];                      /**< Host address */
    uint16_t port;                       /**< Port number */
    export_protocol_t protocol;          /**< Network protocol */
    char endpoint[512];                  /**< API endpoint */
    char api_key[256];                   /**< API key */
    char auth_token[1024];               /**< Authentication token */
    
    // Database configuration
    char database[256];                  /**< Database name */
    char table[256];                     /**< Table name */
    char username[64];                   /**< Username */
    char password[256];                  /**< Password */
    char connection_string[1024];        /**< Connection string */
    
    // Data configuration
    export_schema_t* schema;             /**< Data schema */
    bool validate_data;                  /**< Validate data before export */
    bool transform_data;                 /**< Transform data before export */
    bool filter_data;                    /**< Filter data before export */
    char filter_expression[1024];        /**< Filter expression */
    
    // Performance configuration
    uint32_t batch_size;                 /**< Batch size */
    uint32_t max_records;                /**< Maximum records to export */
    uint32_t timeout_ms;                 /**< Timeout in milliseconds */
    uint32_t retry_count;                /**< Number of retries */
    uint32_t retry_delay_ms;             /**< Retry delay in milliseconds */
    
    // Compression and encryption
    export_compression_t compression;    /**< Compression algorithm */
    export_encryption_t encryption;      /**< Encryption algorithm */
    char encryption_key[256];            /**< Encryption key */
    char encryption_iv[128];             /**< Initialization vector */
    
    // Advanced configuration
    bool asynchronous;                   /**< Asynchronous export */
    bool enable_buffering;               /**< Enable output buffering */
    uint32_t buffer_size;                /**< Buffer size in bytes */
    bool enable_logging;                 /**< Enable export logging */
    char log_file[1024];                 /**< Log file path */
    
    // Callbacks
    void* user_context;                  /**< User-defined context */
    void (*progress_callback)(double progress, const char* status, void* context);
    void (*completion_callback)(export_status_t status, uint32_t records_exported, void* context);
    void (*error_callback)(const char* error_message, void* context);
} export_config_t;

/**
 * @struct export_statistics_t
 * @brief Export statistics
 */
typedef struct {
    // Counters
    uint64_t total_exports;              /**< Total export operations */
    uint64_t successful_exports;         /**< Successful exports */
    uint64_t failed_exports;             /**< Failed exports */
    uint64_t total_records;              /**< Total records exported */
    uint64_t successful_records;         /**< Successfully exported records */
    uint64_t failed_records;             /**< Failed records */
    
    // Performance metrics
    double average_export_time;          /**< Average export time in seconds */
    double min_export_time;              /**< Minimum export time */
    double max_export_time;              /**< Maximum export time */
    double average_throughput;           /**< Average throughput (records/sec) */
    double data_volume_exported;         /**< Total data volume exported (bytes) */
    
    // Quality metrics
    double success_rate;                 /**< Success rate (0-1) */
    double data_quality_score;           /**< Data quality score (0-100) */
    uint64_t validation_errors;          /**< Validation errors */
    uint64_t transformation_errors;      /**< Transformation errors */
    
    // Time-based statistics
    time_t first_export_time;            /**< First export timestamp */
    time_t last_export_time;             /**< Last export timestamp */
    time_t last_success_time;            /**< Last successful export */
    time_t last_failure_time;            /**< Last failed export */
    
    // Resource usage
    double cpu_usage;                    /**< CPU usage percentage */
    double memory_usage;                 /**< Memory usage in MB */
    double network_bandwidth;            /**< Network bandwidth usage (Mbps) */
    double disk_usage;                   /**< Disk usage in MB */
} export_statistics_t;

/**
 * @struct export_job_t
 * @brief Export job definition
 */
typedef struct {
    char job_id[64];                     /**< Job identifier */
    char name[256];                      /**< Job name */
    char description[512];               /**< Job description */
    export_config_t config;              /**< Export configuration */
    export_schedule_t schedule;          /**< Job schedule */
    char schedule_expression[256];       /**< Schedule expression (cron, etc.) */
    time_t start_time;                   /**< Job start time */
    time_t end_time;                     /**< Job end time (optional) */
    bool enabled;                        /**< Is job enabled? */
    bool running;                        /**< Is job currently running? */
    time_t last_run_time;                /**< Last run timestamp */
    export_status_t last_run_status;     /**< Last run status */
    uint32_t run_count;                  /**< Number of times job has run */
    uint32_t success_count;              /**< Number of successful runs */
    uint32_t failure_count;              /**< Number of failed runs */
    char last_error[1024];               /**< Last error message */
    char metadata[4096];                 /**< Job metadata (JSON) */
} export_job_t;

/**
 * @struct export_connection_t
 * @brief Connection information
 */
typedef struct {
    char connection_id[64];              /**< Connection identifier */
    export_destination_t destination;    /**< Destination type */
    char name[256];                      /**< Connection name */
    char host[256];                      /**< Host address */
    uint16_t port;                       /**< Port number */
    char username[64];                   /**< Username */
    char password[256];                  /**< Password (encrypted) */
    char database[256];                  /**< Database name */
    char connection_string[1024];        /**< Connection string */
    bool encrypted;                      /**< Is connection encrypted? */
    bool authenticated;                  /**< Is authenticated? */
    time_t created_time;                 /**< Creation timestamp */
    time_t last_used_time;               /**< Last used timestamp */
    uint32_t use_count;                  /**< Usage count */
    char metadata[4096];                 /**< Connection metadata (JSON) */
} export_connection_t;

/**
 * @struct export_transform_t
 * @brief Data transformation definition
 */
typedef struct {
    char transform_id[64];               /**< Transformation identifier */
    char name[256];                      /**< Transformation name */
    char description[512];               /**< Description */
    char input_schema[1024];             /**< Input schema definition */
    char output_schema[1024];            /**< Output schema definition */
    char transform_function[2048];       /**< Transformation function/script */
    char language[32];                   /**< Language (SQL, JavaScript, etc.) */
    bool enabled;                        /**< Is transformation enabled? */
    time_t created_time;                 /**< Creation timestamp */
    time_t modified_time;                /**< Last modification */
    char author[64];                     /**< Author */
    char version[32];                    /**< Version */
} export_transform_t;

/**
 * @struct export_http_header_t
 * @brief HTTP header for export
 */
typedef struct {
    char name[256];                      /**< Header name */
    char value[1024];                    /**< Header value */
} export_http_header_t;

/**
 * @struct export_api_endpoint_t
 * @brief API endpoint configuration
 */
typedef struct {
    char url[1024];                      /**< API endpoint URL */
    export_protocol_t protocol;          /**< Protocol */
    char method[16];                     /**< HTTP method (GET, POST, PUT, etc.) */
    char content_type[64];               /**< Content-Type header */
    export_http_header_t headers[EXPORT_MAX_HEADERS]; /**< HTTP headers */
    uint32_t header_count;               /**< Number of headers */
    char request_body_template[4096];    /**< Request body template */
    char authentication_type[32];        /**< Authentication type */
    char auth_token[1024];               /**< Authentication token */
    uint32_t timeout_ms;                 /**< Request timeout */
    uint32_t retry_count;                /**< Number of retries */
} export_api_endpoint_t;

/**
 * @struct export_monitor_metrics_t
 * @brief Monitor metrics export
 */
typedef struct {
    // System metrics
    double cpu_usage;                    /**< CPU usage percentage */
    double memory_usage;                 /**< Memory usage percentage */
    double disk_usage;                   /**< Disk usage percentage */
    double network_rx;                   /**< Network receive rate (Mbps) */
    double network_tx;                   /**< Network transmit rate (Mbps) */
    
    // Export-specific metrics
    uint32_t active_exports;             /**< Active export operations */
    uint32_t queued_exports;             /**< Queued export operations */
    double export_queue_size;            /**< Export queue size (MB) */
    double export_latency;               /**< Export latency in milliseconds */
    double export_throughput;            /**< Export throughput (records/sec) */
    
    // Error metrics
    uint32_t export_errors_last_hour;    /**< Export errors in last hour */
    uint32_t connection_errors;          /**< Connection errors */
    uint32_t validation_errors;          /**< Validation errors */
    uint32_t transformation_errors;      /**< Transformation errors */
    
    // Resource metrics
    double cpu_utilization;              /**< CPU utilization percentage */
    double memory_utilization;           /**< Memory utilization percentage */
    double disk_utilization;             /**< Disk utilization percentage */
    double network_utilization;          /**< Network utilization percentage */
    
    // Timestamp
    time_t timestamp;                    /**< Metrics timestamp */
} export_monitor_metrics_t;

/**
 * @struct export_handle_t
 * @brief Opaque handle for export module
 */
typedef struct export_handle export_handle_t;

// ============================================================================
// Initialization and Configuration
// ============================================================================

/**
 * @brief Initialize export module
 * 
 * @param config Pointer to configuration structure (NULL for defaults)
 * @param handle Output parameter for export handle
 * @return export_status_t Status code
 */
export_status_t export_init(const export_config_t* config,
                           export_handle_t** handle);

/**
 * @brief Get default configuration
 * 
 * @param config Output parameter for default configuration
 * @return export_status_t Status code
 */
export_status_t export_get_default_config(export_config_t* config);

/**
 * @brief Load export plugin
 * 
 * @param handle Export handle
 * @param plugin_path Plugin file path
 * @param plugin_type Plugin type (format, destination, transform)
 * @return export_status_t Status code
 */
export_status_t export_load_plugin(export_handle_t* handle,
                                  const char* plugin_path,
                                  const char* plugin_type);

/**
 * @brief Start export service
 * 
 * @param handle Export handle
 * @return export_status_t Status code
 */
export_status_t export_start_service(export_handle_t* handle);

/**
 * @brief Stop export service
 * 
 * @param handle Export handle
 * @return export_status_t Status code
 */
export_status_t export_stop_service(export_handle_t* handle);

/**
 * @brief Clean up export module
 * 
 * @param handle Export handle
 * @return export_status_t Status code
 */
export_status_t export_deinit(export_handle_t* handle);

// ============================================================================
// Data Export Operations
// ============================================================================

/**
 * @brief Export data batch
 * 
 * @param handle Export handle
 * @param batch Data batch to export
 * @param config Export configuration (NULL to use default)
 * @param job_id Output parameter for job ID (optional)
 * @param job_id_size Size of job ID buffer
 * @return export_status_t Status code
 */
export_status_t export_batch(export_handle_t* handle,
                            const export_batch_t* batch,
                            const export_config_t* config,
                            char* job_id,
                            size_t job_id_size);

/**
 * @brief Export data records
 * 
 * @param handle Export handle
 * @param records Array of records
 * @param record_count Number of records
 * @param schema Data schema
 * @param config Export configuration
 * @param job_id Output parameter for job ID
 * @param job_id_size Size of job ID buffer
 * @return export_status_t Status code
 */
export_status_t export_records(export_handle_t* handle,
                              export_data_record_t* records,
                              uint32_t record_count,
                              const export_schema_t* schema,
                              const export_config_t* config,
                              char* job_id,
                              size_t job_id_size);

/**
 * @brief Export data from file
 * 
 * @param handle Export handle
 * @param input_file Input file path
 * @param input_format Input file format
 * @param config Export configuration
 * @param job_id Output parameter for job ID
 * @param job_id_size Size of job ID buffer
 * @return export_status_t Status code
 */
export_status_t export_from_file(export_handle_t* handle,
                                const char* input_file,
                                export_format_t input_format,
                                const export_config_t* config,
                                char* job_id,
                                size_t job_id_size);

/**
 * @brief Export data from database
 * 
 * @param handle Export handle
 * @param query SQL query
 * @param connection Database connection
 * @param config Export configuration
 * @param job_id Output parameter for job ID
 * @param job_id_size Size of job ID buffer
 * @return export_status_t Status code
 */
export_status_t export_from_database(export_handle_t* handle,
                                    const char* query,
                                    const export_connection_t* connection,
                                    const export_config_t* config,
                                    char* job_id,
                                    size_t job_id_size);

/**
 * @brief Export data from API
 * 
 * @param handle Export handle
 * @param endpoint API endpoint
 * @param config Export configuration
 * @param job_id Output parameter for job ID
 * @param job_id_size Size of job ID buffer
 * @return export_status_t Status code
 */
export_status_t export_from_api(export_handle_t* handle,
                               const export_api_endpoint_t* endpoint,
                               const export_config_t* config,
                               char* job_id,
                               size_t job_id_size);

/**
 * @brief Stream data export (real-time)
 * 
 * @param handle Export handle
 * @param config Export configuration
 * @param stream_callback Callback for data streaming
 * @param user_data User data for callback
 * @param stream_id Output parameter for stream ID
 * @param stream_id_size Size of stream ID buffer
 * @return export_status_t Status code
 */
export_status_t export_stream(export_handle_t* handle,
                             const export_config_t* config,
                             void (*stream_callback)(export_data_record_t* record, void* user_data),
                             void* user_data,
                             char* stream_id,
                             size_t stream_id_size);

// ============================================================================
// Job Management
// ============================================================================

/**
 * @brief Create export job
 * 
 * @param handle Export handle
 * @param job Export job definition
 * @param job_id Output parameter for job ID
 * @param job_id_size Size of job ID buffer
 * @return export_status_t Status code
 */
export_status_t export_create_job(export_handle_t* handle,
                                 const export_job_t* job,
                                 char* job_id,
                                 size_t job_id_size);

/**
 * @brief Update export job
 * 
 * @param handle Export handle
 * @param job_id Job identifier
 * @param job Updated job definition
 * @return export_status_t Status code
 */
export_status_t export_update_job(export_handle_t* handle,
                                 const char* job_id,
                                 const export_job_t* job);

/**
 * @brief Delete export job
 * 
 * @param handle Export handle
 * @param job_id Job identifier
 * @return export_status_t Status code
 */
export_status_t export_delete_job(export_handle_t* handle,
                                 const char* job_id);

/**
 * @brief Start export job
 * 
 * @param handle Export handle
 * @param job_id Job identifier
 * @param synchronous Run synchronously (blocking)
 * @return export_status_t Status code
 */
export_status_t export_start_job(export_handle_t* handle,
                                const char* job_id,
                                bool synchronous);

/**
 * @brief Stop export job
 * 
 * @param handle Export handle
 * @param job_id Job identifier
 * @return export_status_t Status code
 */
export_status_t export_stop_job(export_handle_t* handle,
                               const char* job_id);

/**
 * @brief Schedule export job
 * 
 * @param handle Export handle
 * @param job_id Job identifier
 * @param schedule Schedule configuration
 * @param schedule_expression Schedule expression (cron, etc.)
 * @return export_status_t Status code
 */
export_status_t export_schedule_job(export_handle_t* handle,
                                   const char* job_id,
                                   export_schedule_t schedule,
                                   const char* schedule_expression);

/**
 * @brief Get job status
 * 
 * @param handle Export handle
 * @param job_id Job identifier
 * @param status Output parameter for status
 * @param progress Output parameter for progress (0-100)
 * @param message Output parameter for status message
 * @param message_size Size of message buffer
 * @return export_status_t Status code
 */
export_status_t export_get_job_status(export_handle_t* handle,
                                     const char* job_id,
                                     export_status_t* status,
                                     double* progress,
                                     char* message,
                                     size_t message_size);

/**
 * @brief List all jobs
 * 
 * @param handle Export handle
 * @param jobs Array to store jobs
 * @param max_jobs Maximum jobs to retrieve
 * @param actual_jobs Output parameter for actual jobs
 * @param only_active Return only active jobs
 * @return export_status_t Status code
 */
export_status_t export_list_jobs(export_handle_t* handle,
                                export_job_t* jobs,
                                uint32_t max_jobs,
                                uint32_t* actual_jobs,
                                bool only_active);

// ============================================================================
// Connection Management
// ============================================================================

/**
 * @brief Test connection
 * 
 * @param handle Export handle
 * @param connection Connection to test
 * @param is_connected Output parameter for connection status
 * @param latency Output parameter for latency in milliseconds
 * @return export_status_t Status code
 */
export_status_t export_test_connection(export_handle_t* handle,
                                      const export_connection_t* connection,
                                      bool* is_connected,
                                      double* latency);

/**
 * @brief Create connection
 * 
 * @param handle Export handle
 * @param connection Connection definition
 * @param connection_id Output parameter for connection ID
 * @param connection_id_size Size of connection ID buffer
 * @return export_status_t Status code
 */
export_status_t export_create_connection(export_handle_t* handle,
                                        const export_connection_t* connection,
                                        char* connection_id,
                                        size_t connection_id_size);

/**
 * @brief Update connection
 * 
 * @param handle Export handle
 * @param connection_id Connection identifier
 * @param connection Updated connection definition
 * @return export_status_t Status code
 */
export_status_t export_update_connection(export_handle_t* handle,
                                        const char* connection_id,
                                        const export_connection_t* connection);

/**
 * @brief Delete connection
 * 
 * @param handle Export handle
 * @param connection_id Connection identifier
 * @return export_status_t Status code
 */
export_status_t export_delete_connection(export_handle_t* handle,
                                        const char* connection_id);

/**
 * @brief List connections
 * 
 * @param handle Export handle
 * @param connections Array to store connections
 * @param max_connections Maximum connections to retrieve
 * @param actual_connections Output parameter for actual connections
 * @param destination_type Filter by destination type (0 for all)
 * @return export_status_t Status code
 */
export_status_t export_list_connections(export_handle_t* handle,
                                       export_connection_t* connections,
                                       uint32_t max_connections,
                                       uint32_t* actual_connections,
                                       export_destination_t destination_type);

// ============================================================================
// Data Transformation
// ============================================================================

/**
 * @brief Create data transformation
 * 
 * @param handle Export handle
 * @param transform Transformation definition
 * @param transform_id Output parameter for transformation ID
 * @param transform_id_size Size of transformation ID buffer
 * @return export_status_t Status code
 */
export_status_t export_create_transform(export_handle_t* handle,
                                       const export_transform_t* transform,
                                       char* transform_id,
                                       size_t transform_id_size);

/**
 * @brief Apply transformation to data
 * 
 * @param handle Export handle
 * @param transform_id Transformation identifier
 * @param input_data Input data
 * @param input_size Input data size
 * @param output_data Output parameter for transformed data
 * @param output_size Size of output buffer
 * @param actual_size Output parameter for actual output size
 * @return export_status_t Status code
 */
export_status_t export_apply_transform(export_handle_t* handle,
                                      const char* transform_id,
                                      const void* input_data,
                                      size_t input_size,
                                      void* output_data,
                                      size_t output_size,
                                      size_t* actual_size);

/**
 * @brief Apply transformation to records
 * 
 * @param handle Export handle
 * @param transform_id Transformation identifier
 * @param records Array of records
 * @param record_count Number of records
 * @param transformed_records Output parameter for transformed records
 * @param max_records Maximum records in output
 * @param actual_records Output parameter for actual transformed records
 * @return export_status_t Status code
 */
export_status_t export_transform_records(export_handle_t* handle,
                                        const char* transform_id,
                                        export_data_record_t* records,
                                        uint32_t record_count,
                                        export_data_record_t* transformed_records,
                                        uint32_t max_records,
                                        uint32_t* actual_records);

/**
 * @brief Validate transformation
 * 
 * @param handle Export handle
 * @param transform_id Transformation identifier
 * @param is_valid Output parameter for validation status
 * @param errors Output parameter for validation errors
 * @param errors_size Size of errors buffer
 * @return export_status_t Status code
 */
export_status_t export_validate_transform(export_handle_t* handle,
                                         const char* transform_id,
                                         bool* is_valid,
                                         char* errors,
                                         size_t errors_size);

// ============================================================================
// Schema Management
// ============================================================================

/**
 * @brief Create data schema
 * 
 * @param handle Export handle
 * @param schema Schema definition
 * @param schema_id Output parameter for schema ID
 * @param schema_id_size Size of schema ID buffer
 * @return export_status_t Status code
 */
export_status_t export_create_schema(export_handle_t* handle,
                                    const export_schema_t* schema,
                                    char* schema_id,
                                    size_t schema_id_size);

/**
 * @brief Validate data against schema
 * 
 * @param handle Export handle
 * @param schema_id Schema identifier
 * @param records Array of records
 * @param record_count Number of records
 * @param valid_records Output parameter for valid records
 * @param validation_errors Output parameter for validation errors
 * @param errors_size Size of errors buffer
 * @return export_status_t Status code
 */
export_status_t export_validate_data(export_handle_t* handle,
                                    const char* schema_id,
                                    export_data_record_t* records,
                                    uint32_t record_count,
                                    uint32_t* valid_records,
                                    char* validation_errors,
                                    size_t errors_size);

/**
 * @brief Convert schema between formats
 * 
 * @param handle Export handle
 * @param schema_id Schema identifier
 * @param target_format Target format
 * @param converted_schema Output parameter for converted schema
 * @param schema_size Size of schema buffer
 * @param actual_size Output parameter for actual schema size
 * @return export_status_t Status code
 */
export_status_t export_convert_schema(export_handle_t* handle,
                                     const char* schema_id,
                                     export_format_t target_format,
                                     char* converted_schema,
                                     size_t schema_size,
                                     size_t* actual_size);

// ============================================================================
// Format Conversion
// ============================================================================

/**
 * @brief Convert data between formats
 * 
 * @param handle Export handle
 * @param input_data Input data
 * @param input_size Input data size
 * @param input_format Input data format
 * @param output_format Output data format
 * @param output_data Output parameter for converted data
 * @param output_size Size of output buffer
 * @param actual_size Output parameter for actual output size
 * @return export_status_t Status code
 */
export_status_t export_convert_format(export_handle_t* handle,
                                     const void* input_data,
                                     size_t input_size,
                                     export_format_t input_format,
                                     export_format_t output_format,
                                     void* output_data,
                                     size_t output_size,
                                     size_t* actual_size);

/**
 * @brief Convert records to specified format
 * 
 * @param handle Export handle
 * @param records Array of records
 * @param record_count Number of records
 * @param schema Data schema
 * @param target_format Target format
 * @param output_data Output parameter for converted data
 * @param output_size Size of output buffer
 * @param actual_size Output parameter for actual output size
 * @return export_status_t Status code
 */
export_status_t export_convert_records(export_handle_t* handle,
                                      export_data_record_t* records,
                                      uint32_t record_count,
                                      const export_schema_t* schema,
                                      export_format_t target_format,
                                      void* output_data,
                                      size_t output_size,
                                      size_t* actual_size);

/**
 * @brief Get format capabilities
 * 
 * @param handle Export handle
 * @param format Format to check
 * @param capabilities Output parameter for capabilities
 * @param capabilities_size Size of capabilities buffer
 * @return export_status_t Status code
 */
export_status_t export_get_format_capabilities(export_handle_t* handle,
                                              export_format_t format,
                                              char* capabilities,
                                              size_t capabilities_size);

// ============================================================================
// Compression and Encryption
// ============================================================================

/**
 * @brief Compress data
 * 
 * @param handle Export handle
 * @param input_data Input data
 * @param input_size Input data size
 * @param compression Compression algorithm
 * @param compression_level Compression level (1-9)
 * @param compressed_data Output parameter for compressed data
 * @param compressed_size Size of compressed buffer
 * @param actual_size Output parameter for actual compressed size
 * @return export_status_t Status code
 */
export_status_t export_compress_data(export_handle_t* handle,
                                    const void* input_data,
                                    size_t input_size,
                                    export_compression_t compression,
                                    uint32_t compression_level,
                                    void* compressed_data,
                                    size_t compressed_size,
                                    size_t* actual_size);

/**
 * @brief Decompress data
 * 
 * @param handle Export handle
 * @param compressed_data Compressed data
 * @param compressed_size Compressed data size
 * @param compression Compression algorithm used
 * @param decompressed_data Output parameter for decompressed data
 * @param decompressed_size Size of decompressed buffer
 * @param actual_size Output parameter for actual decompressed size
 * @return export_status_t Status code
 */
export_status_t export_decompress_data(export_handle_t* handle,
                                      const void* compressed_data,
                                      size_t compressed_size,
                                      export_compression_t compression,
                                      void* decompressed_data,
                                      size_t decompressed_size,
                                      size_t* actual_size);

/**
 * @brief Encrypt data
 * 
 * @param handle Export handle
 * @param input_data Input data
 * @param input_size Input data size
 * @param encryption Encryption algorithm
 * @param key Encryption key
 * @param iv Initialization vector (optional)
 * @param encrypted_data Output parameter for encrypted data
 * @param encrypted_size Size of encrypted buffer
 * @param actual_size Output parameter for actual encrypted size
 * @return export_status_t Status code
 */
export_status_t export_encrypt_data(export_handle_t* handle,
                                   const void* input_data,
                                   size_t input_size,
                                   export_encryption_t encryption,
                                   const char* key,
                                   const char* iv,
                                   void* encrypted_data,
                                   size_t encrypted_size,
                                   size_t* actual_size);

/**
 * @brief Decrypt data
 * 
 * @param handle Export handle
 * @param encrypted_data Encrypted data
 * @param encrypted_size Encrypted data size
 * @param encryption Encryption algorithm used
 * @param key Decryption key
 * @param iv Initialization vector (optional)
 * @param decrypted_data Output parameter for decrypted data
 * @param decrypted_size Size of decrypted buffer
 * @param actual_size Output parameter for actual decrypted size
 * @return export_status_t Status code
 */
export_status_t export_decrypt_data(export_handle_t* handle,
                                   const void* encrypted_data,
                                   size_t encrypted_size,
                                   export_encryption_t encryption,
                                   const char* key,
                                   const char* iv,
                                   void* decrypted_data,
                                   size_t decrypted_size,
                                   size_t* actual_size);

// ============================================================================
// Monitoring and Statistics
// ============================================================================

/**
 * @brief Get export statistics
 * 
 * @param handle Export handle
 * @param statistics Output parameter for statistics
 * @return export_status_t Status code
 */
export_status_t export_get_statistics(export_handle_t* handle,
                                     export_statistics_t* statistics);

/**
 * @brief Get real-time metrics
 * 
 * @param handle Export handle
 * @param metrics Output parameter for metrics
 * @return export_status_t Status code
 */
export_status_t export_get_metrics(export_handle_t* handle,
                                  export_monitor_metrics_t* metrics);

/**
 * @brief Reset statistics
 * 
 * @param handle Export handle
 * @return export_status_t Status code
 */
export_status_t export_reset_statistics(export_handle_t* handle);

/**
 * @brief Generate export report
 * 
 * @param handle Export handle
 * @param start_time Report start time
 * @param end_time Report end time
 * @param report_format Report format
 * @param report_data Output parameter for report data
 * @param report_size Size of report buffer
 * @param actual_size Output parameter for actual report size
 * @return export_status_t Status code
 */
export_status_t export_generate_report(export_handle_t* handle,
                                      time_t start_time,
                                      time_t end_time,
                                      export_format_t report_format,
                                      void* report_data,
                                      size_t report_size,
                                      size_t* actual_size);

// ============================================================================
// Advanced Operations
// ============================================================================

/**
 * @brief Export with retry logic
 * 
 * @param handle Export handle
 * @param batch Data batch to export
 * @param config Export configuration
 * @param max_retries Maximum retry attempts
 * @param retry_delay_ms Delay between retries in milliseconds
 * @param job_id Output parameter for job ID
 * @param job_id_size Size of job ID buffer
 * @return export_status_t Status code
 */
export_status_t export_with_retry(export_handle_t* handle,
                                 const export_batch_t* batch,
                                 const export_config_t* config,
                                 uint32_t max_retries,
                                 uint32_t retry_delay_ms,
                                 char* job_id,
                                 size_t job_id_size);

/**
 * @brief Bulk export multiple batches
 * 
 * @param handle Export handle
 * @param batches Array of data batches
 * @param batch_count Number of batches
 * @param config Export configuration
 * @param parallel Use parallel processing
 * @param max_workers Maximum worker threads
 * @param job_ids Output parameter for job IDs
 * @param max_jobs Maximum job IDs to return
 * @param actual_jobs Output parameter for actual job count
 * @return export_status_t Status code
 */
export_status_t export_bulk(export_handle_t* handle,
                           const export_batch_t* batches,
                           uint32_t batch_count,
                           const export_config_t* config,
                           bool parallel,
                           uint32_t max_workers,
                           char** job_ids,
                           uint32_t max_jobs,
                           uint32_t* actual_jobs);

/**
 * @brief Export with callback for each record
 * 
 * @param handle Export handle
 * @param records Array of records
 * @param record_count Number of records
 * @param schema Data schema
 * @param config Export configuration
 * @param record_callback Callback for each record
 * @param user_data User data for callback
 * @param job_id Output parameter for job ID
 * @param job_id_size Size of job ID buffer
 * @return export_status_t Status code
 */
export_status_t export_with_callback(export_handle_t* handle,
                                    export_data_record_t* records,
                                    uint32_t record_count,
                                    const export_schema_t* schema,
                                    const export_config_t* config,
                                    void (*record_callback)(export_data_record_t* record, export_status_t status, void* user_data),
                                    void* user_data,
                                    char* job_id,
                                    size_t job_id_size);

/**
 * @brief Export to multiple destinations
 * 
 * @param handle Export handle
 * @param batch Data batch to export
 * @param configs Array of export configurations
 * @param config_count Number of configurations
 * @param job_ids Output parameter for job IDs
 * @param max_jobs Maximum job IDs to return
 * @param actual_jobs Output parameter for actual job count
 * @return export_status_t Status code
 */
export_status_t export_to_multiple(export_handle_t* handle,
                                  const export_batch_t* batch,
                                  const export_config_t* configs,
                                  uint32_t config_count,
                                  char** job_ids,
                                  uint32_t max_jobs,
                                  uint32_t* actual_jobs);

// ============================================================================
// Utility Functions
// ============================================================================

/**
 * @brief Create data batch from array
 * 
 * @param handle Export handle
 * @param records Array of records
 * @param record_count Number of records
 * @param schema Data schema
 * @param batch Output parameter for created batch
 * @return export_status_t Status code
 */
export_status_t export_create_batch(export_handle_t* handle,
                                   export_data_record_t* records,
                                   uint32_t record_count,
                                   const export_schema_t* schema,
                                   export_batch_t* batch);

/**
 * @brief Free data batch resources
 * 
 * @param handle Export handle
 * @param batch Batch to free
 * @return export_status_t Status code
 */
export_status_t export_free_batch(export_handle_t* handle,
                                 export_batch_t* batch);

/**
 * @brief Validate export configuration
 * 
 * @param handle Export handle
 * @param config Configuration to validate
 * @param is_valid Output parameter for validation status
 * @param errors Output parameter for validation errors
 * @param errors_size Size of errors buffer
 * @return export_status_t Status code
 */
export_status_t export_validate_config(export_handle_t* handle,
                                      const export_config_t* config,
                                      bool* is_valid,
                                      char* errors,
                                      size_t errors_size);

/**
 * @brief Estimate export size
 * 
 * @param handle Export handle
 * @param batch Data batch
 * @param config Export configuration
 * @param estimated_size Output parameter for estimated size in bytes
 * @param estimated_records Output parameter for estimated record count
 * @return export_status_t Status code
 */
export_status_t export_estimate_size(export_handle_t* handle,
                                    const export_batch_t* batch,
                                    const export_config_t* config,
                                    uint64_t* estimated_size,
                                    uint32_t* estimated_records);

// ============================================================================
// Inline Utility Functions
// ============================================================================

/**
 * @brief Check if export module is active
 * 
 * @param handle Export handle to check
 * @return true if active, false otherwise
 */
static inline bool export_is_active(const export_handle_t* handle) {
    return (handle != NULL);
}

/**
 * @brief Convert bytes to human-readable string
 * 
 * @param bytes Number of bytes
 * @param buffer Buffer for result
 * @param buffer_size Size of buffer
 * @return const char* Human-readable string
 */
static inline const char* export_bytes_to_human(uint64_t bytes, char* buffer, size_t buffer_size) {
    const char* units[] = {"B", "KB", "MB", "GB", "TB", "PB", "EB"};
    int unit_index = 0;
    double size = (double)bytes;
    
    while (size >= 1024.0 && unit_index < 6) {
        size /= 1024.0;
        unit_index++;
    }
    
    snprintf(buffer, buffer_size, "%.2f %s", size, units[unit_index]);
    return buffer;
}

/**
 * @brief Calculate export throughput
 * 
 * @param records_exported Number of records exported
 * @param time_taken_seconds Time taken in seconds
 * @return Throughput in records per second
 */
static inline double export_calculate_throughput(uint32_t records_exported, double time_taken_seconds) {
    if (time_taken_seconds <= 0.0) return 0.0;
    return (double)records_exported / time_taken_seconds;
}

/**
 * @brief Calculate export success rate
 * 
 * @param successful_records Number of successful records
 * @param total_records Total number of records
 * @return Success rate as percentage (0-100)
 */
static inline double export_calculate_success_rate(uint32_t successful_records, uint32_t total_records) {
    if (total_records == 0) return 100.0;
    return ((double)successful_records / (double)total_records) * 100.0;
}

/**
 * @brief Generate timestamp string
 * 
 * @param timestamp Unix timestamp
 * @param format Format string (NULL for default)
 * @param buffer Buffer for result
 * @param buffer_size Size of buffer
 * @return const char* Formatted timestamp
 */
static inline const char* export_format_timestamp(time_t timestamp, const char* format, char* buffer, size_t buffer_size) {
    if (timestamp == 0) {
        strncpy(buffer, "N/A", buffer_size);
        return buffer;
    }
    
    struct tm* timeinfo;
    timeinfo = localtime(&timestamp);
    
    if (format == NULL) {
        strftime(buffer, buffer_size, "%Y-%m-%d %H:%M:%S", timeinfo);
    } else {
        strftime(buffer, buffer_size, format, timeinfo);
    }
    
    return buffer;
}

/**
 * @brief Parse export format from string
 * 
 * @param format_str Format string
 * @return export_format_t Format enum value
 */
static inline export_format_t export_parse_format(const char* format_str) {
    if (format_str == NULL) return FORMAT_CSV;
    
    if (strcasecmp(format_str, "csv") == 0) return FORMAT_CSV;
    if (strcasecmp(format_str, "json") == 0) return FORMAT_JSON;
    if (strcasecmp(format_str, "xml") == 0) return FORMAT_XML;
    if (strcasecmp(format_str, "yaml") == 0) return FORMAT_YAML;
    if (strcasecmp(format_str, "protobuf") == 0) return FORMAT_PROTOBUF;
    if (strcasecmp(format_str, "avro") == 0) return FORMAT_AVRO;
    if (strcasecmp(format_str, "parquet") == 0) return FORMAT_PARQUET;
    if (strcasecmp(format_str, "orc") == 0) return FORMAT_ORC;
    if (strcasecmp(format_str, "excel") == 0) return FORMAT_EXCEL;
    if (strcasecmp(format_str, "pdf") == 0) return FORMAT_PDF;
    if (strcasecmp(format_str, "html") == 0) return FORMAT_HTML;
    if (strcasecmp(format_str, "markdown") == 0) return FORMAT_MARKDOWN;
    if (strcasecmp(format_str, "text") == 0) return FORMAT_PLAIN_TEXT;
    if (strcasecmp(format_str, "binary") == 0) return FORMAT_BINARY;
    if (strcasecmp(format_str, "sql") == 0) return FORMAT_SQL;
    if (strcasecmp(format_str, "graphql") == 0) return FORMAT_GRAPHQL;
    if (strcasecmp(format_str, "prometheus") == 0) return FORMAT_PROMETHEUS;
    if (strcasecmp(format_str, "influxdb") == 0) return FORMAT_INFLUXDB;
    if (strcasecmp(format_str, "opentsdb") == 0) return FORMAT_OPENTSDB;
    if (strcasecmp(format_str, "logfmt") == 0) return FORMAT_LOGFMT;
    if (strcasecmp(format_str, "syslog") == 0) return FORMAT_SYSLOG;
    
    return FORMAT_CUSTOM;
}

/**
 * @brief Get format MIME type
 * 
 * @param format Export format
 * @return const char* MIME type string
 */
static inline const char* export_get_mime_type(export_format_t format) {
    switch (format) {
        case FORMAT_CSV: return "text/csv";
        case FORMAT_JSON: return "application/json";
        case FORMAT_XML: return "application/xml";
        case FORMAT_YAML: return "application/x-yaml";
        case FORMAT_PROTOBUF: return "application/x-protobuf";
        case FORMAT_AVRO: return "application/avro";
        case FORMAT_PARQUET: return "application/parquet";
        case FORMAT_ORC: return "application/orc";
        case FORMAT_EXCEL: return "application/vnd.ms-excel";
        case FORMAT_PDF: return "application/pdf";
        case FORMAT_HTML: return "text/html";
        case FORMAT_MARKDOWN: return "text/markdown";
        case FORMAT_PLAIN_TEXT: return "text/plain";
        case FORMAT_BINARY: return "application/octet-stream";
        case FORMAT_SQL: return "application/sql";
        case FORMAT_GRAPHQL: return "application/graphql";
        case FORMAT_PROMETHEUS: return "text/plain; version=0.0.4";
        case FORMAT_INFLUXDB: return "text/plain";
        case FORMAT_OPENTSDB: return "application/json";
        case FORMAT_LOGFMT: return "text/plain";
        case FORMAT_SYSLOG: return "text/plain";
        default: return "application/octet-stream";
    }
}

/**
 * @brief Get format file extension
 * 
 * @param format Export format
 * @return const char* File extension
 */
static inline const char* export_get_file_extension(export_format_t format) {
    switch (format) {
        case FORMAT_CSV: return ".csv";
        case FORMAT_JSON: return ".json";
        case FORMAT_XML: return ".xml";
        case FORMAT_YAML: return ".yaml";
        case FORMAT_PROTOBUF: return ".pb";
        case FORMAT_AVRO: return ".avro";
        case FORMAT_PARQUET: return ".parquet";
        case FORMAT_ORC: return ".orc";
        case FORMAT_EXCEL: return ".xlsx";
        case FORMAT_PDF: return ".pdf";
        case FORMAT_HTML: return ".html";
        case FORMAT_MARKDOWN: return ".md";
        case FORMAT_PLAIN_TEXT: return ".txt";
        case FORMAT_BINARY: return ".bin";
        case FORMAT_SQL: return ".sql";
        case FORMAT_GRAPHQL: return ".graphql";
        case FORMAT_PROMETHEUS: return ".prom";
        case FORMAT_INFLUXDB: return ".influx";
        case FORMAT_OPENTSDB: return ".tsdb";
        case FORMAT_LOGFMT: return ".log";
        case FORMAT_SYSLOG: return ".log";
        default: return ".dat";
    }
}

/**
 * @brief Get API version string
 * 
 * @return const char* Version string
 */
static inline const char* export_get_version_string(void) {
    return "4.1.0";
}

// ============================================================================
// Platform-Specific Extensions
// ============================================================================

#if defined(_WIN32)
/**
 * @brief Export to Windows Event Log
 * 
 * @param handle Export handle
 * @param records Data records
 * @param record_count Number of records
 * @param event_log_name Event log name
 * @param event_source Event source
 * @param job_id Output parameter for job ID
 * @param job_id_size Size of job ID buffer
 * @return export_status_t Status code
 */
export_status_t export_to_windows_event_log(export_handle_t* handle,
                                           export_data_record_t* records,
                                           uint32_t record_count,
                                           const char* event_log_name,
                                           const char* event_source,
                                           char* job_id,
                                           size_t job_id_size);
#endif

#if defined(__linux__)
/**
 * @brief Export to Linux syslog
 * 
 * @param handle Export handle
 * @param records Data records
 * @param record_count Number of records
 * @param facility Syslog facility
 * @param priority Syslog priority
 * @param job_id Output parameter for job ID
 * @param job_id_size Size of job ID buffer
 * @return export_status_t Status code
 */
export_status_t export_to_syslog(export_handle_t* handle,
                                export_data_record_t* records,
                                uint32_t record_count,
                                int facility,
                                int priority,
                                char* job_id,
                                size_t job_id_size);
#endif

// ============================================================================
// Export Macros for Shared Libraries
// ============================================================================
#ifdef BUILDING_EXPORT_DLL
    #define EXPORT_API __declspec(dllexport)
#elif defined(USING_EXPORT_DLL)
    #define EXPORT_API __declspec(dllimport)
#else
    #define EXPORT_API
#endif

#ifdef __cplusplus
}
#endif

#endif // EXPORT_H

// ============================================================================
// Implementation Notes:
// ============================================================================
// 1. Format Support: CSV, JSON, XML, YAML, Protobuf, Avro, Parquet, ORC, Excel, PDF, HTML, etc.
// 2. Destination Support: Files, HTTP, FTP, S3, GCS, Azure, Kafka, RabbitMQ, Redis, databases, etc.
// 3. Data Transformation: Field mapping, filtering, aggregation, enrichment, validation
// 4. Compression: Gzip, Zlib, Bzip2, LZ4, Snappy, Zstandard, LZMA
// 5. Encryption: AES, RSA, ChaCha20, PGP
// 6. Scheduling: Cron, intervals, event-driven, real-time streaming
// 7. Monitoring: Real-time metrics, statistics, performance monitoring
// 8. Reliability: Retry logic, error handling, transaction support
// 9. Scalability: Batch processing, parallel execution, distributed export
// 10. Extensibility: Plugin architecture, custom formats, custom destinations