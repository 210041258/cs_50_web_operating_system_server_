#ifndef PROCESS_H
#define PROCESS_H

#include <stdint.h>
#include <sys/types.h>
#include <time.h>

// Forward declarations
typedef struct ProcessState ProcessState;
typedef struct ProcessInfo ProcessInfo;
typedef struct ThreadInfo ThreadInfo;

// Process states
typedef enum : u8 {
    PROC_RUNNING,
    PROC_SLEEPING,
    PROC_STOPPED,
    PROC_ZOMBIE,
    PROC_DEAD,
    PROC_IDLE,
    PROC_UNKNOWN
} ProcessStateType;

// Sort orders
typedef enum : u8 {
    SORT_BY_CPU,
    SORT_BY_MEMORY,
    SORT_BY_PID,
    SORT_BY_TIME,
    SORT_BY_NAME,
    SORT_BY_IO,
    SORT_BY_THREADS,
    SORT_BY_PPID
} SortOrder;

// Resource limits
typedef struct PACKED {
    u64 cpu_soft;
    u64 cpu_hard;
    u64 fsize_soft;
    u64 fsize_hard;
    u64 data_soft;
    u64 data_hard;
    u64 stack_soft;
    u64 stack_hard;
    u64 core_soft;
    u64 core_hard;
    u64 rss_soft;
    u64 rss_hard;
    u64 nproc_soft;
    u64 nproc_hard;
    u64 nofile_soft;
    u64 nofile_hard;
    u64 memlock_soft;
    u64 memlock_hard;
    u64 locks_soft;
    u64 locks_hard;
    u64 sigpending_soft;
    u64 sigpending_hard;
    u64 msgqueue_soft;
    u64 msgqueue_hard;
    u64 nice_soft;
    u64 nice_hard;
    u64 rtprio_soft;
    u64 rtprio_hard;
} ResourceLimits;

// Process snapshot
typedef struct PACKED {
    u32 timestamp;            // Monotonic seconds
    pid_t pid;
    float cpu_usage;          // Percentage
    u64 memory_rss;          // KB
    u64 memory_virt;         // KB
    u32 threads;
    u32 fd_count;
    u8 state;
    u8 priority;
    i8 nice;
    u8 _reserved;
} ProcessSnapshot;

// Function prototypes
ProcessState* process_monitor_init(void) HOT;
void process_monitor_cleanup(ProcessState *state) COLD;

// Process enumeration
u32 process_get_count(const ProcessState *state);
const ProcessInfo* process_get_all(const ProcessState *state, u32 *count);
const ProcessInfo* process_find_by_pid(const ProcessState *state, pid_t pid);
const ProcessInfo* process_find_by_name(const ProcessState *state, const char *name, u32 *count);

// Process information
pid_t process_get_pid(const ProcessInfo *process);
pid_t process_get_ppid(const ProcessInfo *process);
pid_t process_get_pgid(const ProcessInfo *process);
pid_t process_get_sid(const ProcessInfo *process);

const char* process_get_name(const ProcessInfo *process);
const char* process_get_cmdline(const ProcessInfo *process);
const char* process_get_exe_path(const ProcessInfo *process);
const char* process_get_cwd(const ProcessInfo *process);

// Resource usage
float process_get_cpu_usage(const ProcessInfo *process) HOT;
u64 process_get_memory_rss(const ProcessInfo *process) HOT;
u64 process_get_memory_virt(const ProcessInfo *process);
u64 process_get_memory_shared(const ProcessInfo *process);
u64 process_get_memory_data(const ProcessInfo *process);
u64 process_get_memory_stack(const ProcessInfo *process);

// I/O statistics
u64 process_get_read_bytes(const ProcessInfo *process);
u64 process_get_write_bytes(const ProcessInfo *process);
u64 process_get_read_ops(const ProcessInfo *process);
u64 process_get_write_ops(const ProcessInfo *process);
u32 process_get_read_rate(const ProcessInfo *process);   // KB/s
u32 process_get_write_rate(const ProcessInfo *process);  // KB/s

// CPU time
u64 process_get_utime(const ProcessInfo *process);      // User time (jiffies)
u64 process_get_stime(const ProcessInfo *process);      // System time (jiffies)
u64 process_get_cutime(const ProcessInfo *process);     // Children user time
u64 process_get_cstime(const ProcessInfo *process);     // Children system time
time_t process_get_start_time(const ProcessInfo *process);

// Thread information
u32 process_get_thread_count(const ProcessInfo *process);
const ThreadInfo* process_get_threads(const ProcessInfo *process, u32 *count);

// File descriptors
u32 process_get_fd_count(const ProcessInfo *process);
int process_get_fd_info(const ProcessInfo *process, char *buffer, u32 size);

// Context switches
u64 process_get_voluntary_ctxt(const ProcessInfo *process);
u64 process_get_nonvoluntary_ctxt(const ProcessInfo *process);

// Scheduling
i8 process_get_nice(const ProcessInfo *process);
u8 process_get_priority(const ProcessInfo *process);
u32 process_get_rt_priority(const ProcessInfo *process);
u64 process_get_affinity(const ProcessInfo *process);

// Capabilities
int process_get_capabilities(const ProcessInfo *process, 
                            u64 *inheritable, 
                            u64 *permitted, 
                            u64 *effective);

// Namespaces
int process_get_namespaces(const ProcessInfo *process,
                          u32 *mnt_ns,
                          u32 *pid_ns,
                          u32 *net_ns,
                          u32 *ipc_ns,
                          u32 *uts_ns,
                          u32 *user_ns);

// Security
int process_get_seccomp_mode(const ProcessInfo *process);
int process_get_selinux_context(const ProcessInfo *process, char *context, u32 size);

// Cgroups
const char* process_get_cgroup(const ProcessInfo *process, char *buffer, u32 size);

// Process control
int process_send_signal(pid_t pid, u8 signal);
int process_set_priority(pid_t pid, i8 nice);
int process_set_affinity(pid_t pid, u64 mask);
int process_suspend(pid_t pid);
int process_resume(pid_t pid);
int process_terminate(pid_t pid);

// Resource limits
int process_get_limits(pid_t pid, ResourceLimits *limits);
int process_set_limits(pid_t pid, const ResourceLimits *limits);

// Process tree
typedef struct PACKED {
    pid_t pid;
    pid_t parent;
    u8 depth;
    u8 child_count;
} ProcessTreeNode;

u32 process_build_tree(const ProcessState *state, ProcessTreeNode *tree, u32 max_nodes);
void process_print_tree(const ProcessState *state, pid_t root_pid, u8 max_depth, char *buffer, u32 size);

// Sorting and filtering
void process_sort(ProcessState *state, SortOrder order);
void process_filter_by_user(ProcessState *state, uid_t uid);
void process_filter_by_state(ProcessState *state, ProcessStateType state_type);

// Statistics aggregation
u32 process_get_total_count(const ProcessState *state);
u32 process_get_running_count(const ProcessState *state);
u32 process_get_sleeping_count(const ProcessState *state);
u32 process_get_zombie_count(const ProcessState *state);
u64 process_get_total_memory(const ProcessState *state);
float process_get_total_cpu(const ProcessState *state);

// History and trends
const ProcessSnapshot* process_get_history(const ProcessInfo *process, u32 *count);
void process_set_sample_rate(ProcessState *state, u16 interval_ms);

// Performance analysis
typedef struct PACKED {
    u8 issue_type;          // 0=none, 1=memory leak, 2=CPU bound, 3=IO bound
    u8 severity;            // 0-100
    u32 suggested_action;
    char recommendation[256];
} ProcessAnalysis;

ProcessAnalysis process_analyze(const ProcessInfo *process);

// Prediction
typedef struct PACKED {
    float predicted_cpu;
    u64 predicted_memory;
    u32 time_to_oom;        // Seconds until OOM kill
    u8 risk_score;          // 0-100
} ProcessPrediction;

ProcessPrediction process_predict(const ProcessInfo *process);

// Export functions
int process_export_json(const ProcessState *state, char *buffer, u32 size);
int process_export_csv(const ProcessState *state, char *buffer, u32 size);

// Utility functions
const char* process_state_to_string(ProcessStateType state);
const char* process_format_memory(u64 bytes, char *buffer, u32 size);

#endif // PROCESS_H