/**
 * @file gpu.h
 * @brief GPU Monitoring and Management Module
 * 
 * This module provides comprehensive GPU monitoring, management, and diagnostics
 * capabilities for NVIDIA, AMD, and Intel GPUs across multiple platforms.
 * Includes metrics collection, performance analysis, and control functions.
 * 
 * @author GPU Performance Team
 * @date 2024-01-31
 * @version 3.2.0
 * 
 * @license Apache 2.0
 * @copyright Copyright (c) 2024 GPU Solutions
 */

#ifndef GPU_H
#define GPU_H

#ifdef __cplusplus
extern "C" {
#endif

// ============================================================================
// Includes and Dependencies
// ============================================================================
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <time.h>

// Graphics API headers
#if defined(USE_VULKAN)
    #include <vulkan/vulkan.h>
#endif

#if defined(USE_CUDA)
    #include <cuda.h>
    #include <cuda_runtime_api.h>
#endif

#if defined(USE_OPENCL)
    #include <CL/cl.h>
    #include <CL/cl_ext.h>
#endif

// ============================================================================
// Configuration Constants
// ============================================================================
/**
 * @def GPU_API_VERSION_MAJOR
 * @brief Major version number
 */
#define GPU_API_VERSION_MAJOR 3

/**
 * @def GPU_API_VERSION_MINOR
 * @brief Minor version number
 */
#define GPU_API_VERSION_MINOR 2

/**
 * @def GPU_API_VERSION_PATCH
 * @brief Patch version number
 */
#define GPU_API_VERSION_PATCH 0

/**
 * @def GPU_MAX_DEVICES
 * @brief Maximum number of GPUs supported
 */
#define GPU_MAX_DEVICES 32

/**
 * @def GPU_MAX_PROCESSES
 * @brief Maximum processes per GPU
 */
#define GPU_MAX_PROCESSES 256

/**
 * @def GPU_MAX_MEMORY_BANKS
 * @brief Maximum memory banks per GPU
 */
#define GPU_MAX_MEMORY_BANKS 8

/**
 * @def GPU_MAX_FAN_COUNT
 * @brief Maximum fans per GPU
 */
#define GPU_MAX_FAN_COUNT 4

/**
 * @def GPU_MAX_TEMPERATURE_SENSORS
 * @brief Maximum temperature sensors per GPU
 */
#define GPU_MAX_TEMPERATURE_SENSORS 16

/**
 * @def GPU_MAX_POWER_LIMITS
 * @brief Maximum power limits per GPU
 */
#define GPU_MAX_POWER_LIMITS 4

/**
 * @def GPU_DEFAULT_SAMPLE_INTERVAL_MS
 * @brief Default sampling interval in milliseconds
 */
#define GPU_DEFAULT_SAMPLE_INTERVAL_MS 500

// ============================================================================
// Type Definitions
// ============================================================================

/**
 * @enum gpu_status_t
 * @brief Status codes for GPU operations
 */
typedef enum {
    GPU_SUCCESS = 0,                     /**< Operation successful */
    GPU_ERROR_INIT_FAILED,               /**< Initialization failed */
    GPU_ERROR_DEVICE_NOT_FOUND,          /**< No GPU devices found */
    GPU_ERROR_INVALID_DEVICE,            /**< Invalid device index */
    GPU_ERROR_INVALID_PARAMETER,         /**< Invalid parameter */
    GPU_ERROR_NOT_INITIALIZED,           /**< GPU module not initialized */
    GPU_ERROR_UNSUPPORTED_OPERATION,     /**< Operation not supported */
    GPU_ERROR_DRIVER_VERSION,            /**< Driver version mismatch */
    GPU_ERROR_INSUFFICIENT_PERMISSIONS,  /**< Insufficient permissions */
    GPU_ERROR_MEMORY_ALLOCATION,         /**< Memory allocation failed */
    GPU_ERROR_API_UNAVAILABLE,           /**< Graphics API unavailable */
    GPU_ERROR_OVERHEAT,                  /**< GPU overheating detected */
    GPU_ERROR_POWER_LIMIT,               /**< Power limit exceeded */
    GPU_ERROR_TIMEOUT,                   /**< Operation timeout */
    GPU_ERROR_IO_ERROR,                  /**< I/O operation failed */
    GPU_ERROR_THROTTLING,                /**< GPU is throttling */
    GPU_ERROR_RESET_REQUIRED,            /**< GPU reset required */
    GPU_ERROR_FEATURE_DISABLED           /**< Feature disabled */
} gpu_status_t;

/**
 * @enum gpu_vendor_t
 * @brief GPU vendor/manufacturer
 */
typedef enum {
    GPU_VENDOR_NVIDIA,                   /**< NVIDIA Corporation */
    GPU_VENDOR_AMD,                      /**< AMD/ATI Technologies */
    GPU_VENDOR_INTEL,                    /**< Intel Corporation */
    GPU_VENDOR_APPLE,                    /**< Apple Silicon */
    GPU_VENDOR_QUALCOMM,                 /**< Qualcomm Adreno */
    GPU_VENDOR_ARM,                      /**< ARM Mali */
    GPU_VENDOR_VMWARE,                   /**< VMware Virtual GPU */
    GPU_VENDOR_MICROSOFT,                /**< Microsoft WDDM */
    GPU_VENDOR_UNKNOWN                   /**< Unknown vendor */
} gpu_vendor_t;

/**
 * @enum gpu_type_t
 * @brief GPU type/architecture
 */
typedef enum {
    GPU_TYPE_DISCRETE,                   /**< Discrete/dedicated GPU */
    GPU_TYPE_INTEGRATED,                 /**< Integrated GPU */
    GPU_TYPE_VIRTUAL,                    /**< Virtual GPU */
    GPU_TYPE_CLOUD,                      /**< Cloud/Remote GPU */
    GPU_TYPE_ACCELERATOR,                /**< Compute Accelerator */
    GPU_TYPE_UNKNOWN                     /**< Unknown type */
} gpu_type_t;

/**
 * @enum gpu_api_t
 * @brief Graphics/compute API
 */
typedef enum {
    GPU_API_CUDA,                        /**< NVIDIA CUDA */
    GPU_API_VULKAN,                      /**< Vulkan */
    GPU_API_OPENCL,                      /**< OpenCL */
    GPU_API_OPENGL,                      /**< OpenGL */
    GPU_API_DIRECTX,                     /**< DirectX */
    GPU_API_METAL,                       /**< Apple Metal */
    GPU_API_ROCM,                        /**< AMD ROCm */
    GPU_API_ONEAPI,                      /**< Intel oneAPI */
    GPU_API_WEBGPU                       /**< WebGPU */
} gpu_api_t;

/**
 * @enum gpu_memory_type_t
 * @brief GPU memory type
 */
typedef enum {
    GPU_MEMORY_TYPE_GDDR,                /**< GDDR memory */
    GPU_MEMORY_TYPE_HBM,                 /**< High Bandwidth Memory */
    GPU_MEMORY_TYPE_LPDDR,               /**< Low Power DDR */
    GPU_MEMORY_TYPE_SHARED,              /**< Shared system memory */
    GPU_MEMORY_TYPE_UNIFIED,             /**< Unified memory */
    GPU_MEMORY_TYPE_VRAM,                /**< Video RAM */
    GPU_MEMORY_TYPE_UNKNOWN              /**< Unknown memory type */
} gpu_memory_type_t;

/**
 * @enum gpu_power_source_t
 * @brief GPU power source
 */
typedef enum {
    GPU_POWER_SOURCE_PCIE,               /**< PCIe slot power */
    GPU_POWER_SOURCE_EXTERNAL,           /**< External power connector */
    GPU_POWER_SOURCE_AUX,                /**< Auxiliary power */
    GPU_POWER_SOURCE_BUS,                /**< System bus power */
    GPU_POWER_SOURCE_UNKNOWN             /**< Unknown power source */
} gpu_power_source_t;

/**
 * @enum gpu_performance_state_t
 * @brief GPU performance/power state
 */
typedef enum {
    GPU_STATE_P0,                        /**< Maximum performance */
    GPU_STATE_P1,                        /**< High performance */
    GPU_STATE_P2,                        /**< Balanced */
    GPU_STATE_P3,                        /**< Power saving */
    GPU_STATE_P4,                        /**< Minimum power */
    GPU_STATE_P5,                        /**< Deep sleep */
    GPU_STATE_P8,                        /**< Power gated */
    GPU_STATE_UNKNOWN                    /**< Unknown state */
} gpu_performance_state_t;

/**
 * @enum gpu_clock_type_t
 * @brief GPU clock domains
 */
typedef enum {
    GPU_CLOCK_GRAPHICS,                  /**< Graphics/core clock */
    GPU_CLOCK_MEMORY,                    /**< Memory clock */
    GPU_CLOCK_SHADER,                    /**< Shader clock */
    GPU_CLOCK_VIDEO,                     /**< Video decoder clock */
    GPU_CLOCK_SM,                        /**< Streaming Multiprocessor clock */
    GPU_CLOCK_BOOST,                     /**< Boost clock */
    GPU_CLOCK_BASE                       /**< Base clock */
} gpu_clock_type_t;

/**
 * @struct gpu_uuid_t
 * @brief GPU unique identifier (128-bit UUID)
 */
typedef struct {
    uint8_t bytes[16];                   /**< 16-byte UUID */
} gpu_uuid_t;

/**
 * @struct gpu_device_info_t
 * @brief Detailed GPU device information
 */
typedef struct {
    uint32_t device_index;               /**< Device index */
    gpu_uuid_t uuid;                     /**< Unique device identifier */
    gpu_vendor_t vendor;                 /**< GPU vendor */
    gpu_type_t type;                     /**< GPU type */
    char vendor_name[64];                /**< Vendor name string */
    char device_name[128];               /**< Device/model name */
    char driver_version[64];             /**< Driver version string */
    char bios_version[32];               /**< BIOS/VBIOS version */
    uint32_t pci_bus_id;                 /**< PCI bus ID */
    uint32_t pci_device_id;              /**< PCI device ID */
    uint32_t pci_subdevice_id;           /**< PCI subsystem ID */
    uint32_t architecture;               /**< GPU architecture version */
    uint32_t shader_cores;               /**< Number of shader cores */
    uint32_t tensor_cores;               /**< Number of tensor cores */
    uint32_t rt_cores;                   /**< Number of ray tracing cores */
    uint32_t sm_count;                   /**< Streaming Multiprocessor count */
    uint32_t cu_count;                   /**< Compute Unit count */
    uint32_t eu_count;                   /**< Execution Unit count */
    uint32_t max_work_group_size;        /**< Maximum work group size */
    uint32_t max_threads_per_block;      /**< Maximum threads per block */
    bool supports_virtual_memory;        /**< Virtual memory support */
    bool supports_synchronization;       /**< Synchronization primitives */
    bool supports_atomics;               /**< Atomic operations */
    bool supports_fp16;                  /**< Half-precision float support */
    bool supports_fp64;                  /**< Double-precision float support */
    bool supports_ray_tracing;           /**< Ray tracing support */
    bool supports_tensor_cores;          /**< Tensor core support */
    bool supports_multi_gpu;             /**< Multi-GPU support */
    uint32_t supported_apis;             /**< Bitmask of supported APIs */
} gpu_device_info_t;

/**
 * @struct gpu_memory_info_t
 * @brief GPU memory information
 */
typedef struct {
    uint64_t total_memory_bytes;         /**< Total memory in bytes */
    uint64_t free_memory_bytes;          /**< Free memory in bytes */
    uint64_t used_memory_bytes;          /**< Used memory in bytes */
    uint64_t shared_memory_bytes;        /**< Shared memory in bytes */
    uint64_t cached_memory_bytes;        /**< Cached memory in bytes */
    uint32_t memory_bus_width;           /**< Memory bus width in bits */
    uint32_t memory_bandwidth_gbps;      /**< Memory bandwidth in GB/s */
    gpu_memory_type_t memory_type;       /**< Type of memory */
    uint32_t memory_banks;               /**< Number of memory banks */
    uint32_t memory_ecc_supported;       /**< ECC memory support */
    uint32_t memory_ecc_enabled;         /**< ECC memory enabled */
    uint64_t memory_errors_corrected;    /**< Corrected memory errors */
    uint64_t memory_errors_uncorrected;  /**< Uncorrected memory errors */
} gpu_memory_info_t;

/**
 * @struct gpu_utilization_t
 * @brief GPU utilization metrics
 */
typedef struct {
    float gpu_utilization;               /**< GPU core utilization (0-100%) */
    float memory_utilization;            /**< Memory utilization (0-100%) */
    float encoder_utilization;           /**< Video encoder utilization */
    float decoder_utilization;           /**< Video decoder utilization */
    float compute_utilization;           /**< Compute utilization */
    float pcie_utilization;              /**< PCIe bus utilization */
    float render_utilization;            /**< Render engine utilization */
    float tensor_utilization;            /**< Tensor core utilization */
    uint64_t active_warps;               /**< Active warps/SIMD */
    uint64_t issued_warps;               /**< Issued warps */
    uint64_t stalled_warps;              /**< Stalled warps */
} gpu_utilization_t;

/**
 * @struct gpu_temperature_t
 * @brief GPU temperature readings
 */
typedef struct {
    float gpu_core_temp;                 /**< GPU core temperature (°C) */
    float memory_temp;                   /**< Memory temperature (°C) */
    float hotspot_temp;                  /**< GPU hotspot temperature (°C) */
    float pcb_temp;                      /**< PCB temperature (°C) */
    float vr_temp;                       /**< Voltage regulator temp (°C) */
    float ambient_temp;                  /**< Ambient temperature (°C) */
    float max_operating_temp;            /**< Maximum operating temp (°C) */
    float throttle_temp;                 /**< Throttling temperature (°C) */
    float shutdown_temp;                 /**< Shutdown temperature (°C) */
    bool is_throttling;                  /**< Is GPU thermal throttling? */
    uint32_t throttle_reason;            /**< Throttling reason bitmask */
} gpu_temperature_t;

/**
 * @struct gpu_clock_info_t
 * @brief GPU clock frequency information
 */
typedef struct {
    uint32_t graphics_clock_mhz;         /**< Current graphics clock (MHz) */
    uint32_t memory_clock_mhz;           /**< Current memory clock (MHz) */
    uint32_t shader_clock_mhz;           /**< Current shader clock (MHz) */
    uint32_t video_clock_mhz;            /**< Current video clock (MHz) */
    uint32_t sm_clock_mhz;               /**< Current SM clock (MHz) */
    uint32_t base_clock_mhz;             /**< Base clock (MHz) */
    uint32_t boost_clock_mhz;            /**< Boost clock (MHz) */
    uint32_t max_clock_mhz;              /**< Maximum clock (MHz) */
    uint32_t min_clock_mhz;              /**< Minimum clock (MHz) */
    bool is_boost_active;                /**< Is boost clock active? */
    float clock_limit_factor;            /**< Clock limit factor (0.0-1.0) */
} gpu_clock_info_t;

/**
 * @struct gpu_power_info_t
 * @brief GPU power information
 */
typedef struct {
    float current_power_watts;           /**< Current power draw (W) */
    float power_limit_watts;             /**< Power limit (W) */
    float min_power_limit_watts;         /**< Minimum power limit (W) */
    float max_power_limit_watts;         /**< Maximum power limit (W) */
    float default_power_limit_watts;     /**< Default power limit (W) */
    float energy_consumed_kwh;           /**< Total energy consumed (kWh) */
    float power_usage_percent;           /**< Power usage percentage */
    gpu_power_source_t power_source;     /**< Current power source */
    uint32_t pcie_power_watts;           /**< PCIe slot power (W) */
    uint32_t external_power_watts;       /**< External power (W) */
    bool is_power_limited;               /**< Is GPU power limited? */
    uint32_t power_state;                /**< Current power state */
} gpu_power_info_t;

/**
 * @struct gpu_fan_info_t
 * @brief GPU fan information
 */
typedef struct {
    uint32_t fan_count;                  /**< Number of fans */
    uint32_t fan_speed_rpm[GPU_MAX_FAN_COUNT]; /**< Fan speeds in RPM */
    uint32_t fan_speed_percent[GPU_MAX_FAN_COUNT]; /**< Fan speeds in % */
    uint32_t target_fan_speed;           /**< Target fan speed (%) */
    uint32_t min_fan_speed;              /**< Minimum fan speed (%) */
    uint32_t max_fan_speed;              /**< Maximum fan speed (%) */
    bool fan_control_supported;          /**< Manual fan control supported */
    bool fan_control_enabled;            /**< Manual fan control enabled */
    float fan_power_watts;               /**< Fan power consumption (W) */
} gpu_fan_info_t;

/**
 * @struct gpu_process_info_t
 * @brief Process using GPU
 */
typedef struct {
    uint32_t pid;                        /**< Process ID */
    char process_name[256];              /**< Process name */
    uint64_t gpu_memory_used;            /**< GPU memory used by process */
    uint64_t shared_memory_used;         /**< Shared memory used */
    float gpu_utilization;               /**< GPU utilization by process */
    float memory_utilization;            /**< Memory utilization by process */
    uint64_t gpu_time_ms;                /**< GPU time used (ms) */
    uint32_t sm_occupancy;               /**< SM occupancy percentage */
    uint64_t allocated_memory_objects;   /**< Number of memory objects */
    uint64_t kernel_launches;            /**< Number of kernel launches */
} gpu_process_info_t;

/**
 * @struct gpu_performance_metrics_t
 * @brief Comprehensive GPU performance metrics
 */
typedef struct {
    uint32_t device_index;               /**< GPU device index */
    uint64_t timestamp_ns;               /**< Sample timestamp (ns) */
    gpu_utilization_t utilization;       /**< Utilization metrics */
    gpu_memory_info_t memory;            /**< Memory metrics */
    gpu_temperature_t temperature;       /**< Temperature metrics */
    gpu_clock_info_t clocks;             /**< Clock metrics */
    gpu_power_info_t power;              /**< Power metrics */
    gpu_fan_info_t fans;                 /**< Fan metrics */
    uint64_t frames_rendered;            /**< Frames rendered */
    uint64_t frame_time_ms;              /**< Frame time in ms */
    uint64_t draw_calls;                 /**< Number of draw calls */
    uint64_t triangles_rendered;         /**< Triangles rendered */
    uint64_t pixels_rendered;            /**< Pixels rendered */
    uint32_t vram_bandwidth_utilization; /**< VRAM bandwidth utilization */
    uint32_t pcie_bandwidth_utilization; /**< PCIe bandwidth utilization */
    uint64_t cache_hits;                 /**< Cache hits */
    uint64_t cache_misses;               /**< Cache misses */
    float cache_hit_rate;                /**< Cache hit rate */
} gpu_performance_metrics_t;

/**
 * @struct gpu_config_t
 * @brief GPU monitor configuration
 */
typedef struct {
    uint32_t sample_interval_ms;         /**< Sampling interval in ms */
    bool enable_power_monitoring;        /**< Enable power monitoring */
    bool enable_temperature_monitoring;  /**< Enable temperature monitoring */
    bool enable_clock_monitoring;        /**< Enable clock monitoring */
    bool enable_fan_monitoring;          /**< Enable fan monitoring */
    bool enable_process_monitoring;      /**< Enable process monitoring */
    bool enable_performance_counters;    /**< Enable performance counters */
    bool enable_vulkan_support;          /**< Enable Vulkan support */
    bool enable_cuda_support;            /**< Enable CUDA support */
    bool enable_opencl_support;          /**< Enable OpenCL support */
    float critical_temperature;          /**< Critical temperature threshold */
    float warning_temperature;           /**< Warning temperature threshold */
    float critical_power_limit;          /**< Critical power threshold */
    float warning_power_limit;           /**< Warning power threshold */
    uint32_t max_samples_stored;         /**< Maximum samples to store */
    void* user_context;                  /**< User-defined context */
    void (*alert_callback)(uint32_t gpu_index, const char* message, void* context);
} gpu_config_t;

/**
 * @struct gpu_handle_t
 * @brief Opaque handle for GPU monitor instance
 */
typedef struct gpu_handle gpu_handle_t;

// ============================================================================
// Initialization and Configuration
// ============================================================================

/**
 * @brief Initialize GPU monitoring system
 * 
 * @param config Pointer to configuration structure (NULL for defaults)
 * @param handle Output parameter for GPU handle
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_init(const gpu_config_t* config, gpu_handle_t** handle);

/**
 * @brief Get default configuration for GPU monitor
 * 
 * @param config Output parameter for default configuration
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_get_default_config(gpu_config_t* config);

/**
 * @brief Detect available GPUs
 * 
 * @param handle GPU handle
 * @param device_count Output parameter for number of GPUs found
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_detect_devices(gpu_handle_t* handle, uint32_t* device_count);

/**
 * @brief Start GPU monitoring
 * 
 * @param handle GPU handle
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_start_monitoring(gpu_handle_t* handle);

/**
 * @brief Stop GPU monitoring
 * 
 * @param handle GPU handle
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_stop_monitoring(gpu_handle_t* handle);

/**
 * @brief Clean up GPU monitoring resources
 * 
 * @param handle GPU handle
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_deinit(gpu_handle_t* handle);

// ============================================================================
// Device Information
// ============================================================================

/**
 * @brief Get GPU device information
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param info Output parameter for device information
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_get_device_info(gpu_handle_t* handle, uint32_t device_index, 
                                gpu_device_info_t* info);

/**
 * @brief Get number of detected GPUs
 * 
 * @param handle GPU handle
 * @param count Output parameter for GPU count
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_get_device_count(gpu_handle_t* handle, uint32_t* count);

/**
 * @brief Get GPU UUID
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param uuid Output parameter for UUID
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_get_uuid(gpu_handle_t* handle, uint32_t device_index, 
                         gpu_uuid_t* uuid);

/**
 * @brief Get GPU driver information
 * 
 * @param handle GPU handle
 * @param driver_version Output parameter for driver version
 * @param driver_date Output parameter for driver date
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_get_driver_info(gpu_handle_t* handle, char* driver_version,
                                char* driver_date);

// ============================================================================
// Performance Monitoring
// ============================================================================

/**
 * @brief Get current GPU performance metrics
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param metrics Output parameter for performance metrics
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_get_performance_metrics(gpu_handle_t* handle, uint32_t device_index,
                                        gpu_performance_metrics_t* metrics);

/**
 * @brief Get GPU utilization
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param utilization Output parameter for utilization
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_get_utilization(gpu_handle_t* handle, uint32_t device_index,
                                gpu_utilization_t* utilization);

/**
 * @brief Get GPU memory information
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param memory Output parameter for memory info
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_get_memory_info(gpu_handle_t* handle, uint32_t device_index,
                                gpu_memory_info_t* memory);

/**
 * @brief Get GPU temperature
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param temperature Output parameter for temperature
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_get_temperature(gpu_handle_t* handle, uint32_t device_index,
                                gpu_temperature_t* temperature);

/**
 * @brief Get GPU clock information
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param clocks Output parameter for clock info
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_get_clock_info(gpu_handle_t* handle, uint32_t device_index,
                               gpu_clock_info_t* clocks);

/**
 * @brief Get GPU power information
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param power Output parameter for power info
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_get_power_info(gpu_handle_t* handle, uint32_t device_index,
                               gpu_power_info_t* power);

/**
 * @brief Get GPU fan information
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param fans Output parameter for fan info
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_get_fan_info(gpu_handle_t* handle, uint32_t device_index,
                             gpu_fan_info_t* fans);

// ============================================================================
// Performance Control
// ============================================================================

/**
 * @brief Set GPU power limit
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param power_limit_watts Power limit in watts
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_set_power_limit(gpu_handle_t* handle, uint32_t device_index,
                                float power_limit_watts);

/**
 * @brief Set GPU temperature limit
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param temperature_limit_c Temperature limit in Celsius
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_set_temperature_limit(gpu_handle_t* handle, uint32_t device_index,
                                      float temperature_limit_c);

/**
 * @brief Set GPU clock offset
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param clock_type Clock type to adjust
 * @param offset_mhz Clock offset in MHz
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_set_clock_offset(gpu_handle_t* handle, uint32_t device_index,
                                 gpu_clock_type_t clock_type, int32_t offset_mhz);

/**
 * @brief Set GPU fan speed
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param fan_index Fan index (0 for all fans)
 * @param speed_percent Fan speed percentage (0-100)
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_set_fan_speed(gpu_handle_t* handle, uint32_t device_index,
                              uint32_t fan_index, uint32_t speed_percent);

/**
 * @brief Set GPU performance state
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param performance_state Performance state to set
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_set_performance_state(gpu_handle_t* handle, uint32_t device_index,
                                      gpu_performance_state_t performance_state);

/**
 * @brief Reset GPU to default settings
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_reset_to_defaults(gpu_handle_t* handle, uint32_t device_index);

// ============================================================================
// Process Management
// ============================================================================

/**
 * @brief Get processes using GPU
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param processes Array to store process info
 * @param max_processes Maximum processes to retrieve
 * @param actual_count Output parameter for actual count
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_get_processes(gpu_handle_t* handle, uint32_t device_index,
                              gpu_process_info_t* processes, uint32_t max_processes,
                              uint32_t* actual_count);

/**
 * @brief Kill process using GPU
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param pid Process ID to kill
 * @param force Force kill if true
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_kill_process(gpu_handle_t* handle, uint32_t device_index,
                             uint32_t pid, bool force);

/**
 * @brief Get GPU context for current process
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param context_id Output parameter for context ID
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_get_current_context(gpu_handle_t* handle, uint32_t device_index,
                                    uint64_t* context_id);

// ============================================================================
// Memory Management
// ============================================================================

/**
 * @brief Get GPU memory usage by process
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param pid Process ID
 * @param memory_used Output parameter for memory used
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_get_process_memory_usage(gpu_handle_t* handle, uint32_t device_index,
                                         uint32_t pid, uint64_t* memory_used);

/**
 * @brief Clear GPU memory cache
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_clear_memory_cache(gpu_handle_t* handle, uint32_t device_index);

/**
 * @brief Allocate GPU memory (for testing/diagnostics)
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param size_bytes Size to allocate in bytes
 * @param allocated_ptr Output parameter for allocated pointer
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_allocate_memory(gpu_handle_t* handle, uint32_t device_index,
                                uint64_t size_bytes, void** allocated_ptr);

/**
 * @brief Free allocated GPU memory
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param ptr Pointer to free
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_free_memory(gpu_handle_t* handle, uint32_t device_index, void* ptr);

// ============================================================================
// Diagnostics and Health
// ============================================================================

/**
 * @brief Run GPU diagnostic tests
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param test_type Bitmask of tests to run
 * @param results Output parameter for test results
 * @param results_size Size of results buffer
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_run_diagnostics(gpu_handle_t* handle, uint32_t device_index,
                                uint32_t test_type, char* results,
                                size_t results_size);

/**
 * @brief Check GPU health status
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param health_score Output parameter for health score (0-100)
 * @param issues Output parameter for issues found
 * @param max_issues Maximum issues to report
 * @param actual_issues Output parameter for actual issues
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_check_health(gpu_handle_t* handle, uint32_t device_index,
                             uint32_t* health_score, char** issues,
                             uint32_t max_issues, uint32_t* actual_issues);

/**
 * @brief Get GPU error information
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param errors Array to store errors
 * @param max_errors Maximum errors to retrieve
 * @param actual_errors Output parameter for actual errors
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_get_errors(gpu_handle_t* handle, uint32_t device_index,
                           char** errors, uint32_t max_errors,
                           uint32_t* actual_errors);

/**
 * @brief Reset GPU device
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param reset_type Type of reset to perform
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_reset_device(gpu_handle_t* handle, uint32_t device_index,
                             uint32_t reset_type);

// ============================================================================
// Multi-GPU and SLI/CrossFire
// ============================================================================

/**
 * @brief Get multi-GPU configuration
 * 
 * @param handle GPU handle
 * @param config Output parameter for multi-GPU config
 * @param config_size Size of config buffer
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_get_multi_gpu_config(gpu_handle_t* handle, char* config,
                                     size_t config_size);

/**
 * @brief Enable SLI/CrossFire
 * 
 * @param handle GPU handle
 * @param enable Enable or disable multi-GPU
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_enable_multi_gpu(gpu_handle_t* handle, bool enable);

/**
 * @brief Get GPU affinity mask
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param affinity_mask Output parameter for affinity mask
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_get_affinity_mask(gpu_handle_t* handle, uint32_t device_index,
                                  uint64_t* affinity_mask);

/**
 * @brief Set GPU affinity
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param affinity_mask Affinity mask to set
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_set_affinity(gpu_handle_t* handle, uint32_t device_index,
                             uint64_t affinity_mask);

// ============================================================================
// Graphics API Integration
// ============================================================================

/**
 * @brief Initialize graphics API support
 * 
 * @param handle GPU handle
 * @param api Graphics API to initialize
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_init_api(gpu_handle_t* handle, gpu_api_t api);

/**
 * @brief Get graphics API context
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param api Graphics API
 * @param context Output parameter for API context
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_get_api_context(gpu_handle_t* handle, uint32_t device_index,
                                gpu_api_t api, void** context);

/**
 * @brief Query graphics API capabilities
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param api Graphics API
 * @param capabilities Output parameter for capabilities
 * @param caps_size Size of capabilities buffer
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_query_api_capabilities(gpu_handle_t* handle, uint32_t device_index,
                                       gpu_api_t api, char* capabilities,
                                       size_t caps_size);

// ============================================================================
// Inline Utility Functions
// ============================================================================

/**
 * @brief Check if GPU monitoring is active
 * 
 * @param handle GPU handle to check
 * @return true if monitoring is active, false otherwise
 */
static inline bool gpu_is_monitoring_active(const gpu_handle_t* handle) {
    return (handle != NULL);
}

/**
 * @brief Convert bytes to gigabytes
 * 
 * @param bytes Number of bytes
 * @return Size in gigabytes
 */
static inline double gpu_bytes_to_gb(uint64_t bytes) {
    return (double)bytes / (1024.0 * 1024.0 * 1024.0);
}

/**
 * @brief Convert megabytes to gigabytes
 * 
 * @param mb Number of megabytes
 * @return Size in gigabytes
 */
static inline double gpu_mb_to_gb(uint32_t mb) {
    return (double)mb / 1024.0;
}

/**
 * @brief Convert Celsius to Fahrenheit
 * 
 * @param celsius Temperature in Celsius
 * @return Temperature in Fahrenheit
 */
static inline float gpu_celsius_to_fahrenheit(float celsius) {
    return (celsius * 9.0f / 5.0f) + 32.0f;
}

/**
 * @brief Calculate power efficiency (performance per watt)
 * 
 * @param performance_score Performance score (0-100)
 * @param power_watts Power consumption in watts
 * @return Efficiency score
 */
static inline float gpu_calculate_efficiency(float performance_score, float power_watts) {
    if (power_watts < 0.1f) return 0.0f;
    return performance_score / power_watts;
}

/**
 * @brief Get API version string
 * 
 * @return const char* Version string
 */
static inline const char* gpu_get_api_version_string(void) {
    return "3.2.0";
}

// ============================================================================
// Platform-Specific Extensions
// ============================================================================

#if defined(_WIN32)
/**
 * @brief Get DirectX GPU information (Windows only)
 * 
 * @param handle GPU handle
 * @param dx_info Output parameter for DirectX info
 * @param info_size Size of info buffer
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_get_directx_info(gpu_handle_t* handle, char* dx_info,
                                 size_t info_size);
#endif

#if defined(__linux__)
/**
 * @brief Get DRM/KMS GPU information (Linux only)
 * 
 * @param handle GPU handle
 * @param device_index GPU device index
 * @param drm_info Output parameter for DRM info
 * @param info_size Size of info buffer
 * @return gpu_status_t Status code
 */
gpu_status_t gpu_get_drm_info(gpu_handle_t* handle, uint32_t device_index,
                             char* drm_info, size_t info_size);
#endif

// ============================================================================
// Export Macros for Shared Libraries
// ============================================================================
#ifdef BUILDING_GPU_DLL
    #define GPU_API __declspec(dllexport)
#elif defined(USING_GPU_DLL)
    #define GPU_API __declspec(dllimport)
#else
    #define GPU_API
#endif

#ifdef __cplusplus
}
#endif

#endif // GPU_H

// ============================================================================
// Implementation Notes:
// ============================================================================
// 1. Thread Safety: Designed for concurrent access from multiple threads
// 2. Memory Management: Resources are managed internally; use deinit() to clean up
// 3. Error Handling: Always check return codes for error conditions
// 4. Platform Support: Cross-platform with vendor-specific extensions
// 5. Performance: Minimal overhead for real-time monitoring
// 6. Scalability: Supports up to 32 GPUs with per-GPU metrics
// 7. Extensibility: New APIs and features can be added without breaking changes