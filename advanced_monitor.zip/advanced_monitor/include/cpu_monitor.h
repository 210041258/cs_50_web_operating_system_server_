/**
 * @file cpu_monitor.h
 * @brief CPU Performance Monitoring and Management Module
 * 
 * This module provides comprehensive CPU monitoring capabilities including
 * usage metrics, temperature tracking, frequency scaling, and alerting.
 * Designed for cross-platform system monitoring and performance optimization.
 * 
 * @author System Monitoring Team
 * @date 2024-01-31
 * @version 2.1.0
 * 
 * @license Apache 2.0
 * @copyright Copyright (c) 2024 System Monitoring Solutions
 */

#ifndef CPU_MONITOR_H
#define CPU_MONITOR_H

#ifdef __cplusplus
extern "C" {
#endif

// ============================================================================
// Includes and Dependencies
// ============================================================================
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <time.h>

#if defined(_WIN32) || defined(_WIN64)
    #include <windows.h>
    #define CPU_MONITOR_PLATFORM_WINDOWS 1
#elif defined(__linux__) || defined(__unix__)
    #include <unistd.h>
    #include <sys/types.h>
    #define CPU_MONITOR_PLATFORM_LINUX 1
#elif defined(__APPLE__) && defined(__MACH__)
    #include <mach/mach.h>
    #define CPU_MONITOR_PLATFORM_MACOS 1
#else
    #error "Unsupported platform for CPU monitoring"
#endif

// ============================================================================
// Configuration Constants
// ============================================================================
/**
 * @def CPU_MONITOR_VERSION_MAJOR
 * @brief Major version number
 */
#define CPU_MONITOR_VERSION_MAJOR 2

/**
 * @def CPU_MONITOR_VERSION_MINOR
 * @brief Minor version number
 */
#define CPU_MONITOR_VERSION_MINOR 1

/**
 * @def CPU_MONITOR_VERSION_PATCH
 * @brief Patch version number
 */
#define CPU_MONITOR_VERSION_PATCH 0

/**
 * @def CPU_MONITOR_MAX_CORES
 * @brief Maximum number of CPU cores supported
 */
#define CPU_MONITOR_MAX_CORES 256

/**
 * @def CPU_MONITOR_MAX_THREADS
 * @brief Maximum number of threads per core
 */
#define CPU_MONITOR_MAX_THREADS 2

/**
 * @def CPU_MONITOR_SAMPLE_BUFFER_SIZE
 * @brief Size of historical data buffer
 */
#define CPU_MONITOR_SAMPLE_BUFFER_SIZE 3600  // 1 hour at 1 sample/sec

/**
 * @def CPU_MONITOR_DEFAULT_SAMPLE_INTERVAL_MS
 * @brief Default sampling interval in milliseconds
 */
#define CPU_MONITOR_DEFAULT_SAMPLE_INTERVAL_MS 1000

// ============================================================================
// Type Definitions
// ============================================================================

/**
 * @enum cpu_monitor_status_t
 * @brief Status codes for CPU monitor operations
 */
typedef enum {
    CPU_MONITOR_SUCCESS = 0,              /**< Operation successful */
    CPU_MONITOR_ERROR_INIT_FAILED,        /**< Initialization failed */
    CPU_MONITOR_ERROR_INVALID_PARAM,      /**< Invalid parameter */
    CPU_MONITOR_ERROR_NOT_INITIALIZED,    /**< Monitor not initialized */
    CPU_MONITOR_ERROR_PLATFORM_UNSUPPORTED, /**< Platform not supported */
    CPU_MONITOR_ERROR_PERMISSION_DENIED,  /**< Insufficient permissions */
    CPU_MONITOR_ERROR_SAMPLING_FAILED,    /**< Failed to sample CPU data */
    CPU_MONITOR_ERROR_THREAD_CREATE,      /**< Failed to create monitoring thread */
    CPU_MONITOR_ERROR_BUFFER_FULL,        /**< Data buffer full */
    CPU_MONITOR_ERROR_TEMP_UNAVAILABLE,   /**< Temperature data unavailable */
    CPU_MONITOR_ERROR_FREQ_UNAVAILABLE,   /**< Frequency data unavailable */
    CPU_MONITOR_ERROR_TIMEOUT,            /**< Operation timeout */
    CPU_MONITOR_ERROR_OUT_OF_MEMORY       /**< Memory allocation failed */
} cpu_monitor_status_t;

/**
 * @enum cpu_architecture_t
 * @brief CPU architecture types
 */
typedef enum {
    CPU_ARCH_X86,
    CPU_ARCH_X86_64,
    CPU_ARCH_ARM,
    CPU_ARCH_ARM64,
    CPU_ARCH_POWERPC,
    CPU_ARCH_POWERPC64,
    CPU_ARCH_MIPS,
    CPU_ARCH_RISCV,
    CPU_ARCH_UNKNOWN
} cpu_architecture_t;

/**
 * @enum cpu_vendor_t
 * @brief CPU vendor/manufacturer
 */
typedef enum {
    CPU_VENDOR_INTEL,
    CPU_VENDOR_AMD,
    CPU_VENDOR_ARM,
    CPU_VENDOR_APPLE,
    CPU_VENDOR_QUALCOMM,
    CPU_VENDOR_SAMSUNG,
    CPU_VENDOR_UNKNOWN
} cpu_vendor_t;

/**
 * @enum alert_severity_t
 * @brief Alert severity levels
 */
typedef enum {
    ALERT_SEVERITY_INFO,      /**< Informational alert */
    ALERT_SEVERITY_WARNING,   /**< Warning condition */
    ALERT_SEVERITY_CRITICAL,  /**< Critical condition */
    ALERT_SEVERITY_EMERGENCY  /**< Emergency/System failure */
} alert_severity_t;

/**
 * @struct cpu_core_info_t
 * @brief Information about a single CPU core
 */
typedef struct {
    uint32_t core_id;                 /**< Core identifier */
    uint32_t physical_id;             /**< Physical CPU identifier */
    uint32_t siblings;                /**< Number of sibling threads */
    uint32_t cpu_family;              /**< CPU family */
    uint32_t model;                   /**< CPU model */
    uint32_t stepping;                /**< Stepping/revision */
    char model_name[64];              /**< CPU model name string */
} cpu_core_info_t;

/**
 * @struct cpu_usage_sample_t
 * @brief CPU usage sample for a single core
 */
typedef struct {
    uint64_t user_time;               /**< Time spent in user mode (ticks) */
    uint64_t system_time;             /**< Time spent in system mode (ticks) */
    uint64_t idle_time;               /**< Time spent idle (ticks) */
    uint64_t iowait_time;             /**< Time spent waiting for I/O (ticks) */
    uint64_t irq_time;                /**< Time spent handling interrupts */
    uint64_t softirq_time;            /**< Time spent handling soft interrupts */
    uint64_t steal_time;              /**< Time stolen by hypervisor */
    uint64_t total_time;              /**< Total time since last sample */
    double usage_percent;             /**< CPU usage percentage (0-100) */
    uint64_t timestamp_ns;            /**< Sample timestamp in nanoseconds */
} cpu_usage_sample_t;

/**
 * @struct cpu_temperature_t
 * @brief CPU temperature reading
 */
typedef struct {
    uint32_t sensor_id;               /**< Temperature sensor ID */
    float temperature_c;              /**< Temperature in Celsius */
    float temperature_f;              /**< Temperature in Fahrenheit */
    float temperature_k;              /**< Temperature in Kelvin */
    float critical_threshold;         /**< Critical temperature threshold */
    float warning_threshold;          /**< Warning temperature threshold */
    bool is_valid;                    /**< Is temperature reading valid? */
} cpu_temperature_t;

/**
 * @struct cpu_frequency_t
 * @brief CPU frequency information
 */
typedef struct {
    uint64_t current_freq_hz;         /**< Current frequency in Hz */
    uint64_t min_freq_hz;             /**< Minimum frequency in Hz */
    uint64_t max_freq_hz;             /**< Maximum frequency in Hz */
    uint64_t base_freq_hz;            /**< Base frequency in Hz */
    uint64_t turbo_freq_hz;           /**< Turbo frequency in Hz */
    float scaling_factor;             /**< Frequency scaling factor (0.0-1.0) */
    uint32_t governor_id;             /**< CPU frequency governor ID */
} cpu_frequency_t;

/**
 * @struct cpu_cache_info_t
 * @brief CPU cache information
 */
typedef struct {
    uint32_t level;                   /**< Cache level (L1, L2, L3) */
    uint32_t size_kb;                 /**< Cache size in KB */
    uint32_t line_size_bytes;         /**< Cache line size in bytes */
    uint32_t associativity;           /**< Cache associativity */
    bool is_shared;                   /**< Is cache shared between cores? */
    uint32_t shared_cores;            /**< Number of cores sharing cache */
} cpu_cache_info_t;

/**
 * @struct cpu_metrics_t
 * @brief Comprehensive CPU metrics
 */
typedef struct {
    uint32_t core_count;              /**< Total number of CPU cores */
    uint32_t thread_count;            /**< Total number of threads */
    double overall_usage;             /**< Overall CPU usage percentage */
    double user_usage;                /**< User-space CPU usage percentage */
    double system_usage;              /**< Kernel-space CPU usage percentage */
    double idle_percentage;           /**< Idle time percentage */
    double load_average_1m;           /**< 1-minute load average */
    double load_average_5m;           /**< 5-minute load average */
    double load_average_15m;          /**< 15-minute load average */
    uint64_t context_switches;        /**< Context switches per second */
    uint64_t interrupts;              /**< Interrupts per second */
    uint64_t soft_interrupts;         /**< Soft interrupts per second */
    uint64_t processes_created;       /**< Processes created per second */
} cpu_metrics_t;

/**
 * @struct cpu_alert_t
 * @brief CPU alert/notification
 */
typedef struct {
    char alert_id[64];                /**< Unique alert identifier */
    alert_severity_t severity;        /**< Alert severity level */
    time_t timestamp;                 /**< Alert timestamp */
    uint32_t core_id;                 /**< Core that triggered alert (-1 for all) */
    char message[256];                /**< Alert message */
    double threshold_value;           /**< Threshold value */
    double current_value;             /**< Current value */
    bool is_acknowledged;             /**< Has alert been acknowledged? */
} cpu_alert_t;

/**
 * @struct cpu_monitor_config_t
 * @brief CPU monitor configuration
 */
typedef struct {
    uint32_t sample_interval_ms;      /**< Sampling interval in milliseconds */
    uint32_t buffer_size;             /**< Historical data buffer size */
    bool enable_temperature;          /**< Enable temperature monitoring */
    bool enable_frequency;            /**< Enable frequency monitoring */
    bool enable_per_core_stats;       /**< Enable per-core statistics */
    bool enable_alerts;               /**< Enable alert system */
    double critical_temp_threshold;   /**< Critical temperature threshold (°C) */
    double warning_temp_threshold;    /**< Warning temperature threshold (°C) */
    double critical_usage_threshold;  /**< Critical CPU usage threshold (%) */
    double warning_usage_threshold;   /**< Warning CPU usage threshold (%) */
    uint32_t max_alert_history;       /**< Maximum alert history entries */
    void* user_context;               /**< User-defined context pointer */
    void (*alert_callback)(cpu_alert_t* alert, void* context); /**< Alert callback */
} cpu_monitor_config_t;

/**
 * @struct cpu_monitor_handle_t
 * @brief Opaque handle for CPU monitor instance
 */
typedef struct cpu_monitor_handle cpu_monitor_handle_t;

// ============================================================================
// Initialization and Configuration
// ============================================================================

/**
 * @brief Initialize CPU monitoring system
 * 
 * @param config Pointer to configuration structure (NULL for defaults)
 * @param handle Output parameter for monitor handle
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_init(const cpu_monitor_config_t* config, 
                                     cpu_monitor_handle_t** handle);

/**
 * @brief Get default configuration for CPU monitor
 * 
 * @param config Output parameter for default configuration
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_get_default_config(cpu_monitor_config_t* config);

/**
 * @brief Start CPU monitoring
 * 
 * Begins continuous monitoring in background thread
 * 
 * @param handle Initialized monitor handle
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_start(cpu_monitor_handle_t* handle);

/**
 * @brief Stop CPU monitoring
 * 
 * Stops background monitoring thread
 * 
 * @param handle Monitor handle
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_stop(cpu_monitor_handle_t* handle);

/**
 * @brief Clean up and deinitialize CPU monitor
 * 
 * @param handle Monitor handle to deinitialize
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_deinit(cpu_monitor_handle_t* handle);

// ============================================================================
// System Information
// ============================================================================

/**
 * @brief Get CPU architecture information
 * 
 * @param handle Monitor handle
 * @param arch Output parameter for architecture
 * @param vendor Output parameter for vendor
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_get_architecture(cpu_monitor_handle_t* handle,
                                                 cpu_architecture_t* arch,
                                                 cpu_vendor_t* vendor);

/**
 * @brief Get total number of CPU cores
 * 
 * @param handle Monitor handle
 * @param core_count Output parameter for core count
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_get_core_count(cpu_monitor_handle_t* handle,
                                               uint32_t* core_count);

/**
 * @brief Get detailed information about a specific core
 * 
 * @param handle Monitor handle
 * @param core_id Core identifier (0-based)
 * @param info Output parameter for core information
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_get_core_info(cpu_monitor_handle_t* handle,
                                              uint32_t core_id,
                                              cpu_core_info_t* info);

/**
 * @brief Get CPU cache information
 * 
 * @param handle Monitor handle
 * @param cache_level Cache level (1, 2, 3)
 * @param cache_info Array to store cache info
 * @param max_entries Maximum entries in array
 * @param actual_entries Output parameter for actual entries found
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_get_cache_info(cpu_monitor_handle_t* handle,
                                               uint32_t cache_level,
                                               cpu_cache_info_t* cache_info,
                                               uint32_t max_entries,
                                               uint32_t* actual_entries);

// ============================================================================
// Real-time Monitoring
// ============================================================================

/**
 * @brief Get current CPU usage metrics
 * 
 * @param handle Monitor handle
 * @param metrics Output parameter for CPU metrics
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_get_metrics(cpu_monitor_handle_t* handle,
                                            cpu_metrics_t* metrics);

/**
 * @brief Get per-core CPU usage
 * 
 * @param handle Monitor handle
 * @param core_samples Array to store core samples
 * @param max_cores Maximum cores to retrieve
 * @param actual_cores Output parameter for actual cores retrieved
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_get_per_core_usage(cpu_monitor_handle_t* handle,
                                                   cpu_usage_sample_t* core_samples,
                                                   uint32_t max_cores,
                                                   uint32_t* actual_cores);

/**
 * @brief Get CPU temperature readings
 * 
 * @param handle Monitor handle
 * @param temperatures Array to store temperature readings
 * @param max_sensors Maximum sensors to retrieve
 * @param actual_sensors Output parameter for actual sensors found
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_get_temperatures(cpu_monitor_handle_t* handle,
                                                 cpu_temperature_t* temperatures,
                                                 uint32_t max_sensors,
                                                 uint32_t* actual_sensors);

/**
 * @brief Get CPU frequency information
 * 
 * @param handle Monitor handle
 * @param frequencies Array to store frequency info
 * @param max_cores Maximum cores to retrieve
 * @param actual_cores Output parameter for actual cores retrieved
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_get_frequencies(cpu_monitor_handle_t* handle,
                                                cpu_frequency_t* frequencies,
                                                uint32_t max_cores,
                                                uint32_t* actual_cores);

/**
 * @brief Force immediate sample collection
 * 
 * @param handle Monitor handle
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_sample_now(cpu_monitor_handle_t* handle);

// ============================================================================
// Historical Data and Statistics
// ============================================================================

/**
 * @brief Get historical CPU usage data
 * 
 * @param handle Monitor handle
 * @param buffer Array to store historical samples
 * @param max_samples Maximum samples to retrieve
 * @param start_time Start timestamp (0 for all available)
 * @param end_time End timestamp (0 for current time)
 * @param actual_samples Output parameter for actual samples retrieved
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_get_history(cpu_monitor_handle_t* handle,
                                            cpu_usage_sample_t* buffer,
                                            uint32_t max_samples,
                                            time_t start_time,
                                            time_t end_time,
                                            uint32_t* actual_samples);

/**
 * @brief Calculate CPU usage statistics
 * 
 * @param handle Monitor handle
 * @param start_time Start timestamp for analysis
 * @param end_time End timestamp for analysis
 * @param avg_usage Output parameter for average usage
 * @param max_usage Output parameter for maximum usage
 * @param min_usage Output parameter for minimum usage
 * @param std_dev Output parameter for standard deviation
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_calculate_statistics(cpu_monitor_handle_t* handle,
                                                     time_t start_time,
                                                     time_t end_time,
                                                     double* avg_usage,
                                                     double* max_usage,
                                                     double* min_usage,
                                                     double* std_dev);

// ============================================================================
// Alert Management
// ============================================================================

/**
 * @brief Set CPU usage alert threshold
 * 
 * @param handle Monitor handle
 * @param core_id Core identifier (-1 for all cores)
 * @param threshold Usage threshold (0-100%)
 * @param severity Alert severity level
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_set_usage_alert(cpu_monitor_handle_t* handle,
                                                int32_t core_id,
                                                double threshold,
                                                alert_severity_t severity);

/**
 * @brief Set temperature alert threshold
 * 
 * @param handle Monitor handle
 * @param sensor_id Sensor identifier (-1 for all sensors)
 * @param threshold Temperature threshold (°C)
 * @param severity Alert severity level
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_set_temperature_alert(cpu_monitor_handle_t* handle,
                                                      int32_t sensor_id,
                                                      double threshold,
                                                      alert_severity_t severity);

/**
 * @brief Get pending alerts
 * 
 * @param handle Monitor handle
 * @param alerts Array to store alerts
 * @param max_alerts Maximum alerts to retrieve
 * @param actual_alerts Output parameter for actual alerts found
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_get_alerts(cpu_monitor_handle_t* handle,
                                           cpu_alert_t* alerts,
                                           uint32_t max_alerts,
                                           uint32_t* actual_alerts);

/**
 * @brief Acknowledge an alert
 * 
 * @param handle Monitor handle
 * @param alert_id Alert identifier
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_acknowledge_alert(cpu_monitor_handle_t* handle,
                                                  const char* alert_id);

/**
 * @brief Clear all alerts
 * 
 * @param handle Monitor handle
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_clear_alerts(cpu_monitor_handle_t* handle);

// ============================================================================
// Power and Performance Management
// ============================================================================

/**
 * @brief Set CPU frequency governor
 * 
 * @param handle Monitor handle
 * @param governor_id Governor identifier
 * @param core_id Core identifier (-1 for all cores)
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_set_frequency_governor(cpu_monitor_handle_t* handle,
                                                       uint32_t governor_id,
                                                       int32_t core_id);

/**
 * @brief Set CPU frequency limits
 * 
 * @param handle Monitor handle
 * @param min_freq_hz Minimum frequency in Hz (0 for no limit)
 * @param max_freq_hz Maximum frequency in Hz (0 for no limit)
 * @param core_id Core identifier (-1 for all cores)
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_set_frequency_limits(cpu_monitor_handle_t* handle,
                                                     uint64_t min_freq_hz,
                                                     uint64_t max_freq_hz,
                                                     int32_t core_id);

/**
 * @brief Get estimated power consumption
 * 
 * @param handle Monitor handle
 * @param power_watts Output parameter for power in watts
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_get_power_consumption(cpu_monitor_handle_t* handle,
                                                      double* power_watts);

// ============================================================================
// Inline Utility Functions
// ============================================================================

/**
 * @brief Check if CPU monitor is running
 * 
 * @param handle Monitor handle to check
 * @return true if running, false otherwise
 */
static inline bool cpu_monitor_is_running(const cpu_monitor_handle_t* handle) {
    return (handle != NULL);
}

/**
 * @brief Convert temperature from Celsius to Fahrenheit
 * 
 * @param celsius Temperature in Celsius
 * @return Temperature in Fahrenheit
 */
static inline float cpu_monitor_celsius_to_fahrenheit(float celsius) {
    return (celsius * 9.0f / 5.0f) + 32.0f;
}

/**
 * @brief Convert temperature from Celsius to Kelvin
 * 
 * @param celsius Temperature in Celsius
 * @return Temperature in Kelvin
 */
static inline float cpu_monitor_celsius_to_kelvin(float celsius) {
    return celsius + 273.15f;
}

/**
 * @brief Convert CPU ticks to milliseconds
 * 
 * @param ticks CPU ticks
 * @param ticks_per_second Ticks per second (system dependent)
 * @return Time in milliseconds
 */
static inline double cpu_monitor_ticks_to_ms(uint64_t ticks, uint64_t ticks_per_second) {
    return (ticks * 1000.0) / ticks_per_second;
}

/**
 * @brief Get version string
 * 
 * @return const char* Version string
 */
static inline const char* cpu_monitor_get_version_string(void) {
    return "2.1.0";
}

// ============================================================================
// Platform-Specific Extensions
// ============================================================================

#if defined(CPU_MONITOR_PLATFORM_LINUX)
/**
 * @brief Get CPU cgroup statistics (Linux only)
 * 
 * @param handle Monitor handle
 * @param cgroup_path Cgroup path
 * @param usage_ns Output parameter for CPU usage in nanoseconds
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_get_cgroup_stats(cpu_monitor_handle_t* handle,
                                                 const char* cgroup_path,
                                                 uint64_t* usage_ns);
#endif

#if defined(CPU_MONITOR_PLATFORM_WINDOWS)
/**
 * @brief Get CPU process affinity mask (Windows only)
 * 
 * @param handle Monitor handle
 * @param process_id Process ID
 * @param affinity_mask Output parameter for affinity mask
 * @return cpu_monitor_status_t Status code
 */
cpu_monitor_status_t cpu_monitor_get_process_affinity(cpu_monitor_handle_t* handle,
                                                     DWORD process_id,
                                                     DWORD_PTR* affinity_mask);
#endif

// ============================================================================
// Export Macros for Shared Libraries
// ============================================================================
#ifdef BUILDING_CPU_MONITOR_DLL
    #define CPU_MONITOR_API __declspec(dllexport)
#elif defined(USING_CPU_MONITOR_DLL)
    #define CPU_MONITOR_API __declspec(dllimport)
#else
    #define CPU_MONITOR_API
#endif

#ifdef __cplusplus
}
#endif

#endif // CPU_MONITOR_H

// ============================================================================
// Implementation Notes:
// ============================================================================
// 1. Thread Safety: This API is designed to be thread-safe when used correctly
// 2. Memory Management: All allocated memory should be freed through deinit()
// 3. Error Handling: Check return codes for all functions
// 4. Platform Support: Use platform-specific implementations in .c file
// 5. Performance: Minimize overhead for real-time monitoring
// 6. Scalability: Supports up to 256 cores for enterprise systems
// 7. Extensibility: New metrics can be added without breaking API