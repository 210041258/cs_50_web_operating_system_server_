#ifndef CONFIG_H
#define CONFIG_H

#include <stdint.h>

// Fixed-width types
typedef uint8_t  u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef int8_t   i8;
typedef int16_t  i16;
typedef int32_t  i32;
typedef int64_t  i64;

// Compiler optimization hints
#if defined(__GNUC__) || defined(__clang__)
    #define HOT        __attribute__((hot))
    #define COLD       __attribute__((cold))
    #define PACKED     __attribute__((packed))
    #define PURE       __attribute__((pure))
    #define CONST      __attribute__((const))
    #define ALWAYS_INLINE __attribute__((always_inline))
    #define NO_INLINE  __attribute__((noinline))
    #define LIKELY(x)   __builtin_expect(!!(x), 1)
    #define UNLIKELY(x) __builtin_expect(!!(x), 0)
#else
    #define HOT
    #define COLD
    #define PACKED
    #define PURE
    #define CONST
    #define ALWAYS_INLINE
    #define NO_INLINE
    #define LIKELY(x) (x)
    #define UNLIKELY(x) (x)
#endif

#define CACHE_LINE_SIZE 64
#define ALIGN_CACHE

// Core monitoring features
typedef struct PACKED {
    u8 enable_cpu : 1;
    u8 enable_memory : 1;
    u8 enable_disk : 1;
    u8 enable_network : 1;
    u8 enable_process : 1;
    u8 enable_system : 1;
    u8 enable_container : 1;
    u8 enable_gpu : 1;
    u8 enable_security : 1;
    u8 enable_storage_perf : 1;
    u8 _reserved : 6;
} FeatureFlags;

// Performance configuration
typedef struct PACKED {
    u16 sample_rate_ms;      // Sampling interval in milliseconds
    u16 history_size;        // Number of samples to keep
    u8 precision_level;      // 0=low, 1=medium, 2=high
    u8 color_output : 1;     // Enable colored output
    u8 use_unicode : 1;      // Use Unicode characters
    u8 show_graphs : 1;      // Display graphs
    u8 sort_by_memory : 1;   // Sort processes by memory
    u8 _reserved : 4;
} PerformanceConfig;

// Threshold configuration
typedef struct PACKED {
    u16 cpu_warning;         // CPU warning threshold (0-10000 = 0-100.00%)
    u16 cpu_critical;        // CPU critical threshold
    u16 mem_warning;         // Memory warning threshold
    u16 mem_critical;        // Memory critical threshold
    u16 disk_warning;        // Disk usage warning threshold
    u16 disk_critical;       // Disk usage critical threshold
    u16 temp_warning;        // Temperature warning threshold (Celsius)
    u16 temp_critical;       // Temperature critical threshold
} ThresholdConfig;

// Alert configuration
typedef struct PACKED {
    u8 enable_alerts : 1;
    u8 enable_sound : 1;
    u8 enable_logging : 1;
    u8 enable_notifications : 1;
    u8 enable_email : 1;
    u8 enable_sms : 1;
    u8 _reserved : 2;
    
    char email_address[128];
    char phone_number[32];
    char webhook_url[256];
    
    u16 cooldown_seconds;    // Alert cooldown period
    u16 max_alerts_per_hour; // Rate limiting
} AlertConfig;

// Export configuration
typedef struct PACKED {
    u8 enable_json : 1;
    u8 enable_csv : 1;
    u8 enable_prometheus : 1;
    u8 enable_influxdb : 1;
    u8 enable_graphite : 1;
    u8 _reserved : 3;
    
    char export_directory[256];
    u16 export_interval;     // Export interval in seconds
    u8 compression_level;    // 0=none, 1-9 compression level
} ExportConfig;

// Main configuration structure
typedef struct {
    FeatureFlags features;
    PerformanceConfig performance;
    ThresholdConfig thresholds;
    AlertConfig alerts;
    ExportConfig export;
    
    // UI configuration
    struct {
        char date_format[32];
        char time_format[32];
        char language[16];
        u8 show_header : 1;
        u8 show_footer : 1;
        u8 auto_refresh : 1;
        u8 _reserved : 5;
    } ui;
    
    // Network configuration
    struct {
        char interface[16];
        u16 port;
        u8 enable_remote : 1;
        u8 enable_ssl : 1;
        u8 _reserved : 6;
    } network;
    
    // Storage configuration
    struct {
        char data_directory[256];
        u32 max_storage_mb;
        u8 enable_compression : 1;
        u8 enable_encryption : 1;
        u8 _reserved : 6;
    } storage;
} MonitorConfig;

// Function prototypes
MonitorConfig* config_load(const char *filename) HOT;
int config_save(const MonitorConfig *config, const char *filename) COLD;
void config_set_defaults(MonitorConfig *config);
int config_validate(const MonitorConfig *config);
const char* config_get_error(void);

// Feature management
int config_enable_feature(MonitorConfig *config, const char *feature_name);
int config_disable_feature(MonitorConfig *config, const char *feature_name);
int config_is_feature_enabled(const MonitorConfig *config, const char *feature_name);

// Value accessors
int config_get_int(const MonitorConfig *config, const char *key, int default_value);
float config_get_float(const MonitorConfig *config, const char *key, float default_value);
const char* config_get_string(const MonitorConfig *config, const char *key, const char *default_value);

// Watcher for live updates
typedef void (*ConfigUpdateCallback)(const MonitorConfig *config, void *user_data);
int config_watch_file(const char *filename, ConfigUpdateCallback callback, void *user_data);
void config_unwatch_file(const char *filename);

#endif // CONFIG_H