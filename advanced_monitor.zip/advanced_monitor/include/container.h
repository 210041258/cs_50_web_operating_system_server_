/**
 * @file container.h
 * @brief Container and Orchestration Monitoring and Management Module
 * 
 * This module provides comprehensive container runtime monitoring, orchestration management,
 * security scanning, performance optimization, and lifecycle management for Docker, Kubernetes,
 * containerd, Podman, and other container technologies across cloud and on-premise environments.
 * 
 * @author Container Platform Team
 * @date 2024-01-31
 * @version 3.8.0
 * 
 * @license Apache 2.0
 * @copyright Copyright (c) 2024 Container Solutions
 */

#ifndef CONTAINER_H
#define CONTAINER_H

#ifdef __cplusplus
extern "C" {
#endif

// ============================================================================
// Includes and Dependencies
// ============================================================================
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <time.h>

// Container runtime specific headers
#if defined(HAVE_DOCKER)
    #include <docker/docker.h>
#endif

#if defined(HAVE_KUBERNETES)
    #include <kubernetes/kubernetes.h>
#endif

// Network and process monitoring
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

// ============================================================================
// Configuration Constants
// ============================================================================
/**
 * @def CONTAINER_VERSION_MAJOR
 * @brief Major version number
 */
#define CONTAINER_VERSION_MAJOR 3

/**
 * @def CONTAINER_VERSION_MINOR
 * @brief Minor version number
 */
#define CONTAINER_VERSION_MINOR 8

/**
 * @def CONTAINER_VERSION_PATCH
 * @brief Patch version number
 */
#define CONTAINER_VERSION_PATCH 0

/**
 * @def CONTAINER_MAX_CONTAINERS
 * @brief Maximum number of containers to monitor
 */
#define CONTAINER_MAX_CONTAINERS 10000

/**
 * @def CONTAINER_MAX_PODS
 * @brief Maximum number of pods to monitor
 */
#define CONTAINER_MAX_PODS 5000

/**
 * @def CONTAINER_MAX_NODES
 * @brief Maximum number of cluster nodes
 */
#define CONTAINER_MAX_NODES 1000

/**
 * @def CONTAINER_MAX_IMAGES
 * @brief Maximum container images to manage
 */
#define CONTAINER_MAX_IMAGES 5000

/**
 * @def CONTAINER_MAX_VOLUMES
 * @brief Maximum volumes to monitor
 */
#define CONTAINER_MAX_VOLUMES 10000

/**
 * @def CONTAINER_MAX_NETWORKS
 * @brief Maximum networks to monitor
 */
#define CONTAINER_MAX_NETWORKS 1000

/**
 * @def CONTAINER_MAX_SECRETS
 * @brief Maximum secrets to manage
 */
#define CONTAINER_MAX_SECRETS 10000

/**
 * @def CONTAINER_MAX_CONFIGMAPS
 * @brief Maximum configmaps to manage
 */
#define CONTAINER_MAX_CONFIGMAPS 10000

/**
 * @def CONTAINER_MAX_SERVICES
 * @brief Maximum services to monitor
 */
#define CONTAINER_MAX_SERVICES 5000

/**
 * @def CONTAINER_MAX_ENDPOINTS
 * @brief Maximum endpoints per service
 */
#define CONTAINER_MAX_ENDPOINTS 100

/**
 * @def CONTAINER_MAX_PORTS
 * @brief Maximum ports per container
 */
#define CONTAINER_MAX_PORTS 100

/**
 * @def CONTAINER_MAX_MOUNTS
 * @brief Maximum mounts per container
 */
#define CONTAINER_MAX_MOUNTS 100

/**
 * @def CONTAINER_MAX_ENVIRONMENT
 * @brief Maximum environment variables
 */
#define CONTAINER_MAX_ENVIRONMENT 1000

/**
 * @def CONTAINER_MAX_LABELS
 * @brief Maximum labels per resource
 */
#define CONTAINER_MAX_LABELS 100

/**
 * @def CONTAINER_MAX_ANNOTATIONS
 * @brief Maximum annotations per resource
 */
#define CONTAINER_MAX_ANNOTATIONS 100

/**
 * @def CONTAINER_DEFAULT_SAMPLE_INTERVAL_MS
 * @brief Default sampling interval in milliseconds
 */
#define CONTAINER_DEFAULT_SAMPLE_INTERVAL_MS 2000

/**
 * @def CONTAINER_BUFFER_SIZE_SAMPLES
 * @brief Default buffer size for historical samples
 */
#define CONTAINER_BUFFER_SIZE_SAMPLES 1800  // 1 hour at 2 samples/sec

// ============================================================================
// Type Definitions
// ============================================================================

/**
 * @enum container_status_t
 * @brief Status codes for container operations
 */
typedef enum {
    CONTAINER_SUCCESS = 0,                 /**< Operation successful */
    CONTAINER_ERROR_INIT_FAILED,           /**< Initialization failed */
    CONTAINER_ERROR_RUNTIME_UNAVAILABLE,   /**< Container runtime unavailable */
    CONTAINER_ERROR_INVALID_PARAMETER,     /**< Invalid parameter */
    CONTAINER_ERROR_NOT_INITIALIZED,       /**< Container module not initialized */
    CONTAINER_ERROR_PERMISSION_DENIED,     /**< Insufficient permissions */
    CONTAINER_ERROR_CONTAINER_NOT_FOUND,   /**< Container not found */
    CONTAINER_ERROR_IMAGE_NOT_FOUND,       /**< Image not found */
    CONTAINER_ERROR_VOLUME_NOT_FOUND,      /**< Volume not found */
    CONTAINER_ERROR_NETWORK_NOT_FOUND,     /**< Network not found */
    CONTAINER_ERROR_ORCHESTRATION_FAILED,  /**< Orchestration operation failed */
    CONTAINER_ERROR_SECURITY_VIOLATION,    /**< Security violation detected */
    CONTAINER_ERROR_RESOURCE_LIMIT,        /**< Resource limit exceeded */
    CONTAINER_ERROR_HEALTH_CHECK_FAILED,   /**< Health check failed */
    CONTAINER_ERROR_START_FAILED,          /**< Container start failed */
    CONTAINER_ERROR_STOP_FAILED,           /**< Container stop failed */
    CONTAINER_ERROR_RESTART_FAILED,        /**< Container restart failed */
    CONTAINER_ERROR_EXEC_FAILED,           /**< Exec command failed */
    CONTAINER_ERROR_BUILD_FAILED,          /**< Image build failed */
    CONTAINER_ERROR_PULL_FAILED,           /**< Image pull failed */
    CONTAINER_ERROR_PUSH_FAILED,           /**< Image push failed */
    CONTAINER_ERROR_SCAN_FAILED,           /**< Security scan failed */
    CONTAINER_ERROR_MONITORING_FAILED,     /**< Monitoring setup failed */
    CONTAINER_ERROR_TIMEOUT,               /**< Operation timeout */
    CONTAINER_ERROR_QUOTA_EXCEEDED         /**< Quota exceeded */
} container_status_t;

/**
 * @enum container_runtime_t
 * @brief Container runtime types
 */
typedef enum {
    RUNTIME_DOCKER,                       /**< Docker runtime */
    RUNTIME_CONTAINERD,                   /**< containerd runtime */
    RUNTIME_CRIO,                         /**< CRI-O runtime */
    RUNTIME_PODMAN,                       /**< Podman runtime */
    RUNTIME_LXC,                          /**< LXC containers */
    RUNTIME_LXD,                          /**< LXD containers */
    RUNTIME_RKT,                          /**< rkt runtime */
    RUNTIME_SYSTEMD_NSPAWN,               /**< systemd-nspawn */
    RUNTIME_WINDOWS_CONTAINERS,           /**< Windows containers */
    RUNTIME_UNKNOWN                       /**< Unknown runtime */
} container_runtime_t;

/**
 * @enum container_state_t
 * @brief Container states
 */
typedef enum {
    CONTAINER_STATE_CREATED,              /**< Created but not started */
    CONTAINER_STATE_RUNNING,              /**< Currently running */
    CONTAINER_STATE_PAUSED,               /**< Paused */
    CONTAINER_STATE_RESTARTING,           /**< Restarting */
    CONTAINER_STATE_EXITED,               /**< Stopped/exited */
    CONTAINER_STATE_DEAD,                 /**< Dead (cannot be restarted) */
    CONTAINER_STATE_STOPPED,              /**< Stopped gracefully */
    CONTAINER_STATE_KILLED,               /**< Killed forcefully */
    CONTAINER_STATE_ORPHANED,             /**< Orphaned/no parent */
    CONTAINER_STATE_UNKNOWN               /**< Unknown state */
} container_state_t;

/**
 * @enum container_orchestrator_t
 * @brief Container orchestrator types
 */
typedef enum {
    ORCHESTRATOR_KUBERNETES,              /**< Kubernetes */
    ORCHESTRATOR_DOCKER_SWARM,            /**< Docker Swarm */
    ORCHESTRATOR_NOMAD,                   /**< HashiCorp Nomad */
    ORCHESTRATOR_MESOS,                   /**< Apache Mesos */
    ORCHESTRATOR_OPENSHIFT,               /**< Red Hat OpenShift */
    ORCHESTRATOR_RANCHER,                 /**< Rancher */
    ORCHESTRATOR_ECS,                     /**< AWS ECS */
    ORCHESTRATOR_EKS,                     /**< AWS EKS */
    ORCHESTRATOR_AKS,                     /**< Azure AKS */
    ORCHESTRATOR_GKE,                     /**< Google GKE */
    ORCHESTRATOR_NONE                     /**< No orchestrator */
} container_orchestrator_t;

/**
 * @enum container_network_mode_t
 * @brief Container network modes
 */
typedef enum {
    NETWORK_MODE_BRIDGE,                  /**< Bridge network */
    NETWORK_MODE_HOST,                    /**< Host network */
    NETWORK_MODE_NONE,                    /**< No networking */
    NETWORK_MODE_CONTAINER,               /**< Container network */
    NETWORK_MODE_OVERLAY,                 /**< Overlay network */
    NETWORK_MODE_MACVLAN,                 /**< Macvlan network */
    NETWORK_MODE_IPVLAN,                  /**< IPvlan network */
    NETWORK_MODE_CUSTOM,                  /**< Custom network */
    NETWORK_MODE_UNKNOWN                  /**< Unknown network mode */
} container_network_mode_t;

/**
 * @enum container_security_context_t
 * @brief Container security context types
 */
typedef enum {
    SECURITY_CONTEXT_PRIVILEGED,          /**< Privileged container */
    SECURITY_CONTEXT_UNPRIVILEGED,        /**< Unprivileged container */
    SECURITY_CONTEXT_USER_NAMESPACE,      /**< User namespace container */
    SECURITY_CONTEXT_READ_ONLY_ROOT,      /**< Read-only root filesystem */
    SECURITY_CONTEXT_APPARMOR,            /**< AppArmor profile */
    SECURITY_CONTEXT_SELINUX,             /**< SELinux context */
    SECURITY_CONTEXT_SECCOMP,             /**< Seccomp profile */
    SECURITY_CONTEXT_CAPABILITIES         /**< Linux capabilities */
} container_security_context_t;

/**
 * @enum container_health_status_t
 * @brief Container health status
 */
typedef enum {
    HEALTH_STATUS_STARTING,               /**< Container starting */
    HEALTH_STATUS_HEALTHY,                /**< Container healthy */
    HEALTH_STATUS_UNHEALTHY,              /**< Container unhealthy */
    HEALTH_STATUS_DEGRADED,               /**< Container degraded */
    HEALTH_STATUS_UNKNOWN,                /**< Health status unknown */
    HEALTH_STATUS_NONE                    /**< No health check configured */
} container_health_status_t;

/**
 * @enum container_image_type_t
 * @brief Container image types
 */
typedef enum {
    IMAGE_TYPE_DOCKER,                    /**< Docker image */
    IMAGE_TYPE_OCI,                       /**< OCI image */
    IMAGE_TYPE_SINGULARITY,               /**< Singularity image */
    IMAGE_TYPE_APPIMAGE,                  /**< AppImage */
    IMAGE_TYPE_FLATPAK,                   /**< Flatpak */
    IMAGE_TYPE_SNAP,                      /**< Snap */
    IMAGE_TYPE_UNKNOWN                    /**< Unknown image type */
} container_image_type_t;

/**
 * @enum container_storage_driver_t
 * @brief Container storage drivers
 */
typedef enum {
    STORAGE_DRIVER_OVERLAY2,              /**< Overlay2 driver */
    STORAGE_DRIVER_OVERLAY,               /**< Overlay driver */
    STORAGE_DRIVER_AUFS,                  /**< AUFS driver */
    STORAGE_DRIVER_DEVICEMAPPER,          /**< Device Mapper driver */
    STORAGE_DRIVER_BTRFS,                 /**< Btrfs driver */
    STORAGE_DRIVER_ZFS,                   /**< ZFS driver */
    STORAGE_DRIVER_VFS,                   /**< VFS driver */
    STORAGE_DRIVER_CONTAINER_STORAGE,     /**< Container Storage Interface */
    STORAGE_DRIVER_UNKNOWN                /**< Unknown storage driver */
} container_storage_driver_t;

/**
 * @struct container_uuid_t
 * @brief Container unique identifier (128-bit)
 */
typedef struct {
    uint8_t bytes[16];                   /**< 16-byte UUID */
} container_uuid_t;

/**
 * @struct container_info_t
 * @brief Container information
 */
typedef struct {
    container_uuid_t uuid;               /**< Container UUID */
    char id[128];                        /**< Container ID */
    char name[256];                      /**< Container name */
    char image[512];                     /**< Container image */
    char image_id[128];                  /**< Image ID */
    container_state_t state;             /**< Container state */
    container_runtime_t runtime;         /**< Container runtime */
    char runtime_version[64];            /**< Runtime version */
    time_t created_at;                   /**< Creation timestamp */
    time_t started_at;                   /**< Start timestamp */
    time_t finished_at;                  /**< Finish timestamp */
    char command[1024];                  /**< Command executed */
    char entrypoint[1024];               /**< Container entrypoint */
    char working_dir[512];               /**< Working directory */
    char user[64];                       /**< Running user */
    bool auto_remove;                    /**< Auto-remove on exit */
    bool auto_restart;                   /**< Auto-restart policy */
    char restart_policy[64];             /**< Restart policy */
    int64_t exit_code;                   /**< Exit code */
    char error_message[512];             /**< Error message if any */
    bool is_managed;                     /**< Is managed by orchestrator? */
    char orchestrator_id[128];           /**< Orchestrator ID if managed */
    char namespace[128];                 /**< Namespace/Project */
    char labels[CONTAINER_MAX_LABELS][128]; /**< Container labels */
    uint32_t label_count;                /**< Number of labels */
} container_info_t;

/**
 * @struct container_performance_metrics_t
 * @brief Container performance metrics
 */
typedef struct {
    // CPU metrics
    uint64_t cpu_usage_nanos;           /**< CPU usage in nanoseconds */
    uint64_t cpu_system_nanos;          /**< System CPU usage in nanoseconds */
    uint64_t cpu_user_nanos;            /**< User CPU usage in nanoseconds */
    uint64_t cpu_throttled_nanos;       /**< Throttled CPU time in nanoseconds */
    uint64_t cpu_periods;               /**< CPU periods */
    uint64_t cpu_throttled_periods;     /**< Throttled CPU periods */
    double cpu_percentage;              /**< CPU usage percentage */
    uint64_t cpu_quota;                 /**< CPU quota in microseconds */
    uint64_t cpu_period;                /**< CPU period in microseconds */
    uint32_t cpu_shares;                /**< CPU shares */
    uint32_t cpu_set_cpus[64];          /**< CPU set (affinity) */
    uint32_t cpu_set_count;             /**< Number of CPUs in set */
    
    // Memory metrics
    uint64_t memory_usage_bytes;        /**< Memory usage in bytes */
    uint64_t memory_limit_bytes;        /**< Memory limit in bytes */
    uint64_t memory_cache_bytes;        /**< Memory cache usage */
    uint64_t memory_rss_bytes;          /**< RSS memory usage */
    uint64_t memory_swap_bytes;         /**< Swap usage */
    uint64_t memory_kernel_bytes;       /**< Kernel memory usage */
    uint64_t memory_kernel_tcp_bytes;   /**< TCP kernel memory */
    uint64_t memory_mapped_file_bytes;  /**< Mapped file memory */
    uint64_t memory_pgfault;            /**< Page faults */
    uint64_t memory_pgmajfault;         /**< Major page faults */
    uint64_t memory_inactive_file_bytes; /**< Inactive file memory */
    double memory_percentage;           /**< Memory usage percentage */
    uint64_t memory_soft_limit_bytes;   /**< Memory soft limit */
    uint64_t memory_reservation_bytes;  /**< Memory reservation */
    
    // I/O metrics
    uint64_t io_read_bytes;             /**< Bytes read */
    uint64_t io_write_bytes;            /**< Bytes written */
    uint64_t io_read_ops;               /**< Read operations */
    uint64_t io_write_ops;              /**< Write operations */
    uint64_t io_total_bytes;            /**< Total I/O bytes */
    uint64_t io_total_ops;              /**< Total I/O operations */
    
    // Network metrics
    uint64_t network_rx_bytes;          /**< Received bytes */
    uint64_t network_tx_bytes;          /**< Transmitted bytes */
    uint64_t network_rx_packets;        /**< Received packets */
    uint64_t network_tx_packets;        /**< Transmitted packets */
    uint64_t network_rx_errors;         /**< Receive errors */
    uint64_t network_tx_errors;         /**< Transmit errors */
    uint64_t network_rx_dropped;        /**< Received packets dropped */
    uint64_t network_tx_dropped;        /**< Transmitted packets dropped */
    
    // PIDs and processes
    uint64_t pids_current;              /**< Current number of PIDs */
    uint64_t pids_limit;                /**< PID limit */
    
    // Timestamp
    uint64_t timestamp_ns;              /**< Sample timestamp in nanoseconds */
} container_performance_metrics_t;

/**
 * @struct container_network_info_t
 * @brief Container network information
 */
typedef struct {
    char network_id[128];               /**< Network ID */
    char network_name[256];             /**< Network name */
    container_network_mode_t mode;      /**< Network mode */
    char ip_address[46];                /**< IP address */
    char gateway[46];                   /**< Gateway address */
    char mac_address[18];               /**< MAC address */
    char subnet[46];                    /**< Subnet CIDR */
    char ipv6_address[46];              /**< IPv6 address */
    char ipv6_gateway[46];              /**< IPv6 gateway */
    char ipv6_subnet[46];               /**< IPv6 subnet CIDR */
    uint32_t mtu;                       /**< MTU size */
    bool internal;                      /**< Internal network */
    bool attachable;                    /**< Attachable network */
    bool ingress;                       /**< Ingress network */
    bool enable_ipv6;                   /**< IPv6 enabled */
    char driver[64];                    /**< Network driver */
    char scope[32];                     /**< Network scope */
    char labels[CONTAINER_MAX_LABELS][128]; /**< Network labels */
    uint32_t label_count;               /**< Number of labels */
} container_network_info_t;

/**
 * @struct container_port_mapping_t
 * @brief Port mapping information
 */
typedef struct {
    uint16_t container_port;            /**< Container port */
    uint16_t host_port;                 /**< Host port */
    char host_ip[46];                   /**< Host IP address */
    char protocol[8];                   /**< Protocol (TCP/UDP) */
    char type[32];                      /**< Port type (published/exposed) */
} container_port_mapping_t;

/**
 * @struct container_volume_mount_t
 * @brief Volume mount information
 */
typedef struct {
    char source[1024];                  /**< Source path/volume */
    char destination[1024];             /**< Destination path in container */
    char mode[32];                      /**< Mount mode (ro/rw) */
    char propagation[32];               /**< Propagation mode */
    char type[32];                      /**< Mount type (bind/volume/tmpfs) */
    bool read_only;                     /**< Read-only mount */
    bool bind_propagation;              /**< Bind propagation enabled */
} container_volume_mount_t;

/**
 * @struct container_health_check_t
 * @brief Health check configuration
 */
typedef struct {
    char test[1024];                    /**< Health check test command */
    uint32_t interval_seconds;          /**< Check interval in seconds */
    uint32_t timeout_seconds;           /**< Check timeout in seconds */
    uint32_t start_period_seconds;      /**< Start period in seconds */
    uint32_t retries;                   /**< Number of retries */
    bool disable;                       /**< Health check disabled */
} container_health_check_t;

/**
 * @struct container_security_info_t
 * @brief Container security information
 */
typedef struct {
    bool privileged;                    /**< Privileged container */
    bool read_only_rootfs;              /**< Read-only root filesystem */
    char user[64];                      /**< Running user */
    char apparmor_profile[256];         /**< AppArmor profile */
    char seccomp_profile[256];          /**< Seccomp profile */
    char selinux_context[256];          /**< SELinux context */
    char capabilities[1024];            /**< Linux capabilities (comma-separated) */
    bool no_new_privileges;             /**< No new privileges flag */
    char userns_mode[64];               /**< User namespace mode */
    char cgroup_parent[256];            /**< Cgroup parent */
    char security_opt[1024];            /**< Security options */
    bool pid_mode_host;                 /**< Host PID namespace */
    bool ipc_mode_host;                 /**< Host IPC namespace */
    bool uts_mode_host;                 /**< Host UTS namespace */
    bool network_mode_host;             /**< Host network namespace */
    bool userns_mode_host;              /**< Host user namespace */
    char sysctls[1024];                 /**< Sysctls (comma-separated) */
} container_security_info_t;

/**
 * @struct container_resource_limits_t
 * @brief Resource limits and requests
 */
typedef struct {
    // CPU limits
    uint64_t cpu_limit_nanos;           /**< CPU limit in nanoseconds */
    uint32_t cpu_shares;                /**< CPU shares */
    uint32_t cpu_quota;                 /**< CPU quota */
    uint32_t cpu_period;                /**< CPU period */
    char cpu_set[256];                  /**< CPU set (affinity) */
    
    // Memory limits
    uint64_t memory_limit_bytes;        /**< Memory limit in bytes */
    uint64_t memory_reservation_bytes;  /**< Memory reservation */
    uint64_t memory_swap_limit_bytes;   /**< Memory+swap limit */
    uint64_t kernel_memory_limit_bytes; /**< Kernel memory limit */
    
    // I/O limits
    uint64_t blkio_weight;              /**< Block IO weight */
    uint64_t blkio_weight_device[16];   /**< Block IO weight per device */
    uint64_t blkio_read_bps[16];        /**< Read bytes per second */
    uint64_t blkio_write_bps[16];       /**< Write bytes per second */
    uint64_t blkio_read_iops[16];       /**< Read IOPS */
    uint64_t blkio_write_iops[16];      /**< Write IOPS */
    
    // PIDs limit
    uint64_t pids_limit;                /**< PIDs limit */
    
    // Network limits
    uint64_t network_limit_bps;         /**< Network bandwidth limit */
    uint64_t network_limit_pps;         /**< Network packets per second */
    
    // GPU limits
    char gpu_devices[1024];             /**< GPU devices (comma-separated) */
    uint32_t gpu_count;                 /**< Number of GPUs */
    char gpu_capabilities[1024];        /**< GPU capabilities */
} container_resource_limits_t;

/**
 * @struct container_image_info_t
 * @brief Container image information
 */
typedef struct {
    char id[128];                       /**< Image ID */
    char repository[512];               /**< Image repository */
    char tag[128];                      /**< Image tag */
    char digest[256];                   /**< Image digest */
    uint64_t size_bytes;                /**< Image size in bytes */
    uint64_t virtual_size_bytes;        /**< Virtual size in bytes */
    time_t created_at;                  /**< Creation timestamp */
    char author[256];                   /**< Image author */
    char architecture[64];              /**< Architecture */
    char os[64];                        /**< Operating system */
    char variant[64];                   /**< Variant */
    container_image_type_t type;        /**< Image type */
    bool is_official;                   /**< Is official image? */
    bool is_verified;                   /**< Is verified publisher? */
    bool is_trusted;                    /**< Is trusted content? */
    char labels[CONTAINER_MAX_LABELS][128]; /**< Image labels */
    uint32_t label_count;               /**< Number of labels */
    char layers[128][256];              /**< Layer IDs */
    uint32_t layer_count;               /**< Number of layers */
} container_image_info_t;

/**
 * @struct container_pod_info_t
 * @brief Pod information (Kubernetes/Orchestration)
 */
typedef struct {
    char uid[128];                      /**< Pod UID */
    char name[256];                     /**< Pod name */
    char namespace[128];                /**< Pod namespace */
    char phase[32];                     /**< Pod phase */
    char node_name[128];                /**< Node name */
    char host_ip[46];                   /**< Host IP address */
    char pod_ip[46];                    /**< Pod IP address */
    time_t start_time;                  /**< Start timestamp */
    uint32_t restart_count;             /**< Restart count */
    char qos_class[32];                 /**< Quality of Service class */
    bool host_network;                  /**< Host network */
    bool host_pid;                      /**< Host PID namespace */
    bool host_ipc;                      /**< Host IPC namespace */
    char service_account[256];          /**< Service account */
    char labels[CONTAINER_MAX_LABELS][128]; /**< Pod labels */
    uint32_t label_count;               /**< Number of labels */
    char annotations[CONTAINER_MAX_ANNOTATIONS][128]; /**< Pod annotations */
    uint32_t annotation_count;          /**< Number of annotations */
    char containers[32][128];           /**< Container names */
    uint32_t container_count;           /**< Number of containers */
} container_pod_info_t;

/**
 * @struct container_node_info_t
 * @brief Cluster node information
 */
typedef struct {
    char uid[128];                      /**< Node UID */
    char name[256];                     /**< Node name */
    char architecture[64];              /**< Node architecture */
    char kernel_version[64];            /**< Kernel version */
    char container_runtime_version[64]; /**< Container runtime version */
    char kubelet_version[64];           /**< Kubelet version */
    char os_image[256];                 /**< OS image */
    uint64_t cpu_capacity;              /**< CPU capacity in millicores */
    uint64_t memory_capacity_bytes;     /**< Memory capacity in bytes */
    uint64_t pods_capacity;             /**< Pods capacity */
    uint64_t allocatable_cpu;           /**< Allocatable CPU */
    uint64_t allocatable_memory_bytes;  /**< Allocatable memory */
    uint64_t allocatable_pods;          /**< Allocatable pods */
    char addresses[10][128];            /**< Node addresses */
    uint32_t address_count;             /**< Number of addresses */
    char conditions[10][256];           /**< Node conditions */
    uint32_t condition_count;           /**< Number of conditions */
    char taints[20][256];               /**< Node taints */
    uint32_t taint_count;               /**< Number of taints */
    char labels[CONTAINER_MAX_LABELS][128]; /**< Node labels */
    uint32_t label_count;               /**< Number of labels */
} container_node_info_t;

/**
 * @struct container_service_info_t
 * @brief Service information (Kubernetes/Docker Swarm)
 */
typedef struct {
    char uid[128];                      /**< Service UID */
    char name[256];                     /**< Service name */
    char namespace[128];                /**< Service namespace */
    char type[32];                      /**< Service type */
    char cluster_ip[46];                /**< Cluster IP address */
    char external_ip[46];               /**< External IP address */
    char load_balancer_ip[46];          /**< Load balancer IP */
    uint32_t port;                      /**< Service port */
    uint32_t target_port;               /**< Target port */
    char protocol[8];                   /**< Protocol (TCP/UDP) */
    char session_affinity[32];          /**< Session affinity */
    uint32_t replicas;                  /**< Number of replicas */
    uint32_t ready_replicas;            /**< Ready replicas */
    uint32_t available_replicas;        /**< Available replicas */
    uint32_t unavailable_replicas;      /**< Unavailable replicas */
    char selector[1024];                /**< Pod selector */
    char labels[CONTAINER_MAX_LABELS][128]; /**< Service labels */
    uint32_t label_count;               /**< Number of labels */
} container_service_info_t;

/**
 * @struct container_volume_info_t
 * @brief Volume information
 */
typedef struct {
    char name[256];                     /**< Volume name */
    char driver[128];                   /**< Volume driver */
    char mountpoint[1024];              /**< Mount point */
    char scope[32];                     /**< Volume scope */
    bool external;                      /**< External volume */
    char options[1024];                 /**< Driver options */
    uint64_t size_bytes;                /**< Volume size */
    uint64_t used_bytes;                /**< Used bytes */
    char labels[CONTAINER_MAX_LABELS][128]; /**< Volume labels */
    uint32_t label_count;               /**< Number of labels */
    time_t created_at;                  /**< Creation timestamp */
} container_volume_info_t;

/**
 * @struct container_event_t
 * @brief Container event
 */
typedef struct {
    char id[128];                       /**< Event ID */
    time_t timestamp;                   /**< Event timestamp */
    char type[64];                      /**< Event type */
    char action[64];                    /**< Event action */
    char scope[64];                     /**< Event scope */
    char actor_id[128];                 /**< Actor ID */
    char actor_attributes[1024];        /**< Actor attributes */
    uint64_t time_nano;                 /**< Timestamp in nanoseconds */
} container_event_t;

/**
 * @struct container_log_entry_t
 * @brief Container log entry
 */
typedef struct {
    time_t timestamp;                   /**< Log timestamp */
    char stream[32];                    /**< Log stream (stdout/stderr) */
    char log[4096];                     /**< Log message */
    char container_id[128];             /**< Container ID */
    char container_name[256];           /**< Container name */
    char image_name[512];               /**< Image name */
    char labels[1024];                  /**< Associated labels */
} container_log_entry_t;

/**
 * @struct container_config_t
 * @brief Container monitoring configuration
 */
typedef struct {
    uint32_t sample_interval_ms;        /**< Sampling interval in ms */
    bool enable_container_monitoring;   /**< Enable container monitoring */
    bool enable_image_monitoring;       /**< Enable image monitoring */
    bool enable_volume_monitoring;      /**< Enable volume monitoring */
    bool enable_network_monitoring;     /**< Enable network monitoring */
    bool enable_security_scanning;      /**< Enable security scanning */
    bool enable_log_collection;         /**< Enable log collection */
    bool enable_event_monitoring;       /**< Enable event monitoring */
    bool enable_health_checks;          /**< Enable health checks */
    bool enable_orchestration;          /**< Enable orchestration monitoring */
    bool enable_auto_remediation;       /**< Enable auto-remediation */
    bool enable_performance_metrics;    /**< Enable performance metrics */
    uint32_t max_log_size_mb;           /**< Maximum log size in MB */
    uint32_t max_event_history;         /**< Maximum event history */
    uint32_t health_check_interval_ms;  /**< Health check interval in ms */
    void* user_context;                 /**< User-defined context */
    void (*alert_callback)(const char* container_id,
                          container_status_t alert_type,
                          const char* message,
                          void* context);
    void (*event_callback)(const container_event_t* event,
                          void* context);
} container_config_t;

/**
 * @struct container_handle_t
 * @brief Opaque handle for container module
 */
typedef struct container_handle container_handle_t;

// ============================================================================
// Initialization and Configuration
// ============================================================================

/**
 * @brief Initialize container monitoring module
 * 
 * @param config Pointer to configuration structure (NULL for defaults)
 * @param handle Output parameter for container handle
 * @return container_status_t Status code
 */
container_status_t container_init(const container_config_t* config,
                                 container_handle_t** handle);

/**
 * @brief Get default configuration
 * 
 * @param config Output parameter for default configuration
 * @return container_status_t Status code
 */
container_status_t container_get_default_config(container_config_t* config);

/**
 * @brief Connect to container runtime
 * 
 * @param handle Container handle
 * @param runtime Container runtime to connect to
 * @param endpoint Runtime endpoint (NULL for default)
 * @return container_status_t Status code
 */
container_status_t container_connect_runtime(container_handle_t* handle,
                                            container_runtime_t runtime,
                                            const char* endpoint);

/**
 * @brief Connect to orchestrator
 * 
 * @param handle Container handle
 * @param orchestrator Orchestrator to connect to
 * @param kubeconfig Kubeconfig path (NULL for default)
 * @return container_status_t Status code
 */
container_status_t container_connect_orchestrator(container_handle_t* handle,
                                                 container_orchestrator_t orchestrator,
                                                 const char* kubeconfig);

/**
 * @brief Start container monitoring
 * 
 * @param handle Container handle
 * @return container_status_t Status code
 */
container_status_t container_start_monitoring(container_handle_t* handle);

/**
 * @brief Stop container monitoring
 * 
 * @param handle Container handle
 * @return container_status_t Status code
 */
container_status_t container_stop_monitoring(container_handle_t* handle);

/**
 * @brief Clean up container module
 * 
 * @param handle Container handle
 * @return container_status_t Status code
 */
container_status_t container_deinit(container_handle_t* handle);

// ============================================================================
// Container Management
// ============================================================================

/**
 * @brief List containers
 * 
 * @param handle Container handle
 * @param all List all containers (including stopped)
 * @param containers Array to store container info
 * @param max_containers Maximum containers to retrieve
 * @param actual_count Output parameter for actual count
 * @return container_status_t Status code
 */
container_status_t container_list(container_handle_t* handle,
                                 bool all,
                                 container_info_t* containers,
                                 uint32_t max_containers,
                                 uint32_t* actual_count);

/**
 * @brief Get container information
 * 
 * @param handle Container handle
 * @param container_id Container ID or name
 * @param info Output parameter for container info
 * @return container_status_t Status code
 */
container_status_t container_inspect(container_handle_t* handle,
                                    const char* container_id,
                                    container_info_t* info);

/**
 * @brief Create container
 * 
 * @param handle Container handle
 * @param image Container image
 * @param name Container name (NULL for auto-generated)
 * @param command Command to run (NULL for default)
 * @param env Environment variables
 * @param env_count Number of environment variables
 * @param ports Port mappings
 * @param port_count Number of port mappings
 * @param volumes Volume mounts
 * @param volume_count Number of volume mounts
 * @param container_id Output parameter for created container ID
 * @param container_id_size Size of container ID buffer
 * @return container_status_t Status code
 */
container_status_t container_create(container_handle_t* handle,
                                   const char* image,
                                   const char* name,
                                   const char* command,
                                   const char** env,
                                   uint32_t env_count,
                                   const container_port_mapping_t* ports,
                                   uint32_t port_count,
                                   const container_volume_mount_t* volumes,
                                   uint32_t volume_count,
                                   char* container_id,
                                   size_t container_id_size);

/**
 * @brief Start container
 * 
 * @param handle Container handle
 * @param container_id Container ID or name
 * @return container_status_t Status code
 */
container_status_t container_start(container_handle_t* handle,
                                  const char* container_id);

/**
 * @brief Stop container
 * 
 * @param handle Container handle
 * @param container_id Container ID or name
 * @param timeout_seconds Timeout in seconds
 * @return container_status_t Status code
 */
container_status_t container_stop(container_handle_t* handle,
                                 const char* container_id,
                                 uint32_t timeout_seconds);

/**
 * @brief Restart container
 * 
 * @param handle Container handle
 * @param container_id Container ID or name
 * @param timeout_seconds Timeout in seconds
 * @return container_status_t Status code
 */
container_status_t container_restart(container_handle_t* handle,
                                    const char* container_id,
                                    uint32_t timeout_seconds);

/**
 * @brief Pause container
 * 
 * @param handle Container handle
 * @param container_id Container ID or name
 * @return container_status_t Status code
 */
container_status_t container_pause(container_handle_t* handle,
                                  const char* container_id);

/**
 * @brief Unpause container
 * 
 * @param handle Container handle
 * @param container_id Container ID or name
 * @return container_status_t Status code
 */
container_status_t container_unpause(container_handle_t* handle,
                                    const char* container_id);

/**
 * @brief Kill container
 * 
 * @param handle Container handle
 * @param container_id Container ID or name
 * @param signal Signal to send (NULL for default)
 * @return container_status_t Status code
 */
container_status_t container_kill(container_handle_t* handle,
                                 const char* container_id,
                                 const char* signal);

/**
 * @brief Remove container
 * 
 * @param handle Container handle
 * @param container_id Container ID or name
 * @param force Force removal
 * @param remove_volumes Remove associated volumes
 * @return container_status_t Status code
 */
container_status_t container_remove(container_handle_t* handle,
                                   const char* container_id,
                                   bool force,
                                   bool remove_volumes);

// ============================================================================
// Container Performance Monitoring
// ============================================================================

/**
 * @brief Get container performance metrics
 * 
 * @param handle Container handle
 * @param container_id Container ID or name
 * @param metrics Output parameter for performance metrics
 * @return container_status_t Status code
 */
container_status_t container_get_metrics(container_handle_t* handle,
                                        const char* container_id,
                                        container_performance_metrics_t* metrics);

/**
 * @brief Get historical performance data
 * 
 * @param handle Container handle
 * @param container_id Container ID or name
 * @param metrics_buffer Array to store metrics
 * @param max_samples Maximum samples to retrieve
 * @param start_time Start timestamp (0 for all available)
 * @param end_time End timestamp (0 for current time)
 * @param actual_samples Output parameter for actual samples
 * @return container_status_t Status code
 */
container_status_t container_get_history(container_handle_t* handle,
                                        const char* container_id,
                                        container_performance_metrics_t* metrics_buffer,
                                        uint32_t max_samples,
                                        time_t start_time,
                                        time_t end_time,
                                        uint32_t* actual_samples);

/**
 * @brief Get container statistics
 * 
 * @param handle Container handle
 * @param container_id Container ID or name
 * @param cpu_usage Output parameter for CPU usage percentage
 * @param memory_usage Output parameter for memory usage percentage
 * @param network_rx Output parameter for network received bytes/sec
 * @param network_tx Output parameter for network transmitted bytes/sec
 * @param io_read Output parameter for I/O read bytes/sec
 * @param io_write Output parameter for I/O write bytes/sec
 * @return container_status_t Status code
 */
container_status_t container_get_statistics(container_handle_t* handle,
                                           const char* container_id,
                                           double* cpu_usage,
                                           double* memory_usage,
                                           uint64_t* network_rx,
                                           uint64_t* network_tx,
                                           uint64_t* io_read,
                                           uint64_t* io_write);

// ============================================================================
// Container Health and Status
// ============================================================================

/**
 * @brief Get container health status
 * 
 * @param handle Container handle
 * @param container_id Container ID or name
 * @param health_status Output parameter for health status
 * @param health_message Output parameter for health message
 * @param message_size Size of message buffer
 * @return container_status_t Status code
 */
container_status_t container_get_health(container_handle_t* handle,
                                       const char* container_id,
                                       container_health_status_t* health_status,
                                       char* health_message,
                                       size_t message_size);

/**
 * @brief Run container health check
 * 
 * @param handle Container handle
 * @param container_id Container ID or name
 * @param health_status Output parameter for health status
 * @return container_status_t Status code
 */
container_status_t container_check_health(container_handle_t* handle,
                                         const char* container_id,
                                         container_health_status_t* health_status);

/**
 * @brief Get container logs
 * 
 * @param handle Container handle
 * @param container_id Container ID or name
 * @param since Timestamp for logs since
 * @param until Timestamp for logs until
 * @param follow Follow log output
 * @param tail_lines Number of lines to tail
 * @param logs Array to store log entries
 * @param max_logs Maximum logs to retrieve
 * @param actual_logs Output parameter for actual logs
 * @return container_status_t Status code
 */
container_status_t container_get_logs(container_handle_t* handle,
                                     const char* container_id,
                                     time_t since,
                                     time_t until,
                                     bool follow,
                                     uint32_t tail_lines,
                                     container_log_entry_t* logs,
                                     uint32_t max_logs,
                                     uint32_t* actual_logs);

/**
 * @brief Execute command in container
 * 
 * @param handle Container handle
 * @param container_id Container ID or name
 * @param command Command to execute
 * @param args Command arguments
 * @param arg_count Number of arguments
 * @param user User to run as (NULL for default)
 * @param workdir Working directory (NULL for default)
 * @param env Environment variables
 * @param env_count Number of environment variables
 * @param tty Allocate TTY
 * @param stdin Enable stdin
 * @param stdout Output parameter for stdout
 * @param stdout_size Size of stdout buffer
 * @param stderr Output parameter for stderr
 * @param stderr_size Size of stderr buffer
 * @param exit_code Output parameter for exit code
 * @return container_status_t Status code
 */
container_status_t container_exec(container_handle_t* handle,
                                 const char* container_id,
                                 const char* command,
                                 const char** args,
                                 uint32_t arg_count,
                                 const char* user,
                                 const char* workdir,
                                 const char** env,
                                 uint32_t env_count,
                                 bool tty,
                                 bool stdin,
                                 char* stdout,
                                 size_t stdout_size,
                                 char* stderr,
                                 size_t stderr_size,
                                 int* exit_code);

// ============================================================================
// Image Management
// ============================================================================

/**
 * @brief List container images
 * 
 * @param handle Container handle
 * @param all List all images (including intermediate)
 * @param images Array to store image info
 * @param max_images Maximum images to retrieve
 * @param actual_count Output parameter for actual count
 * @return container_status_t Status code
 */
container_status_t container_list_images(container_handle_t* handle,
                                        bool all,
                                        container_image_info_t* images,
                                        uint32_t max_images,
                                        uint32_t* actual_count);

/**
 * @brief Pull container image
 * 
 * @param handle Container handle
 * @param image Image to pull
 * @param tag Image tag (NULL for latest)
 * @param platform Platform (NULL for default)
 * @param auth_config Authentication config (NULL for none)
 * @param auth_config_size Size of auth config
 * @param progress_callback Progress callback (NULL for none)
 * @param user_data User data for callback
 * @return container_status_t Status code
 */
container_status_t container_pull_image(container_handle_t* handle,
                                       const char* image,
                                       const char* tag,
                                       const char* platform,
                                       const void* auth_config,
                                       size_t auth_config_size,
                                       void (*progress_callback)(uint32_t progress, const char* status, void* user_data),
                                       void* user_data);

/**
 * @brief Push container image
 * 
 * @param handle Container handle
 * @param image Image to push
 * @param tag Image tag (NULL for latest)
 * @param auth_config Authentication config (NULL for none)
 * @param auth_config_size Size of auth config
 * @param progress_callback Progress callback (NULL for none)
 * @param user_data User data for callback
 * @return container_status_t Status code
 */
container_status_t container_push_image(container_handle_t* handle,
                                       const char* image,
                                       const char* tag,
                                       const void* auth_config,
                                       size_t auth_config_size,
                                       void (*progress_callback)(uint32_t progress, const char* status, void* user_data),
                                       void* user_data);

/**
 * @brief Build container image
 * 
 * @param handle Container handle
 * @param context_path Build context path
 * @param dockerfile Dockerfile path (NULL for default)
 * @param tag Image tag
 * @param build_args Build arguments
 * @param arg_count Number of build arguments
 * @param progress_callback Progress callback (NULL for none)
 * @param user_data User data for callback
 * @return container_status_t Status code
 */
container_status_t container_build_image(container_handle_t* handle,
                                        const char* context_path,
                                        const char* dockerfile,
                                        const char* tag,
                                        const char** build_args,
                                        uint32_t arg_count,
                                        void (*progress_callback)(uint32_t progress, const char* status, void* user_data),
                                        void* user_data);

/**
 * @brief Remove container image
 * 
 * @param handle Container handle
 * @param image_id Image ID or name
 * @param force Force removal
 * @param prune Remove unused images
 * @return container_status_t Status code
 */
container_status_t container_remove_image(container_handle_t* handle,
                                         const char* image_id,
                                         bool force,
                                         bool prune);

/**
 * @brief Scan container image for vulnerabilities
 * 
 * @param handle Container handle
 * @param image_id Image ID or name
 * @param scan_report Output parameter for scan report
 * @param report_size Size of report buffer
 * @param actual_size Output parameter for actual report size
 * @return container_status_t Status code
 */
container_status_t container_scan_image(container_handle_t* handle,
                                       const char* image_id,
                                       char* scan_report,
                                       size_t report_size,
                                       size_t* actual_size);

// ============================================================================
// Volume Management
// ============================================================================

/**
 * @brief List volumes
 * 
 * @param handle Container handle
 * @param volumes Array to store volume info
 * @param max_volumes Maximum volumes to retrieve
 * @param actual_count Output parameter for actual count
 * @return container_status_t Status code
 */
container_status_t container_list_volumes(container_handle_t* handle,
                                         container_volume_info_t* volumes,
                                         uint32_t max_volumes,
                                         uint32_t* actual_count);

/**
 * @brief Create volume
 * 
 * @param handle Container handle
 * @param name Volume name (NULL for auto-generated)
 * @param driver Volume driver (NULL for default)
 * @param options Driver options
 * @param options_count Number of options
 * @param labels Volume labels
 * @param label_count Number of labels
 * @param volume_name Output parameter for created volume name
 * @param name_size Size of name buffer
 * @return container_status_t Status code
 */
container_status_t container_create_volume(container_handle_t* handle,
                                          const char* name,
                                          const char* driver,
                                          const char** options,
                                          uint32_t options_count,
                                          const char** labels,
                                          uint32_t label_count,
                                          char* volume_name,
                                          size_t name_size);

/**
 * @brief Remove volume
 * 
 * @param handle Container handle
 * @param volume_name Volume name
 * @param force Force removal
 * @return container_status_t Status code
 */
container_status_t container_remove_volume(container_handle_t* handle,
                                          const char* volume_name,
                                          bool force);

/**
 * @brief Prune unused volumes
 * 
 * @param handle Container handle
 * @param pruned_bytes Output parameter for bytes pruned
 * @param pruned_count Output parameter for volumes pruned
 * @return container_status_t Status code
 */
container_status_t container_prune_volumes(container_handle_t* handle,
                                          uint64_t* pruned_bytes,
                                          uint32_t* pruned_count);

// ============================================================================
// Network Management
// ============================================================================

/**
 * @brief List networks
 * 
 * @param handle Container handle
 * @param networks Array to store network info
 * @param max_networks Maximum networks to retrieve
 * @param actual_count Output parameter for actual count
 * @return container_status_t Status code
 */
container_status_t container_list_networks(container_handle_t* handle,
                                          container_network_info_t* networks,
                                          uint32_t max_networks,
                                          uint32_t* actual_count);

/**
 * @brief Create network
 * 
 * @param handle Container handle
 * @param name Network name
 * @param driver Network driver (NULL for default)
 * @param subnet Subnet CIDR (NULL for auto)
 * @param gateway Gateway address (NULL for auto)
 * @param enable_ipv6 Enable IPv6
 * @param internal Internal network
 * @param attachable Attachable network
 * @param labels Network labels
 * @param label_count Number of labels
 * @return container_status_t Status code
 */
container_status_t container_create_network(container_handle_t* handle,
                                           const char* name,
                                           const char* driver,
                                           const char* subnet,
                                           const char* gateway,
                                           bool enable_ipv6,
                                           bool internal,
                                           bool attachable,
                                           const char** labels,
                                           uint32_t label_count);

/**
 * @brief Connect container to network
 * 
 * @param handle Container handle
 * @param container_id Container ID or name
 * @param network_name Network name
 * @param ip_address IP address (NULL for auto)
 * @param aliases Network aliases
 * @param alias_count Number of aliases
 * @return container_status_t Status code
 */
container_status_t container_connect_network(container_handle_t* handle,
                                            const char* container_id,
                                            const char* network_name,
                                            const char* ip_address,
                                            const char** aliases,
                                            uint32_t alias_count);

/**
 * @brief Disconnect container from network
 * 
 * @param handle Container handle
 * @param container_id Container ID or name
 * @param network_name Network name
 * @param force Force disconnect
 * @return container_status_t Status code
 */
container_status_t container_disconnect_network(container_handle_t* handle,
                                               const char* container_id,
                                               const char* network_name,
                                               bool force);

/**
 * @brief Remove network
 * 
 * @param handle Container handle
 * @param network_name Network name
 * @return container_status_t Status code
 */
container_status_t container_remove_network(container_handle_t* handle,
                                           const char* network_name);

// ============================================================================
// Orchestration Management (Kubernetes/OpenShift/Swarm)
// ============================================================================

/**
 * @brief List pods
 * 
 * @param handle Container handle
 * @param namespace Pod namespace (NULL for all)
 * @param pods Array to store pod info
 * @param max_pods Maximum pods to retrieve
 * @param actual_count Output parameter for actual count
 * @return container_status_t Status code
 */
container_status_t container_list_pods(container_handle_t* handle,
                                      const char* namespace,
                                      container_pod_info_t* pods,
                                      uint32_t max_pods,
                                      uint32_t* actual_count);

/**
 * @brief Get pod information
 * 
 * @param handle Container handle
 * @param namespace Pod namespace
 * @param pod_name Pod name
 * @param pod_info Output parameter for pod info
 * @return container_status_t Status code
 */
container_status_t container_get_pod(container_handle_t* handle,
                                    const char* namespace,
                                    const char* pod_name,
                                    container_pod_info_t* pod_info);

/**
 * @brief Create pod
 * 
 * @param handle Container handle
 * @param namespace Pod namespace
 * @param pod_definition Pod definition (YAML/JSON)
 * @param pod_definition_size Size of pod definition
 * @param pod_name Output parameter for pod name
 * @param name_size Size of name buffer
 * @return container_status_t Status code
 */
container_status_t container_create_pod(container_handle_t* handle,
                                       const char* namespace,
                                       const void* pod_definition,
                                       size_t pod_definition_size,
                                       char* pod_name,
                                       size_t name_size);

/**
 * @brief Delete pod
 * 
 * @param handle Container handle
 * @param namespace Pod namespace
 * @param pod_name Pod name
 * @param grace_period Grace period in seconds
 * @return container_status_t Status code
 */
container_status_t container_delete_pod(container_handle_t* handle,
                                       const char* namespace,
                                       const char* pod_name,
                                       uint32_t grace_period);

/**
 * @brief List services
 * 
 * @param handle Container handle
 * @param namespace Service namespace (NULL for all)
 * @param services Array to store service info
 * @param max_services Maximum services to retrieve
 * @param actual_count Output parameter for actual count
 * @return container_status_t Status code
 */
container_status_t container_list_services(container_handle_t* handle,
                                          const char* namespace,
                                          container_service_info_t* services,
                                          uint32_t max_services,
                                          uint32_t* actual_count);

/**
 * @brief List nodes
 * 
 * @param handle Container handle
 * @param nodes Array to store node info
 * @param max_nodes Maximum nodes to retrieve
 * @param actual_count Output parameter for actual count
 * @return container_status_t Status code
 */
container_status_t container_list_nodes(container_handle_t* handle,
                                       container_node_info_t* nodes,
                                       uint32_t max_nodes,
                                       uint32_t* actual_count);

/**
 * @brief Scale deployment
 * 
 * @param handle Container handle
 * @param namespace Deployment namespace
 * @param deployment_name Deployment name
 * @param replicas Number of replicas
 * @return container_status_t Status code
 */
container_status_t container_scale_deployment(container_handle_t* handle,
                                            const char* namespace,
                                            const char* deployment_name,
                                            uint32_t replicas);

/**
 * @brief Get cluster metrics
 * 
 * @param handle Container handle
 * @param total_nodes Output parameter for total nodes
 * @param total_pods Output parameter for total pods
 * @param total_containers Output parameter for total containers
 * @param cpu_usage Output parameter for cluster CPU usage percentage
 * @param memory_usage Output parameter for cluster memory usage percentage
 * @return container_status_t Status code
 */
container_status_t container_get_cluster_metrics(container_handle_t* handle,
                                                uint32_t* total_nodes,
                                                uint32_t* total_pods,
                                                uint32_t* total_containers,
                                                double* cpu_usage,
                                                double* memory_usage);

// ============================================================================
// Security and Compliance
// ============================================================================

/**
 * @brief Scan container for vulnerabilities
 * 
 * @param handle Container handle
 * @param container_id Container ID or name
 * @param scan_report Output parameter for scan report
 * @param report_size Size of report buffer
 * @param actual_size Output parameter for actual report size
 * @return container_status_t Status code
 */
container_status_t container_scan_container(container_handle_t* handle,
                                          const char* container_id,
                                          char* scan_report,
                                          size_t report_size,
                                          size_t* actual_size);

/**
 * @brief Check container compliance
 * 
 * @param handle Container handle
 * @param container_id Container ID or name
 * @param standard Compliance standard (CIS, NIST, etc.)
 * @param is_compliant Output parameter for compliance status
 * @param compliance_score Output parameter for compliance score
 * @param violations Array for violations found
 * @param max_violations Maximum violations to return
 * @param actual_violations Output parameter for actual violations
 * @return container_status_t Status code
 */
container_status_t container_check_compliance(container_handle_t* handle,
                                            const char* container_id,
                                            const char* standard,
                                            bool* is_compliant,
                                            uint32_t* compliance_score,
                                            char** violations,
                                            uint32_t max_violations,
                                            uint32_t* actual_violations);

/**
 * @brief Apply security policy
 * 
 * @param handle Container handle
 * @param container_id Container ID or name
 * @param policy Security policy (YAML/JSON)
 * @param policy_size Size of policy data
 * @return container_status_t Status code
 */
container_status_t container_apply_security_policy(container_handle_t* handle,
                                                  const char* container_id,
                                                  const void* policy,
                                                  size_t policy_size);

/**
 * @brief Quarantine container
 * 
 * @param handle Container handle
 * @param container_id Container ID or name
 * @param reason Quarantine reason
 * @return container_status_t Status code
 */
container_status_t container_quarantine(container_handle_t* handle,
                                       const char* container_id,
                                       const char* reason);

// ============================================================================
// Event Monitoring
// ============================================================================

/**
 * @brief Get container events
 * 
 * @param handle Container handle
 * @param since Timestamp for events since
 * @param until Timestamp for events until
 * @param filter Event filter
 * @param events Array to store events
 * @param max_events Maximum events to retrieve
 * @param actual_events Output parameter for actual events
 * @return container_status_t Status code
 */
container_status_t container_get_events(container_handle_t* handle,
                                       time_t since,
                                       time_t until,
                                       const char* filter,
                                       container_event_t* events,
                                       uint32_t max_events,
                                       uint32_t* actual_events);

/**
 * @brief Subscribe to container events
 * 
 * @param handle Container handle
 * @param filter Event filter
 * @param event_callback Callback for events
 * @param user_data User data for callback
 * @param subscription_id Output parameter for subscription ID
 * @return container_status_t Status code
 */
container_status_t container_subscribe_events(container_handle_t* handle,
                                            const char* filter,
                                            void (*event_callback)(const container_event_t* event, void* user_data),
                                            void* user_data,
                                            char* subscription_id);

/**
 * @brief Unsubscribe from container events
 * 
 * @param handle Container handle
 * @param subscription_id Subscription ID
 * @return container_status_t Status code
 */
container_status_t container_unsubscribe_events(container_handle_t* handle,
                                               const char* subscription_id);

// ============================================================================
// Inline Utility Functions
// ============================================================================

/**
 * @brief Check if container monitoring is active
 * 
 * @param handle Container handle to check
 * @return true if monitoring is active, false otherwise
 */
static inline bool container_is_monitoring_active(const container_handle_t* handle) {
    return (handle != NULL);
}

/**
 * @brief Convert nanoseconds to seconds
 * 
 * @param nanos Time in nanoseconds
 * @return Time in seconds
 */
static inline double container_nanos_to_seconds(uint64_t nanos) {
    return (double)nanos / 1000000000.0;
}

/**
 * @brief Convert bytes to megabytes
 * 
 * @param bytes Size in bytes
 * @return Size in megabytes
 */
static inline double container_bytes_to_mb(uint64_t bytes) {
    return (double)bytes / (1024.0 * 1024.0);
}

/**
 * @brief Convert bytes to gigabytes
 * 
 * @param bytes Size in bytes
 * @return Size in gigabytes
 */
static inline double container_bytes_to_gb(uint64_t bytes) {
    return (double)bytes / (1024.0 * 1024.0 * 1024.0);
}

/**
 * @brief Calculate CPU percentage from usage and system
 * 
 * @param cpu_usage Container CPU usage in nanoseconds
 * @param system_usage System CPU usage in nanoseconds
 * @param previous_cpu_usage Previous container CPU usage
 * @param previous_system_usage Previous system CPU usage
 * @return CPU usage percentage
 */
static inline double container_calculate_cpu_percentage(uint64_t cpu_usage,
                                                       uint64_t system_usage,
                                                       uint64_t previous_cpu_usage,
                                                       uint64_t previous_system_usage) {
    uint64_t cpu_delta = cpu_usage - previous_cpu_usage;
    uint64_t system_delta = system_usage - previous_system_usage;
    
    if (system_delta == 0) return 0.0;
    
    return ((double)cpu_delta / (double)system_delta) * 100.0;
}

/**
 * @brief Calculate memory percentage
 * 
 * @param memory_usage Memory usage in bytes
 * @param memory_limit Memory limit in bytes
 * @return Memory usage percentage
 */
static inline double container_calculate_memory_percentage(uint64_t memory_usage,
                                                          uint64_t memory_limit) {
    if (memory_limit == 0) return 0.0;
    return ((double)memory_usage / (double)memory_limit) * 100.0;
}

/**
 * @brief Parse container state to string
 * 
 * @param state Container state
 * @return const char* State string
 */
static inline const char* container_state_to_string(container_state_t state) {
    switch (state) {
        case CONTAINER_STATE_CREATED: return "created";
        case CONTAINER_STATE_RUNNING: return "running";
        case CONTAINER_STATE_PAUSED: return "paused";
        case CONTAINER_STATE_RESTARTING: return "restarting";
        case CONTAINER_STATE_EXITED: return "exited";
        case CONTAINER_STATE_DEAD: return "dead";
        case CONTAINER_STATE_STOPPED: return "stopped";
        case CONTAINER_STATE_KILLED: return "killed";
        case CONTAINER_STATE_ORPHANED: return "orphaned";
        default: return "unknown";
    }
}

/**
 * @brief Parse health status to string
 * 
 * @param health Health status
 * @return const char* Health status string
 */
static inline const char* container_health_to_string(container_health_status_t health) {
    switch (health) {
        case HEALTH_STATUS_STARTING: return "starting";
        case HEALTH_STATUS_HEALTHY: return "healthy";
        case HEALTH_STATUS_UNHEALTHY: return "unhealthy";
        case HEALTH_STATUS_DEGRADED: return "degraded";
        case HEALTH_STATUS_UNKNOWN: return "unknown";
        case HEALTH_STATUS_NONE: return "none";
        default: return "unknown";
    }
}

/**
 * @brief Get API version string
 * 
 * @return const char* Version string
 */
static inline const char* container_get_version_string(void) {
    return "3.8.0";
}

// ============================================================================
// Platform-Specific Extensions
// ============================================================================

#if defined(HAVE_DOCKER)
/**
 * @brief Get Docker-specific information
 * 
 * @param handle Container handle
 * @param docker_info Output parameter for Docker info
 * @param info_size Size of info buffer
 * @return container_status_t Status code
 */
container_status_t container_get_docker_info(container_handle_t* handle,
                                            char* docker_info,
                                            size_t info_size);
#endif

#if defined(HAVE_KUBERNETES)
/**
 * @brief Get Kubernetes-specific information
 * 
 * @param handle Container handle
 * @param k8s_info Output parameter for Kubernetes info
 * @param info_size Size of info buffer
 * @return container_status_t Status code
 */
container_status_t container_get_kubernetes_info(container_handle_t* handle,
                                                char* k8s_info,
                                                size_t info_size);
#endif

// ============================================================================
// Export Macros for Shared Libraries
// ============================================================================
#ifdef BUILDING_CONTAINER_DLL
    #define CONTAINER_API __declspec(dllexport)
#elif defined(USING_CONTAINER_DLL)
    #define CONTAINER_API __declspec(dllimport)
#else
    #define CONTAINER_API
#endif

#ifdef __cplusplus
}
#endif

#endif // CONTAINER_H

// ============================================================================
// Implementation Notes:
// ============================================================================
// 1. Runtime Support: Docker, containerd, CRI-O, Podman, LXC/LXD
// 2. Orchestrator Support: Kubernetes, Docker Swarm, OpenShift, Nomad, Mesos
// 3. Cloud Integration: AWS ECS/EKS, Azure AKS, Google GKE
// 4. Performance Metrics: CPU, memory, network, I/O, GPU, custom metrics
// 5. Security: Vulnerability scanning, compliance checking, security policies
// 6. Lifecycle Management: Create, start, stop, restart, remove containers
// 7. Image Management: Pull, push, build, scan, manage images
// 8. Storage: Volume management, storage drivers, persistent storage
// 9. Networking: Network management, port mapping, service discovery
// 10. Observability: Logging, events, tracing, health checks, metrics