/**
 * @file features.h
 * @brief System Features and Capabilities Summary
 * 
 * This file provides a comprehensive overview of all features, capabilities,
 * and configuration options available in the Data Export and Alerting System.
 * It serves as a reference for developers, administrators, and integrators.
 * 
 * @author System Architecture Team
 * @date 2024-01-31
 * @version 4.1.0
 * 
 * @license Apache 2.0
 * @copyright Copyright (c) 2024 Integration Solutions
 */

#ifndef FEATURES_H
#define FEATURES_H

#ifdef __cplusplus
extern "C" {
#endif

// ============================================================================
// System Overview
// ============================================================================

/**
 * @def SYSTEM_NAME
 * @brief System name
 */
#define SYSTEM_NAME "Data Integration Platform"

/**
 * @def SYSTEM_VERSION
 * @brief System version
 */
#define SYSTEM_VERSION "4.1.0"

/**
 * @def SYSTEM_DESCRIPTION
 * @brief System description
 */
#define SYSTEM_DESCRIPTION "Enterprise-grade data export, transformation, and alerting platform"

// ============================================================================
// Module: Export System (export.h)
// ============================================================================

/**
 * @defgroup export_features Export System Features
 * @{
 */

/**
 * @def EXPORT_FORMAT_COUNT
 * @brief Number of supported export formats
 */
#define EXPORT_FORMAT_COUNT 22

/**
 * @def EXPORT_DESTINATION_COUNT
 * @brief Number of supported export destinations
 */
#define EXPORT_DESTINATION_COUNT 26

/**
 * @def EXPORT_COMPRESSION_COUNT
 * @brief Number of supported compression algorithms
 */
#define EXPORT_COMPRESSION_COUNT 8

/**
 * @def EXPORT_ENCRYPTION_COUNT
 * @brief Number of supported encryption algorithms
 */
#define EXPORT_ENCRYPTION_COUNT 6

/**
 * @def EXPORT_PROTOCOL_COUNT
 * @brief Number of supported network protocols
 */
#define EXPORT_PROTOCOL_COUNT 12

// Supported Export Formats
#define FEATURE_FORMAT_CSV            /**< CSV: Comma-Separated Values */
#define FEATURE_FORMAT_JSON           /**< JSON: JavaScript Object Notation */
#define FEATURE_FORMAT_XML            /**< XML: Extensible Markup Language */
#define FEATURE_FORMAT_YAML           /**< YAML: YAML Ain't Markup Language */
#define FEATURE_FORMAT_PROTOBUF       /**< Protocol Buffers (binary serialization) */
#define FEATURE_FORMAT_AVRO           /**< Apache Avro (data serialization) */
#define FEATURE_FORMAT_PARQUET        /**< Apache Parquet (columnar storage) */
#define FEATURE_FORMAT_ORC            /**< Apache ORC (Optimized Row Columnar) */
#define FEATURE_FORMAT_EXCEL          /**< Microsoft Excel (XLSX format) */
#define FEATURE_FORMAT_PDF            /**< PDF: Portable Document Format */
#define FEATURE_FORMAT_HTML           /**< HTML: HyperText Markup Language */
#define FEATURE_FORMAT_MARKDOWN       /**< Markdown documentation format */
#define FEATURE_FORMAT_PLAIN_TEXT     /**< Plain text format */
#define FEATURE_FORMAT_BINARY         /**< Custom binary format */
#define FEATURE_FORMAT_SQL            /**< SQL statements and scripts */
#define FEATURE_FORMAT_GRAPHQL        /**< GraphQL queries and responses */
#define FEATURE_FORMAT_PROMETHEUS     /**< Prometheus metrics format */
#define FEATURE_FORMAT_INFLUXDB       /**< InfluxDB line protocol */
#define FEATURE_FORMAT_OPENTSDB       /**< OpenTSDB format */
#define FEATURE_FORMAT_LOGFMT         /**< Logfmt structured logging */
#define FEATURE_FORMAT_SYSLOG         /**< Syslog message format */
#define FEATURE_FORMAT_CUSTOM         /**< Custom/plugin formats */

// Supported Export Destinations
#define FEATURE_DEST_FILE             /**< Local filesystem */
#define FEATURE_DEST_HTTP             /**< HTTP/HTTPS endpoints */
#define FEATURE_DEST_FTP              /**< FTP servers */
#define FEATURE_DEST_SFTP             /**< SFTP/SSH File Transfer */
#define FEATURE_DEST_S3               /**< Amazon S3 object storage */
#define FEATURE_DEST_GCS              /**< Google Cloud Storage */
#define FEATURE_DEST_AZURE_BLOB       /**< Azure Blob Storage */
#define FEATURE_DEST_KAFKA            /**< Apache Kafka message broker */
#define FEATURE_DEST_RABBITMQ         /**< RabbitMQ message broker */
#define FEATURE_DEST_REDIS            /**< Redis in-memory data store */
#define FEATURE_DEST_MYSQL            /**< MySQL database */
#define FEATURE_DEST_POSTGRESQL       /**< PostgreSQL database */
#define FEATURE_DEST_SQLITE           /**< SQLite embedded database */
#define FEATURE_DEST_MONGODB          /**< MongoDB NoSQL database */
#define FEATURE_DEST_ELASTICSEARCH    /**< Elasticsearch search engine */
#define FEATURE_DEST_SPLUNK           /**< Splunk SIEM platform */
#define FEATURE_DEST_DATADOG          /**< Datadog monitoring platform */
#define FEATURE_DEST_NEW_RELIC        /**< New Relic APM */
#define FEATURE_DEST_PROMETHEUS       /**< Prometheus monitoring */
#define FEATURE_DEST_GRAFANA          /**< Grafana dashboards */
#define FEATURE_DEST_CLOUDWATCH       /**< AWS CloudWatch */
#define FEATURE_DEST_STACKDRIVER      /**< Google Stackdriver/Cloud Monitoring */
#define FEATURE_DEST_EMAIL            /**< Email delivery */
#define FEATURE_DEST_WEBHOOK          /**< Custom webhooks */
#define FEATURE_DEST_GRPC             /**< gRPC services */
#define FEATURE_DEST_STDOUT           /**< Standard output (console) */
#define FEATURE_DEST_SYSLOG           /**< Syslog servers */
#define FEATURE_DEST_CUSTOM           /**< Custom/plugin destinations */

// Supported Compression Algorithms
#define FEATURE_COMPRESSION_GZIP      /**< Gzip compression (DEFLATE) */
#define FEATURE_COMPRESSION_ZLIB      /**< Zlib compression library */
#define FEATURE_COMPRESSION_BZIP2     /**< Bzip2 block-sorting compressor */
#define FEATURE_COMPRESSION_LZ4       /**< LZ4 fast compression */
#define FEATURE_COMPRESSION_SNAPPY    /**< Snappy fast compression (Google) */
#define FEATURE_COMPRESSION_ZSTD      /**< Zstandard (Facebook) */
#define FEATURE_COMPRESSION_LZMA      /**< LZMA/LZMA2 (7-Zip) */

// Supported Encryption Algorithms
#define FEATURE_ENCRYPTION_AES_128    /**< AES-128 symmetric encryption */
#define FEATURE_ENCRYPTION_AES_256    /**< AES-256 symmetric encryption */
#define FEATURE_ENCRYPTION_RSA        /**< RSA asymmetric encryption */
#define FEATURE_ENCRYPTION_CHACHA20   /**< ChaCha20 stream cipher */
#define FEATURE_ENCRYPTION_PGP        /**< PGP/GPG encryption */

// Supported Network Protocols
#define FEATURE_PROTOCOL_HTTP         /**< HTTP 1.1/2.0 */
#define FEATURE_PROTOCOL_HTTPS        /**< HTTPS (TLS) */
#define FEATURE_PROTOCOL_FTP          /**< File Transfer Protocol */
#define FEATURE_PROTOCOL_SFTP         /**< SSH File Transfer Protocol */
#define FEATURE_PROTOCOL_WS           /**< WebSocket */
#define FEATURE_PROTOCOL_WSS          /**< Secure WebSocket */
#define FEATURE_PROTOCOL_TCP          /**< Raw TCP sockets */
#define FEATURE_PROTOCOL_UDP          /**< UDP datagrams */
#define FEATURE_PROTOCOL_MQTT         /**< MQTT pub/sub */
#define FEATURE_PROTOCOL_AMQP         /**< AMQP 0.9.1/1.0 */
#define FEATURE_PROTOCOL_GRPC         /**< gRPC (HTTP/2) */
#define FEATURE_PROTOCOL_KAFKA        /**< Apache Kafka protocol */

// Export System Capabilities
#define FEATURE_BATCH_EXPORT          /**< Batch processing of data */
#define FEATURE_STREAMING_EXPORT      /**< Real-time streaming export */
#define FEATURE_INCREMENTAL_EXPORT    /**< Incremental/delta exports */
#define FEATURE_PARALLEL_EXPORT       /**< Parallel export to multiple destinations */
#define FEATURE_TRANSACTIONAL_EXPORT  /**< Atomic transactions with rollback */
#define FEATURE_SCHEMA_VALIDATION     /**< Data schema validation */
#define FEATURE_DATA_TRANSFORMATION   /**< In-flight data transformation */
#define FEATURE_FIELD_MAPPING         /**< Field mapping/renaming */
#define FEATURE_DATA_FILTERING        /**< Row/column filtering */
#define FEATURE_DATA_AGGREGATION      /**< Aggregation (sum, avg, count, etc.) */
#define FEATURE_DATA_ENRICHMENT       /**< Data enrichment from external sources */
#define FEATURE_DATA_MASKING          /**< Sensitive data masking */
#define FEATURE_DATA_ANONYMIZATION    /**< PII anonymization */
#define FEATURE_RETRY_LOGIC           /**< Automatic retry on failure */
#define FEATURE_RATE_LIMITING         /**< Rate limiting and throttling */
#define FEATURE_QUEUE_BUFFERING       /**< In-memory/disk buffering */
#define FEATURE_CHECKPOINT_RESTART    /**< Resume from checkpoint on failure */
#define FEATURE_PROGRESS_TRACKING     /**< Real-time progress tracking */
#define FEATURE_METRICS_COLLECTION    /**< Performance metrics collection */
#define FEATURE_PLUGIN_ARCHITECTURE   /**< Extensible plugin system */
#define FEATURE_TEMPLATE_ENGINE       /**< Template-based formatting */
#define FEATURE_MACRO_EXPANSION       /**< Variable and macro expansion */

// Performance Features
#define FEATURE_HIGH_THROUGHPUT       /**< Optimized for high throughput */
#define FEATURE_LOW_LATENCY           /**< Optimized for low latency */
#define FEATURE_MEMORY_EFFICIENT      /**< Memory-efficient processing */
#define FEATURE_SCALABLE              /**< Horizontally scalable */
#define FEATURE_MULTI_THREADED        /**< Multi-threaded processing */
#define FEATURE_ASYNC_IO              /**< Asynchronous I/O operations */
#define FEATURE_CONNECTION_POOLING    /**< Connection pooling */
#define FEATURE_BATCH_OPTIMIZATION    /**< Batch size optimization */
#define FEATURE_COMPRESSION_OPTIMIZED /**< Compression-optimized formats */

// Security Features
#define FEATURE_TLS_ENCRYPTION        /**< Transport Layer Security */
#define FEATURE_AUTHENTICATION        /**< Multiple authentication methods */
#define FEATURE_AUTHORIZATION         /**< Role-based access control */
#define FEATURE_AUDIT_LOGGING         /**< Comprehensive audit logging */
#define FEATURE_DATA_AT_REST_ENCRYPT  /**< Encryption of data at rest */
#define FEATURE_DATA_IN_TRANSIT_ENCRYPT /**< Encryption of data in transit */
#define FEATURE_KEY_MANAGEMENT        /**< Encryption key management */
#define FEATURE_CERTIFICATE_VALIDATION /**< SSL/TLS certificate validation */
#define FEATURE_SECRETS_MANAGEMENT    /**< Secure secrets storage */

// Reliability Features
#define FEATURE_ATOMIC_OPERATIONS     /**< All-or-nothing operations */
#define FEATURE_IDEMPOTENT_OPS        /**< Idempotent operations */
#define FEATURE_DE_DUPLICATION        /**< Duplicate detection and handling */
#define FEATURE_ORDERING_GUARANTEE    /**< Message/record ordering guarantee */
#define FEATURE_EXACTLY_ONCE_DELIVERY /**< Exactly-once delivery semantics */
#define FEATURE_DEAD_LETTER_QUEUE     /**< Dead letter queue for failed items */
#define FEATURE_HEALTH_CHECKS         /**< System health monitoring */
#define FEATURE_AUTO_HEALING          /**< Automatic recovery from failures */
#define FEATURE_CIRCUIT_BREAKER       /**< Circuit breaker pattern */

// Monitoring & Observability
#define FEATURE_REAL_TIME_METRICS     /**< Real-time performance metrics */
#define FEATURE_DISTRIBUTED_TRACING   /**< End-to-end request tracing */
#define FEATURE_STRUCTURED_LOGGING    /**< Structured JSON logging */
#define FEATURE_LOG_AGGREGATION       /**< Centralized log collection */
#define FEATURE_ALERT_INTEGRATION     /**< Integration with alerting system */
#define FEATURE_DASHBOARD_INTEGRATION /**< Integration with dashboards */
#define FEATURE_PROMETHEUS_METRICS    /**< Prometheus metrics endpoint */
#define FEATURE_HEALTH_ENDPOINTS      /**< Health check HTTP endpoints */

/** @} */ // end of export_features

// ============================================================================
// Module: Alerting System (alerts.h)
// ============================================================================

/**
 * @defgroup alert_features Alerting System Features
 * @{
 */

/**
 * @def ALERT_SEVERITY_COUNT
 * @brief Number of alert severity levels
 */
#define ALERT_SEVERITY_COUNT 6

/**
 * @def ALERT_SOURCE_COUNT
 * @brief Number of alert source types
 */
#define ALERT_SOURCE_COUNT 13

/**
 * @def ALERT_CHANNEL_COUNT
 * @brief Number of notification channels
 */
#define ALERT_CHANNEL_COUNT 17

/**
 * @def ALERT_OPERATOR_COUNT
 * @brief Number of condition operators
 */
#define ALERT_OPERATOR_COUNT 18

// Alert Severity Levels
#define FEATURE_SEVERITY_INFO         /**< Informational (no action required) */
#define FEATURE_SEVERITY_LOW          /**< Low priority (routine maintenance) */
#define FEATURE_SEVERITY_MEDIUM       /**< Medium priority (requires attention) */
#define FEATURE_SEVERITY_HIGH         /**< High priority (immediate attention) */
#define FEATURE_SEVERITY_CRITICAL     /**< Critical (service impacting) */
#define FEATURE_SEVERITY_EMERGENCY    /**< Emergency (system down) */

// Alert Sources
#define FEATURE_ALERT_SOURCE_EXPORT   /**< Export operations and errors */
#define FEATURE_ALERT_SOURCE_SYSTEM   /**< System health (CPU, memory, disk) */
#define FEATURE_ALERT_SOURCE_NETWORK  /**< Network connectivity and performance */
#define FEATURE_ALERT_SOURCE_DATABASE /**< Database connectivity and performance */
#define FEATURE_ALERT_SOURCE_APP      /**< Application errors and performance */
#define FEATURE_ALERT_SOURCE_SECURITY /**< Security events and violations */
#define FEATURE_ALERT_SOURCE_PERFORMANCE /**< Performance degradation */
#define FEATURE_ALERT_SOURCE_CAPACITY /**< Capacity and quota limits */
#define FEATURE_ALERT_SOURCE_DATA_QUALITY /**< Data quality issues */
#define FEATURE_ALERT_SOURCE_BUSINESS /**< Business metrics and KPIs */
#define FEATURE_ALERT_SOURCE_MONITORING /**< Monitoring system itself */
#define FEATURE_ALERT_SOURCE_EXTERNAL /**< External system health */
#define FEATURE_ALERT_SOURCE_CUSTOM   /**< Custom alert sources */

// Notification Channels
#define FEATURE_CHANNEL_EMAIL         /**< Email notifications */
#define FEATURE_CHANNEL_SLACK         /**< Slack messages and alerts */
#define FEATURE_CHANNEL_TEAMS         /**< Microsoft Teams messages */
#define FEATURE_CHANNEL_WEBHOOK       /**< Generic HTTP webhooks */
#define FEATURE_CHANNEL_SMS           /**< SMS text messages */
#define FEATURE_CHANNEL_CALL          /**< Voice calls */
#define FEATURE_CHANNEL_PUSH          /**< Mobile push notifications */
#define FEATURE_CHANNEL_PAGERDUTY     /**< PagerDuty incident management */
#define FEATURE_CHANNEL_OPSGENIE      /**< OpsGenie alert management */
#define FEATURE_CHANNEL_VICTOROPS     /**< VictorOps incident management */
#define FEATURE_CHANNEL_DATADOG       /**< Datadog event streaming */
#define FEATURE_CHANNEL_GRAFANA       /**< Grafana alert notifications */
#define FEATURE_CHANNEL_PROMETHEUS    /**< Prometheus Alertmanager */
#define FEATURE_CHANNEL_SYSLOG        /**< Syslog message forwarding */
#define FEATURE_CHANNEL_CONSOLE       /**< Console output */
#define FEATURE_CHANNEL_FILE          /**< File-based logging */
#define FEATURE_CHANNEL_CUSTOM        /**< Custom notification channels */

// Alert Condition Operators
#define FEATURE_OPERATOR_EQUAL        /**< Equal to (=) */
#define FEATURE_OPERATOR_NOT_EQUAL    /**< Not equal to (!=) */
#define FEATURE_OPERATOR_GREATER      /**< Greater than (>) */
#define FEATURE_OPERATOR_GREATER_EQUAL /**< Greater than or equal (>=) */
#define FEATURE_OPERATOR_LESS         /**< Less than (<) */
#define FEATURE_OPERATOR_LESS_EQUAL   /**< Less than or equal (<=) */
#define FEATURE_OPERATOR_CONTAINS     /**< Contains substring */
#define FEATURE_OPERATOR_NOT_CONTAINS /**< Does not contain substring */
#define FEATURE_OPERATOR_STARTS_WITH  /**< Starts with prefix */
#define FEATURE_OPERATOR_ENDS_WITH    /**< Ends with suffix */
#define FEATURE_OPERATOR_MATCHES      /**< Matches regular expression */
#define FEATURE_OPERATOR_IN_LIST      /**< In list of values */
#define FEATURE_OPERATOR_NOT_IN_LIST  /**< Not in list of values */
#define FEATURE_OPERATOR_BETWEEN      /**< Between two values */
#define FEATURE_OPERATOR_IS_NULL      /**< Is null/empty */
#define FEATURE_OPERATOR_NOT_NULL     /**< Is not null/empty */
#define FEATURE_OPERATOR_CHANGED      /**< Value has changed */
#define FEATURE_OPERATOR_INCREASED    /**< Increased by amount */
#define FEATURE_OPERATOR_DECREASED    /**< Decreased by amount */

// Alerting Capabilities
#define FEATURE_COMPLEX_CONDITIONS    /**< Complex boolean logic (AND/OR/NOT) */
#define FEATURE_TIME_BASED_ALERTS     /**< Time-based alert conditions */
#define FEATURE_RATE_BASED_ALERTS     /**< Rate-of-change alerts */
#define FEATURE_ANOMALY_DETECTION     /**< Statistical anomaly detection */
#define FEATURE_FORECASTING_ALERTS    /**< Predictive alerting */
#define FEATURE_SEASONAL_ADJUSTMENT   /**< Seasonal pattern adjustment */
#define FEATURE_HYSTERESIS            /**< Hysteresis to prevent flapping */
#define FEATURE_DEBOUNCING            /**< Alert debouncing */
#define FEATURE_THROTTLING            /**< Alert rate limiting */
#define FEATURE_DEDUPLICATION         /**< Duplicate alert suppression */
#define FEATURE_CORRELATION           /**< Alert correlation and grouping */
#define FEATURE_ROOT_CAUSE_ANALYSIS   /**< Root cause identification */
#define FEATURE_IMPACT_ANALYSIS       /**< Business impact assessment */
#define FEATURE_AUTO_REMEDIATION      /**< Automated remediation actions */
#define FEATURE_RUNBOOK_INTEGRATION   /**< Integration with runbooks */
#define FEATURE_CHAT_OPS              /**< ChatOps integration */
#define FEATURE_MOBILE_APP            /**< Mobile alert management */

// Escalation Features
#define FEATURE_MULTI_LEVEL_ESCALATION /**< Multi-level escalation policies */
#define FEATURE_TIME_BASED_ESCALATION  /**< Time-triggered escalation */
#define FEATURE_ON_CALL_SCHEDULES      /**< On-call schedule management */
#define FEATURE_ROTATION_MANAGEMENT    /**< Team rotation management */
#define FEATURE_OVERRIDE_HANDLING      /**< Schedule overrides and swaps */
#define FEATURE_ESCALATION_OVERRIDES   /**< Manual escalation overrides */

// Silence/Snooze Features
#define FEATURE_TIME_BASED_SILENCE    /**< Time-based alert suppression */
#define FEATURE_RECURRING_SILENCE     /**< Recurring maintenance windows */
#define FEATURE_PATTERN_BASED_SILENCE /**< Pattern-based suppression */
#define FEATURE_GLOBAL_SILENCE        /**< Global silence mode */
#define FEATURE_SNOOZE_FUNCTIONALITY  /**< Temporary alert snoozing */
#define FEATURE_AUTO_SNOOZE           /**< Automatic snooze based on patterns */

// Alert Management
#define FEATURE_BATCH_OPERATIONS      /**< Batch acknowledge/resolve */
#define FEATURE_BULK_UPDATES          /**< Bulk alert updates */
#define FEATURE_ALERT_TAGGING         /**< Tag-based alert organization */
#define FEATURE_ANNOTATIONS           /**< Alert annotations and notes */
#define FEATURE_ATTACHMENTS           /**< File attachments to alerts */
#define FEATURE_ALERT_TEMPLATES       /**< Alert template management */
#define FEATURE_ALERT_PLAYBOOKS       /**< Alert response playbooks */
#define FEATURE_POST_MORTEM_INTEGRATION /**< Integration with post-mortems */

// Integration Features
#define FEATURE_EXPORT_MONITORING     /**< Real-time export monitoring */
#define FEATURE_PERFORMANCE_MONITORING /**< System performance monitoring */
#define FEATURE_APPLICATION_MONITORING /**< Application performance monitoring */
#define FEATURE_INFRASTRUCTURE_MONITORING /**< Infrastructure monitoring */
#define FEATURE_BUSINESS_METRICS      /**< Business KPI monitoring */
#define FEATURE_THIRD_PARTY_INTEGRATION /**< Third-party system integration */
#define FEATURE_API_GATEWAY           /**< API gateway integration */
#define FEATURE_SERVICE_MESH          /**< Service mesh integration */
#define FEATURE_CLOUD_PLATFORM        /**< Cloud platform integration */

// Dashboard & Reporting
#define FEATURE_REAL_TIME_DASHBOARD   /**< Real-time alert dashboard */
#define FEATURE_HISTORICAL_REPORTS    /**< Historical alert reports */
#define FEATURE_TREND_ANALYSIS        /**< Alert trend analysis */
#define FEATURE_FORECAST_REPORTS      /**< Predictive forecasting reports */
#define FEATURE_CUSTOM_DASHBOARDS     /**< Customizable dashboards */
#define FEATURE_ROLE_BASED_VIEWS      /**< Role-based dashboard views */
#define FEATURE_SCHEDULED_REPORTS     /**< Scheduled report generation */
#define FEATURE_REPORT_EXPORT         /**< Report export in multiple formats */

// Advanced Analytics
#define FEATURE_MACHINE_LEARNING      /**< ML-based alert optimization */
#define FEATURE_PATTERN_RECOGNITION   /**< Pattern recognition in alerts */
#define FEATURE_CLUSTERING_ALGORITHMS /**< Alert clustering algorithms */
#define FEATURE_PREDICTIVE_MAINTENANCE /**< Predictive maintenance alerts */
#define FEATURE_COST_OPTIMIZATION     /**< Cost-based alert optimization */
#define FEATURE_PERFORMANCE_OPTIMIZATION /**< Performance optimization */

/** @} */ // end of alert_features

// ============================================================================
// System-Wide Features
// ============================================================================

/**
 * @defgroup system_features System-Wide Features
 * @{
 */

// Architecture Features
#define FEATURE_MODULAR_ARCHITECTURE  /**< Modular, pluggable architecture */
#define FEATURE_MICROSERVICES_READY   /**< Designed for microservices */
#define FEATURE_CONTAINER_NATIVE      /**< Container-optimized design */
#define FEATURE_CLOUD_NATIVE          /**< Cloud-native principles */
#define FEATURE_SERVERLESS_READY      /**< Serverless deployment ready */
#define FEATURE_KUBERNETES_NATIVE     /**< Kubernetes-native deployment */
#define FEATURE_MULTI_TENANT          /**< Multi-tenant architecture */
#define FEATURE_HIGH_AVAILABILITY     /**< High availability design */
#define FEATURE_DISASTER_RECOVERY     /**< Disaster recovery capabilities */
#define FEATURE_GEO_REPLICATION       /**< Geographic replication */
#define FEATURE_ACTIVE_ACTIVE         /**< Active-active deployment */

// Performance & Scalability
#define FEATURE_HORIZONTAL_SCALING    /**< Horizontal scalability */
#define FEATURE_VERTICAL_SCALING      /**< Vertical scalability */
#define FEATURE_AUTO_SCALING          /**< Automatic scaling */
#define FEATURE_LOAD_BALANCING        /**< Load balancing support */
#define FEATURE_CACHE_LAYERS          /**< Multi-level caching */
#define FEATURE_CDN_INTEGRATION       /**< CDN integration */
#define FEATURE_EDGE_COMPUTING        /**< Edge computing support */

// Security & Compliance
#define FEATURE_SOC2_COMPLIANT        /**< SOC 2 Type II compliance */
#define FEATURE_HIPAA_COMPLIANT       /**< HIPAA compliance */
#define FEATURE_GDPR_COMPLIANT        /**< GDPR compliance */
#define FEATURE_PCI_DSS_COMPLIANT     /**< PCI DSS compliance */
#define FEATURE_ISO27001_COMPLIANT    /**< ISO 27001 compliance */
#define FEATURE_FEDRAMP_READY         /**< FedRAMP compliance ready */
#define FEATURE_DATA_SOVEREIGNTY      /**< Data sovereignty support */
#define FEATURE_PRIVACY_BY_DESIGN     /**< Privacy by design principles */

// Development & Operations
#define FEATURE_DEVOPS_INTEGRATION    /**< DevOps pipeline integration */
#define FEATURE_CI_CD_READY           /**< CI/CD pipeline ready */
#define FEATURE_INFRASTRUCTURE_AS_CODE /**< Infrastructure as code support */
#define FEATURE_GIT_OPS               /**< GitOps workflow support */
#define FEATURE_CONFIGURATION_MANAGEMENT /**< Configuration management */
#define FEATURE_SECRETS_MANAGEMENT    /**< Secrets management */
#define FEATURE_DEPLOYMENT_AUTOMATION /**< Automated deployment */
#define FEATURE_ROLLBACK_CAPABILITY   /**< Safe rollback capability */

// Monitoring & Observability
#define FEATURE_DISTRIBUTED_LOGGING   /**< Distributed logging */
#define FEATURE_METRICS_AGGREGATION   /**< Metrics aggregation */
#define FEATURE_TRACE_SAMPLING        /**< Distributed trace sampling */
#define FEATURE_SERVICE_MAP           /**< Dynamic service mapping */
#define FEATURE_DEPENDENCY_GRAPH      /**< Dependency graph visualization */
#define FEATURE_PERFORMANCE_PROFILING /**< Performance profiling */
#define FEATURE_MEMORY_PROFILING      /**< Memory usage profiling */
#define FEATURE_CPU_PROFILING         /**< CPU usage profiling */

// Data Management
#define FEATURE_DATA_CATALOG          /**< Data catalog integration */
#define FEATURE_DATA_LINEAGE          /**< Data lineage tracking */
#define FEATURE_DATA_GOVERNANCE       /**< Data governance framework */
#define FEATURE_DATA_QUALITY_MONITORING /**< Data quality monitoring */
#define FEATURE_METADATA_MANAGEMENT   /**< Metadata management */
#define FEATURE_MASTER_DATA_MANAGEMENT /**< Master data management */
#define FEATURE_REFERENCE_DATA_MANAGEMENT /**< Reference data management */

// Integration & APIs
#define FEATURE_REST_API              /**< RESTful API */
#define FEATURE_GRAPHQL_API           /**< GraphQL API */
#define FEATURE_GRPC_API              /**< gRPC API */
#define FEATURE_WEB_SOCKETS           /**< WebSocket API */
#define FEATURE_WEBHOOKS              /**< Webhook support */
#define FEATURE_MESSAGE_QUEUES        /**< Message queue integration */
#define FEATURE_EVENT_STREAMING       /**< Event streaming integration */
#define FEATURE_SERVICE_BUS           /**< Service bus integration */
#define FEATURE_API_MANAGEMENT        /**< API management integration */
#define FEATURE_API_GATEWAY           /**< API gateway integration */

// User Experience
#define FEATURE_WEB_INTERFACE         /**< Web-based user interface */
#define FEATURE_MOBILE_INTERFACE      /**< Mobile application */
#define FEATURE_CLI_INTERFACE         /**< Command-line interface */
#define FEATURE_API_CLIENT_LIBRARIES  /**< Client libraries for popular languages */
#define FEATURE_SDK                   /**< Software development kit */
#define FEATURE_THEME_CUSTOMIZATION   /**< UI theme customization */
#define FEATURE_LOCALIZATION          /**< Multi-language support */
#define FEATURE_ACCESSIBILITY         /**< Accessibility compliance */

// Administration & Management
#define FEATURE_USER_MANAGEMENT       /**< User and group management */
#define FEATURE_ROLE_BASED_ACCESS     /**< Role-based access control */
#define FEATURE_PERMISSION_MANAGEMENT /**< Fine-grained permissions */
#define FEATURE_AUDIT_TRAIL           /**< Comprehensive audit trail */
#define FEATURE_COMPLIANCE_REPORTING  /**< Compliance reporting */
#define FEATURE_BILLING_INTEGRATION   /**< Billing and invoicing */
#define FEATURE_USAGE_METRICS         /**< Usage metrics and analytics */
#define FEATURE_COST_MANAGEMENT       /**< Cost tracking and optimization */
#define FEATURE_LICENSE_MANAGEMENT    /**< License management */

// Backup & Recovery
#define FEATURE_AUTO_BACKUP           /**< Automatic backup */
#define FEATURE_INCREMENTAL_BACKUP    /**< Incremental backups */
#define FEATURE_POINT_IN_TIME_RECOVERY /**< Point-in-time recovery */
#define FEATURE_CROSS_REGION_BACKUP   /**< Cross-region backup */
#define FEATURE_BACKUP_ENCRYPTION     /**< Backup encryption */
#define FEATURE_BACKUP_COMPRESSION    /**< Backup compression */
#define FEATURE_BACKUP_VALIDATION     /**< Backup integrity validation */
#define FEATURE_DISASTER_RECOVERY_DRILLS /**< Disaster recovery testing */

// Development Features
#define FEATURE_OPEN_SOURCE           /**< Open source components */
#define FEATURE_EXTENSIBLE_API        /**< Extensible API design */
#define FEATURE_PLUGIN_FRAMEWORK      /**< Plugin framework */
#define FEATURE_CUSTOM_INTEGRATIONS   /**< Custom integration support */
#define FEATURE_WEB_ASSEMBLY          /**< WebAssembly support */
#define FEATURE_NATIVE_EXTENSIONS     /**< Native code extensions */

/** @} */ // end of system_features

// ============================================================================
// Platform Support
// ============================================================================

/**
 * @defgroup platform_support Platform Support
 * @{
 */

// Operating Systems
#define PLATFORM_LINUX                /**< Linux distributions */
#define PLATFORM_WINDOWS              /**< Microsoft Windows */
#define PLATFORM_MACOS                /**< Apple macOS */
#define PLATFORM_BSD                  /**< BSD variants */
#define PLATFORM_SOLARIS              /**< Oracle Solaris */
#define PLATFORM_AIX                  /**< IBM AIX */

// Container Platforms
#define PLATFORM_DOCKER               /**< Docker containers */
#define PLATFORM_KUBERNETES           /**< Kubernetes orchestration */
#define PLATFORM_OPENSHIFT            /**< Red Hat OpenShift */
#define PLATFORM_DOCKER_SWARM         /**< Docker Swarm */
#define PLATFORM_MESOS                /**< Apache Mesos */
#define PLATFORM_NOMAD                /**< HashiCorp Nomad */

// Cloud Platforms
#define CLOUD_AWS                     /**< Amazon Web Services */
#define CLOUD_AZURE                   /**< Microsoft Azure */
#define CLOUD_GCP                     /**< Google Cloud Platform */
#define CLOUD_IBM_CLOUD               /**< IBM Cloud */
#define CLOUD_ORACLE_CLOUD            /**< Oracle Cloud */
#define CLOUD_ALIBABA_CLOUD           /**< Alibaba Cloud */
#define CLOUD_DIGITAL_OCEAN           /**< DigitalOcean */
#define CLOUD_HETZNER                 /**< Hetzner Cloud */

// Programming Languages
#define LANGUAGE_C                    /**< C programming language */
#define LANGUAGE_CPP                  /**< C++ programming language */
#define LANGUAGE_PYTHON               /**< Python bindings */
#define LANGUAGE_JAVA                 /**< Java/JVM bindings */
#define LANGUAGE_GO                   /**< Go bindings */
#define LANGUAGE_RUST                 /**< Rust bindings */
#define LANGUAGE_NODE_JS              /**< Node.js bindings */
#define LANGUAGE_DOTNET               /**< .NET bindings */

// Database Support
#define DATABASE_POSTGRESQL           /**< PostgreSQL support */
#define DATABASE_MYSQL                /**< MySQL/MariaDB support */
#define DATABASE_SQLITE               /**< SQLite support */
#define DATABASE_ORACLE               /**< Oracle Database */
#define DATABASE_SQL_SERVER           /**< Microsoft SQL Server */
#define DATABASE_MONGODB              /**< MongoDB support */
#define DATABASE_REDIS                /**< Redis support */
#define DATABASE_CASSANDRA            /**< Apache Cassandra */
#define DATABASE_ELASTICSEARCH        /**< Elasticsearch support */
#define DATABASE_CLICKHOUSE           /**< ClickHouse support */
#define DATABASE_SNOWFLAKE            /**< Snowflake support */
#define DATABASE_BIGQUERY             /**< Google BigQuery */

/** @} */ // end of platform_support

// ============================================================================
// Feature Categories Summary
// ============================================================================

/**
 * @def FEATURE_CATEGORY_COUNT
 * @brief Number of feature categories
 */
#define FEATURE_CATEGORY_COUNT 12

/**
 * @enum feature_category_t
 * @brief Feature categories for organization
 */
typedef enum {
    CATEGORY_DATA_EXPORT = 0,          /**< Data export and transformation */
    CATEGORY_ALERTING,                 /**< Alerting and notification */
    CATEGORY_PERFORMANCE,              /**< Performance and scalability */
    CATEGORY_SECURITY,                 /**< Security and compliance */
    CATEGORY_RELIABILITY,              /**< Reliability and availability */
    CATEGORY_OBSERVABILITY,            /**< Monitoring and observability */
    CATEGORY_INTEGRATION,              /**< Integration and APIs */
    CATEGORY_USER_EXPERIENCE,          /**< User interface and experience */
    CATEGORY_ADMINISTRATION,           /**< Administration and management */
    CATEGORY_DEVELOPMENT,              /**< Development and extensibility */
    CATEGORY_PLATFORM,                 /**< Platform and deployment */
    CATEGORY_DATA_MANAGEMENT           /**< Data management and governance */
} feature_category_t;

/**
 * @struct feature_summary_t
 * @brief Summary of features by category
 */
typedef struct {
    feature_category_t category;       /**< Feature category */
    const char* name;                  /**< Category name */
    const char* description;           /**< Category description */
    uint32_t feature_count;            /**< Number of features in category */
    const char** features;             /**< Array of feature names */
} feature_summary_t;

// ============================================================================
// Feature Checking Macros
// ============================================================================

/**
 * @brief Check if a specific feature is available
 * 
 * This macro allows compile-time checking of feature availability.
 * Features are defined as preprocessor macros that can be tested.
 * 
 * Example usage:
 * @code
 * #ifdef FEATURE_FORMAT_JSON
 *     // JSON export is available
 *     export_json_data();
 * #endif
 * @endcode
 */

/**
 * @def HAS_FEATURE(feature)
 * @brief Check if a feature macro is defined
 */
#define HAS_FEATURE(feature) defined(feature)

/**
 * @def FEATURE_ENABLED(feature)
 * @brief Check if feature is enabled (defined and non-zero)
 */
#define FEATURE_ENABLED(feature) (defined(feature) && (feature != 0))

/**
 * @def REQUIRE_FEATURE(feature, message)
 * @brief Require a feature at compile time
 */
#define REQUIRE_FEATURE(feature, message) \
    static_assert(defined(feature), message)

/**
 * @def FEATURE_DEPRECATED(feature, version, message)
 * @brief Mark a feature as deprecated
 */
#define FEATURE_DEPRECATED(feature, version, message) \
    __attribute__((deprecated(message " since version " version)))

/**
 * @def FEATURE_EXPERIMENTAL(feature)
 * @brief Mark a feature as experimental
 */
#define FEATURE_EXPERIMENTAL(feature) \
    __attribute__((warning("Feature " #feature " is experimental")))

// ============================================================================
// Feature Configuration
// ============================================================================

/**
 * @brief Get system feature configuration
 * 
 * This function returns a JSON string containing all enabled features
 * and their configuration.
 * 
 * @param config_json Output buffer for JSON configuration
 * @param buffer_size Size of output buffer
 * @return export_status_t Status code
 */
export_status_t features_get_configuration(char* config_json, size_t buffer_size);

/**
 * @brief Check if feature is supported
 * 
 * @param feature_name Name of feature to check
 * @return true if feature is supported, false otherwise
 */
bool features_is_supported(const char* feature_name);

/**
 * @brief Get feature details
 * 
 * @param feature_name Name of feature to query
 * @param details Output buffer for feature details (JSON)
 * @param buffer_size Size of output buffer
 * @return export_status_t Status code
 */
export_status_t features_get_details(const char* feature_name, char* details, size_t buffer_size);

/**
 * @brief List all features by category
 * 
 * @param category Feature category (0 for all)
 * @param features Output buffer for feature list (JSON)
 * @param buffer_size Size of output buffer
 * @return export_status_t Status code
 */
export_status_t features_list_by_category(feature_category_t category, char* features, size_t buffer_size);

/**
 * @brief Get system capabilities report
 * 
 * @param format Report format (using export_format_t)
 * @param report Output buffer for report
 * @param buffer_size Size of output buffer
 * @param actual_size Output parameter for actual report size
 * @return export_status_t Status code
 */
export_status_t features_get_capabilities_report(export_format_t format, 
                                                void* report, 
                                                size_t buffer_size, 
                                                size_t* actual_size);

// ============================================================================
// Inline Utility Functions
// ============================================================================

/**
 * @brief Get system name and version
 * 
 * @param buffer Output buffer
 * @param buffer_size Size of buffer
 * @return const char* System name and version
 */
static inline const char* features_get_system_info(char* buffer, size_t buffer_size) {
    snprintf(buffer, buffer_size, "%s v%s", SYSTEM_NAME, SYSTEM_VERSION);
    return buffer;
}

/**
 * @brief Get total number of features
 * 
 * @return uint32_t Total feature count
 */
static inline uint32_t features_get_total_count(void) {
    return (EXPORT_FORMAT_COUNT + EXPORT_DESTINATION_COUNT + 
            EXPORT_COMPRESSION_COUNT + EXPORT_ENCRYPTION_COUNT +
            EXPORT_PROTOCOL_COUNT + ALERT_SEVERITY_COUNT +
            ALERT_SOURCE_COUNT + ALERT_CHANNEL_COUNT +
            ALERT_OPERATOR_COUNT);
}

/**
 * @brief Check if system has export capabilities
 * 
 * @return true if export features are available
 */
static inline bool features_has_export_capabilities(void) {
    return (EXPORT_FORMAT_COUNT > 0 && EXPORT_DESTINATION_COUNT > 0);
}

/**
 * @brief Check if system has alerting capabilities
 * 
 * @return true if alerting features are available
 */
static inline bool features_has_alerting_capabilities(void) {
    return (ALERT_SEVERITY_COUNT > 0 && ALERT_CHANNEL_COUNT > 0);
}

/**
 * @brief Get feature category name
 * 
 * @param category Feature category
 * @return const char* Category name
 */
static inline const char* features_get_category_name(feature_category_t category) {
    switch (category) {
        case CATEGORY_DATA_EXPORT: return "Data Export";
        case CATEGORY_ALERTING: return "Alerting";
        case CATEGORY_PERFORMANCE: return "Performance";
        case CATEGORY_SECURITY: return "Security";
        case CATEGORY_RELIABILITY: return "Reliability";
        case CATEGORY_OBSERVABILITY: return "Observability";
        case CATEGORY_INTEGRATION: return "Integration";
        case CATEGORY_USER_EXPERIENCE: return "User Experience";
        case CATEGORY_ADMINISTRATION: return "Administration";
        case CATEGORY_DEVELOPMENT: return "Development";
        case CATEGORY_PLATFORM: return "Platform";
        case CATEGORY_DATA_MANAGEMENT: return "Data Management";
        default: return "Unknown";
    }
}

/**
 * @brief Get feature category description
 * 
 * @param category Feature category
 * @return const char* Category description
 */
static inline const char* features_get_category_description(feature_category_t category) {
    switch (category) {
        case CATEGORY_DATA_EXPORT: 
            return "Data export, transformation, and integration capabilities";
        case CATEGORY_ALERTING: 
            return "Alerting, notification, and monitoring capabilities";
        case CATEGORY_PERFORMANCE: 
            return "Performance optimization and scalability features";
        case CATEGORY_SECURITY: 
            return "Security, authentication, and compliance features";
        case CATEGORY_RELIABILITY: 
            return "Reliability, availability, and fault tolerance";
        case CATEGORY_OBSERVABILITY: 
            return "Monitoring, logging, and observability features";
        case CATEGORY_INTEGRATION: 
            return "API integration and third-party system connectivity";
        case CATEGORY_USER_EXPERIENCE: 
            return "User interface, accessibility, and user experience";
        case CATEGORY_ADMINISTRATION: 
            return "Administration, management, and operational features";
        case CATEGORY_DEVELOPMENT: 
            return "Development, extensibility, and customization";
        case CATEGORY_PLATFORM: 
            return "Platform support and deployment options";
        case CATEGORY_DATA_MANAGEMENT: 
            return "Data governance, quality, and management";
        default: return "Unknown category";
    }
}

#ifdef __cplusplus
}
#endif

#endif // FEATURES_H

// ============================================================================
// Implementation Notes:
// ============================================================================
// 1. Feature Organization: Features are organized by module and category
// 2. Compile-time Checking: Macros for feature availability checking
// 3. Runtime Discovery: Functions for dynamic feature discovery
// 4. Configuration Management: JSON-based feature configuration
// 5. Documentation: Each feature is documented with its purpose
// 6. Extensibility: New features can be added without breaking changes
// 7. Compatibility: Backward compatibility maintained for existing features
// 8. Testing: Features can be individually enabled/disabled for testing
// 9. Reporting: Generate comprehensive feature reports
// 10. Integration: Works with both export.h and alerts.h modules