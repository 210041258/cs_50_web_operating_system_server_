#ifndef DISK_H
#define DISK_H

#include <stdint.h>
#include <time.h>

// Forward declarations
typedef struct DiskState DiskState;
typedef struct DiskDevice DiskDevice;
typedef struct FilesystemInfo FilesystemInfo;

// Disk types
typedef enum : u8 {
    DISK_TYPE_HDD,
    DISK_TYPE_SSD,
    DISK_TYPE_NVME,
    DISK_TYPE_OPTANE,
    DISK_TYPE_SAS,
    DISK_TYPE_SATA,
    DISK_TYPE_USB,
    DISK_TYPE_VIRTUAL,
    DISK_TYPE_NVME_OF,      // NVMe over Fabric
    DISK_TYPE_UNKNOWN
} DiskType;

// Filesystem types
typedef enum : u8 {
    FS_EXT2,
    FS_EXT3,
    FS_EXT4,
    FS_XFS,
    FS_BTRFS,
    FS_ZFS,
    FS_NTFS,
    FS_FAT32,
    FS_EXFAT,
    FS_NFS,
    FS_CIFS,
    FS_TMPFS,
    FS_UNKNOWN
} FilesystemType;

// RAID levels
typedef enum : u8 {
    RAID_NONE,
    RAID_0,
    RAID_1,
    RAID_5,
    RAID_6,
    RAID_10,
    RAID_50,
    RAID_60,
    RAID_Z1,
    RAID_Z2,
    RAID_Z3
} RAIDLevel;

// SMART health status
typedef struct PACKED {
    u8 passed : 1;
    u8 temperature_warning : 1;
    u8 reallocated_sectors : 1;
    u8 pending_sectors : 1;
    u8 offline_uncorrectable : 1;
    u8 read_error_rate : 1;
    u8 power_on_hours : 1;
    u8 wear_leveling : 1;
    u8 _reserved : 8;
    
    i16 temperature;           // Celsius
    u32 power_on_hours_count;
    u32 reallocated_sectors_count;
    u32 pending_sectors_count;
    u32 uncorrectable_errors;
    u32 load_cycle_count;
    u32 power_cycles;
    u32 media_wearout;         // Percentage
} SMARTStatus;

// I/O statistics snapshot
typedef struct PACKED {
    u32 timestamp;            // Monotonic seconds
    u16 read_iops;           // IOPS * 10
    u16 write_iops;          // IOPS * 10
    u32 read_throughput;     // KB/s
    u32 write_throughput;    // KB/s
    u16 avg_read_latency;    // Microseconds
    u16 avg_write_latency;   // Microseconds
    u16 queue_depth;
    u16 util_percent;        // Utilization percentage
    u8 device_id;
    u8 _reserved[3];
} DiskIOSnapshot;

// Function prototypes
DiskState* disk_monitor_init(void) HOT;
void disk_monitor_cleanup(DiskState *state) COLD;

// Device enumeration
u8 disk_get_device_count(const DiskState *state);
const DiskDevice* disk_get_device(const DiskState *state, u8 device_id);
const DiskDevice* disk_find_by_name(const DiskState *state, const char *device_name);

// Device information
const char* disk_get_device_name(const DiskDevice *device);
DiskType disk_get_device_type(const DiskDevice *device);
u64 disk_get_device_size(const DiskDevice *device);
u64 disk_get_device_used(const DiskDevice *device);
u64 disk_get_device_free(const DiskDevice *device);

// SMART information
const SMARTStatus* disk_get_smart_status(const DiskDevice *device);
int disk_has_smart(const DiskDevice *device);
int disk_read_smart(const DiskDevice *device, SMARTStatus *status);

// Filesystem information
u8 disk_get_filesystem_count(const DiskState *state);
const FilesystemInfo* disk_get_filesystem(const DiskState *state, u8 fs_id);
FilesystemType disk_get_filesystem_type(const FilesystemInfo *fs);
const char* disk_get_mount_point(const FilesystemInfo *fs);
u64 disk_get_filesystem_size(const FilesystemInfo *fs);
u64 disk_get_filesystem_used(const FilesystemInfo *fs);
u64 disk_get_filesystem_free(const FilesystemInfo *fs);
u64 disk_get_filesystem_available(const FilesystemInfo *fs);

// I/O statistics
void disk_update_io_stats(DiskState *state) HOT;
u32 disk_get_read_iops(const DiskDevice *device) HOT;
u32 disk_get_write_iops(const DiskDevice *device) HOT;
u32 disk_get_read_throughput(const DiskDevice *device) HOT;  // KB/s
u32 disk_get_write_throughput(const DiskDevice *device) HOT; // KB/s
u32 disk_get_avg_latency(const DiskDevice *device);          // Microseconds
u32 disk_get_queue_depth(const DiskDevice *device);
u32 disk_get_utilization(const DiskDevice *device);          // Percentage

// RAID information
int disk_has_raid(const DiskState *state);
RAIDLevel disk_get_raid_level(const DiskState *state);
u8 disk_get_raid_device_count(const DiskState *state);
const char** disk_get_raid_devices(const DiskState *state, u8 *count);

// LVM information
int disk_has_lvm(const DiskState *state);
u8 disk_get_lvm_volume_count(const DiskState *state);
const char* disk_get_lvm_volume_name(const DiskState *state, u8 volume_id);
u64 disk_get_lvm_volume_size(const DiskState *state, u8 volume_id);

// Performance analysis
typedef struct PACKED {
    u8 bottleneck_type;      // 0=none, 1=IOPS, 2=throughput, 3=latency
    u8 severity;            // 0-100
    u32 max_sustainable_iops;
    u32 max_sustainable_mbs;
    u16 optimal_queue_depth;
    char recommendation[256];
} DiskPerformanceAnalysis;

DiskPerformanceAnalysis disk_analyze_performance(const DiskDevice *device);

// Health prediction
typedef struct PACKED {
    u32 remaining_days;
    u8 health_score;        // 0-100
    u8 wear_level;          // Percentage
    u32 predicted_failure_date;  // Unix timestamp
    char issues[512];
} DiskHealthPrediction;

DiskHealthPrediction disk_predict_health(const DiskDevice *device);

// Benchmarking
typedef struct PACKED {
    u32 sequential_read_mbs;
    u32 sequential_write_mbs;
    u32 random_read_iops;
    u32 random_write_iops;
    u32 read_latency_us;
    u32 write_latency_us;
    u32 queue_depth_tested;
} DiskBenchmarkResult;

int disk_run_benchmark(const DiskDevice *device, DiskBenchmarkResult *result, u32 duration_seconds);

// Control functions
int disk_set_scheduler(const char *device_name, const char *scheduler);
int disk_set_read_ahead(const char *device_name, u32 sectors);
int disk_flush_cache(const char *device_name);

// History and trends
const DiskIOSnapshot* disk_get_io_history(const DiskDevice *device, u32 *count);
void disk_set_sample_rate(DiskState *state, u16 interval_ms);

// ZFS/BTRFS specific
int disk_is_zfs(const FilesystemInfo *fs);
int disk_is_btrfs(const FilesystemInfo *fs);
u32 disk_get_deduplication_ratio(const FilesystemInfo *fs);
u32 disk_get_compression_ratio(const FilesystemInfo *fs);

// Encryption status
int disk_is_encrypted(const DiskDevice *device, char *cipher, u32 cipher_size);

// Export functions
int disk_export_json(const DiskState *state, char *buffer, u32 size);
int disk_export_smart(const DiskDevice *device, char *buffer, u32 size);

// Utility functions
float disk_calculate_usage_percent(const FilesystemInfo *fs);
const char* disk_format_bytes(u64 bytes, char *buffer, u32 size);

#endif // DISK_H