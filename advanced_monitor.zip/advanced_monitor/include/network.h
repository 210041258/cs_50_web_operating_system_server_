#ifndef NETWORK_H
#define NETWORK_H

#include <stdint.h>
#include <time.h>
#include <netinet/in.h>

// Forward declarations
typedef struct NetworkState NetworkState;
typedef struct NetworkInterface NetworkInterface;
typedef struct NetworkConnection NetworkConnection;

// Protocol types
typedef enum : u8 {
    PROTO_TCP,
    PROTO_UDP,
    PROTO_ICMP,
    PROTO_IGMP,
    PROTO_RAW,
    PROTO_UNKNOWN
} ProtocolType;

// Interface types
typedef enum : u8 {
    IF_TYPE_ETHERNET,
    IF_TYPE_WIRELESS,
    IF_TYPE_LOOPBACK,
    IF_TYPE_VIRTUAL,
    IF_TYPE_BRIDGE,
    IF_TYPE_BOND,
    IF_TYPE_VLAN,
    IF_TYPE_TUN,
    IF_TYPE_TAP
} InterfaceType;

// Connection states (TCP)
typedef enum : u8 {
    TCP_ESTABLISHED,
    TCP_SYN_SENT,
    TCP_SYN_RECV,
    TCP_FIN_WAIT1,
    TCP_FIN_WAIT2,
    TCP_TIME_WAIT,
    TCP_CLOSE,
    TCP_CLOSE_WAIT,
    TCP_LAST_ACK,
    TCP_LISTEN,
    TCP_CLOSING,
    TCP_UNKNOWN
} TCPState;

// Traffic snapshot
typedef struct PACKED {
    u32 timestamp;            // Monotonic seconds
    u32 rx_bytes;            // Received bytes
    u32 tx_bytes;            // Transmitted bytes
    u16 rx_packets;          // Received packets
    u16 tx_packets;          // Transmitted packets
    u16 rx_errors;           // Receive errors
    u16 tx_errors;           // Transmit errors
    u16 rx_dropped;          // Received dropped
    u16 tx_dropped;          // Transmit dropped
    u8 interface_id;
    u8 _reserved[3];
} TrafficSnapshot;

// Connection information
typedef struct PACKED {
    u32 local_ip;
    u32 remote_ip;
    u16 local_port;
    u16 remote_port;
    ProtocolType protocol;
    TCPState state;
    u64 rx_bytes;
    u64 tx_bytes;
    pid_t pid;
    uid_t uid;
    char process_name[32];
    u32 last_activity;        // Seconds since last packet
} ConnectionInfo;

// Wireless information
typedef struct PACKED {
    char ssid[32];
    char bssid[18];           // MAC address
    i16 signal_dbm;          // Signal strength in dBm
    u8 channel;
    u16 frequency;           // MHz
    u8 link_quality;         // Percentage
    u8 noise_level;          // dBm
    u16 bitrate;             // Mbps * 10
    char security[16];
    char mode[16];
} WirelessInfo;

// Function prototypes
NetworkState* network_monitor_init(void) HOT;
void network_monitor_cleanup(NetworkState *state) COLD;

// Interface enumeration
u8 network_get_interface_count(const NetworkState *state);
const NetworkInterface* network_get_interface(const NetworkState *state, u8 interface_id);
const NetworkInterface* network_find_by_name(const NetworkState *state, const char *name);

// Interface information
const char* network_get_interface_name(const NetworkInterface *interface);
InterfaceType network_get_interface_type(const NetworkInterface *interface);
u32 network_get_ip_address(const NetworkInterface *interface, char *buffer, u32 size);
u32 network_get_netmask(const NetworkInterface *interface, char *buffer, u32 size);
u32 network_get_mac_address(const NetworkInterface *interface, char *buffer, u32 size);
u32 network_get_mtu(const NetworkInterface *interface);
int network_is_up(const NetworkInterface *interface);

// Traffic statistics
void network_update_stats(NetworkState *state) HOT;
u64 network_get_rx_bytes(const NetworkInterface *interface) HOT;
u64 network_get_tx_bytes(const NetworkInterface *interface) HOT;
u64 network_get_rx_packets(const NetworkInterface *interface);
u64 network_get_tx_packets(const NetworkInterface *interface);
u64 network_get_rx_errors(const NetworkInterface *interface);
u64 network_get_tx_errors(const NetworkInterface *interface);
u64 network_get_rx_dropped(const NetworkInterface *interface);
u64 network_get_tx_dropped(const NetworkInterface *interface);

// Rate calculations
u32 network_get_rx_rate(const NetworkInterface *interface);   // KB/s
u32 network_get_tx_rate(const NetworkInterface *interface);   // KB/s
u32 network_get_packet_rx_rate(const NetworkInterface *interface);  // Packets/s
u32 network_get_packet_tx_rate(const NetworkInterface *interface);  // Packets/s

// Wireless information
int network_is_wireless(const NetworkInterface *interface);
const WirelessInfo* network_get_wireless_info(const NetworkInterface *interface);
i16 network_get_signal_strength(const NetworkInterface *interface);
u8 network_get_link_quality(const NetworkInterface *interface);

// Connection tracking
u32 network_get_connection_count(const NetworkState *state);
const ConnectionInfo* network_get_connections(const NetworkState *state, u32 *count);
const ConnectionInfo* network_get_connections_for_pid(const NetworkState *state, pid_t pid, u32 *count);
const ConnectionInfo* network_get_listening_ports(const NetworkState *state, u32 *count);

// Protocol statistics
u64 network_get_tcp_segments(const NetworkState *state);
u64 network_get_udp_datagrams(const NetworkState *state);
u64 network_get_icmp_messages(const NetworkState *state);

// Routing information
u32 network_get_route_count(const NetworkState *state);
int network_get_routing_table(const NetworkState *state, char *buffer, u32 size);

// ARP table
u32 network_get_arp_count(const NetworkState *state);
int network_get_arp_table(const NetworkState *state, char *buffer, u32 size);

// DNS information
u32 network_get_dns_server_count(const NetworkState *state);
int network_get_dns_servers(const NetworkState *state, char **servers, u32 max_servers);
u32 network_get_dns_query_time(const NetworkState *state);  // Milliseconds

// Quality of Service (QoS)
typedef struct PACKED {
    u32 latency;             // Milliseconds
    u32 jitter;              // Milliseconds
    u8 packet_loss;          // Percentage
    u32 throughput;          // KB/s
    u8 quality_score;        // 0-100
} NetworkQuality;

NetworkQuality network_measure_quality(const NetworkState *state, const char *host);

// Bandwidth prediction
typedef struct PACKED {
    u32 predicted_rx_rate;   // KB/s
    u32 predicted_tx_rate;   // KB/s
    u32 time_to_capacity;    // Seconds until saturation
    u32 utilization;         // Percentage
} BandwidthPrediction;

BandwidthPrediction network_predict_bandwidth(const NetworkInterface *interface);

// Traffic shaping
int network_set_tx_limit(const char *interface_name, u32 limit_kbs);
int network_set_rx_limit(const char *interface_name, u32 limit_kbs);
const char* network_get_qdisc(const char *interface_name, char *buffer, u32 size);

// VLAN/Bonding information
int network_is_vlan(const NetworkInterface *interface, char *parent, u32 parent_size, u16 *vlan_id);
int network_is_bond(const NetworkInterface *interface, char **slaves, u32 max_slaves, u32 *slave_count);

// Security monitoring
u32 network_detect_port_scans(const NetworkState *state, u32 time_window);
u32 network_detect_flood_attacks(const NetworkState *state, u32 time_window);

// History and trends
const TrafficSnapshot* network_get_traffic_history(const NetworkInterface *interface, u32 *count);
void network_set_sample_rate(NetworkState *state, u16 interval_ms);

// Export functions
int network_export_json(const NetworkState *state, char *buffer, u32 size);
int network_export_connections(const NetworkState *state, char *buffer, u32 size);

// Utility functions
const char* network_format_rate(u32 rate_kbs, char *buffer, u32 size);
const char* network_format_bytes(u64 bytes, char *buffer, u32 size);
int network_is_valid_ip(const char *ip_address);
int network_is_valid_mac(const char *mac_address);

#endif // NETWORK_H