#ifndef MEMORY_H
#define MEMORY_H

#include <stdint.h>

// Forward declaration
typedef struct MemoryState MemoryState;

// Memory type enumeration
typedef enum : u8 {
    MEM_TYPE_UNKNOWN,
    MEM_TYPE_DDR3,
    MEM_TYPE_DDR4,
    MEM_TYPE_DDR5,
    MEM_TYPE_LPDDR4,
    MEM_TYPE_LPDDR5,
    MEM_TYPE_HBM2,
    MEM_TYPE_HBM2E,
    MEM_TYPE_HBM3
} MemoryType;

// NUMA node structure
typedef struct PACKED {
    u16 node_id;
    u64 total_bytes;
    u64 free_bytes;
    u64 used_bytes;
    u16 distance[16];        // Distance to other NUMA nodes
    u8  local_cpus[64];      // CPUs local to this node
    u8  cpu_count;
} NUMANode;

// Page statistics
typedef struct PACKED {
    u64 total_pages;
    u64 free_pages;
    u64 active_pages;
    u64 inactive_pages;
    u64 dirty_pages;
    u64 writeback_pages;
    u64 mapped_pages;
    u64 slab_pages;
    u64 kernel_stack_pages;
    u64 page_tables;
} PageStats;

// Swap statistics
typedef struct PACKED {
    u64 total_bytes;
    u64 used_bytes;
    u64 free_bytes;
    u64 cached_bytes;
    u64 swap_ins;
    u64 swap_outs;
    u32 swap_priority;       // Swappiness setting
} SwapStats;

// Memory pressure metrics
typedef struct PACKED {
    u32 some_avg10;         // Pressure some (scaled)
    u32 some_avg60;
    u32 some_avg300;
    u32 full_avg10;         // Pressure full (scaled)
    u32 full_avg60;
    u32 full_avg300;
} PressureMetrics;

// Function prototypes
MemoryState* memory_monitor_init(void) HOT;
void memory_monitor_cleanup(MemoryState *state) COLD;

// Real-time statistics
u64 memory_get_total(const MemoryState *state) HOT;
u64 memory_get_used(const MemoryState *state) HOT;
u64 memory_get_free(const MemoryState *state) HOT;
u64 memory_get_available(const MemoryState *state) HOT;
u64 memory_get_cached(const MemoryState *state);
u64 memory_get_buffers(const MemoryState *state);
u64 memory_get_shared(const MemoryState *state);

// Swap statistics
const SwapStats* memory_get_swap_stats(const MemoryState *state);
float memory_get_swap_usage_percent(const MemoryState *state);

// NUMA information
u8 memory_get_numa_node_count(const MemoryState *state);
const NUMANode* memory_get_numa_node(const MemoryState *state, u8 node_id);

// Advanced metrics
const PageStats* memory_get_page_stats(const MemoryState *state);
const PressureMetrics* memory_get_pressure(const MemoryState *state);
u32 memory_get_page_faults(const MemoryState *state);
u32 memory_get_major_faults(const MemoryState *state);

// Memory type and speed
MemoryType memory_get_memory_type(const MemoryState *state);
u32 memory_get_memory_speed_mhz(const MemoryState *state);
u8 memory_get_memory_channels(const MemoryState *state);

// Huge pages
u64 memory_get_hugepages_total(const MemoryState *state);
u64 memory_get_hugepages_free(const MemoryState *state);
u64 memory_get_hugepages_rsvd(const MemoryState *state);
u64 memory_get_hugepages_surp(const MemoryState *state);

// Zone information
typedef struct PACKED {
    u64 free;
    u64 min;
    u64 low;
    u64 high;
    u64 spanned;
    u64 present;
} ZoneInfo;

int memory_get_zone_info(const MemoryState *state, ZoneInfo *zones, u8 max_zones);

// Watermarks
u64 memory_get_watermark_min(const MemoryState *state);
u64 memory_get_watermark_low(const MemoryState *state);
u64 memory_get_watermark_high(const MemoryState *state);

// OOM (Out of Memory) information
u32 memory_get_oom_kills(const MemoryState *state);
u32 memory_get_oom_score(pid_t pid);

// Allocation tracking
typedef struct PACKED {
    u64 malloc_count;
    u64 free_count;
    u64 mmap_count;
    u64 munmap_count;
    u64 page_alloc;
    u64 page_free;
} AllocStats;

const AllocStats* memory_get_alloc_stats(const MemoryState *state);

// Memory compaction
u64 memory_get_compact_migrate(const MemoryState *state);
u64 memory_get_compact_free(const MemoryState *state);

// Cache statistics
u64 memory_get_slab_total(const MemoryState *state);
u64 memory_get_slab_reclaimable(const MemoryState *state);
u64 memory_get_slab_unreclaimable(const MemoryState *state);

// History and trends
const u32* memory_get_usage_history(const MemoryState *state, u32 *count);
const u32* memory_get_swap_history(const MemoryState *state, u32 *count);
void memory_calculate_trends(const MemoryState *state, float *usage_slope, float *swap_slope);

// Prediction
typedef struct PACKED {
    u64 predicted_usage;
    u32 time_to_full;        // Seconds until memory is full
    u8 risk_level;          // 0-100 risk score
    char recommendation[256];
} MemoryPrediction;

MemoryPrediction memory_predict_usage(const MemoryState *state, u32 forecast_seconds);

// Configuration
void memory_set_sample_rate(MemoryState *state, u16 interval_ms);
void memory_enable_numa(MemoryState *state, u8 enabled);
void memory_enable_pressure(MemoryState *state, u8 enabled);

// Export
int memory_export_json(const MemoryState *state, char *buffer, u32 size);
int memory_export_prometheus(const MemoryState *state, char *buffer, u32 size);

// Utility
float memory_calculate_usage_percent(const MemoryState *state);
float memory_calculate_swap_percent(const MemoryState *state);
const char* memory_format_bytes(u64 bytes, char *buffer, u32 size);

#endif // MEMORY_H