/**
 * @file alerts.h
 * @brief Alerting and Notification Module for Data Export System
 * 
 * This module provides comprehensive alerting, notification, and monitoring
 * capabilities for the data export system. It monitors export operations,
 * system health, data quality, and business metrics, generating alerts
 * based on configurable rules and thresholds.
 * 
 * @author Monitoring and Alerting Team
 * @date 2024-01-31
 * @version 4.1.0
 * 
 * @license Apache 2.0
 * @copyright Copyright (c) 2024 Integration Solutions
 */

#ifndef ALERTS_H
#define ALERTS_H

#ifdef __cplusplus
extern "C" {
#endif

// ============================================================================
// Includes and Dependencies
// ============================================================================
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <time.h>
#include <stdio.h>

#include "export.h"  // For integration with export module

// ============================================================================
// Configuration Constants
// ============================================================================
/**
 * @def ALERTS_VERSION_MAJOR
 * @brief Major version number
 */
#define ALERTS_VERSION_MAJOR 4

/**
 * @def ALERTS_VERSION_MINOR
 * @brief Minor version number
 */
#define ALERTS_VERSION_MINOR 1

/**
 * @def ALERTS_VERSION_PATCH
 * @brief Patch version number
 */
#define ALERTS_VERSION_PATCH 0

/**
 * @def ALERTS_MAX_RULES
 * @brief Maximum number of alert rules
 */
#define ALERTS_MAX_RULES 1000

/**
 * @def ALERTS_MAX_ACTIONS
 * @brief Maximum number of actions per alert
 */
#define ALERTS_MAX_ACTIONS 10

/**
 * @def ALERTS_MAX_CONDITIONS
 * @brief Maximum number of conditions per rule
 */
#define ALERTS_MAX_CONDITIONS 20

/**
 * @def ALERTS_MAX_TAGS
 * @brief Maximum number of tags per alert
 */
#define ALERTS_MAX_TAGS 50

/**
 * @def ALERTS_MAX_RECIPIENTS
 * @brief Maximum number of recipients per notification
 */
#define ALERTS_MAX_RECIPIENTS 100

/**
 * @def ALERTS_MAX_HISTORY_DAYS
 * @brief Maximum days to keep alert history
 */
#define ALERTS_MAX_HISTORY_DAYS 90

/**
 * @def ALERTS_MAX_ESCALATION_LEVELS
 * @brief Maximum escalation levels
 */
#define ALERTS_MAX_ESCALATION_LEVELS 5

/**
 * @def ALERTS_DEFAULT_THROTTLE_SECONDS
 * @brief Default alert throttling in seconds
 */
#define ALERTS_DEFAULT_THROTTLE_SECONDS 300

/**
 * @def ALERTS_DEFAULT_RESEND_INTERVAL
 * @brief Default resend interval for unacknowledged alerts (seconds)
 */
#define ALERTS_DEFAULT_RESEND_INTERVAL 3600

/**
 * @def ALERTS_MAX_SUPPRESSION_WINDOW
 * @brief Maximum suppression window (seconds)
 */
#define ALERTS_MAX_SUPPRESSION_WINDOW 86400

// ============================================================================
// Type Definitions
// ============================================================================

/**
 * @enum alert_severity_t
 * @brief Alert severity levels
 */
typedef enum {
    SEVERITY_INFO = 0,                  /**< Informational message */
    SEVERITY_LOW,                       /**< Low severity issue */
    SEVERITY_MEDIUM,                    /**< Medium severity issue */
    SEVERITY_HIGH,                      /**< High severity issue */
    SEVERITY_CRITICAL,                  /**< Critical issue requiring immediate attention */
    SEVERITY_EMERGENCY                  /**< System emergency */
} alert_severity_t;

/**
 * @enum alert_status_t
 * @brief Alert status
 */
typedef enum {
    ALERT_STATUS_NEW = 0,               /**< New alert, not yet processed */
    ALERT_STATUS_TRIGGERED,             /**< Alert has been triggered */
    ALERT_STATUS_ACKNOWLEDGED,          /**< Alert has been acknowledged */
    ALERT_STATUS_RESOLVED,              /**< Alert has been resolved */
    ALERT_STATUS_SUPPRESSED,            /**< Alert is suppressed */
    ALERT_STATUS_EXPIRED,               /**< Alert has expired */
    ALERT_STATUS_CLOSED,                /**< Alert has been closed */
    ALERT_STATUS_ESCALATED,             /**< Alert has been escalated */
    ALERT_STATUS_SNOOZED,               /**< Alert has been snoozed */
    ALERT_STATUS_MUTED                  /**< Alert has been muted */
} alert_status_t;

/**
 * @enum alert_source_t
 * @brief Source of the alert
 */
typedef enum {
    ALERT_SOURCE_EXPORT = 0,            /**< Export operation */
    ALERT_SOURCE_SYSTEM,                /**< System health */
    ALERT_SOURCE_NETWORK,               /**< Network issues */
    ALERT_SOURCE_DATABASE,              /**< Database issues */
    ALERT_SOURCE_APPLICATION,           /**< Application errors */
    ALERT_SOURCE_SECURITY,              /**< Security events */
    ALERT_SOURCE_PERFORMANCE,           /**< Performance degradation */
    ALERT_SOURCE_CAPACITY,              /**< Capacity issues */
    ALERT_SOURCE_DATA_QUALITY,          /**< Data quality issues */
    ALERT_SOURCE_BUSINESS,              /**< Business metrics */
    ALERT_SOURCE_MONITORING,            /**< Monitoring system */
    ALERT_SOURCE_EXTERNAL,              /**< External systems */
    ALERT_SOURCE_CUSTOM                 /**< Custom source */
} alert_source_t;

/**
 * @enum alert_action_type_t
 * @brief Alert action types
 */
typedef enum {
    ACTION_NOTIFICATION = 0,            /**< Send notification */
    ACTION_WEBHOOK,                     /**< Call webhook */
    ACTION_SCRIPT,                      /**< Execute script */
    ACTION_API_CALL,                    /**< Make API call */
    ACTION_EVENT,                       /**< Trigger event */
    ACTION_ESCALATE,                    /**< Escalate alert */
    ACTION_LOG,                         /**< Log to file */
    ACTION_COMMAND,                     /**< Execute command */
    ACTION_SMS,                         /**< Send SMS */
    ACTION_CALL,                        /**< Make phone call */
    ACTION_TICKET,                      /**{ Create support ticket */
    ACTION_PAGER,                       /**{ Page on-call person */
    ACTION_CUSTOM                       /**{ Custom action */
} alert_action_type_t;

/**
 * @enum notification_channel_t
 * @brief Notification channels
 */
typedef enum {
    CHANNEL_EMAIL = 0,                  /**< Email notification */
    CHANNEL_SLACK,                      /**< Slack notification */
    CHANNEL_TEAMS,                      /**< Microsoft Teams */
    CHANNEL_WEBHOOK,                    /**< Generic webhook */
    CHANNEL_SMS,                        /**< SMS text message */
    CHANNEL_CALL,                       /**< Phone call */
    CHANNEL_PUSH,                       /**< Push notification */
    CHANNEL_PAGERDUTY,                  /**{ PagerDuty */
    CHANNEL_OPSGENIE,                   /**{ OpsGenie */
    CHANNEL_VICTOROPS,                  /**{ VictorOps */
    CHANNEL_DATADOG,                    /**{ Datadog */
    CHANNEL_GRAFANA,                    /**{ Grafana */
    CHANNEL_PROMETHEUS,                 /**{ Prometheus alertmanager */
    CHANNEL_SYSLOG,                     /**{ Syslog */
    CHANNEL_CONSOLE,                    /**{ Console output */
    CHANNEL_FILE,                       /**{ Log file */
    CHANNEL_CUSTOM                      /**{ Custom channel */
} notification_channel_t;

/**
 * @enum alert_condition_operator_t
 * @brief Alert condition operators
 */
typedef enum {
    OPERATOR_EQUAL = 0,                 /**< Equal to */
    OPERATOR_NOT_EQUAL,                 /**{ Not equal to */
    OPERATOR_GREATER_THAN,              /**{ Greater than */
    OPERATOR_GREATER_THAN_EQUAL,        /**{ Greater than or equal to */
    OPERATOR_LESS_THAN,                 /**{ Less than */
    OPERATOR_LESS_THAN_EQUAL,           /**{ Less than or equal to */
    OPERATOR_CONTAINS,                  /**{ Contains substring */
    OPERATOR_NOT_CONTAINS,              /**{ Does not contain substring */
    OPERATOR_STARTS_WITH,               /**{ Starts with */
    OPERATOR_ENDS_WITH,                 /**{ Ends with */
    OPERATOR_MATCHES,                   /**{ Matches regex */
    OPERATOR_IN,                        /**{ In list of values */
    OPERATOR_NOT_IN,                    /**{ Not in list of values */
    OPERATOR_BETWEEN,                   /**{ Between two values */
    OPERATOR_IS_NULL,                   /**{ Is null/empty */
    OPERATOR_IS_NOT_NULL,               /**{ Is not null/empty */
    OPERATOR_HAS_CHANGED,               /**{ Value has changed */
    OPERATOR_INCREASED_BY,              /**{ Increased by amount */
    OPERATOR_DECREASED_BY               /**{ Decreased by amount */
} alert_condition_operator_t;

/**
 * @enum alert_timeframe_t
 * @brief Alert evaluation timeframes
 */
typedef enum {
    TIMEFRAME_IMMEDIATE = 0,            /**{ Immediate evaluation */
    TIMEFRAME_LAST_1M,                  /**{ Last 1 minute */
    TIMEFRAME_LAST_5M,                  /**{ Last 5 minutes */
    TIMEFRAME_LAST_15M,                 /**{ Last 15 minutes */
    TIMEFRAME_LAST_30M,                 /**{ Last 30 minutes */
    TIMEFRAME_LAST_1H,                  /**{ Last 1 hour */
    TIMEFRAME_LAST_6H,                  /**{ Last 6 hours */
    TIMEFRAME_LAST_12H,                 /**{ Last 12 hours */
    TIMEFRAME_LAST_24H,                 /**{ Last 24 hours */
    TIMEFRAME_LAST_7D,                  /**{ Last 7 days */
    TIMEFRAME_LAST_30D,                 /**{ Last 30 days */
    TIMEFRAME_CUSTOM                    /**{ Custom timeframe */
} alert_timeframe_t;

/**
 * @enum alert_aggregation_t
 * @brief Alert condition aggregation methods
 */
typedef enum {
    AGGREGATION_NONE = 0,               /**{ No aggregation */
    AGGREGATION_AVERAGE,                /**{ Average value */
    AGGREGATION_SUM,                    /**{ Sum of values */
    AGGREGATION_MIN,                    /**{ Minimum value */
    AGGREGATION_MAX,                    /**{ Maximum value */
    AGGREGATION_COUNT,                  /**{ Count of occurrences */
    AGGREGATION_PERCENTILE_90,          /**{ 90th percentile */
    AGGREGATION_PERCENTILE_95,          /**{ 95th percentile */
    AGGREGATION_PERCENTILE_99,          /**{ 99th percentile */
    AGGREGATION_RATE,                   /**{ Rate of change */
    AGGREGATION_DELTA,                  /**{ Delta from previous */
    AGGREGATION_DISTINCT_COUNT          /**{ Distinct count */
} alert_aggregation_t;

/**
 * @struct alert_recipient_t
 * @brief Alert recipient information
 */
typedef struct {
    char id[64];                        /**{ Recipient identifier */
    char name[128];                     /**{ Recipient name */
    char email[256];                    /**{ Email address */
    char phone[32];                     /**{ Phone number */
    char slack_id[64];                  /**{ Slack user ID */
    char teams_id[64];                  /**{ Microsoft Teams ID */
    char pagerduty_id[64];              /**{ PagerDuty ID */
    notification_channel_t preferred_channel; /**{ Preferred notification channel */
    time_t office_hours_start;          /**{ Office hours start time */
    time_t office_hours_end;            /**{ Office hours end time */
    bool on_call;                       /**{ Currently on call */
    char timezone[64];                  /**{ Timezone */
    char role[64];                      /**{ Role/team */
    char escalation_level[32];          /**{ Escalation level */
} alert_recipient_t;

/**
 * @struct alert_condition_t
 * @brief Alert condition definition
 */
typedef struct {
    char metric_name[256];              /**{ Metric to evaluate */
    alert_condition_operator_t operator; /**{ Comparison operator */
    double threshold;                   /**{ Threshold value */
    char threshold_string[512];         /**{ String threshold (for non-numeric comparisons) */
    alert_timeframe_t timeframe;        /**{ Evaluation timeframe */
    uint32_t custom_timeframe_seconds;  /**{ Custom timeframe in seconds */
    alert_aggregation_t aggregation;    /**{ Aggregation method */
    uint32_t occurrences;               /**{ Number of occurrences needed */
    uint32_t evaluation_window;         /**{ Evaluation window in seconds */
    char unit[32];                      /**{ Metric unit */
    double hysteresis;                  /**{ Hysteresis value to prevent flapping */
} alert_condition_t;

/**
 * @struct alert_action_t
 * @brief Alert action definition
 */
typedef struct {
    alert_action_type_t type;           /**{ Action type */
    notification_channel_t channel;     /**{ Notification channel */
    char target[1024];                  /**{ Action target (URL, email, script path, etc.) */
    char payload_template[4096];        /**{ Payload template */
    char message_template[2048];        /**{ Message template */
    char subject_template[512];         /**{ Subject template */
    uint32_t delay_seconds;             /**{ Action delay in seconds */
    uint32_t timeout_seconds;           /**{ Action timeout in seconds */
    uint32_t retry_count;               /**{ Number of retries */
    uint32_t retry_delay_seconds;       /**{ Retry delay in seconds */
    bool require_acknowledgment;        /**{ Require acknowledgment before action */
    alert_recipient_t recipients[ALERTS_MAX_RECIPIENTS]; /**{ Action recipients */
    uint32_t recipient_count;           /**{ Number of recipients */
    char escalation_level[32];          /**{ Escalation level for this action */
} alert_action_t;

/**
 * @struct alert_rule_t
 * @brief Alert rule definition
 */
typedef struct {
    char rule_id[64];                   /**{ Rule identifier */
    char name[256];                     /**{ Rule name */
    char description[1024];             /**{ Rule description */
    alert_source_t source;              /**{ Alert source */
    alert_severity_t severity;          /**{ Default alert severity */
    bool enabled;                       /**{ Is rule enabled? */
    bool suppress_duplicates;           /**{ Suppress duplicate alerts */
    uint32_t throttle_seconds;          /**{ Throttling period in seconds */
    uint32_t suppression_window;        /**{ Suppression window in seconds */
    char suppression_key[256];          /**{ Suppression key for grouping */
    
    alert_condition_t conditions[ALERTS_MAX_CONDITIONS]; /**{ Alert conditions */
    uint32_t condition_count;           /**{ Number of conditions */
    bool require_all_conditions;         /**{ Require all conditions (AND) or any (OR) */
    
    alert_action_t actions[ALERTS_MAX_ACTIONS]; /**{ Alert actions */
    uint32_t action_count;              /**{ Number of actions */
    
    char tags[ALERTS_MAX_TAGS][64];     /**{ Alert tags */
    uint32_t tag_count;                 /**{ Number of tags */
    
    time_t created_time;                /**{ Creation timestamp */
    time_t modified_time;               /**{ Last modification timestamp */
    char created_by[64];                /**{ Creator username */
    char modified_by[64];               /**{ Last modifier username */
    
    char dependencies[10][64];          /**{ Rule dependencies */
    uint32_t dependency_count;          /**{ Number of dependencies */
    
    uint32_t max_alerts_per_hour;       /**{ Maximum alerts per hour */
    uint32_t alert_count_last_hour;     /**{ Alert count in last hour */
    
    char metadata[4096];                /**{ Rule metadata (JSON) */
} alert_rule_t;

/**
 * @struct alert_instance_t
 * @brief Alert instance (actual triggered alert)
 */
typedef struct {
    char alert_id[64];                  /**{ Alert instance identifier */
    char rule_id[64];                   /**{ Source rule identifier */
    char name[256];                     /**{ Alert name */
    char description[1024];             /**{ Alert description */
    alert_severity_t severity;          /**{ Alert severity */
    alert_source_t source;              /**{ Alert source */
    alert_status_t status;              /**{ Current status */
    
    time_t triggered_time;              /**{ When alert was triggered */
    time_t acknowledged_time;           /**{ When alert was acknowledged */
    time_t resolved_time;               /**{ When alert was resolved */
    time_t last_updated_time;           /**{ Last update timestamp */
    time_t expiration_time;             /**{ When alert expires */
    
    char triggered_by[64];              /**{ What triggered the alert */
    char acknowledged_by[64];           /**{ Who acknowledged the alert */
    char resolved_by[64];               /**{ Who resolved the alert */
    
    double metric_value;                /**{ Current metric value */
    double threshold_value;             /**{ Threshold that was crossed */
    char metric_name[256];              /**{ Metric name */
    char metric_unit[32];               /**{ Metric unit */
    
    char details[4096];                 /**{ Alert details (JSON) */
    char annotations[2048];             /**{ Key-value annotations */
    
    char tags[ALERTS_MAX_TAGS][64];     /**{ Alert tags */
    uint32_t tag_count;                 /**{ Number of tags */
    
    uint32_t escalation_level;          /**{ Current escalation level (0 = initial) */
    uint32_t notification_count;        /**{ Number of notifications sent */
    time_t last_notification_time;      /**{ Last notification timestamp */
    
    bool snoozed;                       /**{ Is alert snoozed? */
    time_t snooze_until;                /**{ Snooze until timestamp */
    
    char related_alerts[10][64];        /**{ Related alert IDs */
    uint32_t related_alert_count;       /**{ Number of related alerts */
    
    char metadata[4096];                /**{ Alert metadata (JSON) */
} alert_instance_t;

/**
 * @struct alert_escalation_policy_t
 * @brief Alert escalation policy
 */
typedef struct {
    char policy_id[64];                 /**{ Policy identifier */
    char name[256];                     /**{ Policy name */
    char description[1024];             /**{ Policy description */
    
    struct {
        uint32_t level;                 /**{ Escalation level (0-based) */
        uint32_t delay_seconds;         /**{ Delay before escalation */
        alert_recipient_t recipients[ALERTS_MAX_RECIPIENTS]; /**{ Recipients for this level */
        uint32_t recipient_count;       /**{ Number of recipients */
        char notification_channel[32];  /**{ Notification channel for this level */
        char message_template[2048];    /**{ Message template */
    } levels[ALERTS_MAX_ESCALATION_LEVELS];
    
    uint32_t level_count;               /**{ Number of escalation levels */
    bool enabled;                       /**{ Is policy enabled? */
    time_t created_time;                /**{ Creation timestamp */
    time_t modified_time;               /**{ Last modification timestamp */
} alert_escalation_policy_t;

/**
 * @struct alert_notification_t
 * @brief Alert notification record
 */
typedef struct {
    char notification_id[64];           /**{ Notification identifier */
    char alert_id[64];                  /**{ Related alert identifier */
    char rule_id[64];                   /**{ Related rule identifier */
    
    notification_channel_t channel;     /**{ Notification channel */
    alert_severity_t severity;          /**{ Alert severity */
    
    char recipient[256];                /**{ Recipient address/ID */
    char subject[512];                  /**{ Notification subject */
    char message[4096];                 /**{ Notification message */
    
    time_t sent_time;                   /**{ When notification was sent */
    bool delivered;                     /**{ Was notification delivered? */
    time_t delivered_time;              /**{ When notification was delivered */
    bool acknowledged;                  /**{ Was notification acknowledged? */
    time_t acknowledged_time;           /**{ When notification was acknowledged */
    
    uint32_t retry_count;               /**{ Number of retry attempts */
    char delivery_status[256];          /**{ Delivery status message */
    char error_message[1024];           /**{ Error message if failed */
    
    char metadata[4096];                /**{ Notification metadata (JSON) */
} alert_notification_t;

/**
 * @struct alert_history_entry_t
 * @brief Alert history entry
 */
typedef struct {
    char entry_id[64];                  /**{ History entry identifier */
    char alert_id[64];                  /**{ Related alert identifier */
    
    alert_status_t old_status;          /**{ Previous status */
    alert_status_t new_status;          /**{ New status */
    
    time_t timestamp;                   /**{ Change timestamp */
    char changed_by[64];                /**{ Who changed the status */
    char change_reason[1024];           /**{ Reason for change */
    
    char comments[2048];                /**{ Additional comments */
    char metadata[2048];                /**{ Entry metadata (JSON) */
} alert_history_entry_t;

/**
 * @struct alert_dashboard_metrics_t
 * @brief Alert dashboard metrics
 */
typedef struct {
    // Alert counts
    uint32_t total_alerts_24h;          /**{ Total alerts in last 24h */
    uint32_t open_alerts;               /**{ Currently open alerts */
    uint32_t unacknowledged_alerts;     /**{ Unacknowledged alerts */
    uint32_t critical_alerts;           /**{ Critical severity alerts */
    uint32_t high_alerts;               /**{ High severity alerts */
    
    // Alert sources
    uint32_t export_alerts;             /**{ Alerts from export operations */
    uint32_t system_alerts;             /**{ System health alerts */
    uint32_t network_alerts;            /**{ Network alerts */
    uint32_t data_quality_alerts;       /**{ Data quality alerts */
    uint32_t performance_alerts;        /**{ Performance alerts */
    
    // Time-based metrics
    double mttr_24h;                    /**{ Mean time to resolve (last 24h) */
    double mtta_24h;                    /**{ Mean time to acknowledge (last 24h) */
    uint32_t alerts_by_hour[24];        /**{ Alerts by hour of day */
    
    // Rule metrics
    uint32_t active_rules;              /**{ Active alert rules */
    uint32_t triggered_rules_24h;       /**{ Rules triggered in last 24h */
    
    // Notification metrics
    uint32_t notifications_sent_24h;    /**{ Notifications sent in last 24h */
    uint32_t notifications_failed_24h;  /**{ Failed notifications in last 24h */
    double notification_delivery_rate;  /**{ Notification delivery rate (%) */
    
    // Timestamp
    time_t timestamp;                   /**{ Metrics timestamp */
} alert_dashboard_metrics_t;

/**
 * @struct alert_silence_t
 * @brief Alert silence/suppression rule
 */
typedef struct {
    char silence_id[64];                /**{ Silence identifier */
    char name[256];                     /**{ Silence name */
    char description[1024];             /**{ Silence description */
    
    time_t start_time;                  /**{ Silence start time */
    time_t end_time;                    /**{ Silence end time */
    bool indefinite;                    /**{ Indefinite silence? */
    
    char rule_pattern[256];             /**{ Rule ID pattern to match */
    char alert_pattern[256];            /**{ Alert name pattern to match */
    char tag_patterns[ALERTS_MAX_TAGS][128]; /**{ Tag patterns to match */
    uint32_t tag_pattern_count;         /**{ Number of tag patterns */
    
    char created_by[64];                /**{ Who created the silence */
    time_t created_time;                /**{ Creation timestamp */
    char reason[1024];                  /**{ Reason for silence */
    
    bool enabled;                       /**{ Is silence enabled? */
    char metadata[4096];                /**{ Silence metadata (JSON) */
} alert_silence_t;

/**
 * @struct alert_threshold_t
 * @brief Dynamic threshold configuration
 */
typedef struct {
    char threshold_id[64];              /**{ Threshold identifier */
    char metric_name[256];              /**{ Metric name */
    char rule_id[64];                   /**{ Related rule identifier */
    
    double warning_threshold;           /**{ Warning threshold */
    double critical_threshold;          /**{ Critical threshold */
    double min_value;                   /**{ Minimum expected value */
    double max_value;                   /**{ Maximum expected value */
    
    bool adaptive;                      /**{ Use adaptive thresholds? */
    double sensitivity;                 /**{ Sensitivity (0-1) */
    uint32_t learning_period_days;      /**{ Learning period in days */
    
    time_t created_time;                /**{ Creation timestamp */
    time_t last_updated_time;           /**{ Last update timestamp */
    time_t last_recalculated_time;      /**{ Last recalculation timestamp */
    
    char seasonality[32];               /**{ Seasonality pattern (daily, weekly, monthly) */
    bool exclude_weekends;              /**{ Exclude weekends from baseline */
    bool exclude_holidays;              /**{ Exclude holidays from baseline */
    
    char baseline_data[4096];           /**{ Baseline data (JSON) */
    char metadata[4096];                /**{ Threshold metadata (JSON) */
} alert_threshold_t;

/**
 * @struct alert_handle_t
 * @brief Opaque handle for alert module
 */
typedef struct alert_handle alert_handle_t;

// ============================================================================
// Initialization and Configuration
// ============================================================================

/**
 * @brief Initialize alert module
 * 
 * @param export_handle Handle to export module (optional)
 * @param config_path Path to configuration file (NULL for defaults)
 * @param handle Output parameter for alert handle
 * @return export_status_t Status code (reusing export_status_t)
 */
export_status_t alert_init(export_handle_t* export_handle,
                          const char* config_path,
                          alert_handle_t** handle);

/**
 * @brief Start alert service
 * 
 * @param handle Alert handle
 * @return export_status_t Status code
 */
export_status_t alert_start_service(alert_handle_t* handle);

/**
 * @brief Stop alert service
 * 
 * @param handle Alert handle
 * @return export_status_t Status code
 */
export_status_t alert_stop_service(alert_handle_t* handle);

/**
 * @brief Clean up alert module
 * 
 * @param handle Alert handle
 * @return export_status_t Status code
 */
export_status_t alert_deinit(alert_handle_t* handle);

// ============================================================================
// Alert Rule Management
// ============================================================================

/**
 * @brief Create alert rule
 * 
 * @param handle Alert handle
 * @param rule Alert rule definition
 * @param rule_id Output parameter for rule ID
 * @param rule_id_size Size of rule ID buffer
 * @return export_status_t Status code
 */
export_status_t alert_create_rule(alert_handle_t* handle,
                                 const alert_rule_t* rule,
                                 char* rule_id,
                                 size_t rule_id_size);

/**
 * @brief Update alert rule
 * 
 * @param handle Alert handle
 * @param rule_id Rule identifier
 * @param rule Updated rule definition
 * @return export_status_t Status code
 */
export_status_t alert_update_rule(alert_handle_t* handle,
                                 const char* rule_id,
                                 const alert_rule_t* rule);

/**
 * @brief Delete alert rule
 * 
 * @param handle Alert handle
 * @param rule_id Rule identifier
 * @param force Force delete even if active alerts exist
 * @return export_status_t Status code
 */
export_status_t alert_delete_rule(alert_handle_t* handle,
                                 const char* rule_id,
                                 bool force);

/**
 * @brief Enable alert rule
 * 
 * @param handle Alert handle
 * @param rule_id Rule identifier
 * @return export_status_t Status code
 */
export_status_t alert_enable_rule(alert_handle_t* handle,
                                 const char* rule_id);

/**
 * @brief Disable alert rule
 * 
 * @param handle Alert handle
 * @param rule_id Rule identifier
 * @return export_status_t Status code
 */
export_status_t alert_disable_rule(alert_handle_t* handle,
                                  const char* rule_id);

/**
 * @brief Test alert rule
 * 
 * @param handle Alert handle
 * @param rule Rule to test
 * @param matches Output parameter for number of matching metrics
 * @param would_trigger Output parameter for would trigger alert
 * @return export_status_t Status code
 */
export_status_t alert_test_rule(alert_handle_t* handle,
                               const alert_rule_t* rule,
                               uint32_t* matches,
                               bool* would_trigger);

/**
 * @brief List alert rules
 * 
 * @param handle Alert handle
 * @param rules Array to store rules
 * @param max_rules Maximum rules to retrieve
 * @param actual_rules Output parameter for actual rules
 * @param enabled_only Return only enabled rules
 * @param source Filter by source (0 for all)
 * @return export_status_t Status code
 */
export_status_t alert_list_rules(alert_handle_t* handle,
                                alert_rule_t* rules,
                                uint32_t max_rules,
                                uint32_t* actual_rules,
                                bool enabled_only,
                                alert_source_t source);

// ============================================================================
// Alert Instance Management
// ============================================================================

/**
 * @brief Trigger alert manually
 * 
 * @param handle Alert handle
 * @param rule_id Rule identifier
 * @param severity Override severity (0 for rule default)
 * @param details Alert details JSON
 * @param alert_id Output parameter for alert ID
 * @param alert_id_size Size of alert ID buffer
 * @return export_status_t Status code
 */
export_status_t alert_trigger(alert_handle_t* handle,
                             const char* rule_id,
                             alert_severity_t severity,
                             const char* details,
                             char* alert_id,
                             size_t alert_id_size);

/**
 * @brief Acknowledge alert
 * 
 * @param handle Alert handle
 * @param alert_id Alert identifier
 * @param acknowledged_by Who acknowledged the alert
 * @param comments Acknowledgement comments
 * @return export_status_t Status code
 */
export_status_t alert_acknowledge(alert_handle_t* handle,
                                 const char* alert_id,
                                 const char* acknowledged_by,
                                 const char* comments);

/**
 * @brief Resolve alert
 * 
 * @param handle Alert handle
 * @param alert_id Alert identifier
 * @param resolved_by Who resolved the alert
 * @param comments Resolution comments
 * @return export_status_t Status code
 */
export_status_t alert_resolve(alert_handle_t* handle,
                             const char* alert_id,
                             const char* resolved_by,
                             const char* comments);

/**
 * @brief Escalate alert
 * 
 * @param handle Alert handle
 * @param alert_id Alert identifier
 * @param policy_id Escalation policy ID (NULL for default)
 * @param level Escalation level (0 for next level)
 * @return export_status_t Status code
 */
export_status_t alert_escalate(alert_handle_t* handle,
                              const char* alert_id,
                              const char* policy_id,
                              uint32_t level);

/**
 * @brief Snooze alert
 * 
 * @param handle Alert handle
 * @param alert_id Alert identifier
 * @param snooze_until Snooze until timestamp
 * @param snoozed_by Who snoozed the alert
 * @param reason Snooze reason
 * @return export_status_t Status code
 */
export_status_t alert_snooze(alert_handle_t* handle,
                            const char* alert_id,
                            time_t snooze_until,
                            const char* snoozed_by,
                            const char* reason);

/**
 * @brief Get alert details
 * 
 * @param handle Alert handle
 * @param alert_id Alert identifier
 * @param alert Output parameter for alert details
 * @return export_status_t Status code
 */
export_status_t alert_get_details(alert_handle_t* handle,
                                 const char* alert_id,
                                 alert_instance_t* alert);

/**
 * @brief List active alerts
 * 
 * @param handle Alert handle
 * @param alerts Array to store alerts
 * @param max_alerts Maximum alerts to retrieve
 * @param actual_alerts Output parameter for actual alerts
 * @param severity Filter by severity (0 for all)
 * @param source Filter by source (0 for all)
 * @param include_snoozed Include snoozed alerts
 * @return export_status_t Status code
 */
export_status_t alert_list_active(alert_handle_t* handle,
                                 alert_instance_t* alerts,
                                 uint32_t max_alerts,
                                 uint32_t* actual_alerts,
                                 alert_severity_t severity,
                                 alert_source_t source,
                                 bool include_snoozed);

/**
 * @brief Search alert history
 * 
 * @param handle Alert handle
 * @param start_time Search start time
 * @param end_time Search end time
 * @param rule_id Filter by rule ID (NULL for all)
 * @param severity Filter by severity (0 for all)
 * @param status Filter by status (0 for all)
 * @param alerts Array to store alerts
 * @param max_alerts Maximum alerts to retrieve
 * @param actual_alerts Output parameter for actual alerts
 * @param total_matches Output parameter for total matches
 * @return export_status_t Status code
 */
export_status_t alert_search_history(alert_handle_t* handle,
                                    time_t start_time,
                                    time_t end_time,
                                    const char* rule_id,
                                    alert_severity_t severity,
                                    alert_status_t status,
                                    alert_instance_t* alerts,
                                    uint32_t max_alerts,
                                    uint32_t* actual_alerts,
                                    uint32_t* total_matches);

// ============================================================================
// Notification Management
// ============================================================================

/**
 * @brief Send notification
 * 
 * @param handle Alert handle
 * @param notification Notification to send
 * @param notification_id Output parameter for notification ID
 * @param notification_id_size Size of notification ID buffer
 * @return export_status_t Status code
 */
export_status_t alert_send_notification(alert_handle_t* handle,
                                       const alert_notification_t* notification,
                                       char* notification_id,
                                       size_t notification_id_size);

/**
 * @brief Retry failed notification
 * 
 * @param handle Alert handle
 * @param notification_id Notification identifier
 * @return export_status_t Status code
 */
export_status_t alert_retry_notification(alert_handle_t* handle,
                                        const char* notification_id);

/**
 * @brief Get notification status
 * 
 * @param handle Alert handle
 * @param notification_id Notification identifier
 * @param delivered Output parameter for delivery status
 * @param acknowledged Output parameter for acknowledgement status
 * @param error_message Output parameter for error message
 * @param error_size Size of error buffer
 * @return export_status_t Status code
 */
export_status_t alert_get_notification_status(alert_handle_t* handle,
                                             const char* notification_id,
                                             bool* delivered,
                                             bool* acknowledged,
                                             char* error_message,
                                             size_t error_size);

// ============================================================================
// Silence Management
// ============================================================================

/**
 * @brief Create silence rule
 * 
 * @param handle Alert handle
 * @param silence Silence definition
 * @param silence_id Output parameter for silence ID
 * @param silence_id_size Size of silence ID buffer
 * @return export_status_t Status code
 */
export_status_t alert_create_silence(alert_handle_t* handle,
                                    const alert_silence_t* silence,
                                    char* silence_id,
                                    size_t silence_id_size);

/**
 * @brief Update silence rule
 * 
 * @param handle Alert handle
 * @param silence_id Silence identifier
 * @param silence Updated silence definition
 * @return export_status_t Status code
 */
export_status_t alert_update_silence(alert_handle_t* handle,
                                    const char* silence_id,
                                    const alert_silence_t* silence);

/**
 * @brief Delete silence rule
 * 
 * @param handle Alert handle
 * @param silence_id Silence identifier
 * @return export_status_t Status code
 */
export_status_t alert_delete_silence(alert_handle_t* handle,
                                    const char* silence_id);

/**
 * @brief Check if alert is silenced
 * 
 * @param handle Alert handle
 * @param alert Alert to check
 * @param is_silenced Output parameter for silenced status
 * @param silence_id Output parameter for matching silence ID
 * @param silence_id_size Size of silence ID buffer
 * @return export_status_t Status code
 */
export_status_t alert_check_silence(alert_handle_t* handle,
                                   const alert_instance_t* alert,
                                   bool* is_silenced,
                                   char* silence_id,
                                   size_t silence_id_size);

// ============================================================================
// Escalation Management
// ============================================================================

/**
 * @brief Create escalation policy
 * 
 * @param handle Alert handle
 * @param policy Escalation policy definition
 * @param policy_id Output parameter for policy ID
 * @param policy_id_size Size of policy ID buffer
 * @return export_status_t Status code
 */
export_status_t alert_create_escalation_policy(alert_handle_t* handle,
                                              const alert_escalation_policy_t* policy,
                                              char* policy_id,
                                              size_t policy_id_size);

/**
 * @brief Apply escalation policy to alert
 * 
 * @param handle Alert handle
 * @param alert_id Alert identifier
 * @param policy_id Escalation policy ID
 * @return export_status_t Status code
 */
export_status_t alert_apply_escalation_policy(alert_handle_t* handle,
                                             const char* alert_id,
                                             const char* policy_id);

/**
 * @brief Get on-call schedule
 * 
 * @param handle Alert handle
 * @param time Timestamp to check
 * @param recipients Array to store on-call recipients
 * @param max_recipients Maximum recipients to retrieve
 * @param actual_recipients Output parameter for actual recipients
 * @param escalation_level Filter by escalation level (0 for all)
 * @return export_status_t Status code
 */
export_status_t alert_get_oncall_schedule(alert_handle_t* handle,
                                         time_t time,
                                         alert_recipient_t* recipients,
                                         uint32_t max_recipients,
                                         uint32_t* actual_recipients,
                                         uint32_t escalation_level);

// ============================================================================
// Metric Monitoring and Alerting
// ============================================================================

/**
 * @brief Submit metric for monitoring
 * 
 * @param handle Alert handle
 * @param metric_name Metric name
 * @param value Metric value
 * @param timestamp Metric timestamp (0 for current time)
 * @param tags Metric tags (JSON string)
 * @return export_status_t Status code
 */
export_status_t alert_submit_metric(alert_handle_t* handle,
                                   const char* metric_name,
                                   double value,
                                   time_t timestamp,
                                   const char* tags);

/**
 * @brief Submit export metrics for alerting
 * 
 * @param handle Alert handle
 * @param export_metrics Export metrics structure
 * @param export_status Export status
 * @param job_id Export job ID
 * @return export_status_t Status code
 */
export_status_t alert_submit_export_metrics(alert_handle_t* handle,
                                           const export_monitor_metrics_t* export_metrics,
                                           export_status_t export_status,
                                           const char* job_id);

/**
 * @brief Evaluate all alert rules
 * 
 * @param handle Alert handle
 * @param force Force evaluation even if not scheduled
 * @param triggered_rules Output parameter for number of rules triggered
 * @param triggered_alerts Output parameter for number of alerts created
 * @return export_status_t Status code
 */
export_status_t alert_evaluate_rules(alert_handle_t* handle,
                                    bool force,
                                    uint32_t* triggered_rules,
                                    uint32_t* triggered_alerts);

/**
 * @brief Get metric history
 * 
 * @param handle Alert handle
 * @param metric_name Metric name
 * @param start_time Start time
 * @param end_time End time
 * @param values Array to store values
 * @param timestamps Array to store timestamps
 * @param max_points Maximum points to retrieve
 * @param actual_points Output parameter for actual points
 * @param aggregation Aggregation method
 * @param interval_seconds Aggregation interval in seconds
 * @return export_status_t Status code
 */
export_status_t alert_get_metric_history(alert_handle_t* handle,
                                        const char* metric_name,
                                        time_t start_time,
                                        time_t end_time,
                                        double* values,
                                        time_t* timestamps,
                                        uint32_t max_points,
                                        uint32_t* actual_points,
                                        alert_aggregation_t aggregation,
                                        uint32_t interval_seconds);

// ============================================================================
// Dashboard and Reporting
// ============================================================================

/**
 * @brief Get alert dashboard metrics
 * 
 * @param handle Alert handle
 * @param metrics Output parameter for dashboard metrics
 * @return export_status_t Status code
 */
export_status_t alert_get_dashboard_metrics(alert_handle_t* handle,
                                           alert_dashboard_metrics_t* metrics);

/**
 * @brief Generate alert report
 * 
 * @param handle Alert handle
 * @param start_time Report start time
 * @param end_time Report end time
 * @param format Report format (reusing export_format_t)
 * @param report_data Output parameter for report data
 * @param report_size Size of report buffer
 * @param actual_size Output parameter for actual report size
 * @return export_status_t Status code
 */
export_status_t alert_generate_report(alert_handle_t* handle,
                                     time_t start_time,
                                     time_t end_time,
                                     export_format_t format,
                                     void* report_data,
                                     size_t report_size,
                                     size_t* actual_size);

/**
 * @brief Get alert statistics
 * 
 * @param handle Alert handle
 * @param start_time Statistics start time
 * @param end_time Statistics end time
 * @param stats_json Output parameter for statistics JSON
 * @param stats_size Size of statistics buffer
 * @param actual_size Output parameter for actual statistics size
 * @return export_status_t Status code
 */
export_status_t alert_get_statistics(alert_handle_t* handle,
                                    time_t start_time,
                                    time_t end_time,
                                    char* stats_json,
                                    size_t stats_size,
                                    size_t* actual_size);

// ============================================================================
// Integration with Export Module
// ============================================================================

/**
 * @brief Monitor export job for alerts
 * 
 * @param handle Alert handle
 * @param export_handle Export module handle
 * @param job_id Export job ID to monitor
 * @param alert_on_success Alert on successful completion
 * @param alert_on_failure Alert on failure
 * @param alert_on_slow Alert on slow execution
 * @param slow_threshold_seconds Threshold for slow execution
 * @return export_status_t Status code
 */
export_status_t alert_monitor_export_job(alert_handle_t* handle,
                                        export_handle_t* export_handle,
                                        const char* job_id,
                                        bool alert_on_success,
                                        bool alert_on_failure,
                                        bool alert_on_slow,
                                        uint32_t slow_threshold_seconds);

/**
 * @brief Monitor export connection for alerts
 * 
 * @param handle Alert handle
 * @param export_handle Export module handle
 * @param connection_id Export connection ID to monitor
 * @param alert_on_disconnect Alert on disconnection
 * @param alert_on_slow Alert on slow response
 * @param alert_on_error Alert on errors
 * @return export_status_t Status code
 */
export_status_t alert_monitor_export_connection(alert_handle_t* handle,
                                               export_handle_t* export_handle,
                                               const char* connection_id,
                                               bool alert_on_disconnect,
                                               bool alert_on_slow,
                                               bool alert_on_error);

/**
 * @brief Monitor export throughput for alerts
 * 
 * @param handle Alert handle
 * @param export_handle Export module handle
 * @param destination_type Export destination type
 * @param min_throughput Minimum acceptable throughput (records/sec)
 * @param max_throughput Maximum expected throughput (records/sec)
 * @return export_status_t Status code
 */
export_status_t alert_monitor_export_throughput(alert_handle_t* handle,
                                               export_handle_t* export_handle,
                                               export_destination_t destination_type,
                                               double min_throughput,
                                               double max_throughput);

// ============================================================================
// Utility Functions
// ============================================================================

/**
 * @brief Parse severity from string
 * 
 * @param severity_str Severity string
 * @return alert_severity_t Severity enum value
 */
static inline alert_severity_t alert_parse_severity(const char* severity_str) {
    if (severity_str == NULL) return SEVERITY_INFO;
    
    if (strcasecmp(severity_str, "info") == 0) return SEVERITY_INFO;
    if (strcasecmp(severity_str, "low") == 0) return SEVERITY_LOW;
    if (strcasecmp(severity_str, "medium") == 0) return SEVERITY_MEDIUM;
    if (strcasecmp(severity_str, "high") == 0) return SEVERITY_HIGH;
    if (strcasecmp(severity_str, "critical") == 0) return SEVERITY_CRITICAL;
    if (strcasecmp(severity_str, "emergency") == 0) return SEVERITY_EMERGENCY;
    
    return SEVERITY_INFO;
}

/**
 * @brief Get severity string
 * 
 * @param severity Severity enum value
 * @return const char* Severity string
 */
static inline const char* alert_get_severity_string(alert_severity_t severity) {
    switch (severity) {
        case SEVERITY_INFO: return "INFO";
        case SEVERITY_LOW: return "LOW";
        case SEVERITY_MEDIUM: return "MEDIUM";
        case SEVERITY_HIGH: return "HIGH";
        case SEVERITY_CRITICAL: return "CRITICAL";
        case SEVERITY_EMERGENCY: return "EMERGENCY";
        default: return "UNKNOWN";
    }
}

/**
 * @brief Get status string
 * 
 * @param status Status enum value
 * @return const char* Status string
 */
static inline const char* alert_get_status_string(alert_status_t status) {
    switch (status) {
        case ALERT_STATUS_NEW: return "NEW";
        case ALERT_STATUS_TRIGGERED: return "TRIGGERED";
        case ALERT_STATUS_ACKNOWLEDGED: return "ACKNOWLEDGED";
        case ALERT_STATUS_RESOLVED: return "RESOLVED";
        case ALERT_STATUS_SUPPRESSED: return "SUPPRESSED";
        case ALERT_STATUS_EXPIRED: return "EXPIRED";
        case ALERT_STATUS_CLOSED: return "CLOSED";
        case ALERT_STATUS_ESCALATED: return "ESCALATED";
        case ALERT_STATUS_SNOOZED: return "SNOOZED";
        case ALERT_STATUS_MUTED: return "MUTED";
        default: return "UNKNOWN";
    }
}

/**
 * @brief Calculate mean time to resolve (MTTR)
 * 
 * @param resolved_alerts Number of resolved alerts
 * @param total_resolution_time Total resolution time in seconds
 * @return double MTTR in seconds
 */
static inline double alert_calculate_mttr(uint32_t resolved_alerts, double total_resolution_time) {
    if (resolved_alerts == 0) return 0.0;
    return total_resolution_time / (double)resolved_alerts;
}

/**
 * @brief Calculate mean time to acknowledge (MTTA)
 * 
 * @param acknowledged_alerts Number of acknowledged alerts
 * @param total_acknowledgment_time Total acknowledgment time in seconds
 * @return double MTTA in seconds
 */
static inline double alert_calculate_mtta(uint32_t acknowledged_alerts, double total_acknowledgment_time) {
    if (acknowledged_alerts == 0) return 0.0;
    return total_acknowledgment_time / (double)acknowledged_alerts;
}

/**
 * @brief Calculate alert rate per hour
 * 
 * @param alert_count Number of alerts
 * @param hours Time period in hours
 * @return double Alerts per hour
 */
static inline double alert_calculate_rate(uint32_t alert_count, double hours) {
    if (hours <= 0.0) return 0.0;
    return (double)alert_count / hours;
}

/**
 * @brief Check if severity requires immediate attention
 * 
 * @param severity Severity to check
 * @return true if immediate attention required
 */
static inline bool alert_requires_immediate_attention(alert_severity_t severity) {
    return (severity == SEVERITY_CRITICAL || severity == SEVERITY_EMERGENCY);
}

/**
 * @brief Check if time is within office hours
 * 
 * @param time Timestamp to check
 * @param office_start Office hours start time (seconds since midnight)
 * @param office_end Office hours end time (seconds since midnight)
 * @param timezone Timezone string (NULL for local time)
 * @return true if within office hours
 */
static inline bool alert_is_office_hours(time_t time, uint32_t office_start, uint32_t office_end, const char* timezone) {
    // Convert timestamp to local time
    struct tm* timeinfo;
    if (timezone != NULL) {
        // Note: Timezone handling would require additional libraries
        // For simplicity, using localtime here
        timeinfo = localtime(&time);
    } else {
        timeinfo = localtime(&time);
    }
    
    uint32_t current_seconds = timeinfo->tm_hour * 3600 + timeinfo->tm_min * 60 + timeinfo->tm_sec;
    
    return (current_seconds >= office_start && current_seconds <= office_end);
}

/**
 * @brief Format duration for human reading
 * 
 * @param seconds Duration in seconds
 * @param buffer Buffer for result
 * @param buffer_size Size of buffer
 * @return const char* Formatted duration
 */
static inline const char* alert_format_duration(uint64_t seconds, char* buffer, size_t buffer_size) {
    if (seconds < 60) {
        snprintf(buffer, buffer_size, "%lu seconds", seconds);
    } else if (seconds < 3600) {
        snprintf(buffer, buffer_size, "%lu minutes", seconds / 60);
    } else if (seconds < 86400) {
        snprintf(buffer, buffer_size, "%lu hours", seconds / 3600);
    } else {
        snprintf(buffer, buffer_size, "%lu days", seconds / 86400);
    }
    return buffer;
}

/**
 * @brief Get API version string
 * 
 * @return const char* Version string
 */
static inline const char* alert_get_version_string(void) {
    return "4.1.0";
}

// ============================================================================
// Callback Types
// ============================================================================

/**
 * @brief Callback for alert triggers
 * 
 * @param alert The triggered alert
 * @param context User-defined context
 */
typedef void (*alert_trigger_callback_t)(const alert_instance_t* alert, void* context);

/**
 * @brief Callback for alert resolution
 * 
 * @param alert_id Resolved alert ID
 * @param resolution_time Resolution timestamp
 * @param context User-defined context
 */
typedef void (*alert_resolution_callback_t)(const char* alert_id, time_t resolution_time, void* context);

/**
 * @brief Callback for notification delivery
 * 
 * @param notification_id Notification ID
 * @param delivered Delivery status
 * @param context User-defined context
 */
typedef void (*notification_delivery_callback_t)(const char* notification_id, bool delivered, void* context);

// ============================================================================
// Advanced Alert Operations
// ============================================================================

/**
 * @brief Register alert trigger callback
 * 
 * @param handle Alert handle
 * @param callback Callback function
 * @param context User context
 * @return export_status_t Status code
 */
export_status_t alert_register_trigger_callback(alert_handle_t* handle,
                                               alert_trigger_callback_t callback,
                                               void* context);

/**
 * @brief Register alert resolution callback
 * 
 * @param handle Alert handle
 * @param callback Callback function
 * @param context User context
 * @return export_status_t Status code
 */
export_status_t alert_register_resolution_callback(alert_handle_t* handle,
                                                  alert_resolution_callback_t callback,
                                                  void* context);

/**
 * @brief Create alert from export error
 * 
 * @param handle Alert handle
 * @param export_status Export status code
 * @param error_message Export error message
 * @param job_id Export job ID
 * @param severity Override severity (0 for auto-determined)
 * @param alert_id Output parameter for alert ID
 * @param alert_id_size Size of alert ID buffer
 * @return export_status_t Status code
 */
export_status_t alert_from_export_error(alert_handle_t* handle,
                                       export_status_t export_status,
                                       const char* error_message,
                                       const char* job_id,
                                       alert_severity_t severity,
                                       char* alert_id,
                                       size_t alert_id_size);

/**
 * @brief Batch process alerts
 * 
 * @param handle Alert handle
 * @param alert_ids Array of alert IDs
 * @param alert_count Number of alerts
 * @param action Action to perform (acknowledge, resolve, etc.)
 * @param performed_by Who performed the action
 * @param comments Action comments
 * @param success_count Output parameter for successful operations
 * @param failed_count Output parameter for failed operations
 * @return export_status_t Status code
 */
export_status_t alert_batch_process(alert_handle_t* handle,
                                   const char** alert_ids,
                                   uint32_t alert_count,
                                   const char* action,
                                   const char* performed_by,
                                   const char* comments,
                                   uint32_t* success_count,
                                   uint32_t* failed_count);

/**
 * @brief Export alerts to external system
 * 
 * @param handle Alert handle
 * @param start_time Start time for alerts
 * @param end_time End time for alerts
 * @param export_config Export configuration
 * @param job_id Output parameter for export job ID
 * @param job_id_size Size of job ID buffer
 * @return export_status_t Status code
 */
export_status_t alert_export_alerts(alert_handle_t* handle,
                                   time_t start_time,
                                   time_t end_time,
                                   const export_config_t* export_config,
                                   char* job_id,
                                   size_t job_id_size);

/**
 * @brief Import alert rules from file
 * 
 * @param handle Alert handle
 * @param file_path File path to import
 * @param format File format
 * @param overwrite Overwrite existing rules
 * @param imported_count Output parameter for imported rules
 * @param failed_count Output parameter for failed imports
 * @return export_status_t Status code
 */
export_status_t alert_import_rules(alert_handle_t* handle,
                                  const char* file_path,
                                  export_format_t format,
                                  bool overwrite,
                                  uint32_t* imported_count,
                                  uint32_t* failed_count);

#ifdef __cplusplus
}
#endif

#endif // ALERTS_H

// ============================================================================
// Implementation Notes:
// ============================================================================
// 1. Integration: Tight integration with export.h for monitoring export operations
// 2. Alert Sources: Export errors, system health, data quality, performance, security
// 3. Severity Levels: Info, Low, Medium, High, Critical, Emergency
// 4. Notification Channels: Email, Slack, Teams, Webhook, SMS, PagerDuty, etc.
// 5. Alert Management: Acknowledge, resolve, escalate, snooze, suppress
// 6. Escalation Policies: Multi-level escalation with configurable delays
// 7. Silence Rules: Temporarily suppress alerts for maintenance or expected issues
// 8. Dashboard: Real-time metrics and statistics
// 9. Reporting: Generate reports in various formats
// 10. Extensibility: Plugin architecture for custom alert sources and actions