#ifndef SYSTEM_H
#define SYSTEM_H

#include <stdint.h>
#include <time.h>

// Forward declarations
typedef struct SystemState SystemState;

// System types
typedef enum : u8 {
    SYS_TYPE_DESKTOP,
    SYS_TYPE_SERVER,
    SYS_TYPE_LAPTOP,
    SYS_TYPE_VIRTUAL,
    SYS_TYPE_CONTAINER,
    SYS_TYPE_EMBEDDED,
    SYS_TYPE_UNKNOWN
} SystemType;

// Virtualization types
typedef enum : u8 {
    VIRT_NONE,
    VIRT_KVM,
    VIRT_VMWARE,
    VIRT_VIRTUALBOX,
    VIRT_XEN,
    VIRT_HYPERV,
    VIRT_DOCKER,
    VIRT_LXC,
    VIRT_PODMAN,
    VIRT_UNKNOWN
} VirtualizationType;

// Battery status
typedef struct PACKED {
    u8 present : 1;
    u8 charging : 1;
    u8 discharging : 1;
    u8 full : 1;
    u8 critical : 1;
    u8 _reserved : 3;
    
    u8 percentage;          // 0-100
    u16 voltage;           // Millivolts
    i16 current;           // Milliamps (negative for discharging)
    u16 power;             // Milliwatts
    u16 temperature;       // Celsius * 10
    u32 capacity;          // mAh
    u32 full_capacity;     // mAh
    u32 remaining_time;    // Minutes
    char technology[16];
    char status[16];
} BatteryStatus;

// Sensor reading
typedef struct PACKED {
    char label[32];
    i16 value;             // Celsius, RPM, Volts * 100, etc.
    i16 min;
    i16 max;
    i16 critical;
    u8 type;              // 0=temp, 1=fan, 2=voltage, 3=current, 4=power
    u8 _reserved[3];
} SensorReading;

// User session
typedef struct PACKED {
    char username[32];
    char terminal[32];
    char host[256];
    time_t login_time;
    pid_t pid;
    u16 session_id;
    u8 _reserved[6];
} UserSession;

// Function prototypes
SystemState* system_monitor_init(void) HOT;
void system_monitor_cleanup(SystemState *state) COLD;

// System identification
const char* system_get_hostname(const SystemState *state);
const char* system_get_domainname(const SystemState *state);
const char* system_get_machine_id(const SystemState *state);
const char* system_get_boot_id(const SystemState *state);

// Distribution information
const char* system_get_distribution(const SystemState *state);
const char* system_get_distro_version(const SystemState *state);
const char* system_get_distro_codename(const SystemState *state);
const char* system_get_package_manager(const SystemState *state);

// Kernel information
const char* system_get_kernel_version(const SystemState *state);
const char* system_get_kernel_release(const SystemState *state);
const char* system_get_kernel_arch(const SystemState *state);
const char* system_get_kernel_cmdline(const SystemState *state, char *buffer, u32 size);

// Hardware information
const char* system_get_vendor(const SystemState *state);
const char* system_get_product(const SystemState *state);
const char* system_get_serial(const SystemState *state);
const char* system_get_uuid(const SystemState *state);
const char* system_get_bios_vendor(const SystemState *state);
const char* system_get_bios_version(const SystemState *state);
const char* system_get_bios_date(const SystemState *state);

// Uptime and time
u64 system_get_uptime(const SystemState *state);      // Seconds
const char* system_get_uptime_string(const SystemState *state, char *buffer, u32 size);
time_t system_get_boot_time(const SystemState *state);
const char* system_get_current_time(const SystemState *state, char *buffer, u32 size);
const char* system_get_timezone(const SystemState *state);

// Load averages
float system_get_load_avg_1(const SystemState *state);
float system_get_load_avg_5(const SystemState *state);
float system_get_load_avg_15(const SystemState *state);

// System type
SystemType system_get_type(const SystemState *state);
VirtualizationType system_get_virtualization(const SystemState *state);
int system_is_container(const SystemState *state);
const char* system_get_container_runtime(const SystemState *state);

// Users and sessions
u32 system_get_user_count(const SystemState *state);
const UserSession* system_get_users(const SystemState *state, u32 *count);
u32 system_get_session_count(const SystemState *state);

// Sensors
u32 system_get_sensor_count(const SystemState *state);
const SensorReading* system_get_sensors(const SystemState *state, u32 *count);
const SensorReading* system_get_temperatures(const SystemState *state, u32 *count);
const SensorReading* system_get_fans(const SystemState *state, u32 *count);
const SensorReading* system_get_voltages(const SystemState *state, u32 *count);

// Battery information
int system_has_battery(const SystemState *state);
const BatteryStatus* system_get_battery(const SystemState *state);

// Security information
int system_selinux_enabled(const SystemState *state);
const char* system_selinux_mode(const SystemState *state);
int system_apparmor_enabled(const SystemState *state);
int system_firewall_enabled(const SystemState *state);
const char* system_firewall_type(const SystemState *state);

// Kernel parameters
u32 system_get_kernel_param_count(const SystemState *state);
int system_get_kernel_param(const SystemState *state, const char *name, char *value, u32 size);
int system_set_kernel_param(const char *name, const char *value);

// Performance counters
u64 system_get_context_switches(const SystemState *state);
u64 system_get_interrupts(const SystemState *state);
u64 system_get_soft_interrupts(const SystemState *state);
u64 system_get_forks(const SystemState *state);
u64 system_get_entropy_available(const SystemState *state);

// Systemd information
int system_systemd_enabled(const SystemState *state);
const char* system_systemd_version(const SystemState *state);
u64 system_systemd_uptime(const SystemState *state);

// Locale information
const char* system_get_language(const SystemState *state);
const char* system_get_charset(const SystemState *state);
const char* system_get_keyboard_layout(const SystemState *state);

// Filesystem information
u32 system_get_filesystem_count(const SystemState *state);
const char* system_get_filesystem_type(const SystemState *state, u8 index);
u64 system_get_filesystem_size(const SystemState *state, u8 index);
u64 system_get_filesystem_used(const SystemState *state, u8 index);

// Network hardware
u32 system_get_network_controller_count(const SystemState *state);
const char* system_get_network_controller(const SystemState *state, u8 index);

// GPU information
u32 system_get_gpu_count(const SystemState *state);
const char* system_get_gpu_vendor(const SystemState *state, u8 index);
const char* system_get_gpu_model(const SystemState *state, u8 index);
const char* system_get_gpu_driver(const SystemState *state, u8 index);
u64 system_get_gpu_memory(const SystemState *state, u8 index);

// Benchmarking
typedef struct PACKED {
    u32 cpu_score;
    u32 memory_score;
    u32 disk_score;
    u32 network_score;
    u32 overall_score;
    time_t benchmark_time;
} BenchmarkScores;

BenchmarkScores system_run_benchmark(SystemState *state);

// Health prediction
typedef struct PACKED {
    u32 predicted_uptime_days;
    u32 predicted_failures;
    u8 maintenance_needed : 1;
    u8 security_updates : 1;
    u8 performance_issues : 1;
    u8 _reserved : 5;
    char recommendations[1024];
} SystemHealthPrediction;

SystemHealthPrediction system_predict_health(const SystemState *state);

// Compliance checking
typedef struct PACKED {
    u8 security_score;      // 0-100
    u8 performance_score;   // 0-100
    u8 compliance_score;    // 0-100
    char violations[1024];
    char recommendations[1024];
} ComplianceReport;

ComplianceReport system_check_compliance(const SystemState *state);

// Event logging
int system_log_event(const char *event, u8 severity);
int system_get_event_log(void (*callback)(const char *event, time_t timestamp, u8 severity));

// Backup/restore
int system_backup_config(const char *backup_path);
int system_restore_config(const char *backup_path);

// Export functions
int system_export_json(const SystemState *state, char *buffer, u32 size);
int system_export_inventory(const SystemState *state, char *buffer, u32 size);

// Utility functions
const char* system_format_uptime(u64 seconds, char *buffer, u32 size);
const char* system_format_bytes(u64 bytes, char *buffer, u32 size);

#endif // SYSTEM_H