#ifndef UTILS_H
#define UTILS_H

#include <stdint.h>
#include <stdio.h>
#include <stdarg.h>
#include <time.h>

// Basic types
typedef uint8_t  u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef int8_t   i8;
typedef int16_t  i16;
typedef int32_t  i32;
typedef int64_t  i64;

// Compiler hints
#if defined(__GNUC__) || defined(__clang__)
    #define HOT        __attribute__((hot))
    #define COLD       __attribute__((cold))
    #define PACKED     __attribute__((packed))
    #define PURE       __attribute__((pure))
    #define CONST      __attribute__((const))
    #define ALWAYS_INLINE __attribute__((always_inline))
    #define NO_INLINE  __attribute__((noinline))
    #define FORMAT_PRINTF(fmt, args) __attribute__((format(printf, fmt, args)))
    #define LIKELY(x)   __builtin_expect(!!(x), 1)
    #define UNLIKELY(x) __builtin_expect(!!(x), 0)
#else
    #define HOT
    #define COLD
    #define PACKED
    #define PURE
    #define CONST
    #define ALWAYS_INLINE
    #define NO_INLINE
    #define FORMAT_PRINTF(fmt, args)
    #define LIKELY(x) (x)
    #define UNLIKELY(x) (x)
#endif

// ANSI color codes
#define COLOR_RESET   "\033[0m"
#define COLOR_BLACK   "\033[30m"
#define COLOR_RED     "\033[31m"
#define COLOR_GREEN   "\033[32m"
#define COLOR_YELLOW  "\033[33m"
#define COLOR_BLUE    "\033[34m"
#define COLOR_MAGENTA "\033[35m"
#define COLOR_CYAN    "\033[36m"
#define COLOR_WHITE   "\033[37m"
#define COLOR_BRIGHT_BLACK   "\033[90m"
#define COLOR_BRIGHT_RED     "\033[91m"
#define COLOR_BRIGHT_GREEN   "\033[92m"
#define COLOR_BRIGHT_YELLOW  "\033[93m"
#define COLOR_BRIGHT_BLUE    "\033[94m"
#define COLOR_BRIGHT_MAGENTA "\033[95m"
#define COLOR_BRIGHT_CYAN    "\033[96m"
#define COLOR_BRIGHT_WHITE   "\033[97m"

#define COLOR_BOLD    "\033[1m"
#define COLOR_DIM     "\033[2m"
#define COLOR_ITALIC  "\033[3m"
#define COLOR_UNDERLINE "\033[4m"
#define COLOR_BLINK   "\033[5m"
#define COLOR_REVERSE "\033[7m"
#define COLOR_HIDDEN  "\033[8m"

// Box drawing characters
#define BOX_HORIZONTAL "─"
#define BOX_VERTICAL   "│"
#define BOX_TOP_LEFT   "┌"
#define BOX_TOP_RIGHT  "┐"
#define BOX_BOTTOM_LEFT "└"
#define BOX_BOTTOM_RIGHT "┘"
#define BOX_T_LEFT     "├"
#define BOX_T_RIGHT    "┤"
#define BOX_T_TOP      "┬"
#define BOX_T_BOTTOM   "┴"
#define BOX_CROSS      "┼"

// Progress bar characters
#define BAR_FULL      "█"
#define BAR_SEVEN     "▇"
#define BAR_SIX       "▆"
#define BAR_FIVE      "▅"
#define BAR_FOUR      "▄"
#define BAR_THREE     "▃"
#define BAR_TWO       "▂"
#define BAR_ONE       "▁"
#define BAR_EMPTY     " "

// Sparkline characters
#define SPARK_MIN     "▁"
#define SPARK_25      "▂"
#define SPARK_50      "▃"
#define SPARK_75      "▄"
#define SPARK_MAX     "█"

// Terminal control
#define CLEAR_SCREEN  "\033[2J"
#define CLEAR_LINE    "\033[2K"
#define CURSOR_HOME   "\033[H"
#define CURSOR_SAVE   "\033[s"
#define CURSOR_RESTORE "\033[u"

// String utilities
char* trim_whitespace(char *str) HOT;
char* trim_newline(char *str) HOT;
char* str_replace(char *orig, const char *rep, const char *with);
int starts_with(const char *str, const char *prefix) PURE;
int ends_with(const char *str, const char *suffix) PURE;
int contains(const char *str, const char *substr) PURE;
char* str_to_lower(char *str);
char* str_to_upper(char *str);
int str_count_char(const char *str, char c) PURE;
char** str_split(const char *str, const char *delim, int *count);
void str_free_split(char **parts, int count);
char* str_join(const char **parts, int count, const char *delim);

// File utilities
char* read_file(const char *path, char *buffer, size_t size);
char* read_file_lines(const char *path, char ***lines, int *line_count);
int write_file(const char *path, const char *content);
int append_file(const char *path, const char *content);
int file_exists(const char *path) PURE;
int is_directory(const char *path);
int is_file(const char *path);
int is_symlink(const char *path);
long file_size(const char *path);
time_t file_mtime(const char *path);
int file_copy(const char *src, const char *dst);
int file_move(const char *src, const char *dst);
int file_delete(const char *path);
int directory_create(const char *path);
int directory_list(const char *path, char ***entries, int *count);
void directory_free_list(char **entries, int count);

// Formatting utilities
void format_bytes(u64 bytes, char *buffer, size_t size);
void format_bytes_si(u64 bytes, char *buffer, size_t size);
void format_percentage(float value, char *buffer, size_t size);
void format_time_duration(u64 seconds, char *buffer, size_t size);
void format_rate(float bytes_per_sec, char *buffer, size_t size);
void format_temperature(float celsius, char *buffer, size_t size);
void format_frequency(float hz, char *buffer, size_t size);
void format_voltage(float volts, char *buffer, size_t size);
void format_power(float watts, char *buffer, size_t size);
void format_date(time_t timestamp, char *buffer, size_t size, const char *format);
void format_number_with_commas(u64 number, char *buffer, size_t size);

// Color utilities
void set_color(FILE *stream, const char *color);
void reset_color(FILE *stream);
void print_colored(FILE *stream, const char *color, const char *format, ...) FORMAT_PRINTF(3, 4);
void vprint_colored(FILE *stream, const char *color, const char *format, va_list args);
const char* get_color_for_percent(float percent);
const char* get_color_for_temperature(float celsius);
const char* get_color_for_value(float value, float min, float max);
int color_supported(void) PURE;

// Terminal/UI utilities
void clear_screen(void);
void clear_line(void);
void move_cursor(int row, int col);
void save_cursor(void);
void restore_cursor(void);
void hide_cursor(void);
void show_cursor(void);
void alternate_screen(void);
void normal_screen(void);
int get_terminal_size(int *rows, int *cols);
int get_cursor_position(int *row, int *col);
void enable_raw_mode(void);
void disable_raw_mode(void);
int kbhit(void);
int getch(void);

// Drawing utilities
void draw_progress_bar(float percent, int width, char *buffer, int show_percent);
void draw_graph(float *history, int size, int width, int height, char *buffer, int show_axis);
void draw_sparkline(float *values, int count, char *buffer);
void draw_histogram(float *values, int count, int height, char *buffer);
void draw_box(int x, int y, int width, int height, const char *title, int style);
const char* get_bar_char(float percent);
const char* get_spark_char(float value, float min, float max);

// Math utilities
float calculate_rate(u64 current, u64 previous, float time_diff) PURE;
float moving_average(float *history, int size, int *index, float new_value);
float exponential_moving_average(float current, float previous, float alpha) PURE;
float weighted_moving_average(float *values, int count, float *weights) PURE;
float standard_deviation(float *values, int count) PURE;
float correlation(float *x, float *y, int count) PURE;
float clamp(float value, float min, float max) PURE CONST;
int clamp_int(int value, int min, int max) PURE CONST;
float lerp(float a, float b, float t) PURE CONST;
float map_range(float value, float from_min, float from_max, float to_min, float to_max) PURE CONST;
float normalize(float value, float min, float max) PURE CONST;

// Time utilities
u64 get_timestamp_ms(void) HOT;
u64 get_timestamp_us(void) HOT;
void sleep_ms(u64 milliseconds);
void sleep_us(u64 microseconds);
int time_diff_ms(struct timeval *start, struct timeval *end) PURE;
int time_diff_us(struct timeval *start, struct timeval *end) PURE;
char* timestamp_to_string(u64 timestamp, const char *format, char *buffer, size_t size);
u64 string_to_timestamp(const char *str, const char *format);
int is_leap_year(int year) PURE CONST;
int days_in_month(int month, int year) PURE CONST;

// Memory utilities
void* xmalloc(size_t size);
void* xcalloc(size_t count, size_t size);
void* xrealloc(void *ptr, size_t size);
void xfree(void *ptr);
void zero_memory(void *ptr, size_t size);
void copy_memory(void *dst, const void *src, size_t size);
int compare_memory(const void *a, const void *b, size_t size) PURE;
void swap_memory(void *a, void *b, size_t size);

// Data structure utilities
typedef struct {
    float *buffer;
    int capacity;
    int size;
    int head;
    int tail;
} CircularBuffer;

CircularBuffer* cb_create(int capacity);
void cb_destroy(CircularBuffer *cb);
void cb_push(CircularBuffer *cb, float value);
float cb_pop(CircularBuffer *cb);
float cb_peek(CircularBuffer *cb, int offset) PURE;
int cb_is_empty(CircularBuffer *cb) PURE;
int cb_is_full(CircularBuffer *cb) PURE;
void cb_clear(CircularBuffer *cb);

typedef struct {
    int *buffer;
    int capacity;
    int size;
    int head;
    int tail;
} RingBuffer;

RingBuffer* rb_create(int capacity);
void rb_destroy(RingBuffer *rb);
void rb_push(RingBuffer *rb, int value);
int rb_pop(RingBuffer *rb);
int rb_peek(RingBuffer *rb, int offset) PURE;

typedef struct HashEntry {
    char *key;
    void *value;
    struct HashEntry *next;
} HashEntry;

typedef struct {
    HashEntry **entries;
    int capacity;
    int size;
} HashTable;

HashTable* ht_create(int capacity);
void ht_destroy(HashTable *ht);
void ht_set(HashTable *ht, const char *key, void *value);
void* ht_get(HashTable *ht, const char *key) PURE;
void ht_remove(HashTable *ht, const char *key);
int ht_contains(HashTable *ht, const char *key) PURE;

// Signal handling
typedef void (*SignalHandler)(int);
void setup_signal_handler(int sig, SignalHandler handler);
void setup_signal_handlers(void);
int should_exit(void) PURE;
void set_should_exit(int value);

// Error handling
typedef enum {
    LOG_DEBUG,
    LOG_INFO,
    LOG_WARNING,
    LOG_ERROR,
    LOG_CRITICAL
} LogLevel;

void log_message(LogLevel level, const char *format, ...) FORMAT_PRINTF(2, 3);
void set_log_level(LogLevel level);
void set_log_file(const char *filename);
const char* get_last_error(void) PURE;
void clear_last_error(void);

// Configuration parsing
typedef struct {
    char *key;
    char *value;
} ConfigEntry;

typedef struct {
    ConfigEntry *entries;
    int count;
    int capacity;
} ConfigMap;

ConfigMap* config_parse_file(const char *filename);
void config_destroy(ConfigMap *config);
const char* config_get(ConfigMap *config, const char *key) PURE;
int config_get_int(ConfigMap *config, const char *key, int default_value) PURE;
float config_get_float(ConfigMap *config, const char *key, float default_value) PURE;
int config_get_bool(ConfigMap *config, const char *key, int default_value) PURE;

// Network utilities
int is_valid_ipv4(const char *ip) PURE;
int is_valid_ipv6(const char *ip) PURE;
int is_valid_mac(const char *mac) PURE;
char* ip_to_hostname(const char *ip);
char* hostname_to_ip(const char *hostname);
int port_is_open(const char *host, int port, int timeout_ms);
int get_local_ip(char *buffer, size_t size);
int get_public_ip(char *buffer, size_t size);

// System information utilities
int get_username(char *buffer, size_t size);
int get_home_directory(char *buffer, size_t size);
int get_current_directory(char *buffer, size_t size);
int is_root(void) PURE;
int get_process_limit(void) PURE;
int get_file_limit(void) PURE;
int get_system_locale(char *buffer, size_t size);

// Validation utilities
int is_valid_number(const char *str) PURE;
int is_valid_float(const char *str) PURE;
int is_valid_int(const char *str) PURE;
int is_valid_hex(const char *str) PURE;
int is_valid_octal(const char *str) PURE;
int is_valid_binary(const char *str) PURE;
int is_valid_email(const char *email) PURE;
int is_valid_url(const char *url) PURE;
int is_valid_date(const char *date, const char *format) PURE;

// Pattern matching
int wildcard_match(const char *pattern, const char *string);
int regex_match(const char *pattern, const char *string);
char* regex_extract(const char *pattern, const char *string, int group);

// Sorting utilities
void quick_sort(void *array, int count, size_t element_size,
                int (*compare)(const void *, const void *));
void bubble_sort(void *array, int count, size_t element_size,
                 int (*compare)(const void *, const void *));
void insertion_sort(void *array, int count, size_t element_size,
                    int (*compare)(const void *, const void *));
void merge_sort(void *array, int count, size_t element_size,
                int (*compare)(const void *, const void *));

// Search utilities
void* binary_search(const void *key, const void *array, int count,
                   size_t element_size,
                   int (*compare)(const void *, const void *)) PURE;
void* linear_search(const void *key, const void *array, int count,
                   size_t element_size,
                   int (*compare)(const void *, const void *)) PURE;

// Compression utilities
int compress_data(const void *input, size_t input_size, 
                 void *output, size_t *output_size);
int decompress_data(const void *input, size_t input_size,
                   void *output, size_t *output_size);
int compress_file(const char *input_file, const char *output_file);
int decompress_file(const char *input_file, const char *output_file);

// Cryptography utilities
void hash_md5(const void *data, size_t size, u8 digest[16]);
void hash_sha1(const void *data, size_t size, u8 digest[20]);
void hash_sha256(const void *data, size_t size, u8 digest[32]);
char* hash_to_string(const u8 *digest, size_t size, char *buffer, size_t buffer_size);
int verify_hash(const u8 *digest1, const u8 *digest2, size_t size) PURE;

#endif // UTILS_H