#!/bin/bash
# setup.sh - Create the complete project structure

set -e

# Create main directories
mkdir -p data_export_alerting_system
cd data_export_alerting_system

echo "Creating project structure..."

# Root level files
touch LICENSE README.md CHANGELOG.md CONTRIBUTING.md SECURITY.md
touch .gitignore .gitattributes .editorconfig .clang-format
touch Doxyfile Makefile CMakeLists.txt meson.build conanfile.py
touch pyproject.toml setup.py requirements.txt
touch docker-compose.yml Dockerfile Jenkinsfile

# GitHub workflows
mkdir -p .github/{workflows,}
touch .github/workflows/{ci,cd,release,security}.yml
touch .github/dependabot.yml .github/CODEOWNERS

# VSCode configuration
mkdir -p .vscode
touch .vscode/{settings.json,tasks.json,launch.json,extensions.json}

# Include directories
mkdir -p include/{export,alerts,common}
touch include/export.h
touch include/alerts.h
touch include/features.h

# Export headers
touch include/export/{export_format,export_destination,export_transform,export_schema,export_job,export_connection,export_compression,export_encryption,export_utils}.h

# Alerts headers
touch include/alerts/{alert_rule,alert_action,alert_notification,alert_escalation,alert_silence,alert_monitor,alert_dashboard,alert_utils}.h

# Common headers
touch include/common/{types,errors,config,logging,memory,time,string,buffer,list,hashmap,queue,threadpool,platform}.h

# Source directories
mkdir -p src/{export/{format,destination,compression,encryption,protocol},alerts/{notification,monitor,metrics},common,platform/{linux,windows,posix}}
touch src/{main,export,alerts,features,config,logging,utils,memory}.c

# Export source files
touch src/export/{export_format,export_destination,export_transform,export_schema,export_job,export_connection,export_compression,export_encryption}.c

# Export format implementations
touch src/export/format/{csv,json,xml,yaml,protobuf,avro,parquet,orc,excel,sql,prometheus,influxdb,custom}.c

# Export destination implementations
touch src/export/destination/{file,http,ftp,s3,gcs,azure,kafka,rabbitmq,redis,mysql,postgresql,sqlite,mongodb,elasticsearch,email,custom}.c

# Compression implementations
touch src/export/compression/{gzip,zlib,bzip2,lz4,snappy,zstd,lzma}.c

# Encryption implementations
touch src/export/encryption/{aes,rsa,chacha20,pgp}.c

# Protocol implementations
touch src/export/protocol/{http,ftp,sftp,websocket,mqtt,amqp,grpc,kafka}.c

# Alerts source files
touch src/alerts/{alert_rule,alert_action,alert_notification,alert_escalation,alert_silence,alert_monitor,alert_dashboard,alert_evaluator}.c

# Notification implementations
touch src/alerts/notification/{email,slack,teams,sms,webhook,pagerduty,opsgenie,datadog,grafana,custom}.c

# Monitor implementations
touch src/alerts/monitor/{export_monitor,system_monitor,network_monitor,database_monitor,performance_monitor,data_quality_monitor,custom_monitor}.c

# Metrics implementations
touch src/alerts/metrics/{collector,aggregator,analyzer,reporter}.c

# Common utilities
touch src/common/{list,hashmap,queue,buffer,string,time,threadpool,atomic,mutex,condition,semaphore,event,timer,uuid,base64,json,yaml,xml,ini,csv,logger}.c

# Platform-specific implementations
touch src/platform/linux/{filesystem,network,process,syslog}.c
touch src/platform/windows/{filesystem,network,process,eventlog}.c
touch src/platform/posix/{filesystem,network,process,signals}.c

# Tests directory
mkdir -p tests/{unit,integration,fuzz,benchmark,mocks,fixtures}
touch tests/{test_runner,test_main}.c
touch tests/test_config.h

# Unit tests
touch tests/unit/{test_export,test_alerts,test_features,test_utils,test_config,test_logging,test_memory,test_format_csv,test_format_json,test_destination_file,test_destination_http,test_alert_rule,test_alert_notification,test_compression,test_encryption,test_integration}.c

# Integration tests
touch tests/integration/{test_export_pipeline,test_alert_pipeline,test_end_to_end,test_performance,test_concurrency}.c

# Fuzz tests
touch tests/fuzz/{fuzz_export,fuzz_alerts,fuzz_config,fuzz_parser}.c

# Benchmark tests
touch tests/benchmark/{benchmark_export,benchmark_alerts,benchmark_compression,benchmark_encryption,benchmark_concurrent}.c

# Mock implementations
touch tests/mocks/{mock_network,mock_filesystem,mock_database,mock_api,mock_time}.c

# Test fixtures
touch tests/fixtures/{test_data.csv,test_data.json,test_config.yaml,test_schema.xml,test_alerts.rules}

# Examples directory
mkdir -p examples/{basic,advanced,integration/{docker_example,kubernetes},tutorials}
touch examples/basic/{export_csv,export_json,alert_basic,alert_email}.c
touch examples/basic/README.md
touch examples/advanced/{export_pipeline,alert_pipeline,monitoring_dashboard,custom_destination,custom_notification}.c
touch examples/integration/{webserver,cli_tool,daemon_service}.c
touch examples/integration/docker_example/{Dockerfile,docker-compose.yml,app.c}
touch examples/integration/kubernetes/{deployment,service,configmap}.yaml
touch examples/integration/kubernetes/README.md
touch examples/tutorials/tutorial_{1,2,3,4,5}.md

# Documentation
mkdir -p docs/{api,guides,architecture,development,reference,diagrams/sequence_diagrams}
touch docs/api/{export_api,alerts_api,features_api,common_api,plugin_api}.md
touch docs/guides/{getting_started,installation,configuration,deployment,security,performance,troubleshooting,migration}.md
touch docs/architecture/{overview,export_module,alerts_module,data_flow,design_patterns,scaling}.md
touch docs/development/{contributing,coding_standards,testing,plugins,api_extensions}.md
touch docs/reference/{formats,destinations,protocols,compression,encryption,alert_sources,notification_channels,error_codes}.md
touch docs/diagrams/{architecture,data_flow,class_diagram}.png
touch docs/CHANGELOG.md

# Scripts directory
mkdir -p scripts/{build,test,deployment,development,monitoring,tools}
touch scripts/build/{build.sh,build.bat,cross_compile.sh,package.sh}
touch scripts/test/{run_tests.sh,run_tests.bat,coverage.sh,valgrind.sh,fuzzing.sh}
touch scripts/deployment/{install.sh,uninstall.sh,docker_build.sh,kubernetes_deploy.sh,cloud_deploy.sh}
touch scripts/development/{setup_env.sh,generate_docs.sh,code_format.sh,code_lint.sh,dependency_check.sh}
touch scripts/monitoring/{health_check.sh,metrics_collector.sh,log_analyzer.sh}
touch scripts/tools/{config_generator,schema_validator,alert_simulator,benchmark_runner,data_generator}.py

# Configuration directory
mkdir -p config/{schemas,templates,rules}
touch config/{default,development,production,testing}.yaml
touch config/schemas/{export_schema,alert_schema,config_schema,metrics_schema}.json
touch config/templates/{email_template.html,slack_template.json,webhook_template.json,report_template.md}
touch config/rules/{system_health,export_performance,data_quality,security}.rules

# Data directory
mkdir -p data/{samples/{csv,json,xml,binary},logs,cache/{schemas,templates,temp},backups}
touch data/samples/csv/{sample1,sample2,large_sample}.csv
touch data/samples/json/{sample1,sample2,nested_sample}.json
touch data/samples/xml/{sample1,sample2,complex_sample}.xml
touch data/samples/binary/{sample1,sample2,large_binary}.bin
touch data/logs/{export,alerts,system,audit}.log
touch data/backups/{config_backup.yaml,rules_backup.json}

# Tools directory
mkdir -p tools/{cli,gui/{web,desktop/resources},plugins/{format_plugins,destination_plugins,notification_plugins,monitor_plugins},exporters}
touch tools/cli/{export_cli,alert_cli,monitor_cli,admin_cli}.c
touch tools/gui/web/{index.html,app.js,styles.css,package.json}
touch tools/gui/desktop/{main.cpp,window.ui}
touch tools/plugins/format_plugins/{custom_format.c,custom_format.h,Makefile}
touch tools/plugins/destination_plugins/{custom_destination.c,custom_destination.h,Makefile}
touch tools/plugins/notification_plugins/{custom_notification.c,custom_notification.h,Makefile}
touch tools/plugins/monitor_plugins/{custom_monitor.c,custom_monitor.h,Makefile}
touch tools/exporters/{prometheus_exporter,statsd_exporter,syslog_exporter,custom_exporter}.c

# Third-party directory
mkdir -p third_party/{libraries,tools,licenses}
mkdir -p third_party/libraries/{jansson,sqlite3,libcurl,openssl,zlib,libxml2,yaml,protobuf-c}
mkdir -p third_party/tools/{cmocka,cunit,valgrind,cppcheck}
touch third_party/licenses/LICENSE-{jansson,sqlite3,libcurl,openssl}

# Packaging directory
mkdir -p packaging/{debian,rpm,nsis/resources,docker}
touch packaging/debian/{control,rules,changelog,copyright,install}
touch packaging/rpm/{export_alert.spec,changelog,macros}
touch packaging/nsis/{installer,uninstaller}.nsi
touch packaging/docker/{Dockerfile.alpine,Dockerfile.ubuntu,Dockerfile.centos,docker-compose.yml}

# Docker and Kubernetes configurations
mkdir -p .docker .kubernetes
touch .docker/{entrypoint,healthcheck}.sh
touch .docker/{nginx,supervisor}.conf
touch .kubernetes/{deployment,service,ingress,configmap,secret,hpa,pvc}.yaml

echo "Project structure created successfully!"
echo "Total directories: $(find . -type d | wc -l)"
echo "Total files: $(find . -type f | wc -l)"

# Make setup script executable
chmod +x scripts/build/build.sh
chmod +x scripts/test/run_tests.sh
chmod +x scripts/deployment/install.sh
chmod +x scripts/development/setup_env.sh

echo "Setup complete!"