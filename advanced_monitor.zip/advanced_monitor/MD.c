#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/statvfs.h>
#include <sys/sysinfo.h>
#include <signal.h>
#include <time.h>
#include <errno.h>
#include <ctype.h>
#include <stdarg.h>

#define MAX_CPU 64
#define MAX_PROCESSES 20
#define HISTORY_SIZE 60
#define CONFIG_FILE ".monitor.conf"
#define CPU_HISTORY 60   // last 60 samples (~1 minute)

typedef struct {
    int pid;
    char name[64];

    long cpu_time;        // current utime + stime
    long prev_cpu_time;   // previous sample

    float cpu_percent;    // current %CPU
    float cpu_hist[CPU_HISTORY]; // %CPU over time
    int hist_index;

} Process;

/* ================= 颜色定义 ================= */
#define COLOR_RESET   "\033[0m"
#define COLOR_RED     "\033[31m"
#define COLOR_GREEN   "\033[32m"
#define COLOR_YELLOW  "\033[33m"
#define COLOR_BLUE    "\033[34m"
#define COLOR_MAGENTA "\033[35m"
#define COLOR_CYAN    "\033[36m"
#define COLOR_BOLD    "\033[1m"
#define COLOR_GRAY    "\033[90m"

/* ================= 配置结构体 ================= */
typedef struct {
    int refresh_rate;
    int show_cpu_graph;
    int show_top_processes;
    int show_memory_graph;
    int sort_by_memory;
    int color_enabled;
} Config;

/* ================= 数据结构 ================= */
typedef struct {
    long total;
    long idle;
} CPUStat;

typedef struct {
    int pid;
    char name[256];
    unsigned long vmrss;  // 物理内存使用(KB)
    unsigned long vsize;  // 虚拟内存使用(KB)
    char state;
    float cpu_usage;
} ProcessInfo;

typedef struct {
    float cpu_history[HISTORY_SIZE];
    float mem_history[HISTORY_SIZE];
    int history_index;
} HistoryData;

/* ================= 全局变量 ================= */
volatile sig_atomic_t running = 1;
Config config = {
    .refresh_rate = 1,
    .show_cpu_graph = 1,
    .show_top_processes = 1,
    .show_memory_graph = 1,
    .sort_by_memory = 0,
    .color_enabled = 1
};
HistoryData history = {0};

/* ================= 工具函数 ================= */
void print_color(const char* color, const char* format, ...) {
    va_list args;
    va_start(args, format);
    
    if (config.color_enabled) {
        printf("%s", color);
    }
    
    vprintf(format, args);
    
    if (config.color_enabled) {
        printf("%s", COLOR_RESET);
    }
    
    va_end(args);
}

void draw_bar(int width, float percent, const char* color) {
    int filled = (int)(width * percent / 100.0f);
    
    print_color(color, "[");
    for (int i = 0; i < width; i++) {
        if (i < filled) {
            print_color(color, "█");
        } else {
            printf(" ");
        }
    }
    print_color(color, "] %.1f%%\n", percent);
}

void print_graph(const char* title, float data[], int size, float max_value) {
    const char* bars = "▁▂▃▄▅▆▇█";
    int bar_count = strlen(bars);
    
    printf("%s: ", title);
    for (int i = 0; i < size; i++) {
        float normalized = data[i] / max_value;
        int index = (int)(normalized * (bar_count - 1));
        if (index < 0) index = 0;
        if (index >= bar_count) index = bar_count - 1;
        
        const char* color;
        if (normalized > 0.8) color = COLOR_RED;
        else if (normalized > 0.6) color = COLOR_YELLOW;
        else color = COLOR_GREEN;
        
        print_color(color, "%c", bars[index]);
    }
    printf("\n");
}

void draw_cpu_history(float *hist, int idx) {
    const char *bars = "▁▂▃▄▅▆▇█";

    for (int i = 0; i < CPU_HISTORY; i++) {
        int pos = (idx + i) % CPU_HISTORY;
        int level = hist[pos] / 12.5; // scale 0–100 → 0–7
        if (level > 7) level = 7;
        printf("%s", &bars[level]);
    }
}

void update_process_history(Process *p) {
    p->cpu_hist[p->hist_index] = p->cpu_percent;
    p->hist_index = (p->hist_index + 1) % CPU_HISTORY;

\*
    Maintain a time-series history of %CPU values
        At every refresh interval:

            Compute current %CPU (already implemented)

            Shift history buffer

            Append new %CPU sample

            Render mini graph per process
                
      */

}


// 导出所有进程的CPU历史到CSV文件
void export_cpu_history(Process processes[], int count) {
    FILE* fp = fopen("cpu_history.csv", "w");
    if (!fp) {
        print_color(COLOR_RED, "Failed to open cpu_history.csv for writing\n");
        return;
    }

    // CSV header
    fprintf(fp, "PID,Name");
    for (int t = 0; t < CPU_HISTORY; t++)
        fprintf(fp, ",T-%d", CPU_HISTORY - t - 1);
    fprintf(fp, "\n");

    // Each process
    for (int i = 0; i < count; i++) {
        Process *p = &processes[i];
        fprintf(fp, "%d,%s", p->pid, p->name);
        for (int t = 0; t < CPU_HISTORY; t++) {
            int idx = (p->hist_index + t) % CPU_HISTORY;
            fprintf(fp, ",%.2f", p->cpu_hist[idx]);
        }
        fprintf(fp, "\n");
    }
    fclose(fp);
    print_color(COLOR_GREEN, "CPU history exported to cpu_history.csv\n");
}

// 改进：更准确地计算CPU利用率，支持多核和进程
// 读取/proc/stat并返回每个CPU的总和空闲时间
int get_cpu_times(long *total, long *idle) {
    FILE *fp = fopen("/proc/stat", "r");
    if (!fp) return -1;
    char line[256];
    if (!fgets(line, sizeof(line), fp)) {
        fclose(fp);
        return -1;
    }
    fclose(fp);

    long user, nice, system, idl, iowait, irq, softirq, steal;
    int n = sscanf(line, "cpu  %ld %ld %ld %ld %ld %ld %ld %ld",
                   &user, &nice, &system, &idl, &iowait, &irq, &softirq, &steal);
    if (n < 4) return -1;

    *idle = idl + iowait;
    *total = user + nice + system + idl + iowait + irq + softirq + steal;
    return 0;
}

// 计算CPU利用率（百分比），支持多核
float calc_cpu_usage(long prev_total, long prev_idle, long curr_total, long curr_idle) {
    long total_diff = curr_total - prev_total;
    long idle_diff = curr_idle - prev_idle;
    if (total_diff <= 0) return 0.0f;
    return 100.0f * (total_diff - idle_diff) / total_diff;
}

// 改进：显示每个核心的详细利用率和温度（如可用）
void show_cpu_details() {
    CPUStat prev[MAX_CPU], curr[MAX_CPU];
    int cpu_count = 0;
    read_cpu_stats(prev, &cpu_count);
    sleep(1);
    read_cpu_stats(curr, &cpu_count);

    print_color(COLOR_BOLD COLOR_CYAN, "\nCPU Details:\n");
    for (int i = 0; i < cpu_count; i++) {
        long total_diff = curr[i].total - prev[i].total;
        long idle_diff = curr[i].idle - prev[i].idle;
        float usage = (total_diff > 0) ? 100.0f * (total_diff - idle_diff) / total_diff : 0.0f;
        print_color(COLOR_GREEN, "  Core %d: ", i);
        draw_bar(15, usage, usage > 80 ? COLOR_RED : usage > 60 ? COLOR_YELLOW : COLOR_GREEN);

        // 可选：显示温度（如果/sys/class/thermal/thermal_zone*/temp可用）
        char temp_path[128];
        snprintf(temp_path, sizeof(temp_path), "/sys/class/thermal/thermal_zone%d/temp", i);
        FILE *tf = fopen(temp_path, "r");
        if (tf) {
            int temp_mC;
            if (fscanf(tf, "%d", &temp_mC) == 1) {
                printf("  Temp: %.1f°C", temp_mC / 1000.0);
            }
            fclose(tf);
        }
        printf("\n");
    }
}

// 改进：支持CPU利用率平滑（移动平均）
float smooth_cpu_usage(float *history, int size) {
    float sum = 0.0f;
    for (int i = 0; i < size; i++)
        sum += history[i];
    return sum / size;
}


// 判断进程在最近duration次采样中是否有连续高于threshold的CPU占用
int is_cpu_hog(Process *p, float threshold, int duration) {
    int consecutive = 0;
    for (int i = 0; i < CPU_HISTORY; i++) {
        int idx = (p->hist_index + i) % CPU_HISTORY;
        if (p->cpu_hist[idx] > threshold) {
            consecutive++;
            if (consecutive >= duration)
                return 1;
        } else {
            consecutive = 0;
        }
    }
    return 0;
}


void print_graph_zoom(float data[], int size, int window) {

    const char* bars = "▁▂▃▄▅▆▇█";
    int bar_count = strlen(bars);
    int start = (size - window < 0) ? 0 : size - window;
    for (int i = start; i < size; i++) {
        float normalized = data[i] / 100.0f;
        int index = (int)(normalized * (bar_count - 1));
        if (index < 0) index = 0;
        if (index >= bar_count) index = bar_count - 1;

        const char* color;
        if (normalized > 0.8) color = COLOR_RED;
        else if (normalized > 0.6) color = COLOR_YELLOW;
        else color = COLOR_GREEN;

        print_color(color, "%c", bars[index]);
    }
    printf("\n");

}



/* ================= 配置管理 ================= */
void load_config() {
    FILE* fp = fopen(CONFIG_FILE, "r");
    if (!fp) return;
    
    char line[256];
    while (fgets(line, sizeof(line), fp)) {
        char key[64], value[64];
        if (sscanf(line, "%63[^=]=%63s", key, value) == 2) {
            if (strcmp(key, "refresh_rate") == 0) config.refresh_rate = atoi(value);
            else if (strcmp(key, "show_cpu_graph") == 0) config.show_cpu_graph = atoi(value);
            else if (strcmp(key, "show_top_processes") == 0) config.show_top_processes = atoi(value);
            else if (strcmp(key, "show_memory_graph") == 0) config.show_memory_graph = atoi(value);
            else if (strcmp(key, "sort_by_memory") == 0) config.sort_by_memory = atoi(value);
            else if (strcmp(key, "color_enabled") == 0) config.color_enabled = atoi(value);
        }
    }
    fclose(fp);
}

void save_config() {
    FILE* fp = fopen(CONFIG_FILE, "w");
    if (!fp) {
        perror("Cannot save config");
        return;
    }
    
    fprintf(fp, "refresh_rate=%d\n", config.refresh_rate);
    fprintf(fp, "show_cpu_graph=%d\n", config.show_cpu_graph);
    fprintf(fp, "show_top_processes=%d\n", config.show_top_processes);
    fprintf(fp, "show_memory_graph=%d\n", config.show_memory_graph);
    fprintf(fp, "sort_by_memory=%d\n", config.sort_by_memory);
    fprintf(fp, "color_enabled=%d\n", config.color_enabled);
    
    fclose(fp);
}

/* ================= CPU监控 ================= */
int read_cpu_stats(CPUStat cpu[], int *count) {
    FILE *fp = fopen("/proc/stat", "r");
    if (!fp) {
        print_color(COLOR_RED, "Error opening /proc/stat\n");
        return -1;
    }
    
    char line[256];
    *count = 0;
    
    while (fgets(line, sizeof(line), fp) && *count < MAX_CPU) {
        if (strncmp(line, "cpu", 3) != 0) continue;
        
        long user, nice, system, idle, iowait, irq, softirq, steal, guest, guest_nice;
        int matched = sscanf(line, "%*s %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld",
               &user, &nice, &system, &idle, &iowait, &irq, &softirq, &steal, &guest, &guest_nice);
        
        if (matched >= 4) {
            cpu[*count].idle = idle + iowait;
            cpu[*count].total = user + nice + system + idle + iowait + irq + softirq + steal;
            
            if (matched >= 8) {
                cpu[*count].total += steal;
            }
            if (matched >= 10) {
                cpu[*count].total += guest + guest_nice;
            }
            
            (*count)++;
        }
    }
    fclose(fp);
    return 0;
}

void show_cpu_usage(CPUStat prev[], CPUStat curr[], int cpu_count) {
    static int first_run = 1;
    
    if (first_run) {
        first_run = 0;
        return;
    }
    
    print_color(COLOR_BOLD COLOR_CYAN, "\nCPU Usage:\n");
    
    // 总CPU使用率
    long total_diff = curr[0].total - prev[0].total;
    long idle_diff = curr[0].idle - prev[0].idle;
    
    if (total_diff > 0) {
        float total_usage = 100.0f * (total_diff - idle_diff) / total_diff;
        
        print_color(COLOR_GREEN, "  Total: ");
        draw_bar(20, total_usage, total_usage > 80 ? COLOR_RED : 
                                         total_usage > 60 ? COLOR_YELLOW : COLOR_GREEN);
        
        // 添加到历史记录
        history.cpu_history[history.history_index] = total_usage;
        
        // 显示CPU历史图
        if (config.show_cpu_graph) {
            printf("  ");
            print_graph("History", history.cpu_history, HISTORY_SIZE, 100.0f);
        }
    }
    
    // 各核心使用率
    if (cpu_count > 1) {
        printf("\n");
        for (int i = 1; i < cpu_count; i++) {
            total_diff = curr[i].total - prev[i].total;
            idle_diff = curr[i].idle - prev[i].idle;
            
            if (total_diff > 0) {
                float core_usage = 100.0f * (total_diff - idle_diff) / total_diff;
                printf("  Core %-2d: ", i - 1);
                draw_bar(15, core_usage, core_usage > 80 ? COLOR_RED : 
                                              core_usage > 60 ? COLOR_YELLOW : COLOR_GREEN);
            }
        }
    }
    
    // 显示CPU频率
    FILE* fp = fopen("/proc/cpuinfo", "r");
    if (fp) {
        char line[256];
        int cores = 0;
        float avg_mhz = 0;
        
        while (fgets(line, sizeof(line), fp)) {
            if (strstr(line, "cpu MHz")) {
                float mhz;
                if (sscanf(line, "%*[^:]: %f", &mhz) == 1) {
                    avg_mhz += mhz;
                    cores++;
                }
            }
        }
        fclose(fp);
        
        if (cores > 0) {
            avg_mhz /= cores;
            print_color(COLOR_GRAY, "  Frequency: %.1f MHz (avg)\n", avg_mhz);
        }
    }
}

/* ================= 内存监控 ================= */
void show_memory() {
    FILE *fp = fopen("/proc/meminfo", "r");
    if (!fp) {
        print_color(COLOR_RED, "Error opening /proc/meminfo\n");
        return;
    }
    
    char key[64];
    long total = 0, free = 0, available = 0, buffers = 0, cached = 0;
    long value;
    
    while (fscanf(fp, "%63s %ld kB", key, &value) == 2) {
        if (strcmp(key, "MemTotal:") == 0) total = value;
        else if (strcmp(key, "MemFree:") == 0) free = value;
        else if (strcmp(key, "MemAvailable:") == 0) available = value;
        else if (strcmp(key, "Buffers:") == 0) buffers = value;
        else if (strcmp(key, "Cached:") == 0) cached = value;
        
        // 跳过行尾
        while (fgetc(fp) != '\n' && !feof(fp));
    }
    fclose(fp);
    
    if (total > 0) {
        float used_percent = 100.0f * (total - available) / total;
        float used_mb = (total - available) / 1024.0f;
        float total_mb = total / 1024.0f;
        
        print_color(COLOR_BOLD COLOR_CYAN, "\nMemory:\n");
        print_color(COLOR_GREEN, "  Used: ");
        
        draw_bar(20, used_percent, used_percent > 80 ? COLOR_RED : 
                                            used_percent > 60 ? COLOR_YELLOW : COLOR_GREEN);
        
        printf("  Details: %.1f/%.1f GB (%.1f%%)\n", 
               used_mb / 1024.0f, total_mb / 1024.0f, used_percent);
        
        if (buffers > 0 || cached > 0) {
            printf("  Buffers: %.1f MB | Cached: %.1f MB | Free: %.1f MB\n",
                   buffers / 1024.0f, cached / 1024.0f, free / 1024.0f);
        }
        
        // 添加到历史记录
        history.mem_history[history.history_index] = used_percent;
        
        // 显示内存历史图
        if (config.show_memory_graph) {
            printf("  ");
            print_graph("History", history.mem_history, HISTORY_SIZE, 100.0f);
        }
    }
    
    // 显示交换空间
    fp = fopen("/proc/meminfo", "r");
    if (fp) {
        long swap_total = 0, swap_free = 0;
        
        while (fscanf(fp, "%63s %ld kB", key, &value) == 2) {
            if (strcmp(key, "SwapTotal:") == 0) swap_total = value;
            else if (strcmp(key, "SwapFree:") == 0) swap_free = value;
            while (fgetc(fp) != '\n' && !feof(fp));
        }
        fclose(fp);
        
        if (swap_total > 0) {
            float swap_used = swap_total - swap_free;
            float swap_percent = 100.0f * swap_used / swap_total;
            printf("  Swap: %.1f/%.1f GB (%.1f%%)\n",
                   swap_used / 1048576.0f, swap_total / 1048576.0f, swap_percent);
        }
    }
}

/* ================= 磁盘监控 ================= */
void show_disk() {
    struct statvfs fs;
    if (statvfs("/", &fs) != 0) {
        perror("statvfs");
        return;
    }
    
    unsigned long total = fs.f_blocks * fs.f_frsize;
    unsigned long free = fs.f_bfree * fs.f_frsize;
    unsigned long avail = fs.f_bavail * fs.f_frsize;
    
    float used_percent = 100.0f * (total - free) / total;
    float used_gb = (total - free) / 1e9;
    float total_gb = total / 1e9;
    
    print_color(COLOR_BOLD COLOR_CYAN, "\nDisk (/):\n");
    print_color(COLOR_GREEN, "  Used: ");
    
    draw_bar(20, used_percent, used_percent > 90 ? COLOR_RED : 
                                        used_percent > 80 ? COLOR_YELLOW : COLOR_GREEN);
    
    printf("  Space: %.1f/%.1f GB (%.1f%%)\n", used_gb, total_gb, used_percent);
    printf("  Available: %.1f GB | Inodes: %lu/%lu\n",
           avail / 1e9, fs.f_files - fs.f_ffree, fs.f_files);
}

/* ================= 网络监控 ================= */
void show_network() {
    static unsigned long long prev_rx = 0, prev_tx = 0;
    static time_t prev_time = 0;
    
    FILE *fp = fopen("/proc/net/dev", "r");
    if (!fp) {
        print_color(COLOR_RED, "Error opening /proc/net/dev\n");
        return;
    }
    
    char line[256];
    unsigned long long total_rx = 0, total_tx = 0;
    
    // 跳过前两行
    fgets(line, sizeof(line), fp);
    fgets(line, sizeof(line), fp);
    
    while (fgets(line, sizeof(line), fp)) {
        char iface[32];
        unsigned long long r, t;
        
        // 解析网络接口统计
        if (sscanf(line, "%31[^:]: %llu %*u %*u %*u %*u %*u %*u %*u %llu",
                   iface, &r, &t) == 3) {
            // 忽略lo回环接口
            if (strcmp(iface, "lo") != 0) {
                total_rx += r;
                total_tx += t;
            }
        }
    }
    fclose(fp);
    
    time_t now = time(NULL);
    double time_diff = difftime(now, prev_time);
    
    print_color(COLOR_BOLD COLOR_CYAN, "\nNetwork:\n");
    
    if (prev_time > 0 && time_diff > 0) {
        double rx_rate = (total_rx - prev_rx) / time_diff;
        double tx_rate = (total_tx - prev_tx) / time_diff;
        
        const char* rx_unit = "B/s";
        const char* tx_unit = "B/s";
        double rx_display = rx_rate;
        double tx_display = tx_rate;
        
        // 自动选择合适单位
        if (rx_rate > 1024*1024) {
            rx_display = rx_rate / (1024*1024);
            rx_unit = "MB/s";
        } else if (rx_rate > 1024) {
            rx_display = rx_rate / 1024;
            rx_unit = "KB/s";
        }
        
        if (tx_rate > 1024*1024) {
            tx_display = tx_rate / (1024*1024);
            tx_unit = "MB/s";
        } else if (tx_rate > 1024) {
            tx_display = tx_rate / 1024;
            tx_unit = "KB/s";
        }
        
        print_color(COLOR_GREEN, "  RX: ");
        printf("%.1f %s | ", rx_display, rx_unit);
        print_color(COLOR_GREEN, "TX: ");
        printf("%.1f %s\n", tx_display, tx_unit);
        
        printf("  Total: RX %.1f MB | TX %.1f MB\n",
               total_rx / (1024.0*1024.0), total_tx / (1024.0*1024.0));
    } else {
        printf("  Initializing...\n");
    }
    
    prev_rx = total_rx;
    prev_tx = total_tx;
    prev_time = now;
}

/* ================= 进程管理 ================= */
int get_process_info(pid_t pid, ProcessInfo* proc) {
    char path[64];
    char line[256];
    FILE* fp;
    
    // 获取进程名
    snprintf(path, sizeof(path), "/proc/%d/comm", pid);
    fp = fopen(path, "r");
    if (!fp) return 0;
    
    if (fgets(proc->name, sizeof(proc->name), fp)) {
        proc->name[strcspn(proc->name, "\n")] = 0;
    }
    fclose(fp);
    
    // 获取进程状态和内存信息
    snprintf(path, sizeof(path), "/proc/%d/stat", pid);
    fp = fopen(path, "r");
    if (!fp) return 0;
    
    if (fgets(line, sizeof(line), fp)) {
        unsigned long utime, stime, vsize, rss;
        char state;
        
        // 解析/proc/[pid]/stat
        sscanf(line, "%*d %*s %c %*d %*d %*d %*d %*d %*u %*u %*u %*u %*u %lu %lu %*d %*d %*d %*d %*d %*d %*u %lu %*d",
               &state, &utime, &stime, &vsize);
        
        // 获取RSS
        sscanf(line, "%*d %*s %*c %*d %*d %*d %*d %*d %*u %*u %*u %*u %*u %*u %*u %*d %*d %*d %*d %*d %*d %*u %*u %lu",
               &rss);
        
        proc->pid = pid;
        proc->state = state;
        proc->vsize = vsize;
        proc->vmrss = rss * sysconf(_SC_PAGESIZE) / 1024; // 转换为KB
    }
    fclose(fp);
    
    return 1;
}

int compare_process_memory(const void* a, const void* b) {
    const ProcessInfo* pa = (const ProcessInfo*)a;
    const ProcessInfo* pb = (const ProcessInfo*)b;
    if (pb->vmrss > pa->vmrss)
        return 1;
    else if (pb->vmrss < pa->vmrss)
        return -1;
    else
        return 0;
}

int compare_process_cpu(const void* a, const void* b) {
    const ProcessInfo* pa = (const ProcessInfo*)a;
    const ProcessInfo* pb = (const ProcessInfo*)b;
    if (pb->cpu_usage > pa->cpu_usage)
        return 1;
    else if (pb->cpu_usage < pa->cpu_usage)
        return -1;
    else
        return 0;
}

void show_processes() {
    if (!config.show_top_processes) return;
    
    DIR* dir = opendir("/proc");
    if (!dir) {
        print_color(COLOR_RED, "Error opening /proc\n");
        return;
    }
    
    ProcessInfo processes[MAX_PROCESSES];
    int count = 0;
    struct dirent* entry;
    
    // 收集进程信息
    while ((entry = readdir(dir)) && count < MAX_PROCESSES) {
        if (entry->d_type == DT_DIR && isdigit(entry->d_name[0])) {
            pid_t pid = atoi(entry->d_name);
            if (get_process_info(pid, &processes[count])) {
                count++;
            }
        }
    }
    closedir(dir);
    
    // 排序
    if (config.sort_by_memory) {
        qsort(processes, count, sizeof(ProcessInfo), compare_process_memory);
    } else {
        qsort(processes, count, sizeof(ProcessInfo), compare_process_cpu);
    }
    
    // 显示
    print_color(COLOR_BOLD COLOR_CYAN, "\nTop Processes");
    if (config.sort_by_memory) {
        print_color(COLOR_YELLOW, " (by memory):\n");
    } else {
        print_color(COLOR_YELLOW, " (by CPU):\n");
    }
    
    print_color(COLOR_BOLD, "  %-8s %-6s %-6s %-10s %s\n", 
                "PID", "STATE", "MEM%", "MEM(MB)", "NAME");
    
    float total_mem = 0;
    FILE* fp = fopen("/proc/meminfo", "r");
    if (fp) {
        char key[64];
        long value;
        while (fscanf(fp, "%63s %ld kB", key, &value) == 2) {
            if (strcmp(key, "MemTotal:") == 0) {
                total_mem = value;
                break;
            }
        }
        fclose(fp);
    }
    
    for (int i = 0; i < (count < 10 ? count : 10); i++) {
        ProcessInfo* p = &processes[i];
        float mem_percent = total_mem > 0 ? (p->vmrss / total_mem) * 100.0f : 0;
        float mem_mb = p->vmrss / 1024.0f;
        
        const char* color = COLOR_RESET;
        if (mem_percent > 10) color = COLOR_RED;
        else if (mem_percent > 5) color = COLOR_YELLOW;
        else color = COLOR_GREEN;
        
        print_color(color, "  %-8d %-6c %-6.1f %-10.1f %s\n",
                    p->pid, p->state, mem_percent, mem_mb, p->name);
    }
}

/* ================= 系统信息 ================= */
void show_system_info() {
    struct sysinfo info;
    if (sysinfo(&info) == 0) {
        print_color(COLOR_BOLD COLOR_CYAN, "\nSystem Info:\n");

        // 运行时间
        long uptime = info.uptime;
        int days = uptime / 86400;
        int hours = (uptime % 86400) / 3600;
        int minutes = (uptime % 3600) / 60;
        int seconds = uptime % 60;

        printf("  Uptime: %dd %02dh %02dm %02ds\n", days, hours, minutes, seconds);

        // 主机名
        char hostname[128] = {0};
        if (gethostname(hostname, sizeof(hostname)) == 0) {
            printf("  Hostname: %s\n", hostname);
        }

        // 内核版本
        struct utsname uts;
        if (uname(&uts) == 0) {
            printf("  Kernel: %s %s\n", uts.sysname, uts.release);
            printf("  Arch: %s\n", uts.machine);
        }

        // 用户数
        FILE *utmp = fopen("/var/run/utmp", "rb");
        int user_count = 0;
        if (utmp) {
            struct {
                short ut_type;
                pid_t ut_pid;
                char ut_line[32];
                char ut_id[4];
                char ut_user[32];
                char ut_host[256];
                struct {
                    short e_termination;
                    short e_exit;
                } ut_exit;
                long ut_session;
                struct timeval ut_tv;
                int32_t ut_addr_v6[4];
                char __unused[20];
            } ut;
            while (fread(&ut, sizeof(ut), 1, utmp) == 1) {
                if (ut.ut_type == 7 /* USER_PROCESS */) user_count++;
            }
            fclose(utmp);
        }
        if (user_count > 0)
            printf("  Users: %d\n", user_count);

        // 进程数
        printf("  Processes: %d\n", info.procs);

        // 平均负载
        printf("  Load Average: %.2f, %.2f, %.2f\n",
               info.loads[0] / 65536.0,
               info.loads[1] / 65536.0,
               info.loads[2] / 65536.0);

        // 当前时间
        time_t now = time(NULL);
        struct tm *tm_info = localtime(&now);
        char time_str[64];
        strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", tm_info);
        printf("  Local Time: %s\n", time_str);
    }
}

/* ================= 信号处理 ================= */
void signal_handler(int signum) {
    running = 0;
    // Restore terminal settings before exit
    system("stty echo icanon");
    printf("\n");
    print_color(COLOR_YELLOW, "Shutting down monitor (signal %d)...\n", signum);
    // Save config on exit
    save_config();
    // Exit gracefully
    exit(0);
}

/* ================= 帮助信息 ================= */
void show_help() {
    printf("\n");
    print_color(COLOR_BOLD COLOR_CYAN, "Advanced System Monitor\n");
    printf("\n");
    print_color(COLOR_BOLD, "Controls:\n");
    printf("  q          - Quit\n");
    printf("  h          - Show this help\n");
    printf("  s          - Toggle sort order (CPU/Memory)\n");
    printf("  c          - Toggle CPU graph\n");
    printf("  m          - Toggle memory graph\n");
    printf("  +/-        - Increase/Decrease refresh rate\n");
    printf("  p          - Pause/Resume\n");
    printf("\n");
    print_color(COLOR_BOLD, "Configuration saved to: %s\n", CONFIG_FILE);
    printf("\nPress any key to continue...\n");
    getchar();
}

/* ================= 键盘输入处理 ================= */
void handle_input() {
    struct timeval tv = {0, 0};
    fd_set fds;
    FD_ZERO(&fds);
    FD_SET(STDIN_FILENO, &fds);
    
    // 非阻塞检查输入
    if (select(STDIN_FILENO + 1, &fds, NULL, NULL, &tv) > 0) {
        char ch = getchar();
        switch (ch) {
            case 'q':
            case 'Q':
                running = 0;
                break;
            case 'h':
            case 'H':
                show_help();
                break;
            case 's':
            case 'S':
                config.sort_by_memory = !config.sort_by_memory;
                break;
            case 'c':
            case 'C':
                config.show_cpu_graph = !config.show_cpu_graph;
                break;
            case 'm':
            case 'M':
                config.show_memory_graph = !config.show_memory_graph;
                break;
            case '+':
                if (config.refresh_rate > 0.1) config.refresh_rate--;
                break;
            case '-':
                config.refresh_rate++;
                break;
            case 'p':
            case 'P':
                printf("Paused. Press any key to continue...\n");
                getchar();
                break;
        }
    }
}

/* ================= 主函数 ================= */
int main() {
    // 设置信号处理
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);
    
    // 加载配置
    load_config();
    
    // 设置终端为无缓冲模式
    system("stty -echo -icanon");
    
    // 清屏并显示标题
    system("clear");
    print_color(COLOR_BOLD COLOR_CYAN, 
                "╔══════════════════════════════════════════════════════════╗\n");
    print_color(COLOR_BOLD COLOR_CYAN,
                "║               ADVANCED SYSTEM MONITOR                    ║\n");
    print_color(COLOR_BOLD COLOR_CYAN,
                "╚══════════════════════════════════════════════════════════╝\n");
    
    printf("\n");
    print_color(COLOR_GRAY, "Press 'h' for help, 'q' to quit\n");
    printf("\n");
    
    // 初始化历史记录
    for (int i = 0; i < HISTORY_SIZE; i++) {
        history.cpu_history[i] = 0;
        history.mem_history[i] = 0;
    }
    
    CPUStat prev_cpu[MAX_CPU];
    CPUStat curr_cpu[MAX_CPU];
    int cpu_count = 0;
    
    // 初始读取
    read_cpu_stats(prev_cpu, &cpu_count);
    
    time_t last_save = time(NULL);
    
    while (running) {
        // 更新历史索引
        history.history_index = (history.history_index + 1) % HISTORY_SIZE;
        
        // 读取CPU状态
        read_cpu_stats(curr_cpu, &cpu_count);
        
        // 清屏并显示信息
        printf("\033[2J\033[H");  // 更高效的清屏方式
        
        // 显示时间
        time_t now = time(NULL);
        struct tm* tm_info = localtime(&now);
        char time_str[64];
        strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", tm_info);
        print_color(COLOR_GRAY, "Last update: %s | Refresh: %ds | Sort: %s\n", 
                    time_str, config.refresh_rate,
                    config.sort_by_memory ? "Memory" : "CPU");
        
        // 显示各项信息
        show_cpu_usage(prev_cpu, curr_cpu, cpu_count);
        show_memory();
        show_disk();
        show_network();
        show_system_info();
        show_processes();
        
        // 显示底部状态栏
        printf("\n");
        print_color(COLOR_GRAY, "[q]Quit [h]Help [s]Sort [c]CPU-graph [m]Mem-graph [+/-]Speed\n");
        
        // 更新前一个状态
        memcpy(prev_cpu, curr_cpu, sizeof(CPUStat) * cpu_count);
        
        // 处理输入
        handle_input();
        
        // 定期保存配置
        if (difftime(time(NULL), last_save) > 30) {
            save_config();
            last_save = time(NULL);
        }
        
        // 延时
        sleep(config.refresh_rate);
    }
    
    // 恢复终端设置
    system("stty echo icanon");
    
    // 保存配置
    save_config();
    
    printf("\n");
    print_color(COLOR_GREEN, "Monitor stopped. Configuration saved.\n");
    
    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/sysinfo.h>
#include <signal.h>
#include <ctype.h>
#include <math.h>
#include <time.h>

#define MAX_PROCESSES 50
#define TOP_PROCESSES 10
#define HISTORY_SIZE 60

volatile sig_atomic_t running = 1;

typedef struct {
    long total;
    long idle;
} CPUStat;

typedef struct {
    int pid;
    char name[64];
    unsigned long vmrss;  // KB
    unsigned long utime;
    unsigned long stime;
    float cpu_percent;       // total CPU %
    float cpu_history[HISTORY_SIZE];
    int anomaly;
} Process;

Process processes[MAX_PROCESSES];
int process_count = 0;

CPUStat prev_cpu, curr_cpu;

int read_total_cpu(CPUStat *cpu) {
    FILE *fp = fopen("/proc/stat", "r");
    if (!fp) return -1;
    char buf[256];
    long user,nice,system,idle,iowait,irq,softirq;
    fgets(buf,sizeof(buf),fp);
    sscanf(buf,"cpu %ld %ld %ld %ld %ld %ld %ld",&user,&nice,&system,&idle,&iowait,&irq,&softirq);
    fclose(fp);
    cpu->idle = idle + iowait;
    cpu->total = user+nice+system+idle+iowait+irq+softirq;
    return 0;
}

int get_process_info(int pid, Process *p) {
    char path[64]; FILE *fp;
    snprintf(path,sizeof(path),"/proc/%d/stat",pid);
    fp=fopen(path,"r"); if(!fp) return 0;
    char comm[64], state; unsigned long utime, stime;
    fscanf(fp,"%*d %63s %c %*d %*d %*d %*d %*d %*u %*u %*u %*u %*u %lu %lu",&comm,&state,&utime,&stime);
    fclose(fp);
    snprintf(path,sizeof(path),"/proc/%d/statm",pid);
    fp=fopen(path,"r"); if(!fp) return 0;
    unsigned long size,rss;
    fscanf(fp,"%lu %lu",&size,&rss); fclose(fp);
    p->pid = pid;
    strcpy(p->name,comm);
    p->utime = utime;
    p->stime = stime;
    p->vmrss = rss * sysconf(_SC_PAGESIZE)/1024;
    return 1;
}

void enumerate_processes() {
    process_count = 0;
    DIR *dir = opendir("/proc"); struct dirent *entry;
    while ((entry = readdir(dir)) && process_count < MAX_PROCESSES) {
        if(entry->d_type==DT_DIR && isdigit(entry->d_name[0])) {
            int pid = atoi(entry->d_name);
            if(get_process_info(pid,&processes[process_count])) process_count++;
        }
    }
    closedir(dir);
}

void update_cpu_percent() {
    long total_diff = curr_cpu.total - prev_cpu.total;
    long idle_diff = curr_cpu.idle - prev_cpu.idle;
    for(int i=0;i<process_count;i++){
        Process *p=&processes[i];
        if(total_diff>0)
            p->cpu_percent = 100.0f * (p->utime + p->stime) / total_diff;
        else p->cpu_percent=0;

        // update history
        for(int t=HISTORY_SIZE-1;t>0;t--) p->cpu_history[t]=p->cpu_history[t-1];
        p->cpu_history[0] = p->cpu_percent;

        // anomaly detection
        float sum=0, sq=0;
        for(int t=0;t<HISTORY_SIZE;t++){ sum+=p->cpu_history[t]; sq+=p->cpu_history[t]*p->cpu_history[t];}
        float mean=sum/HISTORY_SIZE; float sd=sqrt(sq/HISTORY_SIZE - mean*mean);
        p->anomaly = (p->cpu_percent > mean + 2*sd);
    }
}

// simple bubble sort for top CPU%
void sort_processes_by_cpu() {
    for(int i=0;i<process_count-1;i++){
        for(int j=0;j<process_count-i-1;j++){
            if(processes[j].cpu_percent < processes[j+1].cpu_percent){
                Process tmp = processes[j];
                processes[j] = processes[j+1];
                processes[j+1] = tmp;
            }
        }
    }
}

void export_csv() {
    FILE *fp=fopen("cpu_history.csv","w");
    if(!fp) return;
    fprintf(fp,"PID,Name"); for(int t=0;t<HISTORY_SIZE;t++) fprintf(fp,",T-%d",HISTORY_SIZE-t); fprintf(fp,"\n");
    for(int i=0;i<process_count;i++){
        Process *p=&processes[i];
        fprintf(fp,"%d,%s",p->pid,p->name);
        for(int t=0;t<HISTORY_SIZE;t++) fprintf(fp,",%.2f",p->cpu_history[t]);
        fprintf(fp,"\n");
    }
    fclose(fp);
    printf("CSV exported.\n");
}

void signal_handler(int s){ running=0; }

int main(){
    signal(SIGINT,signal_handler);
    signal(SIGTERM,signal_handler);
    read_total_cpu(&prev_cpu);

    while(running){
        enumerate_processes();
        read_total_cpu(&curr_cpu);
        update_cpu_percent();
        sort_processes_by_cpu();

        printf("Time: %ld\nPID\tName\tRSS(KB)\tCPU(%%)\tAnomaly\n",time(NULL));
        int top = process_count < TOP_PROCESSES ? process_count : TOP_PROCESSES;
        for(int i=0;i<top;i++){
            Process *p=&processes[i];
            printf("%d\t%s\t%lu\t%.2f\t%s\n",p->pid,p->name,p->vmrss,p->cpu_percent,p->anomaly?"⚠":"-");
        }

        prev_cpu = curr_cpu;
        sleep(1);
    }

    export_csv();
    printf("Monitor stopped.\n");
    return 0;
}
void print_graph(const char* title, float* data, int size, float max_value) {
    const char* bars = "▁▂▃▄▅▆▇█";
    int bar_count = strlen(bars);
    
    printf("%s: ", title);
    for (int i = 0; i < size; i++) {
        float normalized = data[i] / max_value;
        int index = (int)(normalized * (bar_count - 1));
        if (index < 0) index = 0;
        if (index >= bar_count) index = bar_count - 1;
        printf("%c", bars[index]);
    }
    printf("\n");
}

void draw_bar(int width, float percent, const char* color) {
    int filled = (int)(width * percent / 100.0f);
    printf("%s[", color);
    for (int i = 0; i < width; i++) {
        if (i < filled) printf("█");
        else printf(" ");
    }
    printf("] %.1f%%" COLOR_RESET "\n", percent);
}

#define CONFIG_FILE "sysmon_config.cfg"

typedef struct {
    int refresh_rate;          // 刷新频率（秒）
    int show_cpu_graph;       // 是否显示CPU使用率图
    int show_top_processes;   // 是否显示前N个进程
    int show_memory_graph;    // 是否显示内存使用率图
    int sort_by_memory;       // 进程排序方式（按内存或CPU）
    int color_enabled;        // 是否启用颜色输出
} Config;

Config config = {
    .refresh_rate = 2,
    .show_cpu_graph = 1,
    .show_top_processes = 1,
    .show_memory_graph = 1,
    .sort_by_memory = 0,
    .color_enabled = 1
};

void load_config() {
    FILE *fp = fopen(CONFIG_FILE, "r");
    if (!fp) return;  // 使用默认配置
    
    char line[128];
    while (fgets(line, sizeof(line), fp)) {
        if (strncmp(line, "refresh_rate=", 13) == 0) {
            config.refresh_rate = atoi(line + 13);
        } else if (strncmp(line, "show_cpu_graph=", 15) == 0) {
            config.show_cpu_graph = atoi(line + 15);
        } else if (strncmp(line, "show_top_processes=", 19) == 0) {
            config.show_top_processes = atoi(line + 19);
        } else if (strncmp(line, "show_memory_graph=", 18) == 0) {
            config.show_memory_graph = atoi(line + 18);
        } else if (strncmp(line, "sort_by_memory=", 15) == 0) {
            config.sort_by_memory = atoi(line + 15);
        } else if (strncmp(line, "color_enabled=", 14) == 0) {
            config.color_enabled = atoi(line + 14);
        }
    }
    fclose(fp);
}
void save_config() {
    FILE *fp = fopen(CONFIG_FILE, "w");
    if (!fp) return;
    
    fprintf(fp, "refresh_rate=%d\n", config.refresh_rate);
    fprintf(fp, "show_cpu_graph=%d\n", config.show_cpu_graph);
    fprintf(fp, "show_top_processes=%d\n", config.show_top_processes);
    fprintf(fp, "show_memory_graph=%d\n", config.show_memory_graph);
    fprintf(fp, "sort_by_memory=%d\n", config.sort_by_memory);
    fprintf(fp, "color_enabled=%d\n", config.color_enabled);
    
    fclose(fp);
}

int read_cpu_stats(CPUStat cpu[], int* count) {
    FILE* fp = fopen("/proc/stat", "r");
    if (!fp) return -1;
    
    char line[256];
    *count = 0;
    
    while (fgets(line, sizeof(line), fp)) {
        if (strncmp(line, "cpu", 3) == 0) {
            char cpu_label[16];
            long user, nice, system, idle, iowait, irq, softirq, steal, guest, guest_nice;
            int matched = sscanf(line, "%15s %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld",
                                 cpu_label, &user, &nice, &system, &idle,
                                 &iowait, &irq, &softirq, &steal, &guest, &guest_nice);
            
            if (matched < 5) continue; // 至少需要5个字段
            
            cpu[*count].idle = idle + iowait;
            cpu[*count].total = user + nice + system + idle + iowait + irq + softirq;
            
            if (matched >= 7) {
                cpu[*count].total += irq + softirq;
            }
            if (matched >= 8) {
                cpu[*count].total += steal;
            }
            if (matched >= 10) {
                cpu[*count].total += guest + guest_nice;
            }
            
            (*count)++;
        }
    }
    fclose(fp);
    return 0;
}

void show_cpu_usage(CPUStat* prev, CPUStat* curr, int cpu_count) {
    print_color(COLOR_BOLD COLOR_CYAN, "\nCPU Usage:\n");
    
    // 计算总CPU使用率
    long total_diff = curr[0].total - prev[0].total;
    long idle_diff = curr[0].idle - prev[0].idle;
    
    if (total_diff > 0) {
        float total_usage = 100.0f * (total_diff - idle_diff) / total_diff;
        print_color(COLOR_GREEN, "  Total: ");
        draw_bar(20, total_usage, total_usage > 80 ? COLOR_RED : 
                                         total_usage > 60 ? COLOR_YELLOW : COLOR_GREEN);
        
        // 添加到历史记录
        history.cpu_history[history.history_index] = total_usage;
        
        // 显示CPU历史图
        if (config.show_cpu_graph) {
            printf("  ");
            print_graph("History", history.cpu_history, HISTORY_SIZE, 100.0f);
        }
        
        // 显示每个核心的使用率
        for (int i = 1; i < cpu_count; i++) {
            long core_total_diff = curr[i].total - prev[i].total;
            long core_idle_diff = curr[i].idle - prev[i].idle;  
            if (core_total_diff > 0) {
                float core_usage = 100.0f * (core_total_diff - core_idle_diff) / core_total_diff;
                print_color(COLOR_GREEN, "  CPU%d: ", i - 1);
                draw_bar(15, core_usage, core_usage > 80 ? COLOR_RED : 
                                             core_usage > 60 ? COLOR_YELLOW : COLOR_GREEN);
            }
        }
    }
}

void show_memory() {
    FILE *fp = fopen("/proc/meminfo", "r");
    if (!fp) {
        print_color(COLOR_RED, "Error opening /proc/meminfo\n");
        return;
    }
    
    char key[64];
    long total = 0, free = 0, available = 0;
    long buffers = 0, cached = 0;
    long value;
    while (fscanf(fp, "%63s %ld kB", key, &value) == 2) {
        if (strcmp(key, "MemTotal:") == 0) total = value;
        else if (strcmp(key, "MemFree:") == 0) free = value;
        else if (strcmp(key, "MemAvailable:") == 0) available = value
        else if (strcmp(key, "Buffers:") == 0) buffers = value;
        else if (strcmp(key, "Cached:") == 0) cached = value;
        while (fgetc(fp) != '\n' && !feof(fp));
    }
    fclose(fp);
    
        // 添加到历史记录
    history.mem_history[history.history_index] = 100.0f * (total - free) / total;
    history.history_index = (history.history_index + 1) % HISTORY_SIZE;
    // 显示内存使用率图
    if (config.show_memory_graph) {
        printf("  ");
        print_graph("Memory History", history.mem_history, HISTORY_SIZE, 100.0f);
    }   


    if (total > 0) {
        long used = total - free;
        float used_percent = 100.0f * used / total;
        float used_mb = used / 1024.0f;
        float total_mb = total / 1024.0f;
        
        print_color(COLOR_BOLD COLOR_CYAN, "\nMemory Usage:\n");
        print_color(COLOR_GREEN, "  Used: ");
        
        draw_bar(20, used_percent, used_percent > 90 ? COLOR_RED : 
                                        used_percent > 80 ? COLOR_YELLOW : COLOR_GREEN);
        
        printf("  Space: %.1f/%.1f GB (%.1f%%)\n",
                used_mb / 1024.0f, total_mb / 1024.0f, used_percent);
    }

    // 交换空间
    fp = fopen("/proc/meminfo", "r");
    if (fp) {
        long swap_total = 0, swap_free = 0;
        while (fscanf(fp, "%63s %ld kB", key, &value) == 2) {
            if (strcmp(key, "SwapTotal:") == 0) swap_total = value;
            else if (strcmp(key, "SwapFree:") == 0) swap_free = value;
            while (fgetc(fp) != '\n' && !feof(fp));
        }
        fclose(fp);
        
        if (swap_total > 0) {
            float swap_used = swap_total - swap_free;
            float swap_percent = 100.0f * swap_used / swap_total;
            printf("  Swap: %.1f/%.1f GB (%.1f%%)\n",
                   swap_used / 1048576.0f, swap_total / 1048576.0f, swap_percent);
        }
    }

}

/* ================= 磁盘监控 ================= */
void show_disk() {
    struct statvfs fs;
    if (statvfs("/", &fs) != 0) {
        perror("statvfs");
        return;
    }
    
    unsigned long total = fs.f_blocks * fs.f_frsize;
    unsigned long free = fs.f_bfree * fs.f_frsize;
    unsigned long avail = fs.f_bavail * fs.f_frsize;
    
    float used_percent = 100.0f * (total - free) / total;
    float used_gb = (total - free) / 1e9;
    float total_gb = total / 1e9;
    
    print_color(COLOR_BOLD COLOR_CYAN, "\nDisk (/):\n");
    print_color(COLOR_GREEN, "  Used: ");
    
    draw_bar(20, used_percent, used_percent > 90 ? COLOR_RED : 
                                        used_percent > 80 ? COLOR_YELLOW : COLOR_GREEN);
    
    printf("  Space: %.1f/%.1f GB (%.1f%%)\n", used_gb, total_gb, used_percent);
    printf("  Available: %.1f GB | Inodes: %lu/%lu\n",
           avail / 1e9, fs.f_files - fs.f_ffree, fs.f_files);
}


void show_network() {
    static unsigned long long prev_rx = 0, prev_tx = 0;
    static time_t prev_time = 0;
    
    FILE *fp = fopen("/proc/net/dev", "r");
    if (!fp) {
        print_color(COLOR_RED, "Error opening /proc/net/dev\n");
        return;
    }
    
    char line[256];
    unsigned long long total_rx = 0, total_tx = 0;
    
    // 跳过前两行
    fgets(line, sizeof(line), fp);
    fgets(line, sizeof(line), fp);
    
    while (fgets(line, sizeof(line), fp)) {
        char iface[32];
        unsigned long long r, t;
        
        // 解析网络接口统计
        if (sscanf(line, "%31[^:]: %llu %*u %*u %*u %*u %*u %*u %*u %llu",
                   iface, &r, &t) == 3) {
            // 忽略lo回环接口
            if (strcmp(iface, "lo") != 0) {
                total_rx += r;
                total_tx += t;
            }
        }
    }
    fclose(fp);
    
    time_t now = time(NULL);
    double time_diff = difftime(now, prev_time);
    
    print_color(COLOR_BOLD COLOR_CYAN, "\nNetwork:\n");
    
    if (prev_time > 0 && time_diff > 0) {
        double rx_rate = (total_rx - prev_rx) / time_diff;
        double tx_rate = (total_tx - prev_tx) / time_diff;
        
        const char* rx_unit = "B/s";
        const char* tx_unit = "B/s";
        double rx_display = rx_rate;
        double tx_display = tx_rate;
        
        // 自动选择合适单位
        if (rx_rate > 1024*1024) {
            rx_display = rx_rate / (1024*1024);
            rx_unit = "MB/s";
        } else if (rx_rate > 1024) {
            rx_display = rx_rate / 1024;
            rx_unit = "KB/s";
        }
        
        if (tx_rate > 1024*1024) {
            tx_display = tx_rate / (1024*1024);
            tx_unit = "MB/s";
        }

    
        else if (tx_rate > 1024) {
            tx_display = tx_rate / 1024;
            tx_unit = "KB/s";
        }
        if (tx_rate > 1024*1024) {
            tx_display = tx_rate / (1024*1024);
            tx_unit = "MB/s";
        }
        printf("  RX: %.1f %s\n", rx_display, rx_unit);
        printf("  TX: %.1f %s\n", tx_display, tx_unit);
        printf("  Total RX: %.1f MB | Total TX: %.1f MB
\n",
               total_rx / (1024.0 * 1024.0), total_tx / (1024.0 * 1024.0));
    } else {
        printf("  RX: N/A\n");
        printf("  TX: N/A\n");
    }
    prev_rx = total_rx;
    prev_tx = total_tx;
    prev_time = now;
}

typedef struct {
    int pid;
    char name[64];
    char state;
    unsigned long vsize;  // 虚拟内存大小（字节）
    unsigned long vmrss;  // 常驻集大小（KB）
    float cpu_usage;      // CPU使用率
} ProcessInfo;


int get_process_info(int pid, ProcessInfo* proc) {
    char path[64];
    FILE* fp;
    char line[256];
    
    // 获取进程名称
    snprintf(path, sizeof(path), "/proc/%d/comm", pid);
    fp = fopen(path, "r");
    if (!fp) return 0;
    
    if (fgets(line, sizeof(line), fp)) {
        strncpy(proc->name, line, sizeof(proc->name) - 1);
        proc->name[sizeof(proc->name) - 1] = 0;
        // 去除换行符
        char* newline = strchr(proc->name, '\n');
        if (newline) *newline = 0;
    }
    fclose(fp);

    // 获取进程状态

    snprintf(path, sizeof(path), "/proc/%d/stat", pid);

    fp = fopen(path, "r");
    if (!fp) return 0;

    if (fgets(line, sizeof(line), fp)) {
        char state;
        unsigned long vsize;
        long rss;
        
        // 解析状态和虚拟内存大小
        sscanf(line, "%*d %*s %c %*d %*d %*d %*d %*d %*u %*u %*u %*u %*u %*u %*u %*d %*d %*d %*d %*d %*d %lu",
               &state, &vsize);
        
        // 获取RSS
        sscanf(line, "%*d %*s %*c %*d %*d %*d %*d %*d %*u %*u %*u %*u %*u %*u %*u %*d %*d %*d %*d %*d %ld",
               &rss);
        proc->state = state;
        proc->vsize = vsize;
        proc->vmrss = rss * sysconf(_SC_PAGESIZE) / 102
4;  // 转换为KB
    }
    fclose(fp);
    
    return 1;
}

int compare_process_memory(const void* a, const void* b) {
    const ProcessInfo* pa = (const ProcessInfo*)a;
    const ProcessInfo* pb = (const ProcessInfo*)b;
    if (pb->vmrss > pa->vmrss)
        return 1;
    else if (pb->vmrss < pa->vmrss)
        return -1;
    else
        return 0;
}


int compare_process_cpu(const void* a, const void* b) {
    const ProcessInfo* pa = (const ProcessInfo*)a;
    const ProcessInfo* pb = (const ProcessInfo*)b;
    if (pb->cpu_usage > pa->cpu_usage)
        return 1;
    else if (pb->cpu_usage < pa->cpu_usage)
        return -1;
    else
        return 0;
}

void show_processes() {
    ProcessInfo processes[MAX_PROCESSES];
    int count = 0;
    
    DIR* dir = opendir("/proc");
    if (!dir) {
        print_color(COLOR_RED, "Error opening /proc directory\n");
        return;
    }
    
    struct dirent* entry;
    while ((entry = readdir(dir)) && count < MAX_PROCESSES) {
        if (entry->d_type == DT_DIR && isdigit(entry->d_name[0
])) {
            int pid = atoi(entry->d_name);
            if (get_process_info(pid, &processes[count])) {
                count++;
            }
        }

    }
    closedir(dir);
    // 排序进程
    if (config.sort_by_memory) {
        qsort(processes, count, sizeof(ProcessInfo), compare_process_memory);
    } else {
        qsort(processes, count, sizeof(ProcessInfo), compare_process_cpu);
    }
    print_color(COLOR_BOLD COLOR_CYAN, "\nTop Processes:\n");
    print_color(COLOR_BOLD, "  PID     S     MEM%%      RSS(K
B)    Name\n");


    // 获取总内存用于计算百分比
    long total_mem = 0;
    FILE* fp = fopen("/proc/meminfo", "r");
    if (fp) {
        char key[64];
        long value;
        while (fscanf(fp, "%63s %ld kB", key, &value) == 2) {
            if (strcmp(key, "MemTotal:") == 0) {
                total_mem = value;
                break;
            }
        }
        fclose(fp);
    }
    int top = count < TOP_PROCESSES ? count : TOP_PROCESSES;
    for (int i = 0; i < top; i++) {
        ProcessInfo* p = &processes[i];
        float mem_percent = total_mem > 0 ? 100.0f * p->vmrss / total_mem : 0.0f;
        float mem_mb = p->vmrss / 1024.0f;
        const char* color;
        if (mem_percent > 80.0f) color = COLOR_RED;
        else if (mem_percent > 60.0f) color = COLOR_YELLOW;
        else color = COLOR_GREEN;
        printf("  %5d   %c   %6.2f%%   %10.1f   %s%s\n",
               p->pid, p->state, mem_percent, mem_mb, color, p->name);
    }

}

void show_system_info() {
    struct sysinfo info;
    if (sysinfo(&info) == 0) {
        print_color(COLOR_BOLD COLOR_CYAN, "\nSystem Information:\n");
        // 系统运行时间
        long uptime = info.uptime;
        int days = uptime / 86400;
        uptime %= 86400;
        int hours = uptime / 3600;
        uptime %= 3600;
        int minutes = uptime / 60;
        printf("  Uptime: %d days, %d hours, %d minutes\n
", days, hours, minutes);
        // 主机名
        char hostname[256];
        if (gethostname(hostname, sizeof(hostname)) == 0) {
            printf("  Hostname: %s\n", hostname);
        }
        // 操作系统和内核版本
        struct utsname uts;
        if (uname(&uts) == 0) {
            printf("  OS: %s %s\n", uts.sysname, uts.release);
        }
        // 当前登录用户数
        FILE* utmp = fopen("/var/run/utmp", "rb");
        int user_count = 0;
        if (utmp) {
            // 读取utmp文件
            struct {
                short ut_type;
                pid_t ut_pid;
                char ut_line[32];
                char ut_id[4];
                char ut_user[32];
                char ut_host[256];
                struct {
                    short e_termination;
                    short e_exit;
                } ut_exit;
                long ut_session;
                struct timeval ut_tv;
                int32_t ut_addr_v6[4];
                char __unused[20];
            } ut;
            while (fread(&ut, sizeof(ut), 1, utmp) ==
                     && user_count < 1000) {
                 if (ut.ut_type == 7) { // USER_PROCESS
                      user_count++;
                 }

            }
            fclose(utmp);
        }
        printf("  Logged-in Users: %d\n", user_count);
        // 平均负载
        printf("  Load Average: %.2f, %.2f, %.2f\n", info.loads[0]/65536.0, info.loads[1]/65536.0, info.loads[2]/65536.0);
        // 当前时间
        time_t now = time(NULL);
        struct tm *tm_info = localtime(&now);
        char time_str[64];
        strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", tm_info);
        printf("  Current Time: %s\n", time_str);
    } else {
        print_color(COLOR_RED, "Error getting system information\n");
    }
}
typedef struct {
    float cpu_history[HISTORY_SIZE];
    float mem_history[HISTORY_SIZE];
    int history_index;
} History;

History history = { .history_index = -1 };

void signal_handler(int signum) {
    exit_gracefully(signum);

}


void exit_gracefully(int signum) {
    running = 0;
    // 恢复终端设置
    system("stty echo icanon");
    printf("\n");
    print_color(COLOR_GREEN, "Monitor stopped. Configuration saved.\n");
    exit(0);
}

void show_help() {
    system("clear");
    print_color(COLOR_BOLD COLOR_CYAN, 
                "╔══════════════════════════════════════════════════════════╗\n");
    print_color(COLOR_BOLD COLOR_CYAN,
                "║               ADVANCED SYSTEM MONITOR HELP               ║\n");
    print_color(COLOR_BOLD COLOR_CYAN,
                "╚══════════════════════════════════════════════════════════╝\n");
    
    printf("\n");
    print_color(COLOR_BOLD, "Features:\n");
    printf("  - Real-time CPU, Memory, Disk, Network monitoring\n");
    printf("  - Top processes by CPU or Memory usage\n");
    printf("  - ASCII graphs for CPU and Memory usage history\n");
    printf("  - Color-coded output for easy status recognition\n");
    printf("  - Configurable refresh rate and display options\n");
    printf("\n");
    print_color(COLOR_BOLD, "Controls:\n");
    printf("  q: Quit the monitor\n");
    printf("  h: Show this help screen\n");
    printf("  s: Toggle sorting processes by Memory/CPU\n");
    printf("  c: Toggle CPU usage graph display\n");
    printf("  m: Toggle Memory usage graph display\n");
    printf("  +: Increase refresh speed\n");
    printf("  -: Decrease refresh speed\n");
    printf("  p: Pause the monitor\n");
    printf("\n");
    print_color(COLOR_BOLD, "Press any key to return to the monitor...\n");
    getchar();
}

void handle_input() {
    // 设置非阻塞输入
    struct timeval tv = {0, 0};
    fd_set readfds;
    FD_ZERO(&readfds);
    FD_SET(STDIN_FILENO, &readfds);
    
    if (select(STDIN_FILENO + 1, &readfds, NULL, NULL, &tv) > 0) {
        char ch = getchar();
        switch (ch) {
            case 'q':
            case 'Q':
                running = 0;
                break;
            case 'h':
            case 'H':
                show_help();
                break;
            case 's':
            case 'S':
                config.sort_by_memory = !config.sort_by_memory;
                break;
            case 'c':
            case 'C':
                config.show_cpu_graph = !config.show_cpu_graph;
                break;
            case 'm':
            case 'M':
                config.show_memory_graph = !config.show_memory_graph;
                break;
            case '+':
                if (config.refresh_rate > 1) config.refresh_rate--;
                break;
            case '-':
                config.refresh_rate++;
                break;
            case 'p':
            case 'P':
                // 暂停监控
                print_color(COLOR_YELLOW, "Monitoring paused. Press any key to resume...\n");
                getchar();
                break;
            default:
                break;
        }
    }
}

int main() {
    // 加载配置
    load_config();
    
    // 设置终端为非阻塞输入模式
    system("stty -echo -icanon");
    
    // 注册信号处理函数
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);

    // 初始化CPU状态数组
    int cpu_count = 0;
    CPUStat prev_cpu[32];
    CPUStat curr_cpu[32];
    read_cpu_stats(prev_cpu, &cpu_count);

    time_t last_save = time(NULL);

    while (running) {
        // 更新历史记录索引
        history.history_index = (history.history_index + 1) % HISTORY_SIZE;
        // 读取当前CPU状态
        read_cpu_stats(curr_cpu, &cpu_count);
        // 清屏
        system("clear");
        // 显示监控信息
        print_color(COLOR_BOLD COLOR_CYAN, 
                    "╔══════════════════════════════════════════════════════════╗\n");
        print_color(COLOR_BOLD COLOR_CYAN,
                    "║               ADVANCED SYSTEM MONITOR v1.0               ║\n");
        print_color(COLOR_BOLD COLOR_CYAN,
                    "╚══════════════════════════════════════════════════════════╝\n");
        // 显示当前时间和刷新率
        time_t now = time(NULL);
        struct tm *tm_info = localtime(&now);
        char time_str[64];
        strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", tm_info);
        printf(" Time: %s | Refresh Rate: %d sec\n", time_str,
                config.refresh_rate);   
        show_system_info();
        show_cpu_usage(prev_cpu, curr_cpu, cpu_count);
        show_memory();
        show_disk();
        show_network();
        if (config.show_top_processes) {
            show_processes();
        }
        // 更新前一个CPU状态
        memcpy(prev_cpu, curr_cpu, sizeof(CPUStat) * cpu_count);
        // 处理用户输入
        handle_input();
        // 定期保存配置
        if (difftime(time(NULL), last_save) >= 60) {
            save_config();
            last_save = time(NULL);
        }
        // 等待下次刷新
        sleep(config.refresh_rate);
    }
    // 恢复终端设置
    system("stty echo icanon");
    printf("\n");
    print_color(COLOR_GREEN, "Monitor stopped. Configuration saved.\n");
    // 保存配置
    save_config();
    return 0;
}

void print_color(const char* color, const char* format, ...) {
    va_list args;
    va_start(args, format);
    printf("%s", color);
    vprintf(format, args);
    printf(COLOR_RESET);
    va_end(args);
}


